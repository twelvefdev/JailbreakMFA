/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 *
 * Permission is hereby granted to any person obtaining a legal copy
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for
 * debugging, optimizing, or customizing applications created with
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// Spring movement
//
//----------------------------------------------------------------------------------
package Movements;

import Animations.CAnim;
import Banks.CImage;
import Extensions.CRunBox2DBase;
import Extensions.CRunBox2DBasePosAndAngle;
import Objects.CExtension;
import Objects.CObject;
import RunLoop.CRun;
import RunLoop.CRunMBase;
import Services.CBinaryFile;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Fixture;

public class CRunMvtbox2dspring extends CRunMBase
{
    public static final int SPFLAG_ACTIVE = 0x0001;
    public static final int SPFLAG_WORKING = 0x0002;
    public static final int SPFLAG_ROTATE = 0x0004;

    public CRunBox2DBase m_base;
    public float m_friction = 0;
    public float m_restitution = 0;
    public int m_shape = 0;
    public int m_flags = 0;
    public Fixture m_fixture = null;
    public float m_strength = 0;
    public CRunBox2DBasePosAndAngle m_posAndAngle = new CRunBox2DBasePosAndAngle();
    public int m_anim = 0;
    public int m_actionCounter = 0;
    public CRunMBase m_actionObject = null;
    public int m_imgWidth = 0;
    public int m_imgHeight = 0;
    public float m_scaleX = 1.0f;
    public float m_scaleY = 1.0f;
    public float m_previousAngle = -1;
    public boolean m_changed;
    public boolean m_started = false;

    // Build 283.3 increasing performance
    private CRunBox2DBase GetBase()
    {
        int nObjects = this.rh.rhNObjects;
        CObject[] localObjectList=this.rh.rhObjectList;
        for (CObject pObject : localObjectList)
        {
            if (pObject != null) {
            	--nObjects;
	            if(pObject.hoType>=32)
	            {
	                if (pObject.hoCommon.ocIdentifier == CRun.BASEIDENTIFIER)
	                {
	                    CRunBox2DBase pBase = (CRunBox2DBase)((CExtension)pObject).ext;
	                    if (pBase.identifier == this.m_identifier)
	                    {
	                        return pBase;
	                    }
	                }
	            }
            }
            if(nObjects==0)
            	break;
        }
        return null;
    }

    @Override
    public void initialize(CBinaryFile file)
    {
        file.skipBytes(1);
        this.m_angle = this.dirAtStart(file.readInt()) * 180.0f / 16.0f;
        this.m_currentAngle=this.m_angle;
        this.m_strength=file.readInt()/100.0f*10.0f;
        this.m_flags=file.readInt();
        this.m_shape=file.readShort();
        this.m_identifier=file.readInt();

        this.m_changed=false;
        this.m_anim= CAnim.ANIMID_STOP;
        this.m_actionCounter=0;
        this.m_actionObject=null;
        this.m_started = false;

        this.m_base=this.GetBase();
        this.m_body=null;
        this.InitBase(this.ho, CRunMBase.MTYPE_OBJECT);
    }

    @Override
    public void kill()
    {
        CRunBox2DBase pBase=this.GetBase();
        if (pBase!=null)
        {
            pBase.rDestroyBody(this.m_body);
        }
    }

    @Override
	public void SetCollidingObject(CRunMBase object)
    {
        if ((this.m_flags&CRunMvtbox2dspring.SPFLAG_ACTIVE)!=0 && object!=this)
        {
            if (object!=this.m_actionObject)
            {
                this.m_actionCounter=10;
                this.m_actionObject=object;
                Vector2 velocity=object.m_body.getLinearVelocity();
                double v=Math.sqrt(velocity.x*velocity.x+velocity.y*velocity.y);
                this.m_base.rBodyAddLinearVelocity(object.m_body, (float)(this.m_strength+v), (float)this.m_currentAngle);
                this.m_flags|=CRunMvtbox2dspring.SPFLAG_WORKING;
                this.m_anim=CAnim.ANIMID_WALK;
                this.ho.roa.raAnimForced=this.m_anim+1;
                this.ho.roa.raAnimRepeat=1;
                this.ho.roc.rcSpeed=50;
                this.animations(this.m_anim);
                this.ho.roc.rcSpeed=0;
            }
        }
    }

    @Override
    public Boolean CreateBody()
    {
        if (this.m_body!=null)
            return true;

        if (this.m_base==null)
        {
            this.m_base=this.GetBase();
            if (this.m_base == null)
                return false;
        }

        this.m_currentAngle = this.m_angle;
        float angle = this.m_angle;
        if ((this.m_flags & SPFLAG_ROTATE) == 0)
            angle = 0;
        this.m_body = this.m_base.rCreateBody(BodyDef.BodyType.StaticBody, this.ho.hoX, this.ho.hoY, angle, 0, this, 0, 0);
        if (this.ho.roa == null)
        {
            this.m_shape = 0;
            this.m_imgWidth = this.ho.hoImgWidth;
            this.m_imgHeight = this.ho.hoImgHeight;
        }
        else
        {
            if ((this.m_flags & SPFLAG_ROTATE) == 0)
            {
                this.ho.roc.rcDir = AngleToDir(this.m_currentAngle);
                this.animations(CAnim.ANIMID_STOP);
            }
            this.m_image = this.ho.roc.rcImage;
            CImage img = this.rh.rhApp.imageBank.getImageFromHandle(this.m_image);
            this.m_imgWidth = img.getWidth();
            this.m_imgHeight = img.getHeight();
        }
        this.CreateFixture();
        return true;
    }

    private void CreateFixture()
    {
        if (this.m_fixture != null)
        {
            this.m_body.destroyFixture(this.m_fixture);
        }
        this.m_scaleX = this.ho.roc.rcScaleX;
        this.m_scaleY = this.ho.roc.rcScaleY;
        switch (this.m_shape)
        {
            case 0:
                this.m_fixture = this.m_base.rBodyCreateBoxFixture(this.m_body, this, this.ho.hoX, this.ho.hoY, (int)(this.m_imgWidth * this.m_scaleX), (int)(this.m_imgHeight * this.m_scaleY), 0, this.m_friction, this.m_restitution);
                break;
            case 1:
                this.m_fixture = this.m_base.rBodyCreateCircleFixture(this.m_body, this, this.ho.hoX, this.ho.hoY, (int)((this.ho.hoImgWidth + this.ho.hoImgHeight) / 4 * (this.m_scaleX + this.m_scaleY) / 2), 0, this.m_friction, this.m_restitution);
                break;
            case 2:
                this.m_fixture = this.m_base.rBodyCreateShapeFixture(this.m_body, this, this.ho.hoX, this.ho.hoY, this.ho.roc.rcImage, 0, this.m_friction, this.m_restitution, this.m_scaleX, this.m_scaleY);
                break;
        }
    }

    @Override
    public boolean move()
    {
        if (!this.CreateBody() || this.m_base.isPaused())
            return false;

        // Scale changed?
        if (this.ho.roc.rcScaleX != this.m_scaleX || this.ho.roc.rcScaleY != this.m_scaleY)
            this.CreateFixture();

        if (this.m_actionCounter > 0)
        {
            this.m_actionCounter--;
            if (this.m_actionCounter == 0)
                this.m_actionObject = null;
        }

        this.m_base.rGetBodyPosition(this.m_body, this.m_posAndAngle);
        if (this.m_posAndAngle.x!=this.ho.hoX || this.m_posAndAngle.y!=this.ho.hoY)
        {
            this.ho.hoX=this.m_posAndAngle.x;
            this.ho.hoY=this.m_posAndAngle.y;
            this.m_started = true;
            this.ho.roc.rcChanged=true;
        }
        SetCurrentAngle(this.m_posAndAngle.angle);
        if ((this.m_flags&CRunMvtbox2dspring.SPFLAG_WORKING)!=0 && this.ho.roa != null)
        {
            if (this.ho.roa.raAnimOn!=CAnim.ANIMID_WALK || this.ho.roa.raAnimFrame>=this.ho.roa.raAnimNumberOfFrame)
            {
                this.m_flags&=~CRunMvtbox2dspring.SPFLAG_WORKING;
                this.m_anim=CAnim.ANIMID_STOP;
                this.ho.roa.raAnimForced=0;
                this.ho.roa.raAnimFrame=0;
            }
        }
        this.ho.roc.rcSpeed=50;
        this.animations(this.m_anim);
        this.ho.roc.rcSpeed=0;

        this.ho.roc.rcChanged|=this.m_changed;
        this.m_changed=false;

        return this.ho.roc.rcChanged;
    }
    private void SetCurrentAngle(float angle)
    {
        if ((this.m_flags & SPFLAG_ROTATE) !=0 )
        {
            if (angle!=this.m_previousAngle)
            {
                this.m_currentAngle = angle;
                this.m_previousAngle=angle;
                this.ho.roc.rcChanged=true;
                this.ho.roc.rcAngle=angle;
                this.ho.roc.rcDir=0;
            }
        }
    }
    @Override
    public void setAngle(float angle)
    {
        this.m_currentAngle = angle;
        this.m_base.rBodySetAngle(this.m_body, angle);
        if ((this.m_flags & SPFLAG_ROTATE) == 0)
            this.ho.roc.rcDir = AngleToDir(angle);
    }

    @Override
    public float getAngle()
    {
        if ((this.m_flags&SPFLAG_ROTATE)!=0)
        {
            double angle = this.m_currentAngle;
            while (angle >= 360.0)
                angle -= 360.0;
            while (angle < 0)
                angle += 360;
            return (float)angle;
        }
        return CRunMBase.ANGLE_MAGIC;
    }

    @Override
	public void stop(boolean bCurrent)
    {
        this.m_flags&=~CRunMvtbox2dspring.SPFLAG_ACTIVE;
    }

    @Override
	public void start()
    {
        this.m_flags|=CRunMvtbox2dspring.SPFLAG_ACTIVE;
    }

    @Override
	public void setSpeed(int speed)
    {
        this.m_strength=(float)(speed/100.0*30.0);
    }

    @Override
	public void setDir(int dir)
    {
        this.m_currentAngle = (float)(dir * 11.25);
        this.m_base.rBodySetAngle(this.m_body, (float)(dir * 11.25));
        if ((this.m_flags & SPFLAG_ROTATE) == 0)
            this.ho.roc.rcDir = dir;
    }

    @Override
	public int getDir()
    {
        if ((this.m_flags & CRunMvtbox2dspring.SPFLAG_ROTATE)!=0)
            return AngleToDir(this.m_currentAngle);
        else
            return this.ho.roc.rcDir;
    }

    @Override
	public int getSpeed()
    {
        return (int)(this.m_strength * 100.0 / 30.0);
    }


    @Override
    public void setPosition(int x, int y)
    {
        if (x!=this.ho.hoX || y!=this.ho.hoY)
        {
            if (!m_started)
            {
                this.ho.hoX = x;
                this.ho.hoY = y;
            }
            this.m_base.rBodySetPosition(this.m_body, x, y);
        }
    }
    @Override
    public void setXPosition(int x)
    {
        if (x!=this.ho.hoX)
        {
            if (!m_started)
                this.ho.hoX = x;
            this.m_base.rBodySetPosition(this.m_body, x, CRunBox2DBase.POSDEFAULT);
        }
    }
    @Override
    public void setYPosition(int y)
    {
        if (y!=this.ho.hoY)
        {
            if (!m_started)
                this.ho.hoY = y;
            this.m_base.rBodySetPosition(this.m_body, CRunBox2DBase.POSDEFAULT, y);
        }
    }
}
