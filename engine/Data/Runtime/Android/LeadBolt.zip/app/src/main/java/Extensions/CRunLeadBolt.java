/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import Actions.CActExtension;
import Application.CRunApp;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.Log;
import Runtime.MMFRuntime;
import Services.CBinaryFile;
import android.app.Activity;

import com.apptracker.android.listener.AppModuleListener;
import com.apptracker.android.track.AppTracker;

public class CRunLeadBolt extends CRunExtension
{
	// <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
	public static final int CNDADPROGRESS = 0;
	public static final int CNDADLOADED = 1;
	public static final int CNDADFAILED = 2;
	public static final int CNDADCLICKED = 3;
	public static final int CNDADCLOSED = 4;
	public static final int CNDADCOMPLETE = 5;
	public static final int CNDADALCOMP = 6;
	public static final int CNDADPAUSED = 7;
	public static final int CNDADRESUMED = 8;
	public static final int CNDAADPROGRESS = 9;
	public static final int CNDAADLOADED = 10;
	public static final int CNDAADFINISH = 11;
	public static final int CNDAADFAILED = 12;
	public static final int CNDAADCLOSED = 13;
	public static final int CNDAADCLICKED = 14;
	public static final int CNDNADPAUSED = 15;
	public static final int CNDNADRESUMED = 16;
	public static final int CNDONACTIVITY = 17;
	public static final int CNDADERROR = 18;
	public static final int CNDADCACHED = 19;
	public static final int CNDADAUDCACHED = 20;
	////////////////////////
	public static final int CNDNADLOADED = 21;
	public static final int CNDNADFAILED = 22;
	public static final int CNDNADCLICKED = 23;
	public static final int CNDNADCLOSED = 24;
	public static final int CNDNADCACHED = 25;
	public static final int CNDVADLOADED = 26;
	public static final int CNDVADFAILED = 27;
	public static final int CNDVADCLICKED = 28;
	public static final int CNDVADCLOSED = 29;
	public static final int CNDVADCACHED = 30;
	public static final int CNDVADWATCHED = 31;
	public static final int CND_LAST = 32;

	public static final int ACTSETTYPE = 0;
	public static final int ACTSETMARGIN = 1;
	public static final int ACTSETINTERVAL = 2;
	public static final int ACTLOADAD = 3;
	public static final int ACTPAUSEAD = 4;
	public static final int ACTRESUMEAD = 5;
	public static final int ACTDESTROYAD = 6;
	public static final int ACTSETINTERAUD = 7;
	public static final int ACTLOADAUDAD = 8;
	public static final int ACTLOADICOAD = 9;
	public static final int ACTSHOWLEGAL = 10;
	public static final int ACTNADPAUSE = 11;
	public static final int ACTNADRESUME = 12;
	public static final int ACTLOADADTOCACHE = 13;
	////////////////////////
	public static final int ACTLOADADS = 14;
	public static final int ACTCACHEADS = 15;
	public static final int ACTLOADVIDEO = 16;
	public static final int ACTCACHEVIDEO = 17;

	public static final int EXPERROR = 0;
	public static final int EXPLASTBANNER = 1;
	public static final int EXPLEGALACCEPTANCE = 2;
	////////////////////////
	public static final int EXPLOCATION = 3;
	// </editor-fold>

	private Activity activity = null;
	private int nError = 0;

	private boolean appEndOn = false;

	private String LB_APP_ID = null;
	private String Location;
	
	private CValue tmpValue;
	private static final String LOCATION_CODE		= "defaults";
	
	////////////////////////////////////////////////////////////////////////////////////////
	//
	//				             LeadBolt Listener
	//
	////////////////////////////////////////////////////////////////////////////////////////
	
	private AppModuleListener leadboltListener = new AppModuleListener() {

		@Override
		public void onModuleCached(String place) {
			final String placement = place;
			activity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Location = placement;
					if(Location.contentEquals("reward"))
						ho.pushEvent(CNDVADCACHED, 0);
					else
						ho.pushEvent(CNDNADCACHED, 0);
				}
			});
		}

		@Override
		public void onModuleClicked(String place) {
			final String placement = place;
			activity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Location = placement;
					if(Location.contentEquals("reward"))
						ho.pushEvent(CNDVADCLICKED, 0);
					else
						ho.pushEvent(CNDNADCLICKED, 0);
					SuspendAutoEnd();
				}
			});
		}

		@Override
		public void onModuleClosed(String place, boolean flag) {
			final String placement = place;
			final boolean viewDone = flag;
			activity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Location = placement;
					if(Location.contentEquals("reward"))
						ho.activityEvent(CNDVADCLOSED, 0);
					else
						ho.activityEvent(CNDNADCLOSED, 0);
					if(Location.contentEquals("reward") && viewDone) {
						ho.activityEvent(CNDVADWATCHED, 0);
					} else {
						Log.Log("User skipped watching rewarded video");
					}

				}
			});
		}

		@Override
		public void onModuleFailed(String place, String err, boolean cache) {
			final String placement = place;
			final String error = err;
			boolean isCache	= cache;		
			activity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Location = placement;
					if(Location.contentEquals("reward")) {
						ho.pushEvent(CNDVADFAILED, 0);
					} else {
						ho.pushEvent(CNDNADFAILED, 0);
					}
				}
			});
		}

		@Override
		public void onModuleLoaded(String place) {
			final String placement = place;
			activity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Location = placement;
					if(Location.contentEquals("reward"))
						ho.activityEvent(CNDVADLOADED, 0);
					else
						ho.activityEvent(CNDNADLOADED, 0);
				}
			});
			
		}


	};


	//////////////////////////////////////////////////////////////////////
	//
	//			Control functions
	//
	/////////////////////////////////////////////////////////////////////

	private void RestoreAutoEnd() {
		if(appEndOn) {
			appEndOn = false;
			MMFRuntime.inst.app.hdr2Options |= CRunApp.AH2OPT_AUTOEND;
		}
	}

	private void SuspendAutoEnd() {
		//AH2OPT_AUTOEND
		if (!appEndOn && MMFRuntime.inst.app != null && (MMFRuntime.inst.app.hdr2Options & CRunApp.AH2OPT_AUTOEND) != 0) {
			appEndOn = true;
			MMFRuntime.inst.app.hdr2Options &= ~ CRunApp.AH2OPT_AUTOEND;
		}
	}

	public CRunLeadBolt()
	{
		activity = MMFRuntime.inst;
		tmpValue = new CValue(0);
	}

	public @Override int getNumberOfConditions()
	{
		return CND_LAST;
	}

	public @Override boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
	{
    	file.bUnicode = true;
		file.readShort();
		file.readShort();
		file.readShort();
		file.readShort();
		file.readShort();
		LB_APP_ID 	= file.readString(33);

		Location = "";
		nError = 0;
		
		// Set the Leadbolt Event listener to get notified of different stages of the Ad life-cycle
		AppTracker.setModuleListener(leadboltListener);
		// Initialize Leadbolt SDK
		AppTracker.startSession(activity.getApplicationContext(), LB_APP_ID, true);
		//AppTracker.setAgeRange("18-25");

		return false;
	}

	public @Override void destroyRunObject(boolean bFast)
	{
		RestoreAutoEnd();
	}
	
	@Override
	public void onDestroy() {
		RestoreAutoEnd();
	}

	public @Override int handleRunObject()
	{
		return REFLAG_ONESHOT;
	}

	public @Override void continueRunObject()
	{
		if(MMFRuntime.inst.isScreenOn)
			RestoreAutoEnd();
		
		ho.pushEvent(CNDONACTIVITY, 0);
	}


	// Conditions
	// -------------------------------------------------
	public @Override boolean condition(int num, CCndExtension cnd)
	{
		switch (num)
		{
		case CNDADPROGRESS:
		case CNDADLOADED:
		case CNDADFAILED:
		case CNDADCLICKED:
		case CNDADCLOSED:
		case CNDADCOMPLETE:
		case CNDADALCOMP:
		case CNDADPAUSED:
		case CNDADRESUMED:
		case CNDAADPROGRESS:
		case CNDAADLOADED:
		case CNDAADFINISH:
		case CNDAADFAILED:
		case CNDAADCLOSED:
		case CNDAADCLICKED:
		case CNDNADPAUSED:
		case CNDNADRESUMED:
		case CNDONACTIVITY:
		case CNDADERROR:
		case CNDADCACHED:
		case CNDADAUDCACHED:
			return false;
	   	case CNDNADLOADED:
			return cndNatAdLoaded(cnd);
		case CNDNADFAILED:
			return cndNatAdFailed(cnd);
		case CNDNADCLICKED:
			return cndNatAdClicked(cnd);
		case CNDNADCLOSED:
			return cndNatAdClosed(cnd);
		case CNDNADCACHED:
			return cndNatAdCached(cnd);
		case CNDVADLOADED:
			return cndVideoLoaded(cnd);
		case CNDVADFAILED:
			return cndVideoFailed(cnd);
		case CNDVADCLICKED:
			return cndVideoClicked(cnd);
		case CNDVADCLOSED:
			return cndVideoClosed(cnd);
		case CNDVADCACHED:
			return cndVideoCached(cnd);
		case CNDVADWATCHED:
			return cndVideoWatched(cnd);
			
			
		}
		return false;
	}

	// Actions
	// -------------------------------------------------
	public @Override void action(int num, CActExtension act)
	{
		switch (num)
		{
		case ACTSETTYPE:
		case ACTSETMARGIN:
		case ACTSETINTERVAL:
		case ACTLOADAD:
		case ACTPAUSEAD:
		case ACTRESUMEAD:
		case ACTDESTROYAD:
		case ACTSETINTERAUD:
		case ACTLOADAUDAD:
		case ACTLOADICOAD:
		case ACTSHOWLEGAL:
		case ACTNADPAUSE:
		case ACTNADRESUME:
		case ACTLOADADTOCACHE:
			break;
		case ACTLOADADS:
			actLoadAds(act);
			break;
		case ACTCACHEADS:
			actCacheAds(act);
			break;
		case ACTLOADVIDEO:
			actLoadVideo(act);
			break;
		case ACTCACHEVIDEO:
			actCacheVideo(act);
			break;
		}
	}

	// Expressions
	// -------------------------------------------------
	public @Override CValue expression(int num)
	{
		switch (num)
		{
		case EXPERROR:
			return expError();
		case EXPLASTBANNER:
			return expLastbanner();
		case EXPLEGALACCEPTANCE:
			return expLegalAcceptance();
		case EXPLOCATION:
			return expLocation();
		}
		return null;
	}


	//////////////////////////////////////////////////////////////////////
	//
	//			Conditions
	//
	/////////////////////////////////////////////////////////////////////

	private boolean cndNatAdLoaded(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(Location != null && param0.contentEquals(Location))
			return true;

		return false;
	}

	private boolean cndNatAdFailed(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(Location != null && param0.contentEquals(Location))
			return true;

		return false;
	}

	private boolean cndNatAdClicked(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(Location != null && param0.contentEquals(Location))
			return true;

		return false;
	}

	private boolean cndNatAdClosed(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(Location != null && param0.contentEquals(Location))
			return true;

		return false;
	}

	private boolean cndNatAdCached(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(Location != null && param0.contentEquals(Location))
			return true;

		return false;
	}

	private boolean cndVideoLoaded(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndVideoFailed(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndVideoClicked(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndVideoClosed(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndVideoCached(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndVideoWatched(CCndExtension cnd)
	{
		return true;
	}

	//////////////////////////////////////////////////////////////////////
	//
	//			Actions
	//
	/////////////////////////////////////////////////////////////////////  

	private void actLoadAds(CActExtension act)
	{
		String param0 = act.getParamExpString(rh, 0);
		
		if(param0.length() == 0)
			Location = LOCATION_CODE;
		else
			Location = param0;

		SuspendAutoEnd();
        AppTracker.loadModule(activity.getApplicationContext(),Location);        
	}

	private void actCacheAds(CActExtension act)
	{
		String param0 = act.getParamExpString(rh, 0);
		
		if(param0.length() == 0)
			Location = LOCATION_CODE;
		else
			Location = param0;
		
		AppTracker.destroyModule();
		AppTracker.loadModuleToCache(activity.getApplicationContext(),Location);        
 	}

	private void actLoadVideo(CActExtension act)
	{
		SuspendAutoEnd();
        AppTracker.loadModule(activity.getApplicationContext(), "reward");
	}

	private void actCacheVideo(CActExtension act)
	{
		AppTracker.destroyModule();
		AppTracker.loadModuleToCache(activity.getApplicationContext(), "reward");
	}
	
	//////////////////////////////////////////////////////////////////////
	//
	//			Expressions
	//
	/////////////////////////////////////////////////////////////////////

	private CValue expError()
	{
		tmpValue.forceInt(nError);
		return tmpValue;
	}

	private CValue expLastbanner()
	{
		tmpValue.forceInt(0);
		return tmpValue;
	}

	private CValue expLegalAcceptance()
	{
		tmpValue.forceInt(0);
		return tmpValue;
	}
	
	private CValue expLocation()
	{
		tmpValue.forceString(Location);
		return tmpValue;
	}
	

}

