/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 * 
 *   Updated 11/28/2016 for version 6.6.1
 */
package Extensions;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;

//Import the Chartboost SDK
import com.chartboost.sdk.CBLocation;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.ChartboostDelegate;
import com.chartboost.sdk.InPlay.CBInPlay;
import com.chartboost.sdk.Libraries.CBLogging.Level;
import com.chartboost.sdk.Model.CBError.CBClickError;
import com.chartboost.sdk.Model.CBError.CBImpressionError;

import Actions.CActExtension;
import Application.CRunApp;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.Log;
import Runtime.MMFRuntime;
import Services.CBinaryFile;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;


public class CRunChartBoost extends CRunExtension
{
	// <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
	public static final int CNDINTOK = 0;
	public static final int CNDINTFAIL = 1;
	public static final int CNDINTCACHED = 2;
	public static final int CNDINTDISMISS = 3;
	public static final int CNDINTCLOSE = 4;
	public static final int CNDINTCLICK = 5;
	public static final int CNDAPPSOK = 6;
	public static final int CNDAPPSFAIL = 7;
	public static final int CNDAPPSCACHED = 8;
	public static final int CNDAPPSDISMISS = 9;
	public static final int CNDAPPSCLOSE = 10;
	public static final int CNDAPPSCLICK = 11;
	public static final int CNDONACTIVITY = 12;
	public static final int CNDVIDOK = 13;
	public static final int CNDVIDFAIL = 14;
	public static final int CNDVIDCACHED = 15;
	public static final int CNDVIDDISMISS = 16;
	public static final int CNDVIDCOMPLETE = 17;
	public static final int CNDVIDCLOSE = 18;
	public static final int CNDVIDCLICK = 19;
	public static final int CNDVIDWILL = 20;
	public static final int CNDINPLAYFAIL = 21;
	public static final int CNDINPLAYCACHED = 22;
	public static final int CNDPAUSECLICK = 23;
	public static final int CND_LAST = 24;

	public static final int ACTSHOWINT = 0;
	public static final int ACTCACHEINT = 1;
	public static final int ACTSHOWAPPS = 2;
	public static final int ACTCACHEAPPS = 3;
	public static final int ACTCLEARCACHE = 4;
	public static final int ACTTRACKRESET = 5;
	public static final int ACTTRACKINT = 6;
	public static final int ACTTRACKSTR = 7;
	public static final int ACTTRACKEVENT = 8;
	public static final int ACTPURRESET = 9;
	public static final int ACTPURINT = 10;
	public static final int ACTPURSTR = 11;
	public static final int ACTPURCHASE = 12;
	public static final int ACTSHOWNOINT = 13;
	public static final int ACTDISPINT = 14;
	public static final int ACTREQINT = 15;
	public static final int ACTDISPAPPS = 16;
	public static final int ACTREQAPPS = 17;
	public static final int ACTSHOWVID = 18;
	public static final int ACTCACHEVID = 19;
	public static final int ACTCLICKPLAY = 20;
	public static final int ACTCACHEPLAY = 21;
	public static final int ACTDISPVID = 22;
	public static final int ACTPAUSECLICK = 23;
	public static final int ACTDISMISSADS = 24;
    public static final int ACTSETGDPR = 25;

	public static final int EXPERROR = 0;
	public static final int EXPLASTCACHE = 1;
	public static final int EXPDISPINT = 2;
	public static final int EXPREQINT = 3;
	public static final int EXPDISPAPPS = 4;
	public static final int EXPREQAPPS = 5;
	public static final int EXPGETREWARD = 6;
	public static final int EXPDISPVIDEO = 7;
	public static final int EXPERRORSTR = 8;

	public static final int DEL_CNDINTFAIL = 1;
	public static final int DEL_CNDINTCACHED = 2;
	public static final int DEL_CNDINTDISMISS = 4;
	public static final int DEL_CNDINTCLOSE = 8;
	public static final int DEL_CNDINTCLICK = 16;
	public static final int DEL_CNDAPPSOK = 32;
	public static final int DEL_CNDAPPSFAIL = 64;
	public static final int DEL_CNDAPPSCACHED = 128;
	public static final int DEL_CNDAPPSDISMISS = 256;
	public static final int DEL_CNDAPPSCLOSE = 512;
	public static final int DEL_CNDAPPSCLICK = 1024;
	public static final int DEL_CNDONACTIVITY = 2048;
	public static final int DEL_CNDVIDOK = 4096;
	public static final int DEL_CNDVIDFAIL = 8192;
	public static final int DEL_CNDVIDCACHED = 16384;
	public static final int DEL_CNDVIDDISMISS = 32768;
	public static final int DEL_CNDVIDCOMPLETE = 65536;
	public static final int DEL_CNDVIDCLOSE = 131072;
	public static final int DEL_CNDVIDCLICK = 262144;
	public static final int DEL_CNDVIDWILL = 524288;
	public static final int DEL_CNDINPLAYFAIL = 1048576;
	public static final int DEL_CNDINPLAYCACHED = 2097152;
	public static final int DEL_CNDPAUSECLICK = 4194304;
	public static final int DEL_CNDINTOK = 8388608;

	public static final int DEL_DEFAULT = 0;

	private int delegate_answer = DEL_DEFAULT;

	// </editor-fold>
    public static final int GDPR_ON = 0x0001;
    public static final int OPT_PERM= 0x0002;

    private boolean cb;

	private Activity activity = null;


	private boolean cbRequestInterstitial = true;
	private boolean cbRequestMoreApps     = true;

	private boolean cbDisplayInterstitial = true;
	private boolean cbDisplayMoreApps     = true;
	private boolean cbDisplayRewVideo     = true;

	private boolean cbInFirstSession      = true;

	private boolean cbInPause;

	private int nError = 0;
	private String Error="";
	private int Rewarded;
	private boolean cbOnPause = false;
	private String lastLocation = CBLocation.LOCATION_DEFAULT;
	private String Location = CBLocation.LOCATION_DEFAULT;

	private boolean appEndOn = false;

	private String appId = null;
	private String appSignature = null;
	private boolean restrictGDPR;
    // In Play
    private ImageButton inPlayIcon;
    private ImageButton inPlayCloseButton;
    private RelativeLayout inPlayAd;
    private boolean inPlayShowing = false;

	private static int PERMISSIONS_CHARTBOOST_REQUEST = 19977898;
	private HashMap<String, String> permissionsApi23;
	private boolean enabled_perms;
    private boolean api23_started;
  
    private CValue expRet;
    
	private void RestoreAutoEnd() {
		if(appEndOn) {
			appEndOn = false;
			MMFRuntime.inst.app.hdr2Options |= CRunApp.AH2OPT_AUTOEND;
		}
	}

	private void SuspendAutoEnd() {
		//AH2OPT_AUTOEND
		if (!appEndOn && MMFRuntime.inst.app != null && (MMFRuntime.inst.app.hdr2Options & CRunApp.AH2OPT_AUTOEND) != 0) {
			appEndOn = true;
			MMFRuntime.inst.app.hdr2Options &= ~ CRunApp.AH2OPT_AUTOEND;
		}
	}

	private ChartboostDelegate chartBoostDelegate = new ChartboostDelegate() {

		/*
		 * shouldRequestInterstitialsInFirstSession()
		 *
		 * Return false if the user should not request interstitials until the 2nd startSession()
		 * 
		 */
		//@Override
		//public boolean shouldRequestInterstitialsInFirstSession() {
		//	return cbInFirstSession;
		//}

		/* 
		 * shouldDisplayInterstitial(String location)
		 *
		 * This is used to control when an interstitial should or should not be displayed
		 * If you should not display an interstitial, return false
		 */
		@Override
		public boolean shouldDisplayInterstitial(String location) {
			return cbDisplayInterstitial;
		}

		/*
		 * shouldRequestInterstitial(String location)
		 * 
		 * This is used to control when an interstitial should or should not be requested
		 * If you should not request an interstitial from the server, return false
		 *
		 */
		@Override
		public boolean shouldRequestInterstitial(String location) {
			return cbRequestInterstitial;
		}

		/*
		 * didCacheInterstitial(String location)
		 * 
		 * Passes in the location name that has successfully been cached
		 */
		@Override
		public void didCacheInterstitial(String location) {
			lastLocation = location;
			ho.pushEvent(CNDINTCACHED, 0);
		}

		/*
		 * didFailToLoadInterstitial(String location)
		 * 
		 * This is called when an interstitial has failed to load for any reason
		 * 
		 */
		@Override
		public void didFailToLoadInterstitial(String location, CBImpressionError error) {
			Error = error.name();
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDINTFAIL;
			else
				ho.pushEvent(CNDINTFAIL, 0);
		}

		/*
		 * didDismissInterstitial(String location)
		 *
		 * This is called when an interstitial is dismissed
		 *
		 */
		@Override
		public void didDismissInterstitial(String location) {

			// Immediately re-caches an interstitial
			// not anymore it is fast now
			//Chartboost.cacheInterstitial(location);
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDINTDISMISS;
			else
				ho.pushEvent(CNDINTDISMISS, 0);
		}

		/*
		 * didCloseInterstitial(String location)
		 *
		 * This is called when an interstitial is closed
		 *
		 */
		@Override
		public void didCloseInterstitial(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDINTCLOSE;
			else
				ho.pushEvent(CNDINTCLOSE, 0);
		}

		/*
		 * didClickInterstitial(String location)
		 *
		 * This is called when an interstitial is clicked
		 *
		 */
		@Override
		public void didClickInterstitial(String location) {
			lastLocation = location;
			if(Chartboost.hasInterstitial(location) && !cbInPause)
				SuspendAutoEnd();
			if(cbOnPause)
				delegate_answer |= DEL_CNDINTCLICK;
			else
				ho.pushEvent(CNDINTCLICK, 0);
		}

		/*
		 * didShowInterstitial(String location)
		 *
		 * This is called when an interstitial has been successfully shown
		 *
		 */
		@Override
		public void didDisplayInterstitial(String location) {
			lastLocation = location;
			SuspendAutoEnd();
			if(cbOnPause)
				delegate_answer |= DEL_CNDINTOK;
			else
				ho.pushEvent(CNDINTOK, 0);
		}

		/*
		 * More Apps delegate methods
		 */

		/*
		 * shouldDisplayLoadingViewForMoreApps()
		 *
		 * Return false to prevent the pretty More-Apps loading screen
		 *
		 */
		//@Override
		//public boolean shouldDisplayLoadingViewForMoreApps(String location) {
		//	return true;
		//}

		/*
		 * shouldRequestMoreApps()
		 * 
		 * Return false to prevent a More-Apps page request
		 *
		 * Is fired on:
		 * - cacheMoreApps()
		 * - showMoreApps() if no More-Apps page is cached
		 */
		@Override
		public boolean shouldRequestMoreApps(String location) {
			return cbRequestMoreApps;
		}

		/*
		 * shouldDisplayMoreApps()
		 * 
		 * Return false to prevent the More-Apps page from displaying
		 *
		 */
		@Override
		public boolean shouldDisplayMoreApps(String location) {
			return cbDisplayMoreApps;
		}

		/*
		 * didFailToLoadMoreApps()
		 * 
		 * This is called when the More-Apps page has failed to load for any reason
		 * 
		 */
		@Override
		public void didFailToLoadMoreApps(String location, CBImpressionError error) {
			Error = error.name();
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDAPPSFAIL;
			else
				ho.pushEvent(CNDAPPSFAIL, 0);
		}

		/*
		 * didCacheMoreApps(String location)
		 * 
		 */
		@Override
		public void didCacheMoreApps(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDAPPSCACHED;
			else
				ho.pushEvent(CNDAPPSCACHED, 0);
		}

		/*
		 * didDismissMoreApps()
		 *
		 * This is called when the More-Apps page is dismissed
		 *
		 */
		@Override
		public void didDismissMoreApps(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDAPPSDISMISS;
			else
				ho.pushEvent(CNDAPPSDISMISS, 0);
		}

		/*
		 * didCloseMoreApps()
		 *
		 * This is called when the More-Apps page is closed
		 *
		 */
		@Override
		public void didCloseMoreApps(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDAPPSCLOSE;
			else
				ho.pushEvent(CNDAPPSCLOSE, 0);
		}

		/*
		 * didClickMoreApps()
		 *
		 * This is called when the More-Apps page is clicked
		 *
		 */
		@Override
		public void didClickMoreApps(String location) {
			lastLocation = location;
			if(Chartboost.hasMoreApps(location) && !cbInPause)
				SuspendAutoEnd();
			if(cbOnPause)
				delegate_answer |= DEL_CNDAPPSCLICK;
			else
				ho.pushEvent(CNDAPPSCLICK, 0);
		}

		/*
		 * didShowMoreApps()
		 *
		 * This is called when the More-Apps page has been successfully shown
		 *
		 */
		@Override
		public void didDisplayMoreApps(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDAPPSOK;
			else
				ho.pushEvent(CNDAPPSOK, 0);
		}

		@Override
		public void didFailToRecordClick(String uri, CBClickError error) {
			Error = error.name();
			if(cbOnPause)			
				delegate_answer |= DEL_CNDINTFAIL;
			else
				ho.pushEvent(CNDINTFAIL, 0);
		}

		/*
		 * shouldDisplayRewardedVideo()
		 *
		 * This is called when the More-Apps page has been successfully shown
		 *
		 */		
		@Override
		public boolean shouldDisplayRewardedVideo(String location) {
			return cbDisplayRewVideo;
		}

		/*
		 * didCacheRewardedVideo(String location)
		 *
		 * This is called when the More-Apps page has been successfully shown
		 *
		 */		
		@Override
		public void didCacheRewardedVideo(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDVIDCACHED;
			else
				ho.pushEvent(CNDVIDCACHED, 0);
		}

		@Override
		public void didFailToLoadRewardedVideo(String location,	CBImpressionError error) {
			Error = error.name();
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDVIDFAIL;
			else
				ho.pushEvent(CNDVIDFAIL, 0);
		}

		@Override
		public void didDismissRewardedVideo(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDVIDDISMISS;
			else
				ho.pushEvent(CNDVIDDISMISS, 0);
		}

		@Override
		public void didCloseRewardedVideo(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDVIDCLOSE;
			else
				ho.pushEvent(CNDVIDCLOSE, 0);
		}

		@Override
		public void didClickRewardedVideo(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDVIDCLICK;
			else
				ho.pushEvent(CNDVIDCLICK, 0);
		}

		@Override
		public void didCompleteRewardedVideo(String location, int reward) {
			lastLocation = location;
			Rewarded = reward;
			if(cbOnPause)
				delegate_answer |= DEL_CNDVIDCOMPLETE;
			else
				ho.pushEvent(CNDVIDCOMPLETE, 0);
		}

		@Override
		public void didDisplayRewardedVideo(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDVIDOK;
			else
				ho.pushEvent(CNDVIDOK, 0);
		}

		@Override
		public void willDisplayVideo(String location) {
			SuspendAutoEnd();
			lastLocation = location;
			Rewarded = 0;
			if(cbOnPause)
				delegate_answer |= DEL_CNDVIDWILL;
			else
				ho.pushEvent(CNDVIDWILL, 0);
		}

		@Override
		public void didCacheInPlay(String location) {
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDINPLAYCACHED;
			else
				ho.pushEvent(CNDINPLAYCACHED, 0);
		}

		@Override
		public void didFailToLoadInPlay(String location, CBImpressionError error) {
			Error = error.name();
			lastLocation = location;
			if(cbOnPause)
				delegate_answer |= DEL_CNDINPLAYFAIL;
			else
				ho.pushEvent(CNDINPLAYFAIL, 0);
		}

		//removed from sdk in version 6.6.1
		// Check for age gate confirmation
		/*
		@Override
		public void didPauseClickForConfirmation() {
			if(cbOnPause)
				delegate_answer |= DEL_CNDPAUSECLICK;
			else
				ho.pushEvent(CNDPAUSECLICK, 0);
		}
		*/
		@Override
		public void didInitialize() {
			cb = true;
		}
	};

	private void clearError() {
		nError = 0;
		Error ="";
	}
	private void CreateCB() { 
		try {
			Chartboost.restrictDataCollection(activity.getApplicationContext(), restrictGDPR );
			Chartboost.startWithAppId(activity, appId, appSignature);
	        Chartboost.setActivityCallbacks(false);
	        Chartboost.setShouldRequestInterstitialsInFirstSession(true);
	        Chartboost.setShouldPrefetchVideoContent(true);
	        Log.Log("SDK version:"+Chartboost.getSDKVersion());
			Chartboost.setLoggingLevel(Level.ALL);
			Chartboost.setDelegate(chartBoostDelegate);
			//removed from sdk in version 6.6.1
			//Chartboost.setImpressionsUseActivities(true);
			//Chartboost.setShouldPauseClickForConfirmation(cbInPause);
			Chartboost.onCreate(activity);
			Chartboost.onStart(activity);
			cb = true;
		} catch (Exception e) {
			cb = false;
			nError = 1;
			Error = "Chartboost not initialized";			
		}
				
	}

    public  void destroyCB()
    {
        if(cb) {
            Chartboost.onDestroy(activity);
            Chartboost.startWithAppId(null, "", "");
        }
    }

	//////////////////////////////////////////////////////////////////////////
	//
	//			Chartboost 
	//
	/////////////////////////////////////////////////////////////////////////
	public CRunChartBoost()
	{
		activity = MMFRuntime.inst;		
		expRet = new CValue(0);
	}

	public @Override int getNumberOfConditions()
	{
		return CND_LAST;
	}

	@Override 
	public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
	{
		file.bUnicode = true;
		file.readShort();
		file.readShort();
		file.readShort();
		file.readShort();
		int flags1 = 0;
		int flags2 = 0;
        restrictGDPR = true;
		if(version > 3 )
        {
            flags1 = file.readInt();
            flags2 = file.readInt();
            if((flags1 & GDPR_ON) != 0)
                restrictGDPR = true;
            else
                restrictGDPR = false;
        }
		appId = file.readString(37);
		appSignature = file.readString(49);


		appId = appId.replaceAll("[\\r\\n ]", "");

		appSignature = appSignature.replaceAll("[\\r\\n ]", "");

		Rewarded = 0;

		activity = MMFRuntime.inst;
		
		cbInPause = false;
		cb = false;

        enabled_perms = false;
        if((flags1 & OPT_PERM) != 0) {
            if (MMFRuntime.deviceApi > 22) {
                permissionsApi23 = new HashMap<String, String>();
                permissionsApi23.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, "Write Storage");
                permissionsApi23.put(Manifest.permission.READ_PHONE_STATE, "Read Phone State");
                if (!MMFRuntime.inst.verifyOkPermissionsApi23(permissionsApi23))
                    MMFRuntime.inst.pushForPermissions(permissionsApi23, PERMISSIONS_CHARTBOOST_REQUEST);
                else
                    enabled_perms = true;
            } else
                enabled_perms = true;
        }

		CreateCB();
		clearError();

		try {
			classLayout = Class.forName(MMFRuntime.inst.getPackageName()+".R$layout");
		} catch (ClassNotFoundException e) {
			Log.Log("UtiDlg "+e.toString());
		}
		
		try {
			classIDs = Class.forName(MMFRuntime.inst.getPackageName()+".R$id");
		} catch (ClassNotFoundException e) {
			Log.Log("UtiDlg "+e.toString());
		}

		return false;
	}

	@Override
	public  void destroyRunObject(boolean bFast)
	{
		//destroyCB();
		RestoreAutoEnd();
	}

	@Override
	public int handleRunObject()
	{
		if(MMFRuntime.inst != null) {
			MMFRuntime.inst.askForPermissionsApi23();		
		}
		return REFLAG_ONESHOT;
	}	

	public @Override void pauseRunObject()
	{
		if(cb)
			Chartboost.onPause(activity);
		cbOnPause = true;
	}
	public @Override void continueRunObject()
	{

		if(MMFRuntime.inst.isScreenOn)
			RestoreAutoEnd();

		ho.pushEvent(CNDONACTIVITY, 0);

		checkdelegate();

		if(cb)
			Chartboost.onResume(activity);
		cbOnPause = false;

	}

	public @Override void onStart()
	{
		if(activity != null)
			Chartboost.onStart(activity);
	}

	public @Override void onStop() {
		if(activity != null)
			Chartboost.onStop(activity);
	}

	public @Override boolean onBackPressed() {
		if (cb && Chartboost.onBackPressed())
			return false;
		// Follow the BackPressed to main activity
		return true;
	}

	public @Override void onDestroy() {
		if(activity != null)
			Chartboost.onDestroy(activity);

		//if(trackData != null) {
		//	trackData.clear();
		//	trackData = null; 
		//}

		//if(purchaseData != null) {
		//	purchaseData.clear();
		//	purchaseData = null;
		//}

	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults, List<Integer> permissionsReturned) {
		if(permissionsReturned.contains(PERMISSIONS_CHARTBOOST_REQUEST)) {
			enabled_perms = verifyResponseApi23(permissions, permissionsApi23);
		}
		else
			enabled_perms = false;
	}


	// Conditions
	// -------------------------------------------------
	public @Override boolean condition(int num, CCndExtension cnd)
	{
		switch (num)
		{
		case CNDINTOK:
			return cndIntOk(cnd);
		case CNDINTFAIL:
			return cndIntFail(cnd);
		case CNDINTCACHED:
			return cndIntCached(cnd);
		case CNDINTDISMISS:
			return cndIntDismiss(cnd);
		case CNDINTCLOSE:
			return cndIntClose(cnd);
		case CNDINTCLICK:
			return cndIntClick(cnd);
		case CNDAPPSOK:
			return cndAppsOk(cnd);
		case CNDAPPSFAIL:
			return cndAppsFail(cnd);
		case CNDAPPSCACHED:
			return cndAppsCached(cnd);
		case CNDAPPSDISMISS:
			return cndAppsDismiss(cnd);
		case CNDAPPSCLOSE:
			return cndAppsClose(cnd);
		case CNDAPPSCLICK:
			return cndAppsClick(cnd);
		case CNDONACTIVITY:
			return cndOnActivity(cnd);
		case CNDVIDOK:
			return cndVidOk(cnd);
		case CNDVIDFAIL:
			return cndVidFail(cnd);
		case CNDVIDCACHED:
			return cndVidCached(cnd);
		case CNDVIDDISMISS:
			return cndVidDismiss(cnd);
		case CNDVIDCOMPLETE:
			return cndVidComplete(cnd);
		case CNDVIDCLOSE:
			return cndVidClose(cnd);
		case CNDVIDCLICK:
			return cndVidClick(cnd);
		case CNDVIDWILL:
			return cndVidWill(cnd);
		case CNDINPLAYFAIL:
			return cndInPlayFail(cnd);
		case CNDINPLAYCACHED:
			return cndInPlayCached(cnd);
		case CNDPAUSECLICK:
			return cndPauseClickConfirmation(cnd);
		}
		return false;
	}

	// Actions
	// -------------------------------------------------
	public @Override void action(int num, CActExtension act)
	{
		switch (num)
		{
		case ACTSHOWINT:
			actShowInt(act);
			break;
		case ACTCACHEINT:
			actCacheInt(act);
			break;
		case ACTSHOWAPPS:
			actShowApps(act);
			break;
		case ACTCACHEAPPS:
			actCacheApps(act);
			break;
		case ACTCLEARCACHE:
			actClearCache(act);
			break;
		case ACTTRACKRESET:
			actTrackReset(act);
			break;
		case ACTTRACKINT:
			actTrackInt(act);
			break;
		case ACTTRACKSTR:
			actTrackStr(act);
			break;
		case ACTTRACKEVENT:
			actTrackEvent(act);
			break;
		case ACTPURRESET:
			actPurReset(act);
			break;
		case ACTPURINT:
			actPurInt(act);
			break;
		case ACTPURSTR:
			actPurStr(act);
			break;
		case ACTPURCHASE:
			actPurchase(act);
			break;
		case ACTSHOWNOINT:
			actShowNOInt(act);
			break;
		case ACTDISPINT:
			actDispInt(act);
			break;
		case ACTREQINT:
			actReqInt(act);
			break;
		case ACTDISPAPPS:
			actDispApps(act);
			break;
		case ACTREQAPPS:
			actReqApps(act);
			break;
		case ACTSHOWVID:
			actShowVideo(act);
			break;
		case ACTCACHEVID:
			actCacheVideo(act);
			break;
		case ACTCLICKPLAY:
			actClickInPlay(act);
			break;
		case ACTCACHEPLAY:
			actCacheInPlay(act);
			break;
		case ACTDISPVID:
			actDispVideo(act);
			break;
		case ACTPAUSECLICK:
			actPauseClick(act);
			break;
		case ACTDISMISSADS:
			actDismissAds(act);
			break;
		case ACTSETGDPR:
            actSetGDPR(act);
            break;
		}
	}

	// Expressions
	// -------------------------------------------------
	public @Override CValue expression(int num)
	{
		switch (num)
		{
		case EXPERROR:
			return expError();
		case EXPLASTCACHE:
			return expLastCache();
		case EXPDISPINT:
			return expDispInt();
		case EXPREQINT:
			return expReqInt();
		case EXPDISPAPPS:
			return expDispApps();
		case EXPREQAPPS:
			return expReqApps();
		case EXPGETREWARD:
			return expGetRewarded();
		case EXPDISPVIDEO:
			return expDispVideo();
		case EXPERRORSTR:
			return expErrorStr();
		}
		return null;
	}

	//////////////////////////////////////////////////////
	//
	//			Conditions Routines
	//
	//////////////////////////////////////////////////////


	private boolean cndIntOk(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndIntFail(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndIntCached(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndIntDismiss(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndIntClose(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation == null)
			return false;
		if(param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndIntClick(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndAppsOk(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndAppsFail(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndAppsCached(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndAppsDismiss(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndAppsClose(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndAppsClick(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndOnActivity(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndVidOk(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndVidFail(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndVidCached(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndVidDismiss(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndVidComplete(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation == null)
			return false;
		if(param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndVidClose(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation == null)
			return false;
		if(param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndVidClick(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndVidWill(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndInPlayFail(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndInPlayCached(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(lastLocation != null && param0.contentEquals(lastLocation))
			return true;

		return false;
	}

	private boolean cndPauseClickConfirmation(CCndExtension cnd)
	{
		return true;
	}

	//////////////////////////////////////////////////////
	//
	//			Actions Routines
	//
	////////////////////////////////////////////////////// 

	private void actShowInt(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		clearError();
		if(cb) {
			if(param0.length() > 0)
				Location = param0;
			else
				Location = CBLocation.LOCATION_DEFAULT;
			Chartboost.showInterstitial(Location);
		}
		else {
			nError = 1;
			Error = "No Charboost Instances";
		}
	}

	private void actCacheInt(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		clearError();
		if(cb) {
			if(param0.length() > 0) 
				Location = param0;
			else
				Location = CBLocation.LOCATION_DEFAULT;
			Chartboost.cacheInterstitial(Location);
		}
		else {
			nError = 1;
			Error = "No Charboost Instances";
		}
	}

	private void actShowApps(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		clearError();
		if(cb) {
			if(param0.length() > 0) 
				Location = param0;
			else
				Location = CBLocation.LOCATION_DEFAULT;
			Chartboost.showMoreApps(Location);
		}
		else {
			nError = 1;
			Error = "No Charboost Instances";
		}
	}

	private void actCacheApps(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		clearError();
		if(cb) {
			if(param0.length() > 0)
				Location = param0;
			else
				Location = CBLocation.LOCATION_DEFAULT;
			Chartboost.cacheMoreApps(Location);
		}
		else {
			nError = 1;
			Error = "No Charboost Instances";
		}
	}

	private void actClearCache(CActExtension act)
	{
		// Removed from SDK in version 6.6.1
		/*
		if(cb)
			Chartboost.clearCache();
		else {
			nError = 1;
			Error = "No Charboost Instances";
		}
		*/
	}

	private void actTrackReset(CActExtension act)
	{
		//if(trackData != null)
		//	trackData.clear();
	}

	private void actTrackInt(CActExtension act)
	{
		//int param0 = act.getParamExpression(rh,0);
		//String param1 = act.getParamExpString(rh,1);
		//nError = 0;
		//if(param1.length() > 0)
		//	trackData.put(param1, param0);
		//else
		//	nError = 2;
	}

	private void actTrackStr(CActExtension act)
	{
		//String param0 = act.getParamExpString(rh,0);
		//String param1 = act.getParamExpString(rh,1);
		//nError = 0;
		//if(param0.length() > 0)
		//	trackData.put(param1, param0);
		//else
		//	nError = 2;
	}

	private void actTrackEvent(CActExtension act)
	{
		//String param0 = act.getParamExpString(rh,0);
		//int param1 = act.getParamExpression(rh,1);
		//if(cb != null) { 
		//	if(trackData != null && param0.length() > 0)
		//		CBAnalytics.sharedAnalytics().trackEvent(param0, param1, trackData);
		//}
		//else
		//	nError = 1;
	}

	private void actPurReset(CActExtension act)
	{
		//if(purchaseData != null)
		//	purchaseData.clear();
	}

	private void actPurInt(CActExtension act)
	{
		//int param0 = act.getParamExpression(rh,0);
		//String param1 = act.getParamExpString(rh,1);
		//nError = 0;
		//if(purchaseData != null)
		//	purchaseData.put(param1, param0);
		//else
		//	nError = 3;
	}

	private void actPurStr(CActExtension act)
	{
		//String param0 = act.getParamExpString(rh,0);
		//String param1 = act.getParamExpString(rh,1);
		//nError = 0;
		//if(purchaseData != null)
		//	purchaseData.put(param1, param0);
		//else
		//	nError = 3;
	}

	private void actPurchase(CActExtension act)
	{
		//String param0 = act.getParamExpString(rh,0);
		//String param1 = act.getParamExpString(rh,1);
		//double param2 = act.getParamExpFloat(rh,2);
		//String param3 = act.getParamExpString(rh,3);
		//int param4 = act.getParamExpression(rh,4);
		//if(cb) {
		//	if( purchaseData != null && param0.length() > 0)
		//		CBAnalytics.sharedAnalytics().recordPaymentTransaction(param0, param1, param2, param3, param4, purchaseData);

		//}
		//else
		//	nError = 1; 
	}

	private void actShowNOInt(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 == 1)
			cbInFirstSession = false;
		else
			cbInFirstSession = true;
		if(cb)
			Chartboost.setShouldRequestInterstitialsInFirstSession(cbInFirstSession);
	}

	private void actDispInt(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 == 1)
			cbDisplayInterstitial = true;
		else
			cbDisplayInterstitial = false;
	}

	private void actReqInt(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 == 1)
			cbRequestInterstitial = true;
		else
			cbRequestInterstitial = false;
	}

	private void actDispApps(CActExtension act)
	{
	    /*
		int param0 = act.getParamExpression(rh,0);
		if(param0 == 1)
			cbDisplayMoreApps = true;
		else
			cbDisplayMoreApps = false;
		if(cb)
			Chartboost.setShouldDisplayLoadingViewForMoreApps(cbDisplayMoreApps);
		*/
	}

	private void actReqApps(CActExtension act)
	{
	    /*
		int param0 = act.getParamExpression(rh,0);
		if(param0 == 1)
			cbRequestMoreApps = true;
		else
			cbRequestMoreApps = false;
		*/
	}

	private void actShowVideo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		clearError();
		if(cb) {
			if(param0.length() > 0) 
				Location = param0;
			else
				Location = CBLocation.LOCATION_DEFAULT;			
			Chartboost.showRewardedVideo(Location);
		}
		else {
			nError = 1;
			Error = "No Charboost Instances";
		}
	}

	private void actCacheVideo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		clearError();
		if(cb) {
			if(param0.length() > 0) 
				Location = param0;
			else
				Location = CBLocation.LOCATION_DEFAULT;
			Chartboost.cacheRewardedVideo(Location);
		}
		else {
			nError = 1;
			Error = "No Charboost Instances";
		}
	}

	private static Class<?> classLayout = null;
	private static Class<?> classIDs    = null;

	public int getLayoutByName(String name)
    {
        int id = -1;
        try {
            if (classLayout != null) {
                final Field field = classLayout.getField(name);
                if (field != null)
                    id = field.getInt(null);
            }
        } catch (final Exception e) {
            Log.Log("InPlay "+ e.toString());
            e.printStackTrace();
        }
        return id;
    }
    
    public int getIDsByName(String name)
    {
        int id = -1;
        try
        {
            if (classIDs != null) 
            {
                final Field field = classIDs.getField(name);
                if (field != null)
                    id = field.getInt(null);
            }
        } 
        catch (final Exception e) 
        {
            Log.Log("InPlay "+ e.toString());
            e.printStackTrace();
        }
        return id;
    }

	
	@SuppressLint("ClickableViewAccessibility")
	private void actClickInPlay(CActExtension act) {
		String param0 = act.getParamExpString(rh,0);

		clearError();
		
        // In Play		
		android.widget.RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT);
		inPlayAd = (RelativeLayout) MMFRuntime.inst.getLayoutInflater().inflate(getLayoutByName("cb_inplay"), null, false);
		MMFRuntime.inst.container.addView (inPlayAd, params);
		inPlayAd.setGravity(Gravity.CENTER);
        inPlayIcon = (ImageButton) inPlayAd.findViewById(getIDsByName("inPlayIcon"));
        inPlayCloseButton = (ImageButton) inPlayAd.findViewById(getIDsByName("inPlayCloseButton"));
        
		if(cb) {
			if(param0.length() > 0) 
				Location = param0;
			else
				Location = CBLocation.LOCATION_DEFAULT;

            final CBInPlay inPlay = CBInPlay.getInPlay(Location);
            if(inPlay != null && CBInPlay.hasInPlay(Location)) {
                try {
					inPlayIcon.setImageBitmap(inPlay.getAppIcon());
	                inPlayAd.setVisibility(View.VISIBLE);
	                inPlay.show();
	                inPlayShowing = true;

	                inPlayIcon.setOnClickListener(new View.OnClickListener() {
	                    @Override
	                    public void onClick(View v) {
	                        if (inPlay != null) {
	                            inPlay.click();
	                            inPlayAd.setVisibility(View.GONE);
	                            MMFRuntime.inst.container.removeView(inPlayAd);
	                            inPlayShowing = false;
	                            inPlayAd = null;
	                        }
	                    }
	                });

	                inPlayCloseButton.setOnClickListener(new View.OnClickListener() {
	                    @Override
	                    public void onClick(View v) {
	                        inPlayAd.setVisibility(View.GONE);
	                        inPlayShowing = false;
	                        MMFRuntime.inst.container.removeView(inPlayAd);
	                        inPlayShowing = false;
	                        inPlayAd = null;
	                    }
	                });
				} catch (Exception e) {
					e.printStackTrace();
				}
            } else {
                Log.Log("In Play was not ready at " + Location);
            }
		}
		else {
			nError = 1;
			Error = "No Charboost Instances";
		}
	}

	private void actCacheInPlay(CActExtension act) {
		String param0 = act.getParamExpString(rh,0);
		clearError();
		if(cb) {
			if(param0.length() > 0) 
				Location = param0;
			else
				Location = CBLocation.LOCATION_DEFAULT;
			CBInPlay.cacheInPlay(Location);
		}
		else {
			nError = 1;
			Error = "No Charboost Instances";
		}
	}

	private void actDispVideo(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 == 1)
			cbDisplayRewVideo = true;
		else
			cbDisplayRewVideo = false;
		if(cb)
			Chartboost.setShouldPrefetchVideoContent(cbDisplayRewVideo);
	}

	private void actPauseClick(CActExtension act)
	{
		//boolean shouldPause;
		//int param0 = act.getParamExpression(rh,0);
		//removed from sdk in version 6.6.1
		/*
		if(param0 != 0)
			shouldPause = true;
		else
			shouldPause = false;
		cbInPause = shouldPause;
		if(cb && enabled_perms)
			Chartboost.setShouldPauseClickForConfirmation(cbInPause);
		*/
	}

	private void actDismissAds(CActExtension act)
	{
		if(cb)
			Chartboost.closeImpression();
	}

    private void actSetGDPR(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        if(param0 == 1)
            restrictGDPR = false;
        else
            restrictGDPR = true;

        destroyCB();
        CreateCB();

    }


    //////////////////////////////////////////////////////
	//
	//			Expressions Routines
	//
	//////////////////////////////////////////////////////

	private CValue expError()
	{
		expRet.forceInt(nError);
		return expRet;
	}

	private CValue expLastCache()
	{
		expRet.forceString("");
		if(lastLocation != null)
			expRet.forceString(lastLocation);

		return expRet;
	}

	private CValue expDispInt()
	{
		expRet.forceInt(cbDisplayInterstitial ? 1 : 0);
		return expRet;
	}

	private CValue expReqInt()
	{
		expRet.forceInt(cbRequestInterstitial ? 1 : 0);
		return expRet;
	}

	private CValue expDispApps()
	{
		expRet.forceInt(cbDisplayMoreApps ? 1 : 0);
		return expRet;
	}

	private CValue expReqApps()
	{
		expRet.forceInt(cbRequestMoreApps ? 1 : 0);
		return expRet;
	}

	private CValue expGetRewarded()
	{
		expRet.forceInt(Rewarded);
		return expRet;
	}

	private CValue expDispVideo()
	{
		expRet.forceInt(cbDisplayRewVideo ? 1 : 0);
		return expRet;
	}

	private CValue expErrorStr()
	{
		expRet.forceString(Error);
		return expRet;
	}

	///////////////////////////////////////////////////////////////////////
	
	private void checkdelegate()
	{
		if((delegate_answer & DEL_CNDINTOK) != 0)
			ho.pushEvent(CNDINTOK, 0);

		if((delegate_answer & DEL_CNDINTFAIL) != 0)
			ho.pushEvent(CNDINTFAIL, 0);

		if((delegate_answer & DEL_CNDINTCACHED) != 0)
			ho.pushEvent(CNDINTCACHED, 0);

		if((delegate_answer & DEL_CNDINTDISMISS) != 0)
			ho.pushEvent(CNDINTDISMISS, 0);

		if((delegate_answer & DEL_CNDINTCLOSE) != 0)
			ho.pushEvent(CNDINTCLOSE, 0);

		if((delegate_answer & DEL_CNDINTCLICK) != 0)
			ho.pushEvent(CNDINTCLICK, 0);

		if((delegate_answer & DEL_CNDAPPSOK) != 0)
			ho.pushEvent(CNDAPPSOK, 0);

		if((delegate_answer & DEL_CNDAPPSFAIL) != 0)
			ho.pushEvent(CNDAPPSFAIL, 0);

		if((delegate_answer & DEL_CNDAPPSCACHED) != 0)
			ho.pushEvent(CNDAPPSCACHED, 0);

		if((delegate_answer & DEL_CNDAPPSDISMISS) != 0)
			ho.pushEvent(CNDAPPSDISMISS, 0);

		if((delegate_answer & DEL_CNDAPPSCLOSE) != 0)
			ho.pushEvent(CNDAPPSCLOSE, 0);

		if((delegate_answer & DEL_CNDAPPSCLICK) != 0)
			ho.pushEvent(CNDAPPSCLICK, 0);

		if((delegate_answer & DEL_CNDVIDOK) != 0)
			ho.pushEvent(CNDVIDOK, 0);

		if((delegate_answer & DEL_CNDVIDFAIL) != 0)
			ho.pushEvent(CNDVIDFAIL, 0);

		if((delegate_answer & DEL_CNDVIDCACHED) != 0)
			ho.pushEvent(CNDVIDCACHED, 0);

		if((delegate_answer & DEL_CNDVIDDISMISS) != 0)
			ho.pushEvent(CNDVIDDISMISS, 0);

		if((delegate_answer & DEL_CNDVIDCOMPLETE) != 0)
			ho.pushEvent(CNDVIDCOMPLETE, 0);

		if((delegate_answer & DEL_CNDVIDCLOSE) != 0)
			ho.pushEvent(CNDVIDCLOSE, 0);

		if((delegate_answer & DEL_CNDVIDCLICK) != 0)
			ho.pushEvent(CNDVIDCLICK, 0);

		if((delegate_answer & DEL_CNDVIDWILL) != 0)
			ho.pushEvent(CNDVIDWILL, 0);

		if((delegate_answer & DEL_CNDINPLAYFAIL) != 0)
			ho.pushEvent(CNDINPLAYFAIL, 0);

		if((delegate_answer & DEL_CNDINPLAYCACHED) != 0)
			ho.pushEvent(CNDINPLAYCACHED, 0);

		if((delegate_answer & DEL_CNDPAUSECLICK) != 0)
			ho.pushEvent(CNDPAUSECLICK, 0);

		delegate_answer = DEL_DEFAULT;		
	}
}
