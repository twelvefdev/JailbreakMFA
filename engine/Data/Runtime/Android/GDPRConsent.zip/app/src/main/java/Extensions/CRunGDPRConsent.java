/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

package Extensions;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.StringTokenizer;

import com.google.ads.consent.AdProvider;
import com.google.ads.consent.ConsentForm;
import com.google.ads.consent.ConsentFormListener;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.consent.DebugGeography;
import com.google.gson.Gson;

import Actions.CActExtension;
import Application.CRunApp;
import Conditions.CCndExtension;
import Expressions.CValue;
import Objects.CObject;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;
import android.content.SharedPreferences;
import android.util.Log;

// Version 3 new iOS implementation
public class CRunGDPRConsent extends CRunExtension
{
	// <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
	public static final int CNDONFORMLOADED = 0;
	public static final int CNDONFORMFAILED = 1;
	public static final int CNDONFORMOPENED = 2;
	public static final int CNDONFORMCLOSED = 3;
	public static final int CNDISADSFREE = 4;
	public static final int CNDISCONSENTSTATUS = 5;
	public static final int CNDONERROR = 6;
	public static final int CND_LAST = 7;

	public static final int ACTUNDERAGE = 0;
	public static final int ACTLOADEUFORM = 1;
	public static final int ACTSHOWEUFORM = 2;
    public static final int ACTDEBUGGEOMODE = 3;
    public static final int ACTSETSTATUS = 4;

    public static final int EXPEUSTATUS = 0;
    public static final int EXPDEBUGGEOMODE = 1;
    public static final int EXPEUADSLIST = 2;
    public static final int EXPERROR	 = 3;

	
	private CValue expRet;
	
	private String PUBLISHER_ID = null;
	private String POLICY_URL = null;
	
	// EUS Consent
	private ConsentStatus consentStatus;
	private ConsentInformation consentInf;
	private Boolean userPrefersAdFree;
	private List<AdProvider> adProviders;
	
	private ConsentForm form;
	private int debugGeoMode;
	private int euMode;
	
	private boolean appEndOn;
	private boolean leaving;
	private String szError;
	private int lastEvent;
	
	//////////////////////////////////////////////////////////////////////
	//
	//			Control functions
	//
	/////////////////////////////////////////////////////////////////////

	private void RestoreAutoEnd() {
		if(appEndOn) {
			appEndOn = false;
			MMFRuntime.inst.app.hdr2Options |= CRunApp.AH2OPT_AUTOEND;
		}
	}

	private void SuspendAutoEnd() {
		//AH2OPT_AUTOEND
		if (!appEndOn && MMFRuntime.inst.app != null && (MMFRuntime.inst.app.hdr2Options & CRunApp.AH2OPT_AUTOEND) != 0) {
			appEndOn = true;
			MMFRuntime.inst.app.hdr2Options &= ~ CRunApp.AH2OPT_AUTOEND;
		}
	}

	public CRunGDPRConsent()
	{
		szError = "";
		expRet = new CValue(0);
	}

	public @Override int getNumberOfConditions()
	{
		return CND_LAST;
	}

	public @Override boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
	{
		file.bUnicode = true;
		file.readShort();
		file.readShort();
		file.readShort();
		file.readShort();

		short lflag = file.readShort();
		short wflag = file.readShort();

		PUBLISHER_ID = file.readString(65);
		POLICY_URL = file.readString(264);
		consentInf = ConsentInformation.getInstance(ho.getControlsContext()); //ho.getControlsContext());
		
		if(PUBLISHER_ID.length() > 0)
			PUBLISHER_ID = PUBLISHER_ID.replaceAll("[\\r\\n]", "");
		if(POLICY_URL.length() > 0)
			POLICY_URL = POLICY_URL.replaceAll("[\\r\\n]", "");

		return false;
	}

	public @Override void destroyRunObject(boolean bFast)
	{		
	}

    public @Override void pauseRunObject()
    {
    }
    
    public @Override void continueRunObject()
    {
    	if(MMFRuntime.inst.isScreenOn || leaving)
    		RestoreAutoEnd();
    	
		lastEvent = rh.rh4EventCount;
    }
    
    public @Override int handleRunObject()
    {
    	startConsentForm();
        createConsentForm();
        
        return REFLAG_ONESHOT;
    }

    @Override
	public void onDestroy() 
    {
	}
    
    private void readPreferences()
    {
		SharedPreferences settings = MMFRuntime.inst.getSharedPreferences("GDPRData", ho.getControlsContext().MODE_PRIVATE);
		if(settings != null)
		{
			this.euMode = settings.getInt("GDPRConsent", 0);
			this.userPrefersAdFree = settings.getBoolean("EUFree", false);
			switch(euMode)
			{
			case 0:
				this.consentStatus = ConsentStatus.UNKNOWN;
				break;
			case 1:
				this.consentStatus = ConsentStatus.NON_PERSONALIZED;
				break;
			case 2:
				this.consentStatus = ConsentStatus.PERSONALIZED;
				break;
			}
			
  		    adProviders = consentInf.getAdProviders();
  		    
  		    if(adProviders != null && adProviders.size() > 0)
  		    {
  		    	Gson gson = new Gson();
  		    	String json = settings.getString("adapters", "");
  		    	adProviders = gson.fromJson(json, List.class);
 		    }				
		}
    }
    
    private void savePreferences()
    {
		SharedPreferences settings = MMFRuntime.inst.getSharedPreferences("GDPRData", ho.getControlsContext().MODE_PRIVATE);
		if(settings != null)
		{
			SharedPreferences.Editor editor = settings.edit();
			editor.putInt("GDPRConsent", this.consentStatus.ordinal());
			editor.putBoolean("EUFree", this.userPrefersAdFree);
			// Some Adapters available?
  		    adProviders = consentInf.getAdProviders();
  		    if(adProviders != null && adProviders.size() > 0)
  		    {
  		    	Gson gson = new Gson();
  		    	String json = gson.toJson(adProviders);
				editor.putString("adapters", json);
				editor.commit();
  		    	
  		    }
		}
    	
    }

    private void updateEUStatus(ConsentStatus consentStatus, Boolean userPrefersAdFree)
    {
    	this.consentStatus = consentStatus;
    	if(userPrefersAdFree != null)
    		this.userPrefersAdFree = userPrefersAdFree;
    	
   }
	
	private void startConsentForm()
	{
         String[] publisherIds = {PUBLISHER_ID};
        consentInf.requestConsentInfoUpdate(publisherIds, new ConsentInfoUpdateListener() {
            @Override
            public void onConsentInfoUpdated(ConsentStatus consentStatus) {
                 // User's consent status successfully updated.
            	updateEUStatus(consentStatus, null);
            }

            @Override
            public void onFailedToUpdateConsentInfo(String errorDescription) {
                 // User's consent status failed to update.
        		readPreferences();
            	szError = errorDescription;
            	ho.pushEvent(CNDONERROR, 0);
            }
        });
	}
	
	private void createConsentForm()
	{
        try {
            URL privacyUrl = new URL(POLICY_URL);
           form = new ConsentForm.Builder(ho.getControlsContext(), privacyUrl)
                   .withListener(new ConsentFormListener() {
                       @Override
                       public void onConsentFormLoaded() {
                    	   // Consent form loaded successfully.
                    	   ho.pushEvent(CNDONFORMLOADED, 0);
                       }

                       @Override
                       public void onConsentFormOpened() {
                    	   // Consent form was displayed.
                    	   leaving = true;
                    	   ho.pushEvent(CNDONFORMOPENED, 0);
                       }

                       @Override
                       public void onConsentFormClosed(ConsentStatus consentStatus, Boolean userPrefersAdFree) {
                           // Consent form was closed.
                    	    updateEUStatus(consentStatus, userPrefersAdFree);
                    	    if(consentStatus != ConsentStatus.UNKNOWN)
                    	    	consentInf.setConsentStatus(consentStatus);
                        	// Save some preferences to handle this
                       		savePreferences();
                          	ho.pushEvent(CNDONFORMCLOSED, 0);
                       }

                       @Override
                       public void onConsentFormError(String errorDescription) {
                    	   ho.pushEvent(CNDONFORMFAILED, 0);
                           // Consent form error.
                          	szError = errorDescription;
                        	ho.pushEvent(CNDONERROR, 0);
                       }
                   })
                   .withPersonalizedAdsOption()
                   .withNonPersonalizedAdsOption()
                   .withAdFreeOption()
                   .build();
       } catch (MalformedURLException e) {
       	szError = "Non valid policy url ...";
       	ho.pushEvent(CNDONERROR, 0);
       }
	}
	
	// Conditions
	// -------------------------------------------------
	public @Override boolean condition(int num, CCndExtension cnd)
	{
		switch (num)
		{
        case CNDONFORMLOADED:
            return cndOnFormLoaded(cnd);
        case CNDONFORMFAILED:
            return cndOnFormFailed(cnd);
        case CNDONFORMOPENED:
            return cndOnFormOpened(cnd);
        case CNDONFORMCLOSED:
            return cndOnFormClosed(cnd);
        case CNDISADSFREE:
            return cndIsAdsFree(cnd);
        case CNDISCONSENTSTATUS:
            return cndIsConsentStatus(cnd);
		case CNDONERROR:
			return cndOnError(cnd);
		}
		return false;
	}

	// Actions
	// -------------------------------------------------
	public @Override void action(int num, CActExtension act)
	{
		switch (num)
		{
		case ACTUNDERAGE:
			actUnderAge(act);
			break;
        case ACTLOADEUFORM:
            actLoadEUForm(act);
            break;
        case ACTSHOWEUFORM:
            actShowEUForm(act);
            break;
        case ACTDEBUGGEOMODE:
            actDebugGeoMode(act);
            break;
        case ACTSETSTATUS:
            actSetEUStatus(act);
            break;
		}
	}

	// Expressions
	// -------------------------------------------------
	public @Override CValue expression(int num)
	{
		switch (num)
		{
        case EXPEUSTATUS:
            return expGetConsentStatus();
        case EXPDEBUGGEOMODE:
            return expDebugGeoMode();
        case EXPEUADSLIST:
        	return expAdapterListAsString();
		case EXPERROR:
			return expStringError();
		}
		return null;
	}


	private boolean cndOnError(CCndExtension cnd)
	{
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
		if (rh.rh4EventCount == lastEvent)
		{
			return true;
		}

		return false;
	}
	
    private boolean cndOnFormLoaded(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
		if (rh.rh4EventCount == lastEvent)
		{
			return true;
		}

		return false;
    }
    
    
    private boolean cndOnFormFailed(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
		if (rh.rh4EventCount == lastEvent)
		{
			return true;
		}

		return false;
    }
    
    private boolean cndOnFormOpened(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
		if (rh.rh4EventCount == lastEvent)
		{
			return true;
		}

		return false;
    }
    
    private boolean cndOnFormClosed(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
		if (rh.rh4EventCount == lastEvent)
		{
			return true;
		}

		return false;
    }
    
    private boolean cndIsAdsFree(CCndExtension cnd)
    {
		return this.userPrefersAdFree;
    }
    
    private boolean cndIsConsentStatus(CCndExtension cnd)
    {
    	if(this.consentStatus != null)
    		return this.consentStatus.ordinal()-1 == cnd.getParamExpression(rh, 0);
    	
    	return false;
    }   
    
    //////////////////////////////////////////////////////////////
	//
	//				Actions
	//
	//////////////////////////////////////////////////////////////
	
	private void actUnderAge(CActExtension act)
	{
		int p1 = act.getParamExpression(rh, 0);
		if(p1 == 0)
			consentInf.setTagForUnderAgeOfConsent(false);
		if(p1 == 1)
			consentInf.setTagForUnderAgeOfConsent(true);
	}

	private void actLoadEUForm(CActExtension act)
	{
		if(form != null && consentInf.isRequestLocationInEeaOrUnknown())
			form.load();
	}
	
	private void actShowEUForm(CActExtension act)
	{
		if(form !=null && consentInf.isRequestLocationInEeaOrUnknown())
		{
			SuspendAutoEnd();
			form.show();
		}
	}
	
	private void actDebugGeoMode(CActExtension act)
	{
		int p1 = act.getParamExpression(rh, 0);
		consentInf.setTagForUnderAgeOfConsent(false);
		String p2 = act.getParamExpString(rh, 1);
		
		if(p1 == 0)
		{
			// Geography appears as in EEA for test devices.
			consentInf.setDebugGeography(DebugGeography.DEBUG_GEOGRAPHY_DISABLED);
		}
		if(p1 == 1)
		{	// Geography appears as in EEA for debug devices.
			consentInf.setDebugGeography(DebugGeography.DEBUG_GEOGRAPHY_EEA);
		}
		if(p1 == 2)
		{	// Geography appears as not in EEA for debug devices.
			consentInf.setDebugGeography(DebugGeography.DEBUG_GEOGRAPHY_NOT_EEA);
		}
		if (p1 > 0 && p2.length() != 0)
		{
			StringTokenizer tokenizer = new StringTokenizer(p2, ",");

			while (tokenizer.hasMoreElements())
			{
				String id = tokenizer.nextToken();

				Log.d ("AdMob", "Adding AdMob test device for consent: " + id);
				consentInf.addTestDevice(id);
			}
		}

		debugGeoMode = consentInf.getDebugGeography().ordinal();
		startConsentForm();
	}
	
	private void actSetEUStatus(CActExtension act)
	{
		int p1 = act.getParamExpression(rh, 0)+1;
		if(p1 < 0 || p1 > 2)
			return;
		
		if(p1 == 0)
			consentInf.setConsentStatus(ConsentStatus.UNKNOWN);
		if(p1 == 1)
			consentInf.setConsentStatus(ConsentStatus.NON_PERSONALIZED);
		if(p1 == 2)
			consentInf.setConsentStatus(ConsentStatus.PERSONALIZED);
		
		this.consentStatus = consentInf.getConsentStatus();
		savePreferences();

	}
	
	/////////////////////////////////////////////////////
	//
	//				Expression
	//
	/////////////////////////////////////////////////////
	private CValue expStringError()
	{
		expRet.forceString("");
		if(szError != null)
			expRet.forceString(szError);
		
		return expRet;
	}

	private CValue expGetConsentStatus()
	{
		expRet.forceInt(-1);
		if(consentStatus != null)
			expRet.forceInt(consentStatus.ordinal()-1);
		
		return expRet;
	}
	
	private CValue expDebugGeoMode()
	{
		expRet.forceInt(debugGeoMode);
		return expRet;
	}
    
	private CValue expAdapterListAsString()
	{
		expRet.forceString("");
		if(adProviders != null && adProviders.size() > 0)
		{
			Gson gson = new Gson();
			String json = gson.toJson(adProviders);

			expRet.forceString(json);
		}

		return expRet;
	}
	
	
}
