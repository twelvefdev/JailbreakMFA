/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// CRUNMVTVECTOR
//
//----------------------------------------------------------------------------------

package Movements;

import Animations.CAnim;
import Application.CRunFrame;
import Services.CBinaryFile;

public class CRunMvtclickteam_vector extends CRunMvtExtension
{
    public static final int MOVEATSTART = 1;
    public static final int HANDLE_DIRECTION = 2;
    public static final double ToDegrees = 57.295779513082320876798154814105;
    public static final double ToRadians = 0.017453292519943295769236907684886;
    int m_dwFlags;
    int m_dwVel;
    int m_dwVelAngle;
    int m_dwAcc;
    int m_dwAccAngle;
    boolean r_Stopped = false;
    boolean handleDirection = false;
    double posX = 0;
    double posY = 0;
    double velX = 0;
    double velY = 0;
    double accX = 0;
    double accY = 0;
    double angle = 0;
    double minSpeed = -1;
    double maxSpeed = -1;

    public CRunMvtclickteam_vector()
    {
    }

    @Override
	public void initialize(CBinaryFile file)
    {
        file.skipBytes(1);
        m_dwFlags = file.readInt();
        m_dwVel = file.readInt();
        m_dwVelAngle = file.readInt();
        m_dwAcc = file.readInt();
        m_dwAccAngle = file.readInt();

        //*** General variables
        r_Stopped = ((m_dwFlags & MOVEATSTART) == 0);
        handleDirection = ((m_dwFlags & HANDLE_DIRECTION) != 0);

        double vel = m_dwVel;
        double velAngle = m_dwVelAngle * ToRadians;

        double acc = m_dwAcc * 0.01;
        double accAngle = m_dwAccAngle * ToRadians;

        posX = ho.hoX;
        posY = ho.hoY;

        velX = vel * Math.cos(velAngle);
        velY = -vel * Math.sin(velAngle);

        accX = acc * Math.cos(accAngle);
        accY = -acc * Math.sin(accAngle);
    }

    @Override
	public void kill()
    {
    }

    @Override
	public boolean move()
    {
        //*** Object needs to be moved?
        if (!r_Stopped)
        {
            //*** Update internal variables
            double calculs;
            calculs = accX;
            if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
            {
                calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
            }
            velX += calculs;
            
            calculs = accY;
            if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
            {
                calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
            }
            velY += calculs;
            
            calculs = velX;
            if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
            {
                calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
            }
            posX += calculs * 0.01;
            
            calculs = velY;
            if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
            {
                calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
            }
            posY += calculs * 0.01;

            //*** Code the handle the min / max speed control
            checkSpeed();

            //*** Calculate the current direction
            angle = Math.atan2(-velY, velX);
            if (angle < 0)
            {
                angle += 2 * Math.PI;
            }

            if (handleDirection)
            {
                ho.roc.rcDir = ((int) (((angle + (Math.PI / 32)) * 32) / (2 / Math.PI))) % 32;
            }

            //*** Update MMF2 with the new position
            animations(CAnim.ANIMID_WALK);
            ho.hoX = (int) (posX + 0.5);
            ho.hoY = (int) (posY + 0.5);
            collisions();

            //*** Indicate the object has been moved
            return true;
        }
        
       	animations(CAnim.ANIMID_STOP);
        collisions();
        return false;
    }

    void reset()
    {
        double vel = m_dwVel;
        double velAngle = m_dwVelAngle * ToRadians;

        double acc = m_dwAcc / 100.0;
        double accAngle = m_dwAccAngle * ToRadians;

        posX = ho.hoX;
        posY = ho.hoY;

        velX = vel * Math.cos(velAngle);
        velY = -vel * Math.sin(velAngle);

        accX = acc * Math.cos(accAngle);
        accY = -acc * Math.sin(accAngle);
    }

    boolean checkSpeed()
    {
        //*** Code the handle the min / max speed control
        if (maxSpeed != -1)
        {
            if ((velX * velX + velY * velY) > maxSpeed * maxSpeed)
            {
                recalculateAngle();
                //*** Recalculate velocity components
                velX = maxSpeed * Math.cos(angle);
                velY = -maxSpeed * Math.sin(angle);
                return true;
            }
        }
        else if (minSpeed != -1)
        {
            if ((velX * velX + velY * velY) < minSpeed * minSpeed)
            {
                recalculateAngle();
                //*** Recalculate velocity components
                velX = minSpeed * Math.cos(angle);
                velY = -minSpeed * Math.sin(angle);
                return true;
            }
        }
        return false;
    }

    void recalculateAngle()
    {
        angle = Math.atan2(-velY, velX);
        if (angle < 0)
        {
            angle += 2 * Math.PI;
        }
    }

    @Override
	public void setPosition(int x, int y)
    {
        posX -= (ho.hoX - x);
        posY -= (ho.hoY - y);

        ho.hoX = x;
        ho.hoY = y;
    }

    @Override
	public void setXPosition(int x)
    {
        posX -= (ho.hoX - x);
        ho.hoX = x;
    }

    @Override
	public void setYPosition(int y)
    {
        posY -= (ho.hoY - y);
        ho.hoY = y;
    }

    @Override
	public void stop(boolean bCurrent)
    {
        r_Stopped = true;
    }

    @Override
	public void bounce(boolean bCurrent)
    {
    }

    @Override
	public void reverse()
    {
        velX *= -1;
        velY *= -1;
        recalculateAngle();
    }

    @Override
	public void start()
    {
        r_Stopped = false;
    }

    @Override
	public void setSpeed(int speed)
    {
        velX = speed * Math.cos(angle);
        velY = -speed * Math.sin(angle);

        if (checkSpeed())
        {
            recalculateAngle();
        }
    }

    @Override
	public void setMaxSpeed(int speed)
    {
        maxSpeed = speed;
        if (checkSpeed())
        {
            recalculateAngle();
        }
    }

    @Override
	public void setDir(int dir)
    {
    }

    @Override
	public void setAcc(int acc)
    {
    }

    @Override
	public void setDec(int dec)
    {
    }

    @Override
	public void setRotSpeed(int speed)
    {
    }

    @Override
	public void set8Dirs(int dirs)
    {
    }

    @Override
	public void setGravity(int gravity)
    {
        double accAngle = Math.atan2(-accY, accX);
        double acc = gravity * 0.01;

        accX = acc * Math.cos(accAngle);
        accY = -acc * Math.sin(accAngle);
    }

    @Override
	public int extension(int function, int param)
    {
        return 0;
    }

    @Override
	public double actionEntry(int action)
    {
        int param;
        double vel;
        double accAngle;
        double acc;
        double flo;
        switch (action)
        {
            case 3845:	    // SET_Vector_X = 3845,
                param = (int) getParamDouble();
                posX = param;
                break;
            case 3846:	    // SET_Vector_Y,
                param = (int) getParamDouble();
                posY = param;
                break;
            case 3847:	    // SET_Vector_XY,
                param = (int) getParamDouble();
                break;
            case 3848:	    // SET_Vector_AddDistX,
                param = (int) getParamDouble();
                posX += 0.01 * param;
                break;
            case 3849:	    // SET_Vector_AddDistY,
                param = (int) getParamDouble();
                posY -= 0.01 * param;
                break;
            case 3850:	    // SET_Vector_Dir,
                param = (int) getParamDouble();
                angle = (param) * ToRadians;
                vel = Math.sqrt(velX * velX + velY * velY);
                velX = vel * Math.cos(angle);
                velY = -vel * Math.sin(angle);
                break;
            case 3851:	    // SET_Vector_RotateTowardsAngle,
                param = (int) getParamDouble();
                break;
            case 3852:	    // SET_Vector_RotateTowardsPoint,
                param = (int) getParamDouble();
                break;
            case 3853:	    // SET_Vector_RotateTowardsObject,
                param = (int) getParamDouble();
                break;
            case 3854:	    // SET_Vector_Speed,
                param = (int) getParamDouble();
                vel = param;
                velX = vel * Math.cos(angle);
                velY = -vel * Math.sin(angle);
                if (checkSpeed())
                {
                    recalculateAngle();
                }
                break;
            case 3855:	    // SET_Vector_SpeedX,
                param = (int) getParamDouble();
                velX = param;
                if (checkSpeed())
                {
                    recalculateAngle();
                }
                break;
            case 3856:	    // SET_Vector_SpeedY,
                param = (int) getParamDouble();
                velY = param;
                if (checkSpeed())
                {
                    recalculateAngle();
                }
                break;
            case 3857:	    // SET_Vector_AddSpeedX,
                param = (int) getParamDouble();
                velX += 0.01 * param;
                if (checkSpeed())
                {
                    recalculateAngle();
                }
                break;
            case 3858:	    // SET_Vector_AddSpeedY,
                param = (int) getParamDouble();
                velY -= 0.01 * param;
                if (checkSpeed())
                {
                    recalculateAngle();
                }
                break;
            case 3859:	    // SET_Vector_MinSpeed,
                param = (int) getParamDouble();
                minSpeed = param;
                if (checkSpeed())
                {
                    recalculateAngle();
                }
                break;
            case 3860:	    // SET_Vector_MaxSpeed,
                param = (int) getParamDouble();
                maxSpeed = param;
                if (checkSpeed())
                {
                    recalculateAngle();
                }
                break;
            case 3861:	    // SET_Vector_Gravity,
                param = (int) getParamDouble();
                accAngle = Math.atan2(-accY, accX);
                acc = param * 0.01;
                accX = acc * Math.cos(accAngle);
                accY = -acc * Math.sin(accAngle);
                break;
            case 3862:	    // SET_Vector_GravityDir,
                param = (int) getParamDouble();
                accAngle = param * ToRadians;
                acc = Math.sqrt(accX * accX + accY * accY);
                accX = acc * Math.cos(accAngle);
                accY = -acc * Math.sin(accAngle);
                break;
            case 3863:	    // SET_Vector_BounceCoeff,
                param = (int) getParamDouble();
                break;
            case 3864:	    // SET_Vector_ForceBounce,
                param = (int) getParamDouble();
                angle = param * ToRadians * 2;
                posX -= velX * 0.01;
                posY -= velY * 0.01;
                angle -= Math.atan2(-velY, velX);
                vel = Math.sqrt(velX * velX + velY * velY);
                velX = vel * Math.cos(angle);
                velY = -vel * Math.sin(angle);
                break;

            case 3865:	    // GET_Vector_X,
                return posX;
            case 3866:	    // GET_Vector_Y,
                return posY;
            case 3867:	    // GET_Vector_Dir,
                flo = (angle * ToDegrees);
                if (flo < 0)
                {
                    flo += 360;
                }
                return flo;
            case 3868:	    // GET_Vector_Speed,
                return Math.sqrt(velX * velX + velY * velY);
            case 3869:	    // GET_Vector_SpeedX,
                return velX;
            case 3870:	    // GET_Vector_SpeedY,
                return velY;
            case 3871:	    // GET_Vector_MinSpeed,
                return minSpeed;
            case 3872:	    // GET_Vector_MaxSpeed,
                return maxSpeed;
            case 3873:	    // GET_Vector_Gravity,
                return (100 * Math.sqrt(accX * accX + accY * accY));
            case 3874:	    // GET_Vector_GravityDir,
                flo = (Math.atan2(-accY, accX) * ToDegrees);
                if (flo < 0)
                {
                    flo += 360;
                }
                return flo;
            case 3875:	    // GET_Vector_BounceCoef
                return 0;

        }
        return 0;
    }

    @Override
	public int getSpeed()
    {
        return (int) (Math.sqrt(velX * velX + velY * velY));
    }

    @Override
	public int getAcceleration()
    {
        return 0;
    }

    @Override
	public int getDeceleration()
    {
        return 0;
    }

    @Override
	public int getGravity()
    {
        return (int) (100 * Math.sqrt(accX * accX + accY * accY));
    }
}
