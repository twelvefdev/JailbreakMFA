//////////////////////////////////////////////////////////////////////////////////////////////////
// 																							    //
//		InventoryList																			//
// 																							    //
//////////////////////////////////////////////////////////////////////////////////////////////////
package Extensions;

import Extensions.CRunInventory.pointer;
import Services.CArrayList;
import Services.CFile;

public class CRunInventoryList
{
	public CArrayList<CRunInventoryItem> list=new CArrayList<CRunInventoryItem>();
	public int position;

	private static CRunInventoryList instance;
	
    static {
        instance = new CRunInventoryList();
    }

    public static CRunInventoryList getInstance() {
        return CRunInventoryList.instance;
    }

    public void  Reset()
	{
		list.clear();
		position=0;
	}
	public CRunInventoryItem GetItem(int number, String  pName)
	{
		int n;
		for (n=0; n<list.size(); n++)
		{
			CRunInventoryItem pItem=(CRunInventoryItem)list.get(n);
			if (pItem.GetNumber()==number)
			{
				if (pItem.GetName().contentEquals(pName))
				{
					return pItem;
				}
			}
		}
		return null;
	}
	public int  GetItemIndex(int number, String  pName)
	{
		int n;
		for (n=0; n<list.size(); n++)
		{
			CRunInventoryItem pItem=(CRunInventoryItem)list.get(n);
			if (pItem.GetNumber()==number)
			{
				if (pItem.GetName().contentEquals(pName))
				{
					return n;
				}
			}
		}
		return 0;
	}
	public CRunInventoryItem FirstItem(int number)
	{
		for (position=0; position<list.size(); position++)
		{
			CRunInventoryItem pItem=(CRunInventoryItem)list.get(position);
			if (pItem.GetNumber()==number)
			{
				position++;
				return pItem;
			}
		}
		return null;
	}
	public CRunInventoryItem NextItem(int number)
	{
		for (; position<list.size(); position++)
		{
			CRunInventoryItem pItem=(CRunInventoryItem)list.get(position);
			if (pItem.GetNumber()==number)
			{
				position++;
				return pItem;
			}
		}
		return null;
	}
	
	public void  Load(CFile bfile)
	{
		Reset();
		short size;
		size=(short) bfile.readAInt();
		int n;
		for (n=0; n<size; n++)
		{
			CRunInventoryItem pItem=new CRunInventoryItem(0, "", 0, 1, "");
			pItem.Load(bfile);
			list.add(pItem);
		}
	}
	public int Save(pointer writer)
	{
		int count = 0;
		count += CRunInventory.WriteAnInt(writer, list.size());
		int n;
		for (n=0; n<list.size(); n++)
		{
			CRunInventoryItem pItem=(CRunInventoryItem)list.get(n);
			count += pItem.Save(writer);
		}
		return count;
	}

	public CRunInventoryItem AddItem(int number, String  pName, int  quantity, int  maximum, String  pDisplayString)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem==null)
		{
			pItem=new CRunInventoryItem(number, pName, quantity, maximum, pDisplayString);
			list.add(pItem);
		}
		else
		{
			pItem.AddQuantity(quantity);
			if (pItem.quantity==0)
			{
				list.remove(pItem);
			}
		}
		return pItem;
	}
	public CRunInventoryItem AddItemToPosition(int number, String  insert, String  pName, int  quantity, int  maximum, String  pDisplayString)
	{
		int n;
		CRunInventoryItem pItem2=null;
		for (n=0; n<list.size(); n++)
		{
			pItem2=(CRunInventoryItem)list.get(n);
			if (insert.contentEquals(pItem2.pName))
			{
				break;
			}
		}
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem==null)
		{
			pItem=new CRunInventoryItem(number, pName, quantity, maximum, pDisplayString);
			list.add(n, pItem);
		}
		else
		{
			swapByObject(list, pItem, pItem2);
		}
		return pItem;
	}

	public boolean SubQuantity(int number, String  pName, int  quantity)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			pItem.SubQuantity(quantity);
			if (pItem.quantity==0)
			{
				list.remove(pItem);
				return true;
			}
		}
		return false;
	}
	public void SetMaximum(int number, String  pName, int  max)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			pItem.SetMaximum(max);
		}
	}
	public int GetQuantity(int number, String  pName)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			return pItem.GetQuantity();
		}
		return -1;
	}
	public int GetMaximum(int number, String  pName)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			return pItem.GetMaximum();
		}
		return -1;
	}
	public void DelItem(int number, String  pName)
	{
		int index=GetItemIndex(number, pName);
		if (index>=0)
		{
			list.remove(list.get(index));
		}
	}
	public void SetFlags(int number, String  pName, int  mask, int  flag)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			pItem.SetFlags(mask, flag);
		}
	}
	public int GetFlags(int number, String  pName)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			return pItem.GetFlags();
		}
		return 0;
	}
	public void SetDisplayString(int number, String  pName, String  pDisplayString)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			pItem.SetDisplayString(pDisplayString);
		}
	}
	public String GetDisplayString(int number, String  pName)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			return pItem.GetDisplayString();
		}
		return null;
	}
	public void AddProperty(int number, String  pName, String  propName, int  value)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			pItem.AddProperty(propName, value);
		}
	}
	public void SetPropertyMinimum(int number, String  pName, String  propName, int  value)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			pItem.SetPropertyMinimum(propName, value);
		}
	}
	public void SetPropertyMaximum(int number, String  pName, String  propName, int  value)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			pItem.SetPropertyMinimum(propName, value);
		}
	}
	public int GetProperty(int number, String  pName, String  propName)
	{
		CRunInventoryItem pItem=GetItem(number, pName);
		if (pItem!=null)
		{
			return pItem.GetProperty(propName);
		}
		return 0;
	}
	
	public void swapByObject(CArrayList<CRunInventoryItem> list, CRunInventoryItem item1, CRunInventoryItem item2) {
		CRunInventoryItem temp1 = item1;
		int i = list.indexOf(item1);
		int j = list.indexOf(item2);
		list.add(i, item2);
		list.add(j, temp1);	
	}
}
