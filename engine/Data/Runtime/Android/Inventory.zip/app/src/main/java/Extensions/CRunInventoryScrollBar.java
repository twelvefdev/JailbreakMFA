//////////////////////////////////////////////////////////////////////////////////////////////////
// 																							    //
//		CScrollBar      																		//
// 																							    //
//////////////////////////////////////////////////////////////////////////////////////////////////
package Extensions;

import Application.CKeyConvert;
import OpenGL.GLRenderer;
import RunLoop.CRun;
import Services.CRect;

public class CRunInventoryScrollBar
{
	public static int SX_SLIDER=13;
	public static int SY_SLIDER=13;
	public static int ZONE_NONE=0;
	public final static int ZONE_TOPARROW=1;
	public final static int ZONE_TOPCENTER=2;
	public final static int ZONE_SLIDER=3;
	public final static int ZONE_BOTTOMCENTER=4;
	public final static int ZONE_BOTTOMARROW=5;
	public final static int SCROLL_UP=0;
	public final static int SCROLL_PAGEUP=1;
	public final static int SCROLL_SLIDE=2;
	public final static int SCROLL_PAGEDOWN=3;
	public final static int SCROLL_DOWN=4;

	public int position;
	public int length;
	public int total;
	public int color;
	public int colorHilight;
	public CRun rhPtr;
	public CRunInventory data;
	public CRect topArrow = new CRect();
	public CRect bottomArrow = new CRect();
	public CRect slider = new CRect();
	public CRect center = new CRect();
	public CRect surface = new CRect();
	public int zone;
	public boolean oldBDown;
	public int xStart;
	public int yStart;
	public boolean bDragging;
	public boolean bInitialised;
	public boolean bHorizontal;

	public CRunInventoryScrollBar()
	{
		bInitialised=false;
	}

	public void  Initialise(CRun rh, int x, int y, int sx, int sy, int c, int ch, CRunInventory d)
	{
		rhPtr=rh;
		data=d;
		color=c;
		colorHilight=ch;

		surface.left=x;
		surface.top=y;
		surface.right=x+sx;
		surface.bottom=y+sy;
		if (sx>sy)
		{
			bHorizontal=true;
			topArrow.left=x;
			topArrow.top=y;
			topArrow.right=x+SX_SLIDER;
			topArrow.bottom=y+sy+1;
			
			center.left=x+SX_SLIDER+1;
			center.top=y;
			center.right=x+sx-SX_SLIDER-1;
			center.bottom=y+sy;
			
			bottomArrow.left=x+sx-SX_SLIDER;
			bottomArrow.top=y;
			bottomArrow.right=x+sx;
			bottomArrow.bottom=y+sy+1;
		}
		else
		{
			bHorizontal=false;
			topArrow.left=x;
			topArrow.top=y;
			topArrow.right=x+sx;
			topArrow.bottom=y+SY_SLIDER-1;
			
			center.left=x;
			center.top=y+SY_SLIDER+1;
			center.right=x+sx;
			center.bottom=y+sy-SY_SLIDER-1;
			
			bottomArrow.left=x;
			bottomArrow.top=y+sy-SY_SLIDER+1;
			bottomArrow.right=x+sx;
			bottomArrow.bottom=y+sy;
		}
		SetPosition(position, length, total);
		bInitialised=true;
		bDragging = false;
	}
	public void  SetPosition(int p, int l, int t)
	{
		position=p;
		length=l;
		total=t;

		if (total>0)
		{
			if (bHorizontal)
			{
				slider.left=Math.min(center.left+(position*(center.right-center.left))/total, center.right);
				slider.right=Math.min(slider.left+(length*(center.right-center.left))/total, center.right);
				slider.top=center.top;
				slider.bottom=center.bottom;
			}
			else
			{
				slider.top=Math.min(center.top+(position*(center.bottom-center.top))/total, center.bottom);
				slider.bottom=Math.min(slider.top+(length*(center.bottom-center.top))/total, center.bottom);		
				slider.left=center.left;
				slider.right=center.right;
			}
		}
	}
	public boolean IsMouseInBar(int xx, int yy)
	{
		if (bInitialised)
		{
			return surface.ptInRect(xx, yy);
		}
		return false;
	}
	public boolean IsDragging() 
	{
		return bDragging;
	}	
	public int GetZone(int xx, int yy) 
	{
		if (bDragging)
		{
			return ZONE_SLIDER;
		}
		if (topArrow.ptInRect(xx, yy))
		{
			return ZONE_TOPARROW;
		}
		if (bottomArrow.ptInRect(xx, yy))
		{
			return ZONE_BOTTOMARROW;
		}
		if (center.ptInRect(xx, yy))
		{
			if (slider.ptInRect(xx, yy))
			{
				return ZONE_SLIDER;
			}
			if (bHorizontal)
			{
				if (xx<slider.left)
				{
					return ZONE_TOPCENTER;
				}
				else
				{
					return ZONE_BOTTOMCENTER;
				}
			}
			else
			{
				if (yy<slider.top)
				{
					return ZONE_TOPCENTER;
				}
				else
				{
					return ZONE_BOTTOMCENTER;
				}
			}
		}
		return ZONE_NONE;
	}
	public void Handle(int xx, int yy) 
	{
		int delta;
		int pos;
		if (bInitialised && length<total)
		{
			boolean bDown=rhPtr.rhApp.getKeyState(CKeyConvert.VK_LBUTTON);
			if (bDown!=oldBDown)
			{
				oldBDown=bDown;
				
				if (bDown)
				{
					zone=GetZone(xx, yy);
					bDragging=false;
					
					switch (zone)
					{
						case ZONE_TOPARROW:
							data.Scroll(SCROLL_UP, 0);
							break;
						case ZONE_TOPCENTER:
							data.Scroll(SCROLL_PAGEUP, 0);
							break;
						case ZONE_BOTTOMCENTER:
							data.Scroll(SCROLL_PAGEDOWN, 0);
							break;
						case ZONE_BOTTOMARROW:
							data.Scroll(SCROLL_DOWN, 0);
							break;
						case ZONE_SLIDER:
							xStart=xx;
							yStart=yy;
							bDragging=true;
							break;
					}
				}
				else
				{
					//bDragging=false;
				}
			}
			else
			{
				if (bDragging)
				{
					if (bHorizontal)
					{
						delta=xx-xStart;
						delta=(delta*total)/(center.right-center.left);
						if (delta!=0)
						{
							pos=position+delta;
							pos=Math.max(pos, 0);
							pos=Math.min(pos, total-length);
							data.Scroll(SCROLL_SLIDE, pos);
							xStart=xx;
						}
					}
					else
					{
						delta=yy-yStart;
						delta=(delta*total)/(center.bottom-center.top);
						if (delta!=0)
						{
							pos=position+delta;
							pos=Math.max(pos, 0);
							pos=Math.min(pos, total-length);
							data.Scroll(SCROLL_SLIDE, pos);
							yStart=yy;
						}
					}
				}
			}
		}
	}
	public void  DrawBar()
	{
        GLRenderer renderer = GLRenderer.inst;

		if (bInitialised==true && length<total)
		{
			invDrawRect(center.left, center.top, center.right-center.left, center.bottom-center.top, color, 1);
			
			int sColor;
			if (zone==ZONE_SLIDER)
				sColor = colorHilight;
			else
				sColor = color;
			
			renderer.renderGradient(slider.left, slider.top, slider.right-slider.left, slider.bottom-slider.top, sColor,  sColor, false, 0, 0);

			int lcolor = 0;
			if (bHorizontal)
			{
				if (zone==ZONE_TOPARROW)
					lcolor = colorHilight;
				else
					lcolor = color;

				renderer.renderGradient(topArrow.left, topArrow.top, SX_SLIDER, SY_SLIDER, lcolor,  lcolor, false, 0, 0);
				
				if (zone==ZONE_BOTTOMARROW)
					lcolor = colorHilight;
				else
					lcolor = color;

				renderer.renderGradient(bottomArrow.left, bottomArrow.top, SX_SLIDER, SY_SLIDER, lcolor,  lcolor, false, 0, 0);
			}
			else
			{
				if (zone==ZONE_TOPARROW)
					lcolor = colorHilight;
				else
					lcolor = color;

				renderer.renderGradient(topArrow.left, topArrow.top, SX_SLIDER, SY_SLIDER, lcolor,  lcolor, false, 0, 0);
				
				if (zone==ZONE_BOTTOMARROW)
					lcolor = colorHilight;
				else
					lcolor = color;
				
				renderer.renderGradient(bottomArrow.left, bottomArrow.top, SX_SLIDER, SY_SLIDER, lcolor,  lcolor, false, 0, 0);
			}
		}
	}
	
	public void invDrawRect(int x, int y, int w, int h, int color, int thickness)
	{
		GLRenderer renderer = GLRenderer.inst;
		renderer.renderLine(x   , y+h , x+w , y+h , color, thickness);
		renderer.renderLine(x+w , y   , x+w , y+h , color, thickness);
		renderer.renderLine(x   , y   , x+w , y   , color, thickness);
		renderer.renderLine(x   , y   , x   , y+h , color, thickness);

	}
}
