//////////////////////////////////////////////////////////////////////////////////////////////////
// 																							    //
//		Inventory property																		//
// 																							    //
//////////////////////////////////////////////////////////////////////////////////////////////////
package Extensions;

import Extensions.CRunInventory.pointer;
import Services.CFile;

public class CRunInventoryProperty
{
	public String pName;
	public int value;
	public int maximum;
	public int minimum;

	public CRunInventoryProperty(String name, int  v, int  min, int  max)
	{
		pName=name;

		value=v;
		minimum=min;
		maximum=max;
	}

	public int Save(pointer writer) 
	{
		int count = 0;
		count += CRunInventory.WriteAString(writer, pName);
		count += CRunInventory.WriteAnInt(writer, value);
		count += CRunInventory.WriteAnInt(writer, minimum);
		count += CRunInventory.WriteAnInt(writer, maximum);
		return count;
	}
	public void Load(CFile file)
	{
		pName=file.readAString();
		value=file.readAInt();
		minimum=file.readAInt();
		maximum=file.readAInt();
	}
	
	public void  AddValue(int v)
	{
		value=Math.max(Math.min(value+v, maximum), minimum);
	}
	public void  SetMinimum(int m)
	{
		minimum=m;
		value=Math.max(Math.min(value, maximum), minimum);
	}
	public void  SetMaximum(int m)
	{
		maximum=m;
		value=Math.max(Math.min(value, maximum), minimum);
	}
	public int  GetValue()
	{
		return value;
	}
}
