//////////////////////////////////////////////////////////////////////////////////////////////////
// //
//InventoryItem																			//
// //
//////////////////////////////////////////////////////////////////////////////////////////////////
package Extensions;

import Extensions.CRunInventory.pointer;
import Services.CArrayList;
import Services.CFile;

public class CRunInventoryItem
{
	public int number;
	public String pName;
	public String pDisplayString;
	public int flags;
	public int quantity;
	public int maximum;
	public int x;
	public int y;
	public CArrayList<CRunInventoryProperty> properties;
	public static int FLAG_VISIBLE=0x0001;

	public CRunInventoryItem(int n, String ptr, int  q, int  max, String  displayString)
	{
		number=n;
		pName=ptr;
		pDisplayString=displayString;
		maximum=Math.max(max, 1);
		quantity=Math.min(q, maximum);
		quantity=Math.max(quantity, 0);
		flags=FLAG_VISIBLE;
		properties=new CArrayList<CRunInventoryProperty>();
		x=0;
		y=0;
	}

	public void  Reset()
	{
		properties.clear();
	}

	public void  SetFlags(int mask, int  flag)
	{
		flags = (flags & mask) | flag;
	}

	public String GetName()
	{
		return pName;
	}

	public String GetDisplayString()
	{
		return pDisplayString;
	}

	public int GetQuantity()
	{
		return quantity;
	}

	public int GetMaximum()
	{
		return maximum;
	}

	public int GetNumber()
	{
		return number;
	}

	public int  GetFlags()
	{
		return flags;
	}
	
	public int Save(pointer writer) 
	{
		int count = 0;
		count += CRunInventory.WriteAnInt(writer, number);
		count += CRunInventory.WriteAnInt(writer, flags);
		count += CRunInventory.WriteAnInt(writer, quantity);
		count += CRunInventory.WriteAnInt(writer, maximum);
		count += CRunInventory.WriteAnInt(writer, x);
		count += CRunInventory.WriteAnInt(writer, y);

		count += CRunInventory.WriteAString(writer, pName);

		count += CRunInventory.WriteAString(writer, pDisplayString);

		int l=properties.size();
		count += CRunInventory.WriteAnInt(writer, l);
		for (int n=0; n<l; n++)
		{
			CRunInventoryProperty pProperty=(CRunInventoryProperty)properties.get(n);
			count += pProperty.Save(writer);
		}
		return count;
	}
	public void Load(CFile file) 
	{
		Reset();
		number=file.readAInt();
		flags=file.readAInt();
		quantity=file.readAInt();
		maximum=file.readAInt();
		x=file.readAInt();
		y=file.readAInt();

		pName=file.readAString();
		pDisplayString=file.readAString();

		int l=file.readAInt();
		for (int n=0; n<l; n++)
		{
			CRunInventoryProperty pProperty=new CRunInventoryProperty("", 0, 0, 0);
		pProperty.Load(file);
		properties.add(pProperty);
		}
	}
			
	public void SetDisplayString(String displayString)
	{
		pDisplayString=displayString;
	}

	public void SetQuantity(int q)
	{
		q=Math.max(q, 0);
		q=Math.min(q, maximum);
		quantity=q;
	}

	public void AddQuantity(int q)
	{
		q=Math.max(q+quantity, 0);
		q=Math.min(q, maximum);
		quantity=q;
	}

	public void SubQuantity(int q)
	{
		q=Math.max(quantity-q, 0);
		q=Math.min(q, maximum);
		quantity=q;
	}

	public void  SetMaximum(int m)
	{
		maximum=Math.max(m, 1);
		quantity=Math.min(quantity, maximum);
	}

	public CRunInventoryProperty FindProperty(String pName)
	{
		int n;
		for (n=0; n<properties.size(); n++)
		{
			CRunInventoryProperty pProperty=(CRunInventoryProperty)properties.get(n);
			if (pName.contentEquals(pProperty.pName))
			{
				return pProperty;
			}
		}
		return null;
	}

	public void  AddProperty(String pName, int value)
	{
		CRunInventoryProperty pProperty=FindProperty(pName);
		if (pProperty!=null)
		{
			pProperty.AddValue(value);
		}
		else
		{
			pProperty=new CRunInventoryProperty(pName, value, 0x80000000, 0x7FFFFFFF);
			properties.add(pProperty);
		}
	}

	public void SetPropertyMinimum(String pName, int  min)
	{
		CRunInventoryProperty pProperty=FindProperty(pName);
		if (pProperty!=null)
		{
			pProperty.SetMinimum(min);
		}
		else
		{
			pProperty=new CRunInventoryProperty(pName, 0, min, 0x7FFFFFFF);
			properties.add(pProperty);
		}
	}

	public void SetPropertyMaximum(String pName, int  max)
	{
		CRunInventoryProperty pProperty=FindProperty(pName);
		if (pProperty!=null)
		{
			pProperty.SetMaximum(max);
		}
		else
		{
			pProperty=new CRunInventoryProperty(pName, 0, 0x80000000, max);
			properties.add(pProperty);
		}
	}

	public int GetProperty(String pName)
	{
		CRunInventoryProperty pProperty=FindProperty(pName);
		if (pProperty!=null)
		{
			return pProperty.GetValue();
		}
		return 0;
	}
}
