
//
// CRUNINVENTORY
//
//----------------------------------------------------------------------------------
package Extensions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;

import Actions.CActExtension;
import Application.CKeyConvert;
import Application.CRunApp;
import Banks.CFont;
import Conditions.CCndExtension;
import Expressions.CValue;
import Frame.CLayer;
import Objects.CObject;
import OpenGL.CTextSurface;
import OpenGL.GLRenderer;
import RunLoop.CCreateObjectInfo;
import RunLoop.CObjInfo;
import Runtime.MMFRuntime;
import Services.CArrayList;
import Services.CBinaryFile;
import Services.CFile;
import Services.CFontInfo;
import Services.CRect;
import Services.CServices;
import Sprites.CRSpr;
import android.content.Context;

public class CRunInventory extends CRunExtension
{
	private final static int CND_NAMEDITEMSELECTED=0;
	private final static int CND_NAMEDCOMPARENITEMS=1;
	private final static int CND_ITEMSELECTED=2;
	private final static int CND_COMPARENITEMS=3;
	private final static int CND_NAMEDITEMPRESENT=4;
	private final static int CND_ITEMPRESENT=5;
	private final static int CND_NAMEDHILIGHTED=6;
	private final static int CND_HILIGHTED=7;
	private final static int CND_CANADD=8;
	private final static int CND_NAMEDCANADD=9;
	private final static int CND_LAST=10;
	private final static int ACT_NAMEDADDITEM=0;
	private final static int ACT_NAMEDADDNITEMS=1;
	private final static int ACT_NAMEDDELITEM=2;
	private final static int ACT_NAMEDDELNITEMS=3;
	private final static int ACT_NAMEDHIDEITEM=4;
	private final static int ACT_NAMEDSHOWITEM=5;
	private final static int ACT_ADDITEM=6;
	private final static int ACT_ADDNITEMS=7;
	private final static int ACT_DELITEM=8;
	private final static int ACT_DELNITEMS=9;
	private final static int ACT_HIDEITEM=10;
	private final static int ACT_SHOWITEM=11;
	private final static int ACT_LEFT=12;
	private final static int ACT_RIGHT=13;
	private final static int ACT_UP=14;
	private final static int ACT_DOWN=15;
	private final static int ACT_SELECT=16;
	private final static int ACT_CURSOR=17;
	private final static int ACT_NAMEDSETSTRING=18;
	private final static int ACT_SETSTRING=19;
	private final static int ACT_ACTIVATE=20;
	private final static int ACT_NAMEDSETMAXIMUM=21;
	private final static int ACT_SETMAXIMUM=22;
	private final static int ACT_SETPOSITION=23;
	private final static int ACT_SETPAGE=24;
	private final static int ACT_ADDPROPERTY=25;
	private final static int ACT_NAMEDSETPROPMINMAX=26;
	private final static int ACT_SETPROPMINMAX=27;
	private final static int ACT_NAMEDADDPROPERTY=28;
	private final static int ACT_ADDGRIDITEM=29;
	private final static int ACT_ADDGRIDNITEMS=30;
	private final static int ACT_NAMEDADDGRIDITEM=31;
	private final static int ACT_NAMEDADDGRIDNITEMS=32;
	private final static int ACT_HILIGHTDROP=33;
	private final static int ACT_NAMEDHILIGHTDROP=34;
	private final static int ACT_SAVE=35;
	private final static int ACT_LOAD=36;
	private final static int ACT_ADDLISTITEM=37;
	private final static int ACT_ADDLISTNITEMS=38;
	private final static int ACT_NAMEDADDLISTITEM=39;
	private final static int ACT_NAMEDADDLISTNITEMS=40;
	private final static int EXP_NITEM=0;
	private final static int EXP_NAMEOFHILIGHTED=1;
	private final static int EXP_NAMEOFSELECTED=2;
	private final static int EXP_POSITION=3;
	private final static int EXP_PAGE=4;
	private final static int EXP_TOTAL=5;
	private final static int EXP_DISPLAYED=6;
	private final static int EXP_NUMOFSELECTED=7;
	private final static int EXP_NUMOFHILIGHTED=8;
	private final static int EXP_NAMEOFNUM=9;
	private final static int EXP_MAXITEM=10;
	private final static int EXP_NUMBERMAXITEM=11;
	private final static int EXP_NUMBERNITEM=12;
	private final static int EXP_GETPROPERTY=13;
	private final static int EXP_NUMBERGETPROPERTY=14;

	private final static int IFLAG_CURSOR=0x0001;
	private final static int IFLAG_HSCROLL=0x0002;
	private final static int IFLAG_VSCROLL=0x0004;
	private final static int IFLAG_SORT=0x0010;
	private final static int IFLAG_MOUSE=0x0020;
	private final static int IFLAG_FORCECURSOR=0x0040;
	private final static int IFLAG_CURSORBYACTION=0x0080;
	private final static int IFLAG_DISPLAYGRID=0x0100;
	private final static int INVTYPE_LIST=0;
	private final static int INVTYPE_GRID=1;

	private final static int VK_LEFT= 1;
	private final static int VK_RIGHT= 2;
	private final static int VK_UP= 3;
	private final static int VK_DOWN= 4;
	private final static int VK_RETURN= 5;

	private static CRunInventoryList inventory;
	public int type;
	public int number;
	public int itemSx;
	public int itemSy;
	public int flags;
	public int textAlignment;
	public CFontInfo logFont;
	public int fontColor;
	public int scrollColor;
	public int scrollColor2;
	public int cursorColor;
	public int gridColor;
	public int cursorType;
	public String pDisplayString;

	public CArrayList<CRunInventoryItem> displayList=new CArrayList<CRunInventoryItem>();
	public CArrayList<Integer> objectList=new CArrayList<Integer>();
	public CRunInventoryScrollBar slider;
	public int nColumns;
	public int nLines;
	public int position;
	public int xCursor;
	public int yCursor;
	public boolean bUpdateList;
	public boolean bRedraw;
	public int displayQuantity;
	public int showQuantity;
	public int oldKey;
	public int selectedCount;
	public boolean oldBMouse;
	public boolean bActivated;
	public String pNameSelected;
	public String pNameHilighted;
	public int maximum;
	public int numSelected;
	public int numHilighted;
	public int[] pGrid;
	public CRect rcDrop=new CRect();
	public boolean bDropItem;
	public int scrollX;
	public int scrollY;
	public int scrollPosition;
	public boolean oldBHidden;
	public CFont font;
	public String conditionString;

	public CLayer pLayer;
	public CTextSurface textSurface;
	private CValue expRet = new CValue(0);
	private boolean antialiased;

	public CRunInventory() 
	{
		inventory = null;
	}

	@Override
	public int getNumberOfConditions()
	{
		return CND_LAST;
	}

	@Override
	public boolean createRunObject(CBinaryFile file, CCreateObjectInfo  cob, int  version)
	{
		ho.hoImgWidth=file.readInt();
		ho.hoImgHeight=file.readInt();
		number=file.readShort();
		itemSx=file.readShort();
		itemSy=file.readShort();
		flags=file.readInt();
		textAlignment=file.readInt();
		logFont=file.readLogFont();
		fontColor=file.readColor();
		scrollColor=file.readColor();
		displayQuantity=file.readInt();
		showQuantity=file.readInt();
		scrollColor2=file.readColor();
		maximum=file.readInt();
		cursorColor=file.readColor();
		cursorType=file.readInt();
		type=file.readShort();
		gridColor=file.readColor();
		pDisplayString=file.readString();
		nColumns=Math.max(ho.hoImgWidth/itemSx, 1);
		nLines=Math.max(ho.hoImgHeight/itemSy, 1);
		selectedCount=-1;
		numSelected=-1;
		numHilighted=-1;
		position=0;
		bDropItem=false;
		oldBHidden=false;
		bUpdateList=true;
		bRedraw = true;
		font = CFont.createFromFontInfo(logFont);
		textSurface = new CTextSurface(ho.getApplication(), ho.hoImgWidth, ho.hoImgHeight);

		if (inventory==null)
		{
			inventory=CRunInventoryList.getInstance();
		}
		//pLayer=ho.hoAdRunHeader.rhFrame.layers[ho.ros.rsLayer];

		if (type==INVTYPE_LIST)
		{
			slider=new CRunInventoryScrollBar();
			SetSlider();
		}
		UpdateDisplayList();
		return true;
	}

	private void SetSlider()
	{
		int x, y;
		if ((flags&IFLAG_HSCROLL)!=0)
		{
			x=ho.hoX;
			y=ho.hoY+ho.hoImgHeight-CRunInventoryScrollBar.SY_SLIDER;
			slider.Initialise(rh, x, y, ho.hoImgWidth, CRunInventoryScrollBar.SY_SLIDER, scrollColor, scrollColor2, this);
		}
		else if ((flags&IFLAG_VSCROLL)!=0)
		{
			x=ho.hoX+ho.hoImgWidth-CRunInventoryScrollBar.SX_SLIDER;
			y=ho.hoY;
			slider.Initialise(rh, x, y, CRunInventoryScrollBar.SX_SLIDER, ho.hoImgHeight, scrollColor, scrollColor2, this);
		}
	}
	private void obHide(CObject hoPtr)
	{
		hoPtr.ros.obHide();
	}

	private void obShow(CObject hoPtr)
	{
		hoPtr.ros.obShow();
	}

	private int  GetFixedValue(CObject pHo)
	{
		return (pHo.hoCreationId<<16)|(pHo.hoNumber&0xFFFF);
	}

	private CObject GetHO(int fixedValue)
	{
		CObject hoPtr=rh.rhObjectList[fixedValue&0xFFFF];
		if (hoPtr!=null && hoPtr.hoCreationId==fixedValue>>16)
		{
			return hoPtr;
		}
		return null;
	}

	private void showHide(Boolean bHidden)
	{
		int n;
		CObject hoPtr;
		if (!bHidden)
		{
			for (n=0; n<objectList.size(); n++)
			{
				hoPtr=GetHO(objectList.get(n));
				if (hoPtr!=null)
				{
					obShow(hoPtr);
				}
			}
		}
		else
		{
			for (n=0; n<objectList.size(); n++)
			{
				hoPtr=GetHO(objectList.get(n));
				if (hoPtr!=null)
				{
					obHide(hoPtr);
				}
			}
		}
	}

	private void  CenterDisplay(int pos)
	{
		int size=nColumns*nLines;
		if (pos<position)
		{
			position=pos;
		}
		else if (pos>=position+size)
		{
			position=Math.max(0, pos-size+1);
		}
	}

	private void  UpdateDisplayList()
	{
		displayList.clear();
		objectList.clear();
		int n;
		if (type==INVTYPE_GRID)
		{
			if (pGrid==null)
			{
				pGrid=new int[nColumns*nLines];
			}
			for (n=nColumns*nLines-1; n>=0; n--)
				pGrid[n]=0;
		}

		CRunInventoryItem pItem;
		for (pItem=inventory.FirstItem(number); pItem!=null; pItem=inventory.NextItem(number))
		{
			String pName=pItem.GetName();
			int objectNum=0;
			for (int nObject=0; nObject<rh.rhNObjects; objectNum++, nObject++)
			{
				while(rh.rhObjectList[objectNum]==null) objectNum++;
				CObject hoPtr=rh.rhObjectList[objectNum];
				if (hoPtr.hoType==2)
				{
					CObjInfo pOiList=hoPtr.hoOiList;
					if (pOiList.oilName.contentEquals(pName))
					{
						if (pItem.GetQuantity()>=showQuantity)
						{
							if ((pItem.GetFlags()&CRunInventoryItem.FLAG_VISIBLE)!=0)
							{
								displayList.add(pItem);
								int fix=GetFixedValue(hoPtr);
								objectList.add(fix);
								if (type==INVTYPE_GRID)
								{
									int sx=(hoPtr.hoImgWidth+itemSx-1)/itemSx;
									int sy=(hoPtr.hoImgHeight+itemSy-1)/itemSy;
									int x, y;
									for (y=0; y<sy; y++)
									{
										for (x=0; x<sx; x++)
										{
											pGrid[(pItem.y+y)*nColumns+pItem.x+x]=fix;
										}
									}
									//bring to front
									rh.spriteGen.moveSpriteToFront(hoPtr.roc.rcSprite);
								}
							}
							else
							{
								obHide(hoPtr);
							}
							break;
						}
						else
						{
							obHide(hoPtr);
						}
					}
				}
			}
		}
		if (type==INVTYPE_LIST && displayList.size()>2 && (flags&IFLAG_SORT)!=0)
		{
			Boolean bFlag=true;
			while(bFlag==true)
			{
				bFlag=false;
				for (n=0; n<displayList.size()-1; n++)
				{
					CRunInventoryItem pItem1=displayList.get(n);
					CRunInventoryItem pItem2=displayList.get(n+1);
					String pName1=pItem1.GetName();
					String pName2=pItem2.GetName();
					if (pName1.compareTo(pName2)>0)
					{
						swapByIndex(displayList, n, n+1);
						swapByIndex(objectList, n, n+1);
						bFlag=true;
					}
				}
			}
		}
		bUpdateList=true;
		bRedraw = true;
		ho.redraw();
	}

	void swapByIndex(CArrayList array, int index1, int index2)
	{
		Object temp= array.get(index1);
		array.set(index1, array.get(index2));
		array.set(index2, temp);
	}

	private void  SetPosition(CObject pHo, int  x, int  y)
	{
		pHo.hoX=x+pHo.hoImgXSpot;
		pHo.hoY=y+pHo.hoImgYSpot;
		pHo.rom.rmMoveFlag=true;	
		pHo.roc.rcChanged=true;
		pHo.roc.rcCheckCollides=true;
		//bring to front
		rh.spriteGen.moveSpriteToFront(pHo.roc.rcSprite);
	}

	private Boolean CheckDisplayList()
	{
		Boolean bRet=false;
		int o;
		for (o=0; o<displayList.size(); o++)
		{
			int fixedValue=objectList.get(o);
			CObject hoPtr=GetHO(fixedValue);
			if (hoPtr==null)
			{
				displayList.remove(o);
				objectList.remove(o);
				o--;
				bRet=true;
			}
		}
		return bRet;
	}

	public void Scroll(int type, int  slide)
	{
		int pos=position;
		if (slider.bHorizontal==false)
		{
			switch(type)
			{
			case CRunInventoryScrollBar.SCROLL_UP:
				pos--;
				break;
			case CRunInventoryScrollBar.SCROLL_PAGEUP:
				pos-=nColumns;
				break;
			case CRunInventoryScrollBar.SCROLL_PAGEDOWN:
				pos+=nColumns;
				break;
			case CRunInventoryScrollBar.SCROLL_DOWN:
				pos++;
				break;
			case CRunInventoryScrollBar.SCROLL_SLIDE:
				pos=slide;
				break;
			}
		}
		else
		{
			switch(type)
			{
			case CRunInventoryScrollBar.SCROLL_UP:
				pos--;
				break;
			case CRunInventoryScrollBar.SCROLL_PAGEUP:
				pos-=nLines;
				break;
			case CRunInventoryScrollBar.SCROLL_PAGEDOWN:
				pos+=nLines;
				break;
			case CRunInventoryScrollBar.SCROLL_DOWN:
				pos++;
				break;
			case CRunInventoryScrollBar.SCROLL_SLIDE:
				pos=slide;
				break;
			}
		}
		if (pos<0)
		{
			pos=0;
		}
		if (pos>displayList.size()-nColumns*nLines)
		{
			pos=displayList.size()-nColumns*nLines;
		}
		if (pos!=position)
		{
			position=pos;
			slider.SetPosition(position, Math.min(displayList.size()-position, nLines*nColumns), displayList.size()); 
			bRedraw=true;
			bUpdateList=true;
		}
	}

	private void CleanList()
	{
		int n;
		for (n=0; n<objectList.size(); n++)
		{
			int fixed=objectList.get(n);
			if (GetHO(fixed)==null)
			{
				CRunInventoryItem pItem =displayList.get(n);
				inventory.list.remove(pItem);
			}
		}
	}

	private int GetGridRect(int x, int  y, CRect  pRc)
	{
		int fix=pGrid[y*nColumns+x];
		if (fix!=0)
		{
			int xx, yy;
			for (xx=0; xx<x; xx++)
			{
				if (pGrid[y*nColumns+xx]==fix)
				{
					break;
				}
			}
			pRc.left=ho.hoX+xx*itemSx;
			for (xx=x; xx<nColumns; xx++)
			{
				if (pGrid[y*nColumns+xx]!=fix)
				{
					break;
				}
			}
			pRc.right=ho.hoX+xx*itemSx;
			for (yy=0; yy<y; yy++)
			{
				if (pGrid[yy*nColumns+x]==fix)
				{
					break;
				}
			}
			pRc.top=ho.hoY+yy*itemSy;
			for (yy=y; yy<nLines; yy++)
			{
				if (pGrid[yy*nColumns+x]!=fix)
				{
					break;
				}
			}
			pRc.bottom=ho.hoY+yy*itemSy;
		}
		else
		{
			pRc.left=ho.hoX+x*itemSx;
			pRc.right=pRc.left+itemSx;
			pRc.top=ho.hoY+y*itemSy;
			pRc.bottom=pRc.top+itemSy;
		}
		return fix;
	}

	public int getKeys()
	{
		int key=0;
		if (rh.rhApp.getKeyState(38))
			key = VK_UP;
		if (rh.rhApp.getKeyState(40))
			key = VK_DOWN;
		if (rh.rhApp.getKeyState(37))
			key = VK_LEFT;
		if (rh.rhApp.getKeyState(39))
			key = VK_RIGHT;
		if (rh.rhApp.getKeyState(13))
			key = VK_RETURN;
		return key;
	}

	@Override
	public void destroyRunObject(boolean bFast)
	{
		textSurface.recycle();
	}
	@Override
	public int handleRunObject()
	{
		int ret=0;
		Boolean bUpdate=false;

		CleanList();
		if (bUpdateList)
		{
			UpdateDisplayList();
			ret=REFLAG_DISPLAY;
		}
		else
		{
			if (CheckDisplayList())
			{
				ret=REFLAG_DISPLAY;
			}
		}
		if (bRedraw)
		{
			ret=REFLAG_DISPLAY;
			bRedraw=false;
		}

		Boolean bHidden=(ho.ros.rsFlags&CRSpr.RSFLAG_HIDDEN)!=0;
		if (bHidden!=oldBHidden)
		{
			oldBHidden=bHidden;
			showHide(bHidden);
		}
		if (bHidden)
		{
			return ret;
		}

		int fix;
		int x, y, xx=0, yy=0;
		Boolean bFlag;
		CRunInventoryItem pItem;
		CObject hoPtr;
		Boolean bMouse;
		int key;
		numHilighted=-1;
		pNameHilighted="";
		bMouse=rh.rhApp.getKeyState(CKeyConvert.VK_LBUTTON);
		if (type == INVTYPE_LIST)
		{
			if (position>0 && position>Math.max(0, displayList.size()-nLines*nColumns))
			{
				position=Math.max(displayList.size()-nLines*nColumns, 0);
				bUpdate=true;
			}
			if (position+yCursor*nColumns+xCursor>=displayList.size())
			{
				xCursor=0;
				yCursor=0;
				bUpdate=true;
			}
			if (displayList.size()>0)
			{
				xx=rh.getMouseFrameX();
				yy=rh.getMouseFrameY();
				x=xx - ho.hoX;
				y=yy - ho.hoY;
				bFlag=false;
				if ((flags&IFLAG_MOUSE)!=0)
				{
					if (x>=0 && y>=0 && x<ho.hoImgWidth && y<ho.hoImgHeight)
					{
						if (!slider.IsMouseInBar(xx, yy))
						{
							x/=itemSx;
							y/=itemSy;
							if (x<nColumns && y<nLines)
							{
								int o=position+y*nColumns+x;
								if (o<position+displayList.size())
								{
									bFlag=true;
									if (xCursor!=x || yCursor!=y)
									{
										xCursor=x;
										yCursor=y;
										bUpdate=true;
									}
									pItem=displayList.get(o);
									pNameHilighted=pItem.GetName();
									numHilighted=o;
								}
							}
						}
					}
				}
				if (bMouse!=oldBMouse)
				{
					oldBMouse=bMouse;
					if (bMouse==true && (flags&IFLAG_MOUSE)!=0)
					{
						scrollX=x*itemSx;
						scrollY=y*itemSy;
						scrollPosition=position;
						pNameSelected=pNameHilighted;
						numSelected=position+yCursor*nColumns+xCursor;
						selectedCount=rh.rh4EventCount;
						pItem=displayList.get(position+yCursor*nColumns+xCursor);
						hoPtr=GetHO(objectList.get(position+yCursor*nColumns+xCursor));
						conditionString=pItem.GetName();
						ho.generateEvent(CND_NAMEDITEMSELECTED, 0);
						ho.generateEvent(CND_ITEMSELECTED, hoPtr.hoOi);
					}
					if ((flags&IFLAG_CURSOR)!=0 && x>=0 && y>=0 && x<ho.hoImgWidth && y<ho.hoImgHeight)
					{
						bActivated=true;
						xCursor=x/itemSx;
						yCursor=y/itemSy;
						bUpdate=true;
					}
					else
					{
						bActivated=false;
						bUpdate=true;
					}
				}
				if (bMouse && slider.bInitialised)
				{
					if (!slider.IsMouseInBar(xx, yy))
					{
						if ((flags&IFLAG_VSCROLL)!=0)
						{
							if (yy<scrollY)
								position=scrollPosition-((yy-scrollY-itemSy)/itemSy)*nColumns;
							else
								position=scrollPosition-((yy-scrollY)/itemSy)*nColumns;
							if (position<0)
								position=0;
							if (position>Math.max(0, displayList.size()-nLines*nColumns))
								position=Math.max(displayList.size()-nLines*nColumns, 0);
							bUpdate=true;
						}
						else if ((flags&IFLAG_HSCROLL)!=0)
						{
							if (xx<scrollX)
								position=scrollPosition-((xx-scrollX-itemSx)/itemSx)*nLines;
							else
								position=scrollPosition-((xx-scrollX)/itemSx)*nLines;
							if (position<0)
								position=0;
							if (position>Math.max(0, displayList.size()-nLines*nColumns))
								position=Math.max(displayList.size()-nLines*nColumns, 0);
							bUpdate=true;
						}
					}
				}
				if (bActivated)
				{
					bFlag=true;
				}
				key= getKeys();
				if (bActivated && (flags&IFLAG_CURSOR)!=0)
				{
					if (key!=oldKey)
					{
						oldKey=key;
						switch(key)
						{
						case VK_UP:
							yCursor--;
							if (yCursor<0)
							{
								yCursor++;
								position=Math.max(position-nColumns, 0);
							}
							break;
						case VK_DOWN:
							yCursor++;
							if (yCursor>=nLines)
							{
								yCursor--;
								position=Math.min(position+nColumns, displayList.size()-nColumns*nLines);
								position=Math.max(position, 0);
							}
							break;
						case VK_RIGHT:
							xCursor++;
							if (xCursor>=nColumns)
							{
								xCursor--;
								position=Math.min(position+1, displayList.size()-nColumns*nLines);
								position=Math.max(position, 0);
							}
							break;
						case VK_LEFT:
							xCursor--;
							if (xCursor<0)
							{
								xCursor++;
								position=Math.max(position-1, 0);
							}
							break;
						case VK_RETURN:
						{
							pNameSelected=pNameHilighted;
							selectedCount=rh.rh4EventCount;
							numSelected=position+yCursor*nColumns+xCursor;
							pItem=displayList.get(position+yCursor*nColumns+xCursor);
							hoPtr=GetHO(objectList.get(position+yCursor*nColumns+xCursor));
							conditionString=pItem.GetName();
							ho.generateEvent(CND_NAMEDITEMSELECTED, 0);
							ho.generateEvent(CND_ITEMSELECTED, hoPtr.hoOi);
						}
						break;
						}
						bUpdate=true;
					}
				}
				if ((flags&IFLAG_CURSORBYACTION)==0)
				{
					if (bFlag)
					{
						if ((flags&IFLAG_FORCECURSOR)==0)
						{
							flags|=IFLAG_FORCECURSOR;
							bUpdate=true;
						}
					}
					else
					{
						if ((flags&IFLAG_FORCECURSOR)!=0)
						{
							flags&=~IFLAG_FORCECURSOR;
							bUpdate=true;
						}
					}
				}
			}

			if (bUpdate)
			{
				if (slider.bInitialised)
				{
					slider.SetPosition(position, Math.min(displayList.size()-position, nLines*nColumns), displayList.size()); 
				}
			}
			if (slider.bInitialised)
			{
				slider.Handle(xx, yy);	
			}
		}
		else
		{
			// Grid display
			x=rh.getMouseFrameX()-ho.hoX;
			y=rh.getMouseFrameY()-ho.hoY;
			bFlag=false;
			if ((flags&IFLAG_MOUSE)!=0)
			{
				if (x>=0 && y>=0 && x<ho.hoImgWidth && y<ho.hoImgHeight)
				{
					x/=itemSx;
					y/=itemSy;
					if (x<nColumns && y<nLines)
					{
						bFlag=true;
						if (xCursor!=x || yCursor!=y)
						{
							xCursor=x;
							yCursor=y;
							ret=REFLAG_DISPLAY;
						}
						int o=y*nColumns+x;
						int fixed=pGrid[o];
						if (fixed!=0) 
						{
							int n;
							for (n=0; n<objectList.size(); n++)
								if (fixed==objectList.get(n))
									break;
							if (n<objectList.size())
							{
								pItem=displayList.get(n);
								pNameHilighted=pItem.GetName();
								numHilighted=o;
							}
						}
					}
				}
			}
			//bMouse=rh.rhApp.getKeyState(CKeyConvert.VK_LBUTTON);
			if (bMouse!=oldBMouse)
			{
				oldBMouse=bMouse;
				if (bMouse && (flags&IFLAG_MOUSE)!=0)
				{
					fix=pGrid[yCursor*nColumns+xCursor];
					if (fix!=0)
					{
						pNameSelected=pNameHilighted;
						numSelected=yCursor*nColumns+xCursor;
						selectedCount=rh.rh4EventCount;
						hoPtr=GetHO(fix);
						conditionString=hoPtr.hoOiList.oilName;
						ho.generateEvent(CND_NAMEDITEMSELECTED, 0);
						ho.generateEvent(CND_ITEMSELECTED, hoPtr.hoOi);
					}
				}
				if ((flags&IFLAG_CURSOR)!=0 && x>=0 && y>=0 && x<ho.hoImgWidth && y<ho.hoImgHeight)
				{
					bActivated=true;
					xCursor=x/itemSx;
					yCursor=y/itemSy;
					ret=REFLAG_DISPLAY;
				}
				else
				{
					bActivated=false;
					ret=REFLAG_DISPLAY;
				}
			}
			if (bActivated)
			{
				bFlag=true;
			}

			key=getKeys();
			if (bActivated && (flags&IFLAG_CURSOR)!=0)
			{
				if (key!=oldKey)
				{
					oldKey=key;
					switch(key)
					{
					case VK_UP:
						if (yCursor>0)
						{
							y=yCursor-1;
							fix=pGrid[y*nColumns+xCursor];
							if (fix!=0)
							{
								while (y>0)
								{
									if (pGrid[(y-1)*nColumns+xCursor]!=fix)
									{
										break;
									}
									y--;
								}
							}
							yCursor=y;
						}
						break;
					case VK_DOWN:
						if (yCursor<nLines-1)
						{
							fix=pGrid[yCursor*nColumns+xCursor];
							y=yCursor+1;
							if (fix!=0)
							{
								while (pGrid[y*nColumns+xCursor]==fix && y<nLines-1)
									y++;
							}
							yCursor=y;
						}
						break;
					case VK_RIGHT:
						if (xCursor<nColumns-1)
						{
							fix=pGrid[yCursor*nColumns+xCursor];
							x=xCursor+1;
							if (fix!=0)
							{
								while (pGrid[yCursor*nColumns+x]==fix && x>0)
									x++;
							}
							xCursor=x;
						}
						break;
					case VK_LEFT:
						if (xCursor>0)
						{
							x=xCursor-1;
							fix=pGrid[yCursor*nColumns+x];
							if (fix!=0)
							{
								while (x>0)
								{
									if (pGrid[yCursor*nColumns+x-1]!=fix)
									{
										break;
									}
									x--;
								}
							}
							xCursor=x;
						}
						break;
					case VK_RETURN:
					{
						pNameSelected=pNameHilighted;
						selectedCount=rh.rh4EventCount;
						numSelected=position+yCursor*nColumns+xCursor;
						pItem=displayList.get(position+yCursor*nColumns+xCursor);
						if (pItem!=null)
						{
							hoPtr=GetHO(objectList.get(position + yCursor * nColumns + xCursor));
							conditionString=pItem.GetName();
							ho.generateEvent(CND_NAMEDITEMSELECTED, 0);
							ho.generateEvent(CND_ITEMSELECTED, hoPtr.hoOi);
						}
					}
					break;
					}
					ret=REFLAG_DISPLAY;
				}
			}

			if ((flags&IFLAG_CURSORBYACTION)==0)
			{
				if (bFlag)
				{
					if ((flags&IFLAG_FORCECURSOR)==0)
					{
						flags|=IFLAG_FORCECURSOR;
						ret=REFLAG_DISPLAY;
					}
				}
				else
				{
					if ((flags&IFLAG_FORCECURSOR)!=0)
					{
						flags&=~IFLAG_FORCECURSOR;
						ret=REFLAG_DISPLAY;
					}
				}
				bUpdate=true;
			}
		}
		if (bUpdate)
		{
			bUpdateList=true;
			ret=REFLAG_DISPLAY;
		}
		return ret;
	}


	private final static int SX_SEPARATION=8;
	private final static int SY_SEPARATION=8;

	@Override
	public void displayRunObject()
	{
		GLRenderer renderer = GLRenderer.inst;

		CRect rc;
		int x, y;
		int xObject;
		int yObject;
		int sx;
		int sy;

		if (type==INVTYPE_LIST)
		{
			if (displayList.size()==0)
			{
				return;
			}

			if (bUpdateList)
			{
				textSurface.manualClear(fontColor);            
			}

			pNameHilighted=null;
			numHilighted=-1;
			boolean uploadTexture = false;
			for (int o=0; o<displayList.size(); o++)
			{
				CObject hoPtr=GetHO(objectList.get(o));
				if (hoPtr!=null)
				{
					if (o>=position && o<position+nLines*nColumns)
					{
						CRunInventoryItem pItem=displayList.get(o);
						obShow(hoPtr);

						int line=(o-position)/nColumns;
						int column=(o-position)-line*nColumns;		
						xObject=column*itemSx+itemSx/2-hoPtr.hoImgWidth/2;
						yObject=line*itemSy+itemSy/2-hoPtr.hoImgHeight/2;
						sy = 0;

						if (o==position+xCursor+yCursor*nColumns)
						{
							rc=new CRect();
							rc.left=ho.hoX+column*itemSx;
							rc.top=ho.hoY+line*itemSy;
							rc.right=rc.left+itemSx-1;
							rc.bottom=rc.top+itemSy-1;
							pNameHilighted=pItem.GetName();
							numHilighted=o;
							if ((flags&IFLAG_FORCECURSOR)!=0 && cursorType>0) 
							{
								if (cursorType==1)
								{
									invDrawRect(rc.left, rc.top, rc.right-rc.left, rc.bottom-rc.top, 0xFF << 24 |cursorColor, 2); // will set 2 for thickness in Android
								}
								else
								{
									renderer.renderGradient(rc.left, rc.top, rc.right-rc.left, rc.bottom-rc.top, 0xFF << 24 | cursorColor,  0xFF << 24 | cursorColor, false, 0, 0);
								}
							}
						}

						if (maximum>1 && bUpdateList)
						{
							CRect rcText;
							short dtFlags;
							String text=pItem.GetDisplayString();
							String temp=null;
							int pos=text.indexOf("%q");
							if (pos>=0)
							{
								temp=text.substring(0, pos);
								temp+=String.valueOf(pItem.GetQuantity());
								temp+=text.substring(pos+2);
								text = temp;
							}
							pos=text.indexOf("%m");
							if (pos>=0)
							{
								temp=text.substring(0, pos);
								temp+=String.valueOf(pItem.GetMaximum());
								temp+=text.substring(pos+2);
							}
							text=temp;

							rcText = new CRect();
							rcText.left = 0;
							rcText.top  = 0;
							rcText.bottom = 1024;
							rcText.right  = 1024;
							textSurface.measureText(text, CServices.DT_LEFT, font.getFontInfo(), rcText, 0);
							int syText=textSurface.getHeight();
							if ((textAlignment&0x00000001)!=0)       // TEXT_ALIGN_LEFT)
							{
								rcText.left=column*itemSx;
								rcText.right=rcText.left+itemSx;
								dtFlags=CServices.DT_LEFT;
								xObject=(column+1)*itemSx-hoPtr.hoImgWidth;
							}
							else if ((textAlignment&0x00000002)!=0)  //TEXT_ALIGN_HCENTER)
							{
								rcText.left=column*itemSx;
								rcText.right=rcText.left+itemSx;
								dtFlags=CServices.DT_CENTER;
							}
							else											// (textAlignment&TEXT_ALIGN_RIGHT)
							{
								xObject=column*itemSx;
								rcText.left=xObject+hoPtr.hoImgWidth+SX_SEPARATION;
								rcText.right=xObject+itemSx;
								dtFlags=CServices.DT_LEFT;
							}
							if ((textAlignment&0x00000008)!=0)       //TEXT_ALIGN_TOP)
							{
								sy=hoPtr.hoImgHeight+SY_SEPARATION+syText;
								rcText.top=line*itemSy+itemSy/2-sy/2;
								rcText.bottom=rcText.top+syText;
								yObject=rcText.top+syText+SY_SEPARATION;
								dtFlags|=CServices.DT_TOP;
							}
							else if ((textAlignment&0x00000010)!=0)  //TEXT_ALIGN_VCENTER)
							{
								rcText.top=line*itemSy+itemSy/2-syText/2;
								rcText.bottom=rcText.top+syText;
								yObject=line*itemSy+itemSy/2-hoPtr.hoImgHeight/2;
								dtFlags|=CServices.DT_VCENTER;
							}
							else											// (textAlignment&TEXT_ALIGN_BOTTOM)
							{
								sy=hoPtr.hoImgHeight+SY_SEPARATION+syText;
								yObject=line*itemSy+itemSy/2-sy/2;
								rcText.top=yObject+hoPtr.hoImgHeight+SY_SEPARATION;
								rcText.bottom=rcText.top+syText;
								dtFlags|=CServices.DT_TOP;
							}
							if (pItem.GetQuantity()>=displayQuantity)
							{
								textSurface.manualDrawText(text, dtFlags, rcText, fontColor, font.getFontInfo(), true);
								uploadTexture = true;
							}

						}
						if (bUpdateList)
						{
							SetPosition(hoPtr, ho.hoX+xObject, ho.hoY+yObject);
						}
					}
					else
					{
						obHide(hoPtr);
					}
				}
			}
			if(uploadTexture)
				textSurface.updateTexture();

			textSurface.draw(ho.hoX, ho.hoY, 0, 0);

			SetSlider();
			slider.DrawBar();
		}
		else
		{
			if ((flags&IFLAG_DISPLAYGRID)!=0)
			{
				rc=new CRect();
				for (y=0; y<nLines; y++)
				{
					for (x=0; x<nColumns; x++)
					{
						GetGridRect(x, y, rc);
						invDrawRect(rc.left, rc.top, rc.right-rc.left, rc.bottom-rc.top, gridColor, 1);
					}
				}		

				if (bDropItem==false)
				{
					GetGridRect(xCursor, yCursor, rc);
				}
				else
				{
					rc.copyRect(rcDrop);
				}
				if (bDropItem || ((flags&IFLAG_FORCECURSOR)!=0 && cursorType>0)) 
				{
					renderer.renderGradient(rc.left, rc.top, rc.right-rc.left, rc.bottom-rc.top, cursorColor, cursorColor, false, 0, 0);
				}
			}
			if (bUpdateList)
			{
				for (int o=0; o<displayList.size(); o++)
				{
					CObject hoPtr=GetHO(objectList.get(o));
					if (hoPtr!=null)
					{
						CRunInventoryItem pItem=displayList.get(o);
						obShow(hoPtr);

						sx=(hoPtr.hoImgWidth+itemSx-1)/itemSx;
						sy=(hoPtr.hoImgHeight+itemSy-1)/itemSy;
						rc=new CRect();
						GetGridRect(pItem.x, pItem.y, rc);
						xObject=(rc.left+rc.right)/2-sx-hoPtr.hoImgWidth/2;
						yObject=(rc.top+rc.bottom)/2-sy-hoPtr.hoImgHeight/2;
						SetPosition(hoPtr, xObject, yObject);
					}
				}
			}
		}
		bUpdateList=false;
		bDropItem=false;
	}

	@Override
	public CFontInfo getRunObjectFont()
	{
		return logFont;
	}

	@Override
	public void setRunObjectFont(CFontInfo fi, CRect  rc)
	{
		logFont = fi;
		font = CFont.createFromFontInfo(fi);
		if (rc!=null)
		{
			ho.hoImgWidth=rc.right-rc.left;
			ho.hoImgHeight=rc.bottom-rc.top;
		}
		ho.redraw();
	}

	@Override
	public int  getRunObjectTextColor()
	{
		return fontColor;
	}

	@Override
	public void setRunObjectTextColor(int rgb)
	{
		fontColor = rgb;
		ho.redraw();
	}



	@Override
	public boolean condition(int num, CCndExtension cnd)
	{
		switch(num)
		{
		case CND_NAMEDITEMSELECTED:
			return RCND_NAMEDITEMSELECTED(cnd);
		case CND_NAMEDCOMPARENITEMS:
			return RCND_NAMEDCOMPARENITEMS(cnd);
		case CND_ITEMSELECTED:
			return RCND_ITEMSELECTED(cnd);
		case CND_COMPARENITEMS:
			return RCND_COMPARENITEMS(cnd);
		case CND_NAMEDITEMPRESENT:
			return RCND_NAMEDITEMPRESENT(cnd);
		case CND_ITEMPRESENT:
			return RCND_ITEMPRESENT(cnd);
		case CND_NAMEDHILIGHTED:
			return RCND_NAMEDHILIGHTED(cnd);
		case CND_HILIGHTED:
			return RCND_HILIGHTED(cnd);
		case CND_CANADD:
			return RCND_CANADD(cnd);
		case CND_NAMEDCANADD:
			return RCND_NAMEDCANADD(cnd);												
		}
		return false;
	}

	private Boolean  RCND_NAMEDITEMSELECTED(CCndExtension cnd)
	{
		String pName=cnd.getParamExpString(rh, 0);
		if (pName.contentEquals(conditionString))
		{
			if ((ho.hoFlags & CObject.HOF_TRUEEVENT)!=0)
			{
				return true;
			}

			if (rh.rh4EventCount == selectedCount)
			{
				return true;
			}
		}
		return false;
	}
	private Boolean  RCND_NAMEDCOMPARENITEMS(CCndExtension cnd)
	{
		CRunInventoryItem pItem=inventory.GetItem(number, cnd.getParamExpString(rh, 0));
		if (pItem!=null)
		{
			if(pItem.GetQuantity() > 0)
				return true;
		}
		return false;
	}
	private Boolean  RCND_ITEMSELECTED(CCndExtension cnd)
	{
		int oi=cnd.getParamObject(rh, 0).oi;

		if (oi==rh.rhEvtProg.rhCurParam0)
		{
			if ((ho.hoFlags & CObject.HOF_TRUEEVENT)!=0)
			{
				return true;
			}

			if (rh.rh4EventCount == selectedCount)
			{
				return true;
			}
		}
		return false;
	}
	private Boolean  RCND_COMPARENITEMS(CCndExtension cnd)
	{
		int oi=cnd.getParamObject(rh, 0).oi;

		for (int n=0; n<objectList.size(); n++)
		{
			CObject hoPtr=GetHO(objectList.get(n));
			if (hoPtr.hoOi==oi)
			{
				CRunInventoryItem pItem=displayList.get(n);
				if(pItem != null ) {
					expRet.forceInt(pItem.GetQuantity());
					return cnd.compareValues(rh, 1, expRet);
				}
			}
		}
		return false;
	}
	private Boolean  RCND_NAMEDITEMPRESENT(CCndExtension cnd)
	{
		CRunInventoryItem pItem=inventory.GetItem(number, cnd.getParamExpString(rh, 0));
		if (pItem!=null)
		{
			if (pItem.GetQuantity()>0)
			{
				return true;
			}
		}
		return false;
	}
	private Boolean  RCND_ITEMPRESENT(CCndExtension cnd)
	{
		int oi=cnd.getParamObject(rh, 0).oi;

		int n;
		for (n=0; n<objectList.size(); n++)
		{
			CObject hoPtr=GetHO(objectList.get(n));
			if (hoPtr.hoOi==oi)
			{
				CRunInventoryItem pItem=displayList.get(n);
				if (pItem.GetQuantity()>0)
				{
					return true;
				}
			}
		}
		return false;
	}
	private Boolean  RCND_NAMEDHILIGHTED(CCndExtension cnd)
	{
		String pName=cnd.getParamExpString(rh, 0);
		if (pNameHilighted!=null)
		{
			if (pName.contentEquals(pNameHilighted))
			{
				return true;
			}
		}
		return false;
	}
	private Boolean  RCND_HILIGHTED(CCndExtension cnd)
	{
		int oiList=cnd.getParamObject(rh, 0).oiList;
		CObjInfo pOiList=rh.rhOiList[oiList];
		if (pNameHilighted!=null)
		{
			if (pOiList.oilName.contentEquals(pNameHilighted))
			{
				return true;
			}
		}
		return false;
	}

	private Boolean  RCND_CANADD(CCndExtension cnd)
	{
		if (type!=INVTYPE_GRID)
		{
			return false;
		}

		int xx=cnd.getParamExpression(rh, 1);
		int yy=cnd.getParamExpression(rh, 2);

		if (xx<0 || xx>=nColumns || yy<0 || yy>=nLines)
		{
			return false;
		}

		CObject hoPtr;
		CObjInfo pOiList=rh.rhOiList[cnd.getParamObject(rh, 0).oiList];
		int number=pOiList.oilObject;
		if (number>=0)
		{
			hoPtr=rh.rhObjectList[number];
			int sx=(hoPtr.hoImgWidth+itemSx-1)/itemSx;
			int sy=(hoPtr.hoImgHeight+itemSy-1)/itemSy;
			if (xx+sx>nColumns || yy+sy>nLines)
			{
				return false;
			}
			int x, y;
			for (y=0; y<sy; y++)
			{
				for (x=0; x<sx; x++)
				{
					if (pGrid[(yy+y)*nColumns+xx+x]!=0)
					{
						return false;
					}
				}
			}
			rcDrop.left=ho.hoX+xx*itemSx;
			rcDrop.right=rcDrop.left+itemSx;
			rcDrop.top=ho.hoY+yy*itemSy;
			rcDrop.bottom=rcDrop.top+itemSy;
			bDropItem=true;
			return true;
		}
		return false;
	}
	private Boolean  GridCanAdd(String pName, int  xx, int  yy, Boolean  bDrop)
	{
		if (type!=INVTYPE_GRID)
		{
			return false;
		}
		if (xx<0 || xx>=nColumns || yy<0 || yy>=nLines)
		{
			return false;
		}

		CObject hoPtr;
		int n;
		for (n=0; n<rh.rhOiList.length; n++)
		{
			if (rh.rhOiList[n].oilName.contentEquals(pName))
			{
				int number = rh.rhOiList[n].oilObject;
				if (number>=0)
				{
					hoPtr=rh.rhObjectList[number];
					int sx=(hoPtr.hoImgWidth+itemSx-1)/itemSx;
					int sy=(hoPtr.hoImgHeight+itemSy-1)/itemSy;
					if (xx+sx>nColumns || yy+sy>nLines)
					{
						return false;
					}
					int x, y;
					for (y=0; y<sy; y++)
					{
						for (x=0; x<sx; x++)
						{
							if (pGrid[(yy+y)*nColumns+xx+x]!=0)
							{
								return false;
							}
						}
					}
					if (bDrop)
					{
						rcDrop.left=ho.hoX+xx*itemSx;
						rcDrop.right=rcDrop.left+itemSx;
						rcDrop.top=ho.hoY+yy*itemSy;
						rcDrop.bottom=rcDrop.top+itemSy;
						bDropItem=true;
					}
					return true;
				}
			}
		}
		return false;
	}
	private Boolean  RCND_NAMEDCANADD(CCndExtension cnd)
	{
		if (type==INVTYPE_GRID)
		{
			String name=cnd.getParamExpString(rh, 0);
			int xx=cnd.getParamExpression(rh, 1);
			int yy=cnd.getParamExpression(rh, 2);
			return GridCanAdd(name, xx, yy, true);
		}
		return false;
	}





	@Override
	public void action(int num, CActExtension act)
	{
		switch (num)
		{
		case ACT_NAMEDADDITEM:
			RACT_NAMEDADDITEM(act);
			break;
		case ACT_NAMEDADDNITEMS:
			RACT_NAMEDADDNITEMS(act);
			break;
		case ACT_NAMEDDELITEM:
			RACT_NAMEDDELITEM(act);
			break;
		case ACT_NAMEDDELNITEMS:
			RACT_NAMEDDELNITEMS(act);
			break;
		case ACT_NAMEDHIDEITEM:
			RACT_NAMEDHIDEITEM(act);
			break;
		case ACT_NAMEDSHOWITEM:
			RACT_NAMEDSHOWITEM(act);
			break;
		case ACT_ADDITEM:
			RACT_ADDITEM(act);
			break;
		case ACT_ADDNITEMS:
			RACT_ADDNITEMS(act);
			break;
		case ACT_DELITEM:
			RACT_DELITEM(act);
			break;
		case ACT_DELNITEMS:
			RACT_DELNITEMS(act);
			break;
		case ACT_HIDEITEM:
			RACT_HIDEITEM(act);
			break;
		case ACT_SHOWITEM:
			RACT_SHOWITEM(act);
			break;
		case ACT_LEFT:
			RACT_LEFT(act);
			break;
		case ACT_RIGHT:
			RACT_RIGHT(act);
			break;
		case ACT_UP:
			RACT_UP(act);
			break;
		case ACT_DOWN:
			RACT_DOWN(act);
			break;
		case ACT_SELECT:
			RACT_SELECT(act);
			break;
		case ACT_CURSOR:
			RACT_CURSOR(act);
			break;
		case ACT_NAMEDSETSTRING:
			RACT_NAMEDSETSTRING(act);
			break;
		case ACT_SETSTRING:
			RACT_SETSTRING(act);
			break;
		case ACT_ACTIVATE:
			RACT_ACTIVATE(act);
			break;
		case ACT_NAMEDSETMAXIMUM:
			RACT_NAMEDSETMAXIMUM(act);
			break;
		case ACT_SETMAXIMUM:
			RACT_SETMAXIMUM(act);
			break;
		case ACT_SETPOSITION:
			RACT_SETPOSITION(act);
			break;
		case ACT_SETPAGE:
			RACT_SETPAGE(act);
			break;
		case ACT_ADDPROPERTY:
			RACT_ADDPROPERTY(act);
			break;
		case ACT_NAMEDSETPROPMINMAX:
			RACT_NAMEDSETPROPMINMAX(act);
			break;
		case ACT_SETPROPMINMAX:
			RACT_SETPROPMINMAX(act);
			break;
		case ACT_NAMEDADDPROPERTY:
			RACT_NAMEDADDPROPERTY(act);
			break;
		case ACT_ADDGRIDITEM:
			RACT_ADDGRIDITEM(act);
			break;
		case ACT_ADDGRIDNITEMS:
			RACT_ADDGRIDNITEMS(act);
			break;
		case ACT_NAMEDADDGRIDITEM:
			RACT_NAMEDADDGRIDITEM(act);
			break;
		case ACT_NAMEDADDGRIDNITEMS:
			RACT_NAMEDADDGRIDNITEMS(act);
			break;
		case ACT_HILIGHTDROP:
			RACT_HILIGHTDROP(act);
			break;
		case ACT_NAMEDHILIGHTDROP:
			RACT_NAMEDHILIGHTDROP(act);
			break;
		case ACT_SAVE:
			RACT_SAVE(act);
			break;
		case ACT_LOAD:
			RACT_LOAD(act);
			break;
		case ACT_ADDLISTITEM:
			RACT_ADDLISTITEM(act);
			break;
		case ACT_ADDLISTNITEMS:
			RACT_ADDLISTNITEMS(act);
			break;
		case ACT_NAMEDADDLISTITEM:
			RACT_NAMEDADDLISTITEM(act);
			break;
		case ACT_NAMEDADDLISTNITEMS:
			RACT_NAMEDADDLISTNITEMS(act);
			break;
		}
	}

	private CRunInventoryItem FindItem(String pName)
	{
		int n;
		CObject hoPtr;
		for (n=0; n<objectList.size(); n++)
		{
			hoPtr=GetHO(objectList.get(n));
			if (pName.contentEquals(hoPtr.hoOiList.oilName))
			{
				return displayList.get(n);
			}
		}
		return null;
	}
	private CObject FindHO(String pName)
	{
		int n;
		CObject hoPtr;
		for (n=0; n<objectList.size(); n++)
		{
			hoPtr=GetHO(objectList.get(n));
			if (pName.contentEquals(hoPtr.hoOiList.oilName))
			{
				return hoPtr;
			}
		}
		return null;
	}

	private void RACT_NAMEDADDPROPERTY(CActExtension act)
	{
		String pItem=act.getParamExpString(rh, 0);
		String pProperty=act.getParamExpString(rh, 1);
		int value=act.getParamExpression(rh, 2);
		inventory.AddProperty(number, pItem, pProperty, value);
		return;
	}
	private void RACT_NAMEDSETPROPMINMAX(CActExtension act)
	{
		String pItem=act.getParamExpString(rh, 0);
		String pProperty=act.getParamExpString(rh, 1);
		int min=act.getParamExpression(rh, 2);
		int max=act.getParamExpression(rh, 3);
		inventory.SetPropertyMinimum(number, pItem, pProperty, min);
		inventory.SetPropertyMaximum(number, pItem, pProperty, max);
		return;
	}

	private void RACT_NAMEDADDLISTITEM(CActExtension act)
	{
		if (type==INVTYPE_LIST)
		{
			String pName=act.getParamExpString(rh, 0);
			int pos=act.getParamExpression(rh, 1);
			String namePos="";
			CRunInventoryItem pItem;
			if (pos>=0 && pos<displayList.size())
			{
				pItem=displayList.get(pos);
				namePos=pItem.pName;
			}
			pItem=inventory.AddItemToPosition(number, namePos, pName, 1, maximum, pDisplayString);
			Boolean bAbsent=true;
			int n;
			for (n=0; n<displayList.size(); n++)
			{
				if (pItem==displayList.get(n))
				{
					bAbsent=false;
					break;
				}
			}
			UpdateDisplayList();
			if (bAbsent)
			{
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==displayList.get(n))
					{
						CenterDisplay(n);
						break;
					}
				}
			}
		}
		return;
	}
	private void RACT_NAMEDADDLISTNITEMS(CActExtension act)
	{
		if (type==INVTYPE_LIST)
		{
			String pName=act.getParamExpString(rh, 0);
			int pos=act.getParamExpression(rh, 1);
			int number=act.getParamExpression(rh, 2);
			String namePos="";
			CRunInventoryItem pItem;
			if (pos>=0 && pos<displayList.size())
			{
				pItem=displayList.get(pos);
				namePos=pItem.pName;
			}
			pItem=inventory.AddItemToPosition(number, namePos, pName, number, maximum, pDisplayString);
			Boolean bAbsent=true;
			int n;
			for (n=0; n<displayList.size(); n++)
			{
				if (pItem==displayList.get(n))
				{
					bAbsent=false;
					break;
				}
			}
			UpdateDisplayList();
			if (bAbsent)
			{
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==displayList.get(n))
					{
						CenterDisplay(n);
						break;
					}
				}
			}
		}
		return;
	}
	private void RACT_NAMEDADDITEM(CActExtension act)
	{
		CRunInventoryItem pItem;
		String param1=act.getParamExpString(rh, 0);
		if (type==INVTYPE_LIST)
		{
			pItem=inventory.AddItem(number, param1, 1, maximum, pDisplayString);
			Boolean bAbsent=true;
			int n;
			for (n=0; n<displayList.size(); n++)
			{
				if (pItem==displayList.get(n))
				{
					bAbsent=false;
					break;
				}
			}
			UpdateDisplayList();
			if (bAbsent)
			{
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==displayList.get(n))
					{
						CenterDisplay(n);
						break;
					}
				}
			}
		}
		else
		{
			int x, y;
			for (y=0; y<nLines; y++)
			{
				for (x=0; x<nColumns; x++)
				{
					if (GridCanAdd(param1, x, y, false))
					{
						pItem=inventory.AddItem(number, param1, 1, maximum, pDisplayString);
						pItem.x=x;
						pItem.y=y;
						UpdateDisplayList();
						return;
					}
				}
			}
		}
		return;
	}

	private void RACT_NAMEDADDNITEMS(CActExtension act)
	{
		String param1=act.getParamExpString(rh, 0);
		int param2=act.getParamExpression(rh, 1);
		if (param2>=0)
		{
			CRunInventoryItem pItem;
			if (type==INVTYPE_LIST)
			{
				pItem=inventory.AddItem(number, param1, param2, maximum, pDisplayString);
				Boolean bAbsent=true;
				int n;
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==displayList.get(n))
					{
						bAbsent=false;
						break;
					}
				}
				UpdateDisplayList();
				if (bAbsent)
				{
					for (n=0; n<displayList.size(); n++)
					{
						if (pItem==displayList.get(n))
						{
							CenterDisplay(n);
							break;
						}
					}
				}
			}
			else
			{
				int x, y;
				for (y=0; y<nLines; y++)
				{
					for (x=0; x<nColumns; x++)
					{
						if (GridCanAdd(param1, x, y, false))
						{
							pItem=inventory.AddItem(number, param1, param2, maximum, pDisplayString);
							pItem.x=x;
							pItem.y=y;
							UpdateDisplayList();
							return;
						}
					}
				}
			}
		}
		return;
	}

	private void RACT_NAMEDSETMAXIMUM(CActExtension act)
	{
		String param1=act.getParamExpString(rh, 0);
		int param2=act.getParamExpression(rh, 1);
		if (param2>=0)
		{
			inventory.SetMaximum(number, param1, param2);
			UpdateDisplayList();
		}
		return;
	}

	private void RACT_NAMEDDELITEM(CActExtension act)
	{
		String param1=act.getParamExpString(rh, 0);
		CObject hoPtr=FindHO(param1);
		if (inventory.SubQuantity(number, param1, 1))
		{
			if (hoPtr!=null)
			{
				obHide(hoPtr);
			}
		}
		UpdateDisplayList();
		return;
	}

	private void RACT_NAMEDDELNITEMS(CActExtension act)
	{
		String param1=act.getParamExpString(rh, 0);
		int param2=act.getParamExpression(rh, 1);
		if (param2>=0)
		{
			CObject hoPtr=FindHO(param1);
			if (inventory.SubQuantity(number, param1, param2))
			{
				if (hoPtr!=null)
				{
					obHide(hoPtr);
				}
			}
			UpdateDisplayList();
		}
		return;
	}
	private void RACT_NAMEDHIDEITEM(CActExtension act)
	{
		String param1=act.getParamExpString(rh, 0);
		inventory.SetFlags(number, param1, ~CRunInventoryItem.FLAG_VISIBLE, 0);
		UpdateDisplayList();
		return;
	}
	private void RACT_NAMEDSHOWITEM(CActExtension act)
	{
		String param1=act.getParamExpString(rh, 0);
		inventory.SetFlags(number, param1, -1, CRunInventoryItem.FLAG_VISIBLE);
		UpdateDisplayList();
		return;
	}
	private void RACT_ADDLISTITEM(CActExtension act)
	{
		if (type==INVTYPE_LIST)
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			String pName=hoPtr.hoOiList.oilName;

			int pos=act.getParamExpression(rh, 1);
			String namePos="";
			CRunInventoryItem pItem;
			if (pos>=0 && pos<displayList.size())
			{
				pItem=displayList.get(pos);
				namePos=pItem.pName;
			}
			pItem=inventory.AddItemToPosition(number, namePos, pName, 1, maximum, pDisplayString);
			Boolean bAbsent=true;
			int n;
			for (n=0; n<displayList.size(); n++)
			{
				if (pItem==displayList.get(n))
				{
					bAbsent=false;
					break;
				}
			}
			UpdateDisplayList();
			if (bAbsent)
			{
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==displayList.get(n))
					{
						CenterDisplay(n);
						break;
					}
				}
			}
		}
		return;
	}
	private void RACT_ADDLISTNITEMS(CActExtension act)
	{
		if (type==INVTYPE_LIST)
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			String pName=hoPtr.hoOiList.oilName;
			int pos=act.getParamExpression(rh, 1);
			int number=act.getParamExpression(rh, 2);
			String namePos="";
			CRunInventoryItem pItem;
			if (pos>=0 && pos<displayList.size())
			{
				pItem=displayList.get(pos);
				namePos=pItem.pName;
			}
			pItem=inventory.AddItemToPosition(number, namePos, pName, number, maximum, pDisplayString);
			Boolean bAbsent=true;
			int n;
			for (n=0; n<displayList.size(); n++)
			{
				if (pItem==displayList.get(n))
				{
					bAbsent=false;
					break;
				}
			}
			UpdateDisplayList();
			if (bAbsent)
			{
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==displayList.get(n))
					{
						CenterDisplay(n);
						break;
					}
				}
			}
		}
		return;
	}
	private void RACT_ADDITEM(CActExtension act)
	{
		CObject hoPtr=act.getParamObject(rh, 0);
		CObjInfo pOiList=hoPtr.hoOiList;
		CRunInventoryItem pItem;
		if (type==INVTYPE_LIST)
		{
			pItem=inventory.AddItem(number, pOiList.oilName, 1, maximum, pDisplayString);
			Boolean bAbsent=true;
			int n;
			for (n=0; n<displayList.size(); n++)
			{
				if (pItem==displayList.get(n))
				{
					bAbsent=false;
					break;
				}
			}
			UpdateDisplayList();
			if (bAbsent)
			{
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==displayList.get(n))
					{
						CenterDisplay(n);
						break;
					}
				}
			}
		}
		else
		{
			int x, y;
			for (y=0; y<nLines; y++)
			{
				for (x=0; x<nColumns; x++)
				{
					if (GridCanAdd(pOiList.oilName, x, y, false))
					{
						pItem=inventory.AddItem(number, pOiList.oilName, 1, maximum, pDisplayString);
						pItem.x=x;
						pItem.y=y;
						UpdateDisplayList();
						return;
					}
				}
			}
		}
		return;
	}
	private void RACT_ADDPROPERTY(CActExtension act)
	{
		CObject hoPtr=act.getParamObject(rh, 0);
		String pProperty=act.getParamExpString(rh, 1);
		int value=act.getParamExpression(rh, 2);

		CObjInfo pOiList=hoPtr.hoOiList;
		inventory.AddProperty(number, pOiList.oilName, pProperty, value);
		return;
	}
	private void RACT_SETPROPMINMAX(CActExtension act)
	{
		CObject hoPtr=act.getParamObject(rh, 0);
		String pProperty=act.getParamExpString(rh, 1);
		int min=act.getParamExpression(rh, 2);
		int max=act.getParamExpression(rh, 3);

		CObjInfo pOiList=hoPtr.hoOiList;
		inventory.SetPropertyMinimum(number, pOiList.oilName, pProperty, min);
		inventory.SetPropertyMaximum(number, pOiList.oilName, pProperty, max);
		return;
	}
	private void RACT_ADDNITEMS(CActExtension act)
	{
		int param2 = act.getParamExpression(rh, 1);
		if (param2 >= 0)
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			CObjInfo pOiList=hoPtr.hoOiList;
			CRunInventoryItem pItem;
			if (type==INVTYPE_LIST)
			{
				pItem=inventory.AddItem(number, pOiList.oilName, param2, maximum, pDisplayString);
				Boolean bAbsent=true;
				int n;
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==displayList.get(n))
					{
						bAbsent=false;
						break;
					}
				}
				UpdateDisplayList();
				if (bAbsent)
				{
					for (n=0; n<displayList.size(); n++)
					{
						if (pItem==displayList.get(n))
						{
							CenterDisplay(n);
							break;
						}
					}
				}
			}
			else
			{
				int x, y;
				for (y=0; y<nLines; y++)
				{
					for (x=0; x<nColumns; x++)
					{
						if (GridCanAdd(pOiList.oilName, x, y, false))
						{
							pItem=inventory.AddItem(number, pOiList.oilName, param2, maximum, pDisplayString);
							pItem.x=x;
							pItem.y=y;
							UpdateDisplayList();
							return;
						}
					}
				}
			}
		}
		return;
	}
	private void RACT_SETMAXIMUM(CActExtension act)
	{
		int param2 = act.getParamExpression(rh, 1);
		if (param2>=0)
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			CObjInfo pOiList=hoPtr.hoOiList;
			inventory.SetMaximum(number, pOiList.oilName, param2);
			UpdateDisplayList();
		}
		return;
	}
	private void RACT_DELITEM(CActExtension act)
	{
		CObject hoPtr=act.getParamObject(rh, 0);
		CObjInfo pOiList=hoPtr.hoOiList;
		hoPtr=FindHO(pOiList.oilName);
		if (inventory.SubQuantity(number, pOiList.oilName, 1))
		{
			if (hoPtr!=null)
			{
				obHide(hoPtr);
			}
		}
		UpdateDisplayList();
		return;
	}
	private void RACT_DELNITEMS(CActExtension act)
	{
		int param2=act.getParamExpression(rh, 1);
		if (param2>=0)
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			CObjInfo pOiList=hoPtr.hoOiList;
			hoPtr=FindHO(pOiList.oilName);
			if (inventory.SubQuantity(number, pOiList.oilName, param2))
			{
				if (hoPtr!=null)
				{
					obHide(hoPtr);
				}
			}
			UpdateDisplayList();
		}
		return;
	}
	private void RACT_HIDEITEM(CActExtension act)
	{
		CObject hoPtr=act.getParamObject(rh, 0);
		CObjInfo pOiList=hoPtr.hoOiList;
		inventory.SetFlags(number, pOiList.oilName, ~CRunInventoryItem.FLAG_VISIBLE, 0);
		UpdateDisplayList();
		return;
	}
	private void RACT_SHOWITEM(CActExtension act)
	{
		CObject hoPtr=act.getParamObject(rh, 0);
		CObjInfo pOiList=hoPtr.hoOiList;
		inventory.SetFlags(number, pOiList.oilName, -1, CRunInventoryItem.FLAG_VISIBLE);
		UpdateDisplayList();
		return;
	}

	private void RACT_LEFT(CActExtension act)
	{
		if (displayList.size()>0)
		{
			xCursor--;
			if (xCursor<0)
			{
				xCursor++;
				position=Math.max(position-1, 0);
			}
			bRedraw=true;
		}
		return;
	}
	private void RACT_RIGHT(CActExtension act)
	{
		if (displayList.size()>0)
		{
			xCursor++;
			if (xCursor>=nColumns)
			{
				xCursor--;
				position=Math.min(position+1, displayList.size()-nColumns*nLines);
			}
			bRedraw=true;
		}
		return;
	}
	private void RACT_UP(CActExtension act)
	{
		if (displayList.size()>0)
		{
			yCursor--;
			if (yCursor<0)
			{
				yCursor++;
				position=Math.max(position-nColumns, 0);
			}
			bRedraw=true;
		}
		return;
	}
	private void RACT_DOWN(CActExtension act)
	{
		if (displayList.size()>0)
		{
			yCursor++;
			if (yCursor>=nLines)
			{
				yCursor--;
				position=Math.min(position+nColumns, displayList.size()-nColumns*nLines);
			}
			bRedraw=true;
		}
		return;
	}
	private void RACT_SELECT(CActExtension act)
	{
		if (displayList.size()>0)
		{
			selectedCount=rh.rh4EventCount;
			CRunInventoryItem pItem=displayList.get(position+yCursor*nColumns+xCursor);
			CObject hoPtr=GetHO(objectList.get(position+yCursor*nColumns+xCursor));
			conditionString=pItem.GetName();
			ho.generateEvent(CND_NAMEDITEMSELECTED, 0);
			ho.generateEvent(CND_ITEMSELECTED, hoPtr.hoOi);
			bRedraw=true;
		}
		return;
	}
	private void RACT_CURSOR(CActExtension act)
	{
		int param1 = act.getParamExpression(rh, 0);
		if (param1==0)
		{
			flags&=~(IFLAG_FORCECURSOR|IFLAG_CURSORBYACTION);
		}
		else
		{
			flags|=IFLAG_FORCECURSOR|IFLAG_CURSORBYACTION;
		}
		bRedraw=true;
		return;
	}
	private void RACT_ACTIVATE(CActExtension act)
	{
		int param1 = act.getParamExpression(rh, 0);
		if (param1 != 0)
		{
			bActivated=true;
			flags|=IFLAG_CURSOR|IFLAG_FORCECURSOR;
		}
		else
		{
			bActivated=false;
			flags&=~(IFLAG_CURSOR|IFLAG_FORCECURSOR);
		}
		bRedraw=true;
		return;
	}
	private void RACT_NAMEDSETSTRING(CActExtension act)
	{
		inventory.SetDisplayString(number, act.getParamExpString(rh, 0), act.getParamExpString(rh, 1));
		UpdateDisplayList();
		return;
	}
	private void RACT_SETSTRING(CActExtension act)
	{
		CObject hoPtr=act.getParamObject(rh, 0);
		CObjInfo pOiList=hoPtr.hoOiList;
		inventory.SetDisplayString(number, pOiList.oilName, act.getParamExpString(rh, 1));
		UpdateDisplayList();
		return;
	}
	private void RACT_SETPOSITION(CActExtension act)
	{
		int param1=act.getParamExpression(rh, 1);
		if (type==INVTYPE_LIST)
		{
			if (param1<0)
				param1=0;
			int last=Math.max(displayList.size()-nLines*nColumns, 0);
			if (param1>last)
				param1=last;
			position=last;
			bRedraw=true;
		}
		return;
	}
	private void RACT_SETPAGE(CActExtension act)
	{
		int param1=act.getParamExpression(rh, 1);
		if (type==INVTYPE_LIST)
		{
			param1=nLines*nColumns;
			if (param1<0)
				param1=0;
			int last=Math.max(displayList.size()-nLines*nColumns, 0);
			if (param1>last)
				param1=last;
			position=last;
			bRedraw=true;
		}
		return;
	}
	private void RACT_ADDGRIDITEM(CActExtension act)
	{
		if (type==INVTYPE_GRID)
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			int x=act.getParamExpression(rh, 1);
			int y=act.getParamExpression(rh, 2);
			CObjInfo pOiList=hoPtr.hoOiList;
			if (GridCanAdd(pOiList.oilName, x, y, false))
			{
				CRunInventoryItem pItem=FindItem(pOiList.oilName);
				if (pItem==null)
				{
					pItem=inventory.AddItem(number, pOiList.oilName, 1, maximum, pDisplayString);
				}
				else if (pItem.x==x && pItem.y==y)
				{
					inventory.AddItem(number, pOiList.oilName, 1, maximum, pDisplayString);
				}
				pItem.x=x;
				pItem.y=y;
				UpdateDisplayList();
			}
		}
		return;
	}
	private void RACT_ADDGRIDNITEMS(CActExtension act)
	{
		if (type==INVTYPE_GRID)
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			int number=act.getParamExpression(rh, 1);
			int x=act.getParamExpression(rh, 2);
			int y=act.getParamExpression(rh, 3);
			CObjInfo pOiList=hoPtr.hoOiList;
			if (GridCanAdd(pOiList.oilName, x, y, false))
			{
				CRunInventoryItem pItem=FindItem(pOiList.oilName);
				if (pItem==null)
				{
					pItem=inventory.AddItem(number, pOiList.oilName, number, maximum, pDisplayString);
				}
				else if (pItem.x==x && pItem.y==y)
				{
					inventory.AddItem(number, pOiList.oilName, number, maximum, pDisplayString);
				}
				pItem.x=x;
				pItem.y=y;
				UpdateDisplayList();
			}
		}
		return;
	}
	private void RACT_NAMEDADDGRIDITEM(CActExtension act)
	{
		if (type==INVTYPE_GRID)
		{
			String pName=act.getParamExpString(rh, 0);
			int x=act.getParamExpression(rh, 1);
			int y=act.getParamExpression(rh, 2);
			if (GridCanAdd(pName, x, y, false))
			{
				CRunInventoryItem pItem=FindItem(pName);
				if (pItem==null)
				{
					pItem=inventory.AddItem(number, pName, 1, maximum, pDisplayString);
				}
				else if (pItem.x==x && pItem.y==y)
				{
					inventory.AddItem(number, pName, 1, maximum, pDisplayString);
				}
				pItem.x=x;
				pItem.y=y;
				UpdateDisplayList();
			}
		}
		return;
	}
	private void RACT_NAMEDADDGRIDNITEMS(CActExtension act)
	{
		if (type==INVTYPE_GRID)
		{
			String pName=act.getParamExpString(rh, 0);
			int number=act.getParamExpression(rh, 1);
			int x=act.getParamExpression(rh, 2);
			int y = act.getParamExpression(rh, 3);
			if (GridCanAdd(pName, x, y, false))
			{
				CRunInventoryItem pItem=FindItem(pName);
				if (pItem==null)
				{
					pItem=inventory.AddItem(number, pName, number, maximum, pDisplayString);
				}
				else if (pItem.x==x && pItem.y==y)
				{
					inventory.AddItem(number, pName, number, maximum, pDisplayString);
				}
				pItem.x=x;
				pItem.y=y;
				UpdateDisplayList();
			}
		}
		return;
	}

	private void HilightDrop(String pName, int  xx, int  yy)
	{
		if (xx<0 || xx>=nColumns || yy<0 || yy>=nLines)
		{
			return;
		}

		CObject hoPtr;
		int n;		
		for (n=0; n<rh.rhOiList.length; n++)
		{
			if (rh.rhOiList[n].oilName.contentEquals(pName))
			{
				int number=rh.rhOiList[n].oilObject;
				if (number>=0)
				{
					hoPtr=rh.rhObjectList[number];
					int sx=(hoPtr.hoImgWidth+itemSx-1)/itemSx;
					int sy=(hoPtr.hoImgHeight+itemSy-1)/itemSy;
					if (xx+sx<=nColumns && yy+sy<=nLines)
					{
						rcDrop.left=ho.hoX+xx*itemSx;
						rcDrop.right=rcDrop.left+itemSx*sx;
						rcDrop.top = ho.hoY+yy*itemSy;
						rcDrop.bottom=rcDrop.top+itemSy*sy;
						bDropItem=true;
						xCursor=xx;
						yCursor=yy;
						ho.redraw();
					}
				}
			}
		}
	}				
	private void RACT_HILIGHTDROP(CActExtension act)
	{
		if (type==INVTYPE_GRID)
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			int x=act.getParamExpression(rh, 1);
			int y=act.getParamExpression(rh, 2);
			CObjInfo pOiList=hoPtr.hoOiList;
			HilightDrop(pOiList.oilName, x, y);
		}
		return;
	}
	private void RACT_NAMEDHILIGHTDROP(CActExtension act)
	{
		if (type==INVTYPE_GRID)
		{
			String pName=act.getParamExpString(rh, 0);
			int x=act.getParamExpression(rh, 1);
			int y=act.getParamExpression(rh, 2);
			HilightDrop(pName, x, y);
		}
		return;
	}

	private String cleanName(String name)
	{
		int pos = name.lastIndexOf('\\');
		if (pos < 0)
		{
			pos = name.lastIndexOf('/');
		}
		if (pos >= 0 && pos + 1 < name.length())
		{
			name = name.substring(pos + 1);
		}
		return name;
	}

	private void RACT_SAVE(CActExtension act)
	{
		String path=cleanName(act.getParamFilename(rh, 0));
		try{
			FileOutputStream out = MMFRuntime.inst.openFileOutput(path, Context.MODE_PRIVATE);

			int count = inventory.Save(null);
			pointer data = new pointer(count);
			inventory.Save(data);
			out.write(data.getBytes());
			out.close();
		}
		catch (Exception e)
		{      
			e.printStackTrace();
		}

		return;
	}
	private void RACT_LOAD(CActExtension act)
	{
		String path=MMFRuntime.inst.getFilesDir ().toString ()+"/"+cleanName(act.getParamFilename(rh, 0));

		File cfile = new File(path);
		byte[] data = new byte[(int) cfile.length()];
		if(data.length!=0)
		{
			CFile file= new CFile(path);

			inventory.Load(file);
			file.finalize();
			position=0;
			xCursor=0;
			yCursor=0;
			bUpdateList = true;
			UpdateDisplayList();
			bActivated = true;
		}
		return;
	}					

	class pointer {
		byte[] data;
		int index;
		int length;

		pointer(int size) {
			data = new byte[size];
			length = data.length;
			index = 0;
		}

		public void addByte(byte a) {
			data[index] = a;
			index++;			
		}

		public void addBytes(byte[] a) {
			for(int i=0; i < a.length; i++) {
				data[index] = a[i];
				index++;
			}
			index+=1;
		}

		public byte[] getBytes() {
			return data;
		}
	}

	public static int WriteAString(pointer ptr, String text)
	{
		int l =0;
		try {
			l=text.getBytes("UTF-8").length;
			if (ptr!=null)
			{
				ptr.addBytes(text.getBytes("UTF-8"));
			}       
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return l+1;
	}
	public static int WriteAByte(pointer ptr, byte value)
	{
		if (ptr!=null)
		{
			ptr.addByte(value);
		}
		return 1;
	}
	public static int WriteAShort(pointer ptr, short value)
	{
		if (ptr!=null)
		{
			ptr.addByte((byte) (value&0xFF));
			ptr.addByte((byte) ((value>>8)&0xFF));
			//ptr.addByte((byte) (0));
			//ptr.addByte((byte) (0));
		}
		return 4;
	}
	public static int WriteAnInt(pointer ptr, int value)
	{
		if (ptr!=null)
		{
			ptr.addByte((byte) (value&0xFF));
			ptr.addByte((byte) ((value>>8)&0xFF));
			ptr.addByte((byte) ((value>>16)&0xFF));
			ptr.addByte((byte) ((value>>24)&0xFF));
		}
		return 4;
	}	
	////////////////////////////////////////////
	//
	//           Expressions
	//
	////////////////////////////////////////////
	@Override
	public CValue expression(int num)
	{
		switch (num)
		{
		case EXP_NITEM:
			return REXP_NITEM();
		case EXP_NAMEOFHILIGHTED:
			return REXP_NAMEOFHILIGHTED();
		case EXP_NAMEOFSELECTED:
			return REXP_NAMEOFSELECTED();
		case EXP_POSITION:
			return REXP_POSITION();
		case EXP_PAGE:
			return REXP_PAGE();
		case EXP_TOTAL:
			return REXP_TOTAL();
		case EXP_DISPLAYED:
			return REXP_DISPLAYED();
		case EXP_NUMOFSELECTED:
			return REXP_NUMOFSELECTED();
		case EXP_NUMOFHILIGHTED:
			return REXP_NUMOFHILIGHTED();
		case EXP_NAMEOFNUM:
			return REXP_NAMEOFNUM();
		case EXP_MAXITEM:
			return REXP_MAXITEM();
		case EXP_NUMBERMAXITEM:
			return REXP_NUMBERMAXITEM();
		case EXP_NUMBERNITEM:
			return REXP_NUMBERNITEM();
		case EXP_GETPROPERTY:
			return REXP_GETPROPERTY();
		case EXP_NUMBERGETPROPERTY:
			return REXP_NUMBERGETPROPERTY();
		}
		return new CValue(0);
	}

	private CValue REXP_NITEM()
	{
		String pName=ho.getExpParam().getString();
		expRet.forceInt(0);
		CRunInventoryItem pItem=inventory.GetItem(number, pName);
		if (pItem!=null)
		{
			expRet.forceInt(pItem.GetQuantity());
		}
		return expRet;
	}

	private CValue REXP_GETPROPERTY()
	{
		String pName=ho.getExpParam().getString();
		String pProperty=ho.getExpParam().getString();
		CRunInventoryItem pItem=inventory.GetItem(number, pName);
		expRet.forceInt(0);
		if (pItem!=null)
		{
			expRet.forceInt(pItem.GetProperty(pProperty));
		}
		return expRet;
	}

	private CValue REXP_MAXITEM()
	{
		String pName = ho.getExpParam().getString();
		CRunInventoryItem pItem=inventory.GetItem(number, pName);
		expRet.forceInt(0);
		if (pItem!=null)
		{
			expRet.forceInt(pItem.GetMaximum());
		}
		return expRet;
	}

	private CValue REXP_NUMBERNITEM()
	{
		int num = ho.getExpParam().getInt();
		expRet.forceInt(0);
		if (num>=0 && num<displayList.size())
		{
			CRunInventoryItem pItem=displayList.get(num);
			if (pItem!=null)
			{
				expRet.forceInt(pItem.GetQuantity());
			}
		}
		return expRet;
	}

	private CValue REXP_NUMBERGETPROPERTY()
	{
		int num = ho.getExpParam().getInt();
		String pProperty = ho.getExpParam().getString();
		expRet.forceInt(0);
		if (num>=0 && num<displayList.size())
		{
			CRunInventoryItem pItem=displayList.get(num);
			if (pItem!=null)
			{
				expRet.forceInt(pItem.GetProperty(pProperty));
			}
		}
		return expRet;
	}

	private CValue REXP_NUMBERMAXITEM()
	{
		int num = ho.getExpParam().getInt();
		expRet.forceInt(0);
		if (num>=0 && num<displayList.size())
		{
			CRunInventoryItem pItem=displayList.get(num);
			if (pItem!=null)
			{
				expRet.forceInt(pItem.GetMaximum());
			}
		}
		return expRet;
	}

	private CValue REXP_NAMEOFHILIGHTED(  )
	{
		if (pNameHilighted!=null)
			expRet.forceString(pNameHilighted);
		else
			expRet.forceString("");

		return expRet;
	}

	private CValue REXP_NAMEOFSELECTED()
	{
		if (pNameSelected!=null)
			expRet.forceString(pNameSelected);
		else
			expRet.forceString("");

		return expRet;
	}

	private CValue REXP_POSITION()
	{
		expRet.forceInt(position);
		return expRet;
	}

	private CValue REXP_PAGE()
	{
		expRet.forceInt(position/(nLines*nColumns));
		return expRet;
	}

	private CValue REXP_TOTAL()
	{
		expRet.forceInt(displayList.size());
		return expRet;
	}

	private CValue REXP_DISPLAYED()
	{
		expRet.forceInt(Math.min(displayList.size()-position, nLines*nColumns));
		return expRet;
	}

	private CValue REXP_NUMOFSELECTED()
	{
		expRet.forceInt(numSelected);
		return expRet;
	}

	private CValue REXP_NUMOFHILIGHTED()
	{
		expRet.forceInt(numHilighted);
		return expRet;
	}

	private CValue REXP_NAMEOFNUM()
	{
		expRet.forceString("");
		int num = ho.getExpParam().getInt();
		if (num>=0 && num<displayList.size())
		{
			CRunInventoryItem pItem=displayList.get(num);
			expRet.forceString(pItem.GetName());
		}
		return expRet;
	}

	/*
	 *               Utilities
	 * 
	 */

	public void invDrawRect(int x, int y, int w, int h, int color, int thickness)
	{
		GLRenderer renderer = GLRenderer.inst;
		renderer.renderLine(x   , y+h , x+w , y+h , color, thickness);
		renderer.renderLine(x+w , y   , x+w , y+h , color, thickness);
		renderer.renderLine(x   , y   , x+w , y   , color, thickness);
		renderer.renderLine(x   , y   , x   , y+h , color, thickness);

	}

}
