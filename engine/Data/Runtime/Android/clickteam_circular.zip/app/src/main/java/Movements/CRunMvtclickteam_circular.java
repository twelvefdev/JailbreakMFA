/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// CRUNMVTCIRCULAR : Movement circular!
//
//----------------------------------------------------------------------------------

package Movements;

import Animations.CAnim;
import Application.CRunFrame;
import Services.CBinaryFile;

public class CRunMvtclickteam_circular extends CRunMvtExtension
{
    static final int MFLAG1_MOVEATSTART = 1;
    static final int ONEND_STOP = 0;
    static final int ONEND_RESET = 1;
    static final int ONEND_REVERSE_VEL = 2;
    static final int ONEND_REVERSE_DIR = 3;
    int m_dwCX;
    int m_dwCY;
    int m_dwStartAngle;
    int m_dwRadius;
    int m_dwRmin;
    int m_dwRmax;
    int m_dwFlags;
    int m_dwOnEnd;
    int m_dwSpiVel;
    int m_dwAngVel;
    boolean r_Stopped;
    int r_OnEnd;
    int r_CX;
    int r_CY;
    int r_Rmin;
    int r_Rmax;
    double r_AngVel;
    double r_SpiVel;
    double r_CurrentRadius;
    double r_CurrentAngle;

    public CRunMvtclickteam_circular()
    {
    }

    @Override
	public void initialize(CBinaryFile file)
    {
        file.skipBytes(1);
        m_dwCX = file.readInt();
        m_dwCY = file.readInt();
        m_dwRadius = file.readInt();
        m_dwStartAngle = file.readInt();
        m_dwRmin = file.readInt();
        m_dwRmax = file.readInt();
        m_dwFlags = file.readInt();
        m_dwOnEnd = file.readInt();
        m_dwAngVel = file.readInt();
        m_dwSpiVel = file.readInt();

        //*** General variables
//	r_Stopped = (bool)( 1 - m_pMvt->m_dwFlags);
        r_Stopped = ((m_dwFlags & MFLAG1_MOVEATSTART) == 0);
        r_OnEnd = m_dwOnEnd;

        r_CX = m_dwCX;
        r_CY = m_dwCY;
        r_Rmin = m_dwRmin;
        r_Rmax = m_dwRmax;
        r_AngVel = m_dwAngVel / 50.0 * (Math.PI / 180.0);
        r_SpiVel = m_dwSpiVel / 50.0;
        r_CurrentAngle = m_dwStartAngle * (Math.PI / 180.0);
        r_CurrentRadius = m_dwRadius;
        ho.roc.rcSpeed = m_dwAngVel;
    }

    @Override
	public void kill()
    {
    }

    @Override
	public boolean move()
    {
        double calculs;

        //*** Object needs to be moved?
        if (!r_Stopped)
        {
            animations(CAnim.ANIMID_WALK);
            ho.hoX = (int) (r_CX + r_CurrentRadius * Math.cos(r_CurrentAngle));
            ho.hoY = (int) (r_CY - r_CurrentRadius * Math.sin(r_CurrentAngle));
            collisions();

            calculs = r_AngVel;
            if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
            {
                calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
            }
            r_CurrentAngle += calculs;

            if (r_CurrentAngle < 0)
            {
                r_CurrentAngle += 2 * Math.PI;
            }
            else if (r_CurrentAngle > 2 * Math.PI)
            {
                r_CurrentAngle -= 2 * Math.PI;
            }

            if (Math.abs(r_SpiVel) > 0.00001)
            {
                calculs = r_SpiVel;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                r_CurrentRadius += calculs;

                if (r_CurrentRadius < r_Rmin || r_CurrentRadius > r_Rmax)
                {
                    if (r_OnEnd == ONEND_STOP)
                    {
                        r_Stopped = true;
                    }
                    else if (r_OnEnd == ONEND_REVERSE_VEL)
                    {
                        r_SpiVel *= -1;
                    }
                    else if (r_OnEnd == ONEND_REVERSE_DIR)
                    {
                        r_AngVel *= -1;
                        r_SpiVel *= -1;
                    }
                    else if (r_OnEnd == ONEND_RESET)
                    {
                        reset();
                    }
                }
            }
            //*** Indicate the object has been moved
            return true;
        }
        animations(CAnim.ANIMID_STOP);
        collisions();

        //*** The object has not been moved
        return false;
    }
    //*** Reset the movement to restart it ***

    void reset()
    {
        r_CX = m_dwCX;
        r_CY = m_dwCY;
        r_Rmin = m_dwRmin;
        r_Rmax = m_dwRmax;
        r_AngVel = m_dwAngVel / 50.0 * (Math.PI / 180.0);
        r_SpiVel = m_dwSpiVel / 50.0;
        r_CurrentAngle = m_dwStartAngle * (Math.PI / 180.0);
        r_CurrentRadius = m_dwRadius;
    }

    @Override
	public void setPosition(int x, int y)
    {
        r_CX -= ho.hoX - x;
        r_CY -= ho.hoY - y;

        ho.hoX = x;
        ho.hoY = y;
    }

    @Override
	public void setXPosition(int x)
    {
        r_CX -= ho.hoX - x;
        ho.hoX = x;
    }

    @Override
	public void setYPosition(int y)
    {
        r_CY -= ho.hoY - y;
        ho.hoY = y;
    }

    @Override
	public void stop(boolean bCurrent)
    {
        r_Stopped = true;
    }

    @Override
	public void bounce(boolean bCurrent)
    {
    }

    @Override
	public void reverse()
    {
        r_AngVel *= -1;
    }

    @Override
	public void start()
    {
        r_Stopped = false;
    }

    @Override
	public void setSpeed(int speed)
    {
        //*** Linear motion components;
        r_AngVel = (speed) / 50.0 * (Math.PI / 180.0);
        ho.roc.rcSpeed = speed;
    }

    @Override
	public void setMaxSpeed(int speed)
    {
    }

    @Override
	public void setDir(int dir)
    {
    }

    @Override
	public void setAcc(int acc)
    {
    }

    @Override
	public void setDec(int dec)
    {
    }

    @Override
	public void setRotSpeed(int speed)
    {
    }

    @Override
	public void set8Dirs(int dirs)
    {
    }

    @Override
	public void setGravity(int gravity)
    {
    }

    @Override
	public int extension(int function, int param)
    {
        return 0;
    }

    @Override
	public double actionEntry(int action)
    {
        int param;
        switch (action)
        {
            case 3345:		// SET_CENTRE_X = 3345,
                param = (int) getParamDouble();
                r_CX = param;
                return 0;
            case 3346:		// SET_CENTRE_Y,
                param = (int) getParamDouble();
                r_CY = param;
                return 0;
            case 3347:		// SET_ANGSPEED,
                param = (int) getParamDouble();
                r_AngVel = param / 50.0 * (Math.PI / 180.0);
                ho.roc.rcSpeed = param;
                return 0;
            case 3348:		// SET_CURRENTANGLE,
                param = (int) getParamDouble();
                r_CurrentAngle = param * (Math.PI / 180.0);
                return 0;
            case 3349:		// SET_RADIUS,
                param = (int) getParamDouble();
                r_CurrentRadius = Math.max(param, 0);
                return 0;
            case 3350:		// SET_SPIRALVEL,
                param = (int) getParamDouble();
                r_SpiVel = param / 50.0;
                return 0;
            case 3351:		// SET_MINRADIUS,
                param = (int) getParamDouble();
                r_Rmin = Math.min(param, 0);
                return 0;
            case 3352:		// SET_MAXRADIUS,
                param = (int) getParamDouble();
                r_Rmax = Math.min(param, 0);
                return 0;
            case 3353:		// SET_ONCOMPLETION,
                param = (int) getParamDouble();
                int onEnd = param;
                if (onEnd >= ONEND_STOP && onEnd <= ONEND_REVERSE_DIR)
                {
                    r_OnEnd = onEnd;
                }
                return 0;
            case 3354:		// GET_CENTRE_X,
                return r_CX;
            case 3355:		// GET_CENTRE_Y,
                return r_CY;
            case 3356:		// GET_ANGSPEED,
                return r_AngVel * 50.0 * (180.0 / Math.PI);
            case 3357:		// GET_CURRENTANGLE,
                return r_CurrentAngle * (180 / Math.PI);
            case 3358:		// GET_RADIUS,
                return r_CurrentRadius;
            case 3359:		// GET_SPIRALVEL,
                return r_SpiVel * 50;
            case 3360:		// GET_MINRADIUS,
                return r_Rmin;
            case 3361:		// GET_MAXRADIUS
                return r_Rmax;
        }
        return 0;
    }

    @Override
	public int getSpeed()
    {
        return ho.roc.rcSpeed;
    }

    @Override
	public int getAcceleration()
    {
        return 0;
    }

    @Override
	public int getDeceleration()
    {
        return 0;
    }

    @Override
	public int getGravity()
    {
        return 0;
    }

}
