package Extensions;

import RunLoop.CRunMBase;

public class CRunBox2DBaseElementParent extends CRunMBase
{
    public CRunBox2DBaseParent parent;
}
