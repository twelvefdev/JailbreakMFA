/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// CRUNMVTCLICKTEAM-DRAGDROP
//
//----------------------------------------------------------------------------------

package Movements;

import Animations.CAnim;
import OI.COI;
import Objects.CObject;
import Runtime.ITouchAware;
import Runtime.MMFRuntime;
import Services.CBinaryFile;
import Sprites.CSprite;
import Sprites.CSpriteGen;


public class CRunMvtclickteam_dragdrop extends CRunMvtExtension implements ITouchAware
{
	public static final int FLAG_LIMITAREA = 1;
	public static final int FLAG_SNAPTO = 2;
	public static final int FLAG_DROPWHENLEAVE = 4;
	public static final int FLAG_FORCELIMITS = 8;

	public static final int SET_DragDrop_Method = 4145;
	public static final int SET_DragDrop_IsLimited=4146;
	public static final int SET_DragDrop_DropOutsideArea=4147;
	public static final int SET_DragDrop_ForceWithinLimits=4148;
	public static final int SET_DragDrop_AreaX=4149;
	public static final int SET_DragDrop_AreaY=4150;
	public static final int SET_DragDrop_AreaW=4151;
	public static final int SET_DragDrop_AreaH=4152;
	public static final int SET_DragDrop_SnapToGrid=4153;
	public static final int SET_DragDrop_GridX=4154;
	public static final int SET_DragDrop_GridY=4155;
	public static final int SET_DragDrop_GridW=4156;
	public static final int SET_DragDrop_GridH=4157;
	public static final int GET_DragDrop_AreaX=4158;
	public static final int GET_DragDrop_AreaY=4159;
	public static final int GET_DragDrop_AreaW=4160;
	public static final int GET_DragDrop_AreaH=4161;
	public static final int GET_DragDrop_GridX=4162;
	public static final int GET_DragDrop_GridY=4163;
	public static final int GET_DragDrop_GridW=4164;
	public static final int GET_DragDrop_GridH=4165;

	// Donnees edittime
	public int ed_dragWithSelected;
	public int ed_limitX;
	public int ed_limitY;
	public int ed_limitWidth;
	public int ed_limitHeight;
	public int ed_gridOriginX;
	public int ed_gridOriginY;
	public int ed_gridDx;
	public int ed_gridDy;
	public int ed_flags;

	// Donnees yourapplication
	public int dragWith;
	public boolean drag;
	public boolean bMouseDown;
	public boolean keyDown;
	public int clickLoop;

	// Variables for limited area dragging
	public boolean snapToGrid=false;
	public boolean limitedArea=false;
	public boolean dropWhenLeaveArea=false;
	public boolean forceWithinLimits=false;
	public int minX;
	public int minY;
	public int maxX;
	public int maxY;

	public int gridOriginX;
	public int gridOriginY;
	public int gridSizeX;
	public int gridSizeY;
	public int x;
	public int y;

	public int draggedX;
	public int draggedY;

	public int dragOffsetX, dragOffsetY;

	@Override
	public void initialize(CBinaryFile file)
	{
		file.skipBytes(1);

		//Flags
		ed_flags = file.readInt();
		ed_dragWithSelected = file.readInt();
		ed_limitX = file.readInt();
		ed_limitY = file.readInt();
		ed_limitWidth = file.readInt();
		ed_limitHeight = file.readInt();
		ed_gridOriginX = file.readInt();
		ed_gridOriginY = file.readInt();
		ed_gridDx = file.readInt();
		ed_gridDy = file.readInt();

		//*** General variables
		drag = false;
		bMouseDown = false;
		keyDown = false;
		dragWith = ed_dragWithSelected;
		snapToGrid = ((ed_flags & FLAG_SNAPTO) != 0);
		limitedArea = ((ed_flags & FLAG_LIMITAREA) != 0);
		dropWhenLeaveArea = ((ed_flags & FLAG_DROPWHENLEAVE) != 0);
		forceWithinLimits = ((ed_flags & FLAG_FORCELIMITS) != 0);

		// Limit area settings
		minX = ed_limitX;
		minY = ed_limitY;
		maxX = minX + ed_limitWidth;
		maxY = minY + ed_limitHeight;

		// Grid settings
		gridOriginX = ed_gridOriginX;
		gridOriginY = ed_gridOriginY;
		gridSizeX = ed_gridDx;
		gridSizeY = ed_gridDy;

		MMFRuntime.inst.touchManager.addTouchAware (this);
	}

	@Override
	public void kill()
	{
		MMFRuntime.inst.touchManager.removeTouchAware (this);
	}

	public int touch = -1;

	@Override
	public void newTouch (int id, float x, float y)
	{
		x += rh.rhWindowX;
		y += rh.rhWindowY;

		int left = (ho.hoX - ho.hoImgXSpot);
		int right = left + ho.hoImgWidth;
		int top = (ho.hoY - ho.hoImgYSpot);
		int bottom = top + ho.hoImgHeight;

		if(ho.hoAdRunHeader.rhApp.container != null) {
			x -= ho.hoAdRunHeader.rhApp.absoluteX;
			y -= ho.hoAdRunHeader.rhApp.absoluteY;
		}

		if (x >= left && x <= right && y >= top && y <= bottom)
		{
			if (!isTopMostAOAtXY_Transparent ((int) x, (int) y)) {
				return;
			}
			touch = id;

			dragOffsetX = (int) (x - ho.hoX);
			dragOffsetY = (int) (y - ho.hoY);

			draggedX = ho.hoX;
			draggedY = ho.hoY;
			drag = true;           	
			ho.roc.rcSpeed = 50;
		}
		bMouseDown = true;
	}

	@Override
	public void touchMoved (int id, float x, float y)
	{
		if (id == touch)
		{
			x += rh.rhWindowX;
			y += rh.rhWindowY;

			if(ho.hoAdRunHeader.rhApp.container != null) {
				x -= ho.hoAdRunHeader.rhApp.absoluteX;
				y -= ho.hoAdRunHeader.rhApp.absoluteY;
			}

			draggedX = (int) x - dragOffsetX;
			draggedY = (int) y - dragOffsetY;
			drag = true;           	
			bMouseDown = true;
		}
	}

	@Override
	public void endTouch (int id)
	{
		if (id == touch) {
			drag = true;
			bMouseDown = false; 
		}
	}

	public boolean isTopMostAOAtXY_Transparent(int x, int y)
	{
		CObject pRo = null;
		CSprite pSpr = null;

		do
		{
			// Get the next sprite at x,y
			pSpr = ho.hoAdRunHeader.spriteGen.spriteCol_TestPoint
					(pSpr, (short)-1 , x - rh.rhWindowX, y - rh.rhWindowY,
							CSpriteGen.SCF_EVENNOCOL);

			if ( pSpr == null )
				break;

			// Object not being destroyed?
			if ( (pSpr.sprFlags & CSprite.SF_TOKILL) == 0 )
			{
				// Get object pointer
				CObject pHo = pSpr.sprExtraInfo;

				// Active object ?
				if ( pHo != null && pHo.hoType == COI.OBJ_SPR )
					pRo = pHo;

			}
		} while (pSpr != null);

		if (pRo == ho)
			return true;

    	// Explore other objects
    	// ~~~~~~~~~~~~~~~~~~~~~
        int count=0;
    	int i;
    	CObject pHox;
    	int left, top, right, bottom;

    	for (i=0; i<ho.hoAdRunHeader.rhNObjects; i++)
    	{
    		while(ho.hoAdRunHeader.rhObjectList[count]==null)
    			count++;

    		pHox=ho.hoAdRunHeader.rhObjectList[count];
    		count++;		
			if ( pHox.hoType!=COI.OBJ_SPR && (pHox.hoFlags & CObject.HOF_REALSPRITE) == 0 && (pHox.hoFlags & CObject.HOF_DESTROYED) == 0 )
			{
    			left = pHox.hoX - pHox.hoImgXSpot;
    			top = pHox.hoY - pHox.hoImgYSpot;
    			right = left + pHox.hoImgWidth;
    			bottom = top + pHox.hoImgHeight;
    			if (x>=left && x<right && y>=top && y<bottom)
    			{
   					pRo = pHox;
    			}
			}
    	}

    	if ( pRo != null )
    	{
    		if ( pRo == ho )
    		{
    			return true;
    		}
    	}

		return false;
	}

	@Override
	public boolean move()
	{
		if (touch != -1 && (draggedX != ho.hoX || draggedY != ho.hoY))
		{
			ho.hoX = draggedX;
			ho.hoY = draggedY;
		}

		if(drag)
		{
			if(snapToGrid)
			{
				int topX = ((ho.hoX - ho.hoImgXSpot) - gridOriginX) % gridSizeX;
				int topY = ((ho.hoY - ho.hoImgYSpot) - gridOriginY) % gridSizeY;

				ho.hoX -= topX;
				ho.hoY -= topY;
			}

			animations(CAnim.ANIMID_WALK);
			checkLimitedArea ();
			collisions();
			if(!bMouseDown) {
				touch = -1;
				drag = false;
				stop(true);
			}
			return true;
		}
		else
		{        	
			checkLimitedArea ();
			animations(CAnim.ANIMID_STOP);           
			collisions();

			return true;
		}
	}

	@Override
	public boolean stopped ()
	{
		return touch == -1;
	}

	public void checkLimitedArea()
	{
		if( limitedArea )
		{
			// Check x-coordinates
			if( ho.hoX < minX)
			{
				ho.hoX = minX;
				if(dropWhenLeaveArea) touch = -1;
			}
			else if( ho.hoX > maxX)
			{
				ho.hoX = maxX;
				if(dropWhenLeaveArea) touch = -1;
			}

			// Check y-coordinates
			if( ho.hoY < minY)
			{
				ho.hoY = minY;
				if(dropWhenLeaveArea) touch = -1;
			}
			else if( ho.hoY > maxY)
			{
				ho.hoY = maxY;
				if(dropWhenLeaveArea) touch = -1;
			}
		}
	}

	@Override
	public void setPosition(int x, int y)
	{
		draggedX=ho.hoX=x;
		draggedY=ho.hoY=y;
	}

	@Override
	public void setXPosition(int x)
	{
		draggedX=ho.hoX=x;
	}

	@Override
	public void setYPosition(int y)
	{
		draggedY=ho.hoY=y;
	}

	@Override
	public void stop(boolean bCurrent)
	{
		touch = -1;
		ho.roc.rcSpeed = 0;
	}

	@Override
	public void start()
	{
		if (touch != -1)
			return;

		touch = MMFRuntime.inst.touchManager.lastTouch;

		draggedX = rh.rhApp.mouseX;
		draggedY = rh.rhApp.mouseY;

		if (touch == -1)
		{
			touch = 0;
			move ();
			touch = -1;
		}
		else
		{
			move ();
		}
	}

	@Override
	public void bounce(boolean bCurrent)
	{
		if( touch !=1)
		{
			setPosition(draggedX, draggedY);
			stop(true);
		}
	}

	@Override
	public void reverse()
	{
	}

	@Override
	public void setSpeed(int speed)
	{
	}

	@Override
	public void setMaxSpeed(int speed)
	{
	}

	@Override
	public void setDir(int speed)
	{
	}

	@Override
	public void setAcc(int acc)
	{
	}

	@Override
	public void setDec(int dec)
	{
	}

	@Override
	public void setRotSpeed(int speed)
	{
	}

	@Override
	public void set8Dirs(int dirs)
	{
	}

	@Override
	public void setGravity(int gravity)
	{
	}

	//****************************************
	//*** Extension Actions entry ************
	//****************************************
	@Override
	public double actionEntry(int action)
	{
		int param;
		switch (action)
		{
		case SET_DragDrop_Method:
		{
			param=(int)getParamDouble();
			// Methods 0-4 supported
			if ((param >= 0) && (param < 5))
			{
				dragWith = param;
			}
		}
		break;

		case SET_DragDrop_IsLimited:
		{
			param=(int)getParamDouble();
			limitedArea = param != 0;
		}
		break;

		case SET_DragDrop_DropOutsideArea:
		{
			param=(int)getParamDouble();
			dropWhenLeaveArea = param != 0;
		}
		break;

		case SET_DragDrop_ForceWithinLimits:
		{
			param=(int)getParamDouble();
			forceWithinLimits = param != 0;
		}
		break;

		case SET_DragDrop_AreaX:
		{
			param=(int)getParamDouble();
			minX = param;
		}
		break;

		case SET_DragDrop_AreaY:
		{
			param=(int)getParamDouble();
			minY = param;
		}
		break;

		case SET_DragDrop_AreaW:
		{
			param=(int)getParamDouble();
			maxX = minX + param;
		}
		break;

		case SET_DragDrop_AreaH:
		{
			param=(int)getParamDouble();
			maxY = minY + param;
		}
		break;

		case SET_DragDrop_SnapToGrid:
		{
			param=(int)getParamDouble();
			snapToGrid = param != 0;
		}
		break;

		case SET_DragDrop_GridX:
		{
			param=(int)getParamDouble();
			gridOriginX = param;
		}
		break;

		case SET_DragDrop_GridY:
		{
			param=(int)getParamDouble();
			gridOriginY = param;
		}
		break;

		case SET_DragDrop_GridW:
		{
			param=(int)getParamDouble();
			gridSizeX = param;
		}
		break;

		case SET_DragDrop_GridH:
		{
			param=(int)getParamDouble();
			gridSizeY = param;
		}
		break;

		case GET_DragDrop_AreaX:
		{
			return minX;
		}

		case GET_DragDrop_AreaY:
		{
			return minY;
		}

		case GET_DragDrop_AreaW:
		{
			return maxX - minX;
		}

		case GET_DragDrop_AreaH:
		{
			return maxY - minY;
		}

		case GET_DragDrop_GridX:
		{
			return gridOriginX;
		}

		case GET_DragDrop_GridY:
		{
			return gridOriginY;
		}

		case GET_DragDrop_GridW:
		{
			return gridSizeX;
		}

		case GET_DragDrop_GridH:
		{
			return gridSizeY;
		}
		}
		return 0;
	}

	@Override
	public int getSpeed()
	{
		return ho.roc.rcSpeed;
	}

	@Override
	public int getAcceleration()
	{
		return 100;
	}

	@Override
	public int getDeceleration()
	{
		return 100;
	}

	@Override
	public int getGravity()
	{
		return 0;
	}

	@Override
	public int extension(int function, int param)
	{
		return 0;
	}

}
