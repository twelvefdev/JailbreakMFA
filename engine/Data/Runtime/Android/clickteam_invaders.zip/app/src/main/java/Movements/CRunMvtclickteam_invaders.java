/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// CRUNMVTINVADERS
//
//----------------------------------------------------------------------------------

package Movements;

import java.util.ArrayList;

import Animations.CAnim;
import Extensions.CExtStorage;
import Objects.CObject;
import Services.CBinaryFile;

public class CRunMvtclickteam_invaders extends CRunMvtExtension
{
    static final int IDENTIFIER = 2;

    public CRunMvtclickteam_invaders()
    {
    }

    @Override
	public void initialize(CBinaryFile file)
    {
        CGlobalDataInvader data = (CGlobalDataInvader) rh.getStorage(IDENTIFIER);
        if (data == null)
        {
            file.skipBytes(1);
            int m_dwFlagMoveAtStart = file.readInt();
            int m_dwFlagAutoSpeed = file.readInt();
            int m_dwInitialDirection = file.readInt();
            int m_dwDX = file.readInt();
            int m_dwDY = file.readInt();
            int m_dwSpeed = file.readInt();
            int m_dwGroup = file.readInt();

            data = new CGlobalDataInvader();
            data.count = 0;

            if (m_dwFlagMoveAtStart == 1)
            {
                data.isMoving = true;
            }
            else
            {
                data.isMoving = false;
            }

            data.autoSpeed = m_dwFlagAutoSpeed == 1;
            data.dx = m_dwDX;
            data.dy = m_dwDY;
            data.minX = 0;
            data.maxX = ho.hoAdRunHeader.rhLevelSx;
            data.initialSpeed = m_dwSpeed;
            if (m_dwInitialDirection == 0)
            {
                data.cdx = -data.dx;
            }
            else
            {
                data.cdx = data.dx;
            }
            data.speed = 101 - data.initialSpeed;

            data.myList = new ArrayList<CObject>();
            rh.addStorage(data, IDENTIFIER);
        }
        //*** Adds this object to the end of our list
        data.count++;
        data.myList.add(this.ho);
    }

    @Override
	public void kill()
    {
        CGlobalDataInvader data = (CGlobalDataInvader) rh.getStorage(IDENTIFIER);
        if (data != null)
        {
            int n;
            for (n = 0; n < data.myList.size(); n++)
            {
                CObject obj = data.myList.get(n);
                if (obj == ho)
                {
                    data.myList.remove(n);
                    break;
                }
            }
            data.count--;
            if (data.count == 0)
            {
                rh.delStorage(IDENTIFIER);
            }
        }
    }

    @Override
	public boolean move()
    {
        CGlobalDataInvader data = (CGlobalDataInvader) rh.getStorage(IDENTIFIER);
        if (data != null)
        {
            if (!data.isMoving)
            {
                return false;
            }
            if (data.myList.size() > 0)
            {
                CObject myObject = data.myList.get(0);
                if (myObject == this.ho)
                {
                    data.frames++;
                    if (data.frames % data.speed == 0)
                    {
                        data.cdy = 0;

                        //*** Loop over all objects to ensure non have left the playing field
                        int index;
                        CObject hoPtr;
                        for (index = 0; index < data.myList.size(); index++)
                        {
                            hoPtr = data.myList.get(index);
                            if ((hoPtr.hoX < data.minX + hoPtr.hoImgXSpot) && data.cdx < 0)
                            {
                                data.cdx = data.dx;
                                data.cdy = data.dy;
                                break;
                            }
                            else if (hoPtr.hoX > (data.maxX + hoPtr.hoImgXSpot - hoPtr.hoImgWidth) && data.cdx > 0)
                            {
                                data.cdx = -data.dx;
                                data.cdy = data.dy;
                                break;
                            }
                        }

                        //*** Loop over all objects and move them
                        for (index = 0; index < data.myList.size(); index++)
                        {
                            hoPtr = data.myList.get(index);
                            if (data.cdy != 0)
                            {
                                hoPtr.hoY = (hoPtr.hoY + data.cdy);
                                ho.roc.rcAnim = CAnim.ANIMID_WALK;
                                if(hoPtr.roa != null) {
                                    hoPtr.roa.animations();
                                }
                                hoPtr.rom.rmMovement.newMake_Move(hoPtr.roc.rcSpeed, hoPtr.roc.rcDir);
                                //moveIt();
                            }
                            else
                            {
                                hoPtr.hoX = (hoPtr.hoX + data.cdx);
                                ho.roc.rcAnim = CAnim.ANIMID_WALK;
                                if(hoPtr.roa != null) {
                                    hoPtr.roa.animations();
                                }
                                hoPtr.rom.rmMovement.newMake_Move(hoPtr.roc.rcSpeed, hoPtr.roc.rcDir);
                                //moveIt();
                            }
                        }
                    }
                }
            }
            //*** Objects have been moved return true
            if (data.frames % data.speed == 0)
            {
                return true;
            }
        }
        //** The object has not been moved
        return false;
    }

    @Override
	public void setPosition(int x, int y)
    {
        ho.hoX = x;
        ho.hoY = y;
    }

    @Override
	public void setXPosition(int x)
    {
        ho.hoX = x;
    }

    @Override
	public void setYPosition(int y)
    {
        ho.hoY = y;
    }

    @Override
	public void stop(boolean bCurrent)
    {
        CGlobalDataInvader data = (CGlobalDataInvader) rh.getStorage(IDENTIFIER);
        if (data != null)
        {
            data.isMoving = false;
        }
    }

    @Override
	public void bounce(boolean bCurrent)
    {
    }

    @Override
	public void reverse()
    {
        CGlobalDataInvader data = (CGlobalDataInvader) rh.getStorage(IDENTIFIER);
        if (data != null)
        {
            data.cdx *= -1;
        }
    }

    @Override
	public void start()
    {
        CGlobalDataInvader data = (CGlobalDataInvader) rh.getStorage(IDENTIFIER);
        if (data != null)
        {
            data.isMoving = true;
        }
    }

    @Override
	public void setSpeed(int speed)
    {
        CGlobalDataInvader data = (CGlobalDataInvader) rh.getStorage(IDENTIFIER);
        if (data != null)
        {
            data.speed = 101 - speed;
            if (data.speed < 1)
            {
                data.speed = 1;
            }
        }
    }

    @Override
	public void setMaxSpeed(int speed)
    {
    }

    @Override
	public void setDir(int dir)
    {
    }

    @Override
	public void setAcc(int acc)
    {
    }

    @Override
	public void setDec(int dec)
    {
    }

    @Override
	public void setRotSpeed(int speed)
    {
    }

    @Override
	public void set8Dirs(int dirs)
    {
    }

    @Override
	public void setGravity(int gravity)
    {
    }

    @Override
	public int extension(int function, int param)
    {
        return 0;
    }

    @Override
	public double actionEntry(int action)
    {
        CGlobalDataInvader data = (CGlobalDataInvader) rh.getStorage(IDENTIFIER);
        if (data == null)
        {
            return 0;
        }

        int param;
        switch (action)
        {
            case 3745:		// SET_INVADERS_SPEED = 3745,
                param = (int) getParamDouble();
                data.speed = param;
                if (data.speed < 1)
                {
                    data.speed = 1;
                }
                break;
            case 3746:		// SET_INVADERS_STEPX,
                param = (int) getParamDouble();
                data.dx = param;
                break;
            case 3747:		// SET_INVADERS_STEPY,
                param = (int) getParamDouble();
                data.dy = param;
                break;
            case 3748:		// SET_INVADERS_LEFTBORDER,
                param = (int) getParamDouble();
                data.minX = param;
                break;
            case 3749:		// SET_INVADERS_RIGHTBORDER,
                param = (int) getParamDouble();
                data.maxX = param;
                break;
            case 3750:		// GET_INVADERS_SPEED,
                return data.speed;
            case 3751:		// GET_INVADERS_STEPX,
                return data.dx;
            case 3752:		// GET_INVADERS_STEPY,
                return data.dy;
            case 3753:		// GET_INVADERS_LEFTBORDER,
                return data.minX;
            case 3754:		// GET_INVADERS_RIGHTBORDER,
                return data.maxX;
        }
        return 0;
    }

    @Override
	public int getSpeed()
    {
        return 0;
    }

    @Override
	public int getAcceleration()
    {
        return 0;
    }

    @Override
	public int getDeceleration()
    {
        return 0;
    }

    @Override
	public int getGravity()
    {
        return 0;
    }

}

class CGlobalDataInvader extends CExtStorage
{
    int count = 0;
    int tillSpeedIncrease = 0;
    int dx = 1;
    int dy = 0;
    int cdx = 0;
    int cdy = 0;
    int speed = 0;
    int frames = 0;
    int initialSpeed = 0;
    int minX = 0;
    int maxX = 640;
    boolean isMoving = false;
    boolean autoSpeed = false;
    ArrayList<CObject> myList = null;
}
    
