/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// CRUNMVTPRESENTAION
//
//----------------------------------------------------------------------------------
package Movements;

import java.util.ArrayList;

import Animations.CAnim;
import Application.CRunFrame;
import Extensions.CExtStorage;
import Objects.CObject;
import RunLoop.CRun;
import Services.CBinaryFile;

class CGlobalPres extends CExtStorage
{
    public int orderPosition = 0;
    public int finalOrder = -1;
    public int keyNext = 0;
    public int keyPrev = 0;
    public boolean reset = true;
    public boolean resetToEnd = false;
    public boolean autoControl = true;
    public boolean autoFrameJump = true;
    public boolean autoComplete = true;
    public ArrayList<CRunMvtclickteam_presentation> myList = null;
}

public class CRunMvtclickteam_presentation extends CRunMvtExtension
{
    static final int IDENTIFIER = 3;
    //*** Fly In/Out effects
    static final int FLYEFFECT_NONE = 0;
    static final int FLYEFFECT_APPEAR = 1;
    static final int FLYEFFECT_BOTTOM = 2;
    static final int FLYEFFECT_LEFT = 3;
    static final int FLYEFFECT_RIGHT = 4;
    static final int FLYEFFECT_TOP = 5;

    //*** Movement status
    static final int STOPPED = 0;
    static final int ENTRANCE = 1;
    static final int EXIT = 2;

    //*** Speed
    static final int SPEED_VERYSLOW = 0;
    static final int SPEED_SLOW = 1;
    static final int SPEED_MEDIUM = 2;
    static final int SPEED_FAST = 3;
    static final int SPEED_VERYFAST = 4;

    //*** Global settings
    static final int GLOBAL_AUTOCONTROL = 1;
    static final int GLOBAL_AUTOFRAMEJUMP = 2;
    static final int GLOBAL_AUTOCOMPLETE = 4;
    int m_dwEntranceType;
    int m_dwEntranceSpeed;
    int m_dwEntranceOrder;
    int m_dwExitType;
    int m_dwExitSpeed;
    int m_dwExitOrder;
    int m_dwFlagsGlobalSettings;
    CObject pLPHO;
    int initialX;
    int initialY;
    int startEntranceX;
    int startEntranceY;
    int entranceEffect;
    int entranceOrder;
    int entranceSpeed;
    double entranceSpeedX;
    double entranceSpeedY;
    int finalExitX;
    int finalExitY;
    int exitEffect;
    int exitOrder;
    int exitSpeed;
    double exitSpeedX;
    double exitSpeedY;
    int isMoving;

    public CRunMvtclickteam_presentation()
    {
    }

    
    @Override
	public void initialize(CBinaryFile file)
    {
        file.skipBytes(1);
        m_dwEntranceType = file.readInt();
        m_dwEntranceSpeed = file.readInt();
        m_dwEntranceOrder = file.readInt();
        m_dwExitType = file.readInt();
        m_dwExitSpeed = file.readInt();
        m_dwExitOrder = file.readInt();
        m_dwFlagsGlobalSettings = file.readInt();

        CGlobalPres data = (CGlobalPres) rh.getStorage(IDENTIFIER);
        if (data == null)
        {
            data = new CGlobalPres();
            rh.addStorage(data, IDENTIFIER);
            data.myList = new ArrayList<CRunMvtclickteam_presentation>();
        }

        // Store pointer to edit data
        pLPHO = ho;
        initialX = ho.hoX;
        initialY = ho.hoY;
        isMoving = STOPPED;

        //*** Adds this object to the end of our list
        data.myList.add(this);

        data.autoControl = ((m_dwFlagsGlobalSettings & GLOBAL_AUTOCONTROL) != 0);
        data.autoFrameJump = ((m_dwFlagsGlobalSettings & GLOBAL_AUTOFRAMEJUMP) != 0);
        data.autoComplete = ((m_dwFlagsGlobalSettings & GLOBAL_AUTOCOMPLETE) != 0);
    }

    public void reset(CGlobalPres data)
    {
        //*******************************************
        //*** Entrance parameters *******************
        //*******************************************
        entranceEffect = m_dwEntranceType;
        entranceOrder = m_dwEntranceOrder;

        if (entranceOrder == 0 && entranceEffect != FLYEFFECT_NONE)
        {
            isMoving = ENTRANCE;
        }

        if (entranceOrder > data.finalOrder && entranceEffect != FLYEFFECT_NONE)
        {
            data.finalOrder = entranceOrder;
        }

        switch (m_dwEntranceSpeed)
        {
            case 0:	    // SPEED_VERYSLOW:
                entranceSpeed = 1;
                break;
            case 1:	    // SPEED_SLOW:
                entranceSpeed = 2;
                break;
            case 2:	    // SPEED_MEDIUM:
                entranceSpeed = 4;
                break;
            case 3:	    // SPEED_FAST:
                entranceSpeed = 8;
                break;
            case 4:	    // SPEED_VERYFAST:
                entranceSpeed = 16;
                break;
        }

        switch (entranceEffect)
        {
            case 0:	    // FLYEFFECT_NONE:
                entranceOrder = -1;
                break;
            case 1:	    // FLYEFFECT_APPEAR:
                startEntranceX = initialX;
                startEntranceY = -10 - pLPHO.hoImgWidth + pLPHO.hoImgXSpot;
                entranceSpeedX = 0;
                entranceSpeedY = 0;
                break;
            case 2:	    // FLYEFFECT_BOTTOM:
                startEntranceX = initialX;
                startEntranceY = pLPHO.hoAdRunHeader.rhLevelSy + 10 - pLPHO.hoImgYSpot;
                entranceSpeedX = 0;
                entranceSpeedY = entranceSpeed;
                break;
            case 3:	    // FLYEFFECT_LEFT:
                startEntranceX = -10 - pLPHO.hoImgWidth + pLPHO.hoImgXSpot;
                startEntranceY = initialY;
                entranceSpeedX = entranceSpeed;
                entranceSpeedY = 0;
                break;
            case 4:	    // FLYEFFECT_RIGHT:
                startEntranceX = pLPHO.hoAdRunHeader.rhLevelSx + 10 - pLPHO.hoImgXSpot;
                startEntranceY = initialY;
                entranceSpeedX = entranceSpeed;
                entranceSpeedY = 0;
                break;
            case 5:	    // FLYEFFECT_TOP:
                startEntranceX = initialX;
                startEntranceY = -10 - pLPHO.hoImgHeight + pLPHO.hoImgYSpot;
                entranceSpeedX = 0;
                entranceSpeedY = entranceSpeed;
                break;
        }

        //*******************************************
        //*** Exit parameters ***********************
        //*******************************************
        exitEffect = m_dwExitType;
        exitOrder = m_dwExitOrder;

        if (exitOrder == 0 && exitEffect != FLYEFFECT_NONE)
        {
            isMoving = EXIT;
        }

        if (exitOrder > data.finalOrder && exitEffect != FLYEFFECT_NONE)
        {
            data.finalOrder = exitOrder;
        }

        switch (m_dwExitSpeed)
        {
            case 0:	    // SPEED_VERYSLOW:
                exitSpeed = 1;
                break;
            case 1:	    // SPEED_SLOW:
                exitSpeed = 2;
                break;
            case 2:	    // SPEED_MEDIUM:
                exitSpeed = 4;
                break;
            case 3:	    // SPEED_FAST:
                exitSpeed = 8;
                break;
            case 4:	    // SPEED_VERYFAST:
                exitSpeed = 16;
                break;
        }

        switch (exitEffect)
        {
            case 0:	    // FLYEFFECT_NONE:
                exitOrder = -1;
                break;
            case 1:	    // FLYEFFECT_APPEAR:
                finalExitX = initialX;
                finalExitY = -10 - pLPHO.hoImgHeight;
                exitSpeedX = 0;
                exitSpeedY = 0;
                break;
            case 2:	    // FLYEFFECT_BOTTOM:
                finalExitX = initialX;
                finalExitY = pLPHO.hoAdRunHeader.rhLevelSy + 10 - pLPHO.hoImgYSpot;
                exitSpeedX = 0;
                exitSpeedY = exitSpeed;
                break;
            case 3:	    // FLYEFFECT_LEFT:
                finalExitX = -10 - pLPHO.hoImgWidth + pLPHO.hoImgXSpot;
                finalExitY = initialY;
                exitSpeedX = exitSpeed;
                exitSpeedY = 0;
                break;
            case 4:	    // FLYEFFECT_RIGHT:
                finalExitX = pLPHO.hoAdRunHeader.rhLevelSx + 10 - pLPHO.hoImgXSpot;
                finalExitY = initialY;
                exitSpeedX = exitSpeed;
                exitSpeedY = 0;
                break;
            case 5:	    // FLYEFFECT_TOP:
                finalExitX = initialX;
                finalExitY = -10 - pLPHO.hoImgHeight + pLPHO.hoImgYSpot;
                exitSpeedX = 0;
                exitSpeedY = exitSpeed;
                break;
        }

        //**************************************
        //*** Calculate the initial position ***
        //**************************************
        if (exitOrder == -1)
        {
            if (entranceOrder != -1)
            {
                pLPHO.hoX = startEntranceX;
                pLPHO.hoY = startEntranceY;
                pLPHO.roc.rcChanged=true;
            }
        }
        else if (entranceOrder != -1 && exitOrder != -1)
        {
            if (exitOrder > entranceOrder)
            {
                pLPHO.hoX = startEntranceX;
                pLPHO.hoY = startEntranceY;
                pLPHO.roc.rcChanged=true;
            }
        }
    }

    public void moveToEnd()
    {
        if (entranceOrder != -1 && exitOrder == -1)
        {
            pLPHO.hoX = initialX;
            pLPHO.hoY = initialY;
            pLPHO.roc.rcChanged=true;
        }
        else if (entranceOrder == -1 && exitOrder != -1)
        {
            pLPHO.hoX = finalExitX;
            pLPHO.hoY = finalExitY;
            pLPHO.roc.rcChanged=true;
        }
        else if (entranceOrder != -1 && exitOrder != -1)
        {
            if (entranceOrder > exitOrder)
            {
                pLPHO.hoX = initialX;
                pLPHO.hoY = initialY;
            }
            else
            {
                pLPHO.hoX = finalExitX;
                pLPHO.hoY = finalExitY;
            }
            pLPHO.roc.rcChanged=true;
        }
    }

    void checkKeyPresses(CGlobalPres data)
    {
        //*** Has the user pressed a key so we need to increase / decrease the order?

        //*******************************
        //*** Check move foward keys    *
        //*******************************
        if (data.keyNext == 0)
        {
            if (ho.hoAdRunHeader.rhApp.getKeyState(40))	    // VK_DOWN
            {
                data.keyNext = 40;			// VK_DOWN;
                moveForward();
            }
            else if (ho.hoAdRunHeader.rhApp.getKeyState(39))	// VK_RIGHT
            {
                data.keyNext = 39;			// VK_RIGHT;
                moveForward();
            }
        }
        else if (ho.hoAdRunHeader.rhApp.getKeyState(data.keyNext) == false)
        {
            data.keyNext = 0;
        }

        //*******************************
        //*** Check move backwards keys *
        //*******************************
        if (data.keyPrev == 0)
        {
            if (ho.hoAdRunHeader.rhApp.getKeyState(38))	// VK_UP
            {
                data.keyPrev = 38;		// VK_UP;
                moveBack();
            }
            else if (ho.hoAdRunHeader.rhApp.getKeyState(37))	// VK_LEFT
            {
                data.keyPrev = 37;		// VK_LEFT;
                moveBack();
            }
        }
        else if (ho.hoAdRunHeader.rhApp.getKeyState(data.keyPrev) == false)
        {
            data.keyPrev = 0;
        }
    }

    @Override
	public void kill()
    {
        CGlobalPres data = (CGlobalPres) rh.getStorage(IDENTIFIER);
        if (data != null)
        {
			int idx = data.myList.indexOf(this);
			if (idx >= 0) {
			    data.myList.remove(idx);
			    if (data.myList.size() == 0)
				{
	                rh.delStorage(IDENTIFIER);
			    }
			}
        }
    }

    @Override
	public boolean move()
    {
        CGlobalPres data = (CGlobalPres) rh.getStorage(IDENTIFIER);
        if (data == null)
        {
            return false;
        }

        //************************
        //*** Reset workaround ***
        //************************
        CRunMvtclickteam_presentation p;
        if (data.reset)
        {
            if (ho.hoImgHeight != 0)
            {
                int index;
                for (index = 0; index < data.myList.size(); index++)
                {
                    p = data.myList.get(index);
                    p.reset(data);
                    if (data.resetToEnd)
                    {
                        p.moveToEnd();
                    }
                }
                if (data.resetToEnd)
                {
                    data.orderPosition = data.finalOrder;
                }
                data.reset = false;
                data.resetToEnd = false;
            }
            else
            {
                return false;
            }
        }

        if (data.myList.size() > 0)
        {
            p = data.myList.get(0);
            if (p == this)
            {
                checkKeyPresses(data);
            }
        }

        //************************
        //*** Move Object ********
        //************************
        double calculs;
        if (isMoving == ENTRANCE)
        {
            animations(CAnim.ANIMID_WALK);

            //*** Entrance movement
            switch (entranceEffect)
            {
                case 1:	    // FLYEFFECT_APPEAR:
                    ho.hoX = initialX;
                    ho.hoY = initialY;
                    isMoving = STOPPED;
                    break;
                case 2:	    // FLYEFFECT_BOTTOM:
                    calculs = entranceSpeedY;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    ho.hoY -= Math.min(calculs, Math.abs(initialY - ho.hoY));
                    if (ho.hoY == initialY)
                    {
                        isMoving = STOPPED;
                    }
                    break;
                case 3:	    // FLYEFFECT_LEFT:
                    calculs = entranceSpeedX;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    ho.hoX += Math.min(calculs, Math.abs(initialX - ho.hoX));
                    if (ho.hoX == initialX)
                    {
                        isMoving = STOPPED;
                    }
                    break;
                case 4:	    // FLYEFFECT_RIGHT:
                    calculs = entranceSpeedX;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    ho.hoX -= Math.min(calculs, Math.abs(initialX - ho.hoX));
                    if (ho.hoX == initialX)
                    {
                        isMoving = STOPPED;
                    }
                    break;
                case 5:	    // FLYEFFECT_TOP:
                    calculs = entranceSpeedY;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    ho.hoY += Math.min(calculs, Math.abs(initialY - ho.hoY));
                    if (ho.hoY == initialY)
                    {
                        isMoving = STOPPED;
                    }
                    break;
            }
            collisions();
            return true;
        }
        else if (isMoving == EXIT)
        {
            animations(CAnim.ANIMID_WALK);

            //*** Exit movement
            switch (exitEffect)
            {
                case 1:	    // FLYEFFECT_APPEAR:
                    ho.hoY = finalExitY;
                    isMoving = STOPPED;
                    break;
                case 2:	    // FLYEFFECT_BOTTOM:
                    calculs = exitSpeedY;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    ho.hoY += Math.min(calculs, Math.abs(finalExitY - ho.hoY));
                    if (ho.hoY >= finalExitY)
                    {
                        isMoving = STOPPED;
                    }
                    break;
                case 3:	    // FLYEFFECT_LEFT:
                    calculs = exitSpeedX;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    ho.hoX -= Math.min(calculs, Math.abs(finalExitX - ho.hoX));
                    if (ho.hoX <= finalExitX)
                    {
                        isMoving = STOPPED;
                    }
                    break;
                case 4:	    // FLYEFFECT_RIGHT:
                    calculs = exitSpeedX;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    ho.hoX += Math.min(calculs, Math.abs(finalExitX - ho.hoX));
                    if (ho.hoX >= finalExitX)
                    {
                        isMoving = STOPPED;
                    }
                    break;
                case 5:	    // FLYEFFECT_TOP:
                    calculs = exitSpeedY;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    ho.hoY -= Math.min(calculs, Math.abs(finalExitY - ho.hoY));
                    if (ho.hoY <= finalExitY)
                    {
                        isMoving = STOPPED;
                    }
                    break;
            }
            collisions();
            return true;
        }
        animations(CAnim.ANIMID_STOP);
        collisions();

        //** The object has not been moved
        return ho.roc.rcChanged;
    }

    public void moveForward()
    {
        CGlobalPres data = (CGlobalPres) rh.getStorage(IDENTIFIER);
        if (data != null)
        {
            int index;
            CRunMvtclickteam_presentation p;
            for (index = 0; index < data.myList.size(); index++)
            {
                p = data.myList.get(index);

                //*** Find any objects that did not complete from the last move and complete them!
                if (data.autoComplete)
                {
                    if (p.entranceOrder == data.orderPosition && p.isMoving != STOPPED)
                    {
                        p.pLPHO.hoX = p.initialX;
                        p.pLPHO.hoY = p.initialY;
                        p.isMoving = STOPPED;
                        p.pLPHO.roc.rcChanged=true;
                    }
                    if (p.exitOrder == data.orderPosition && p.isMoving != STOPPED)
                    {
                        p.pLPHO.hoX = p.finalExitX;
                        p.pLPHO.hoY = p.finalExitY;
                        p.isMoving = STOPPED;
                        p.pLPHO.roc.rcChanged=true;
                    }
                }

                //*** Find any objects to move at this order : Entrance
                if (p.entranceOrder == (data.orderPosition + 1))
                {
                    p.pLPHO.hoX = p.startEntranceX;
                    p.pLPHO.hoY = p.startEntranceY;
                    p.isMoving = ENTRANCE;
                    p.pLPHO.roc.rcChanged=true;
                }
                //*** Find any objects to move at this order : Exit
                if (p.exitOrder == (data.orderPosition + 1))
                {
                    p.isMoving = EXIT;
                }
            }
            data.orderPosition++;

            if (data.orderPosition > data.finalOrder && data.autoFrameJump == true)
            {
                ho.hoAdRunHeader.rhQuit = CRun.LOOPEXIT_NEXTLEVEL;
            }
        }
    }

    public void moveBack()
    {
        CGlobalPres data = (CGlobalPres) rh.getStorage(IDENTIFIER);
        if (data != null)
        {
            int index;
            CRunMvtclickteam_presentation p;
            for (index = 0; index < data.myList.size(); index++)
            {
                p = data.myList.get(index);

                //*** Find any objects from the last move and reset them!
                if (p.entranceOrder == data.orderPosition)
                {
                    p.pLPHO.hoX = p.startEntranceX;
                    p.pLPHO.hoY = p.startEntranceY;
                    p.isMoving = STOPPED;
                    p.pLPHO.roc.rcChanged=true;
                }
                if (p.exitOrder == data.orderPosition)
                {
                    p.pLPHO.hoX = p.initialX;
                    p.pLPHO.hoY = p.initialY;
                    p.isMoving = STOPPED;
                    p.pLPHO.roc.rcChanged=true;
                }
            }
            data.orderPosition--;

            if (data.orderPosition < 0)
            {
                if (data.autoFrameJump && ho.hoAdRunHeader.rhApp.currentFrame != 0)
                {
                    data.resetToEnd = true;
                    ho.hoAdRunHeader.rhQuit = CRun.LOOPEXIT_PREVLEVEL;
                }
                else
                {
                    data.orderPosition = 0;
                }
            }
        }
    }

    @Override
	public void setPosition(int x, int y)
    {
        ho.hoX = x;
        ho.hoY = y;
    }

    @Override
	public void setXPosition(int x)
    {
        ho.hoX = x;
    }

    @Override
	public void setYPosition(int y)
    {
        ho.hoY = y;
    }

    @Override
	public void stop(boolean bCurrent)
    {
    }

    @Override
	public void bounce(boolean bCurrent)
    {
    }

    @Override
	public void reverse()
    {
    }

    @Override
	public void start()
    {
    }

    @Override
	public void setSpeed(int speed)
    {
    }

    @Override
	public void setMaxSpeed(int speed)
    {
    }

    @Override
	public void setDir(int dir)
    {
    }

    @Override
	public void setAcc(int acc)
    {
    }

    @Override
	public void setDec(int dec)
    {
    }

    @Override
	public void setRotSpeed(int speed)
    {
    }

    @Override
	public void set8Dirs(int dirs)
    {
    }

    @Override
	public void setGravity(int gravity)
    {
    }

    @Override
	public int extension(int function, int param)
    {
        return 0;
    }

    @Override
	public double actionEntry(int action)
    {
        CGlobalPres data = (CGlobalPres) rh.getStorage(IDENTIFIER);
        if (data == null)
        {
            return 0;
        }

        int index;
        CRunMvtclickteam_presentation p;
        switch (action)
        {
            case 3945:		// SET_PRESENTATION_Next = 3945,
                moveForward();
                break;
            case 3946:		// SET_PRESENTATION_Prev,
                moveBack();
                break;
            case 3947:		// SET_PRESENTATION_ToStart,
                for (index = 0; index < data.myList.size(); index++)
                {
                    p = data.myList.get(index);
                    p.isMoving = STOPPED;
                    p.reset(data);
                }
                data.orderPosition = 0;
                break;
            case 3948:		// SET_PRESENTATION_ToEnd,
                for (index = 0; index < data.myList.size(); index++)
                {
                    p = data.myList.get(index);
                    p.isMoving = STOPPED;
                    p.moveToEnd();
                }
                data.orderPosition = data.finalOrder;
                break;
            case 3949:		// GET_PRESENTATION_Index,
                return data.orderPosition;
            case 3950:		// GET_PRESENTATION_LastIndex
                return data.finalOrder;
        }
        return 0;
    }

    @Override
	public int getSpeed()
    {
        return finalExitX;
    }

    @Override
	public int getAcceleration()
    {
        return 0;
    }

    @Override
	public int getDeceleration()
    {
        return 0;
    }

    @Override
	public int getGravity()
    {
        return 0;
    }

}
