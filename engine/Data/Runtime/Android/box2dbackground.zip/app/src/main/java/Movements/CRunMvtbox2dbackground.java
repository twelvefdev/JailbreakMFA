/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 *
 * Permission is hereby granted to any person obtaining a legal copy
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for
 * debugging, optimizing, or customizing applications created with
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// 8 directions box 2d movement
//
//----------------------------------------------------------------------------------
package Movements;

import Actions.CAct;
import Animations.CAnim;
import Banks.CImage;
import Expressions.CExp;
import Extensions.CRunBox2DBase;
import Extensions.CRunBox2DBasePosAndAngle;
import Objects.CExtension;
import Objects.CObject;
import RunLoop.CRun;
import RunLoop.CRunMBase;
import Services.CBinaryFile;

import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Fixture;

public class CRunMvtbox2dbackground extends CRunMBase
{
    public static final int B2FLAG_ROTATE=0x0001;

    public CRunBox2DBase m_base;
    public float m_friction = 0;
    public float m_restitution = 0;
    public int m_shape = 0;
    public int m_flags = 0;
    public Fixture m_fixture = null;
    public int m_obstacle = 0;
    public CRunBox2DBasePosAndAngle m_posAndAngle = new CRunBox2DBasePosAndAngle();
    public int m_imgWidth = 0;
    public int m_imgHeight = 0;
    public float m_scaleX = 1.0f;
    public float m_scaleY = 1.0f;
    public double m_previousAngle = -1;
    public short m_jointType = 0;
    public short m_jointAnchor = 0;
    public float m_rJointLLimit = 0;
    public float m_rJointULimit = 0;
    public float m_dJointFrequency = 0;
    public float m_dJointDamping = 0;
    public float m_pJointLLimit = 0;
    public float m_pJointULimit = 0;
    public String m_jointName = null;
    public String m_jointObject = null;
    public int m_moved = 0;

    // Build 283.3 increasing performance
    private CRunBox2DBase GetBase()
    {
        int nObjects = this.rh.rhNObjects;
        CObject[] localObjectList=this.rh.rhObjectList;
        for (CObject pObject : localObjectList)
        {
            if (pObject != null) {
            	--nObjects;
	            if(pObject.hoType>=32)
	            {
	                if (pObject.hoCommon.ocIdentifier == CRun.BASEIDENTIFIER)
	                {
	                    CRunBox2DBase pBase = (CRunBox2DBase)((CExtension)pObject).ext;
	                    if (pBase.identifier == this.m_identifier)
	                    {
	                        return pBase;
	                    }
	                }
	            }
            }
            if(nObjects==0)
            	break;
        }
        return null;
    }

    @Override
    public void initialize(CBinaryFile file)
    {
        file.skipBytes(1);
        this.m_friction=file.readInt()/100.0f;
        this.m_restitution=file.readInt()/100.0f;
        this.m_flags=file.readInt();
        this.m_angle=this.dirAtStart(file.readInt())*180.0f/16.0f;
        this.m_shape=file.readShort();
        this.m_obstacle=file.readShort();
        this.m_identifier=file.readInt();
        this.m_jointType = file.readShort();
        this.m_jointAnchor = file.readShort();
        this.m_jointName = file.readString(CRunBox2DBase.MAX_JOINTNAME);
        this.m_jointObject = file.readString(CRunBox2DBase.MAX_JOINTOBJECT);
        this.m_rJointLLimit = (float)(file.readInt() * Math.PI / 180.0);
        this.m_rJointULimit = (float)(file.readInt() * Math.PI / 180.0);
        this.m_dJointFrequency = file.readInt();
        this.m_dJointDamping = file.readInt() / 100.0f;
        this.m_pJointLLimit = file.readInt();
        this.m_pJointULimit = file.readInt();

        this.m_base=this.GetBase();
        this.m_body=null;
        this.InitBase(this.ho, CRunMBase.MTYPE_OBJECT);
        this.m_background = true;
    }

    @Override
    public void kill()
    {
        CRunBox2DBase pBase=this.GetBase();
        if (pBase!=null)
        {
            pBase.rDestroyBody(this.m_body);
        }
    }

    @Override
    public Boolean CreateBody()
    {
        if (this.m_body!=null)
            return true;

        if (this.m_base==null)
        {
            this.m_base=this.GetBase();
            if (this.m_base == null)
                return false;
        }

        int obstacle;
        switch (this.m_obstacle)
        {
            case 1:
                obstacle=CRunMBase.MTYPE_OBSTACLE;
                break;
            case 2:
                obstacle= CRunMBase.MTYPE_PLATFORM;
                break;
            default:
                obstacle = CRunMBase.MTYPE_OBJECT;
                break;
        }
        this.m_type = obstacle;
        this.m_body = this.m_base.rCreateBody(BodyDef.BodyType.StaticBody, this.ho.hoX, this.ho.hoY, this.m_angle, 0, this, 0, 0);
        if (this.ho.roa == null)
        {
            this.m_shape = 0;
            this.m_imgWidth = this.ho.hoImgWidth;
            this.m_imgHeight = this.ho.hoImgHeight;
        }
        else
        {
            this.m_image = this.ho.roc.rcImage;
            CImage img = this.rh.rhApp.imageBank.getImageFromHandle(this.m_image);
            this.m_imgWidth = img.getWidth();
            this.m_imgHeight = img.getHeight();
        }
        this.CreateFixture();
        m_moved = 2;
        return true;
    }

    private void CreateFixture()
    {
        if (this.m_fixture != null)
        {
            this.m_body.destroyFixture(this.m_fixture);
        }
        this.m_scaleX = this.ho.roc.rcScaleX;
        this.m_scaleY = this.ho.roc.rcScaleY;
        switch (this.m_shape)
        {
            case 0:
                this.m_fixture = this.m_base.rBodyCreateBoxFixture(this.m_body, this, this.ho.hoX, this.ho.hoY, (int)(this.m_imgWidth * this.m_scaleX), (int)(this.m_imgHeight * this.m_scaleY), 0, this.m_friction, this.m_restitution);
                break;
            case 1:
                this.m_fixture = this.m_base.rBodyCreateCircleFixture(this.m_body, this, this.ho.hoX, this.ho.hoY, (int)((this.ho.hoImgWidth + this.ho.hoImgHeight) / 4 * (this.m_scaleX + this.m_scaleY) / 2), 0, this.m_friction, this.m_restitution);
                break;
            case 2:
                this.m_fixture = this.m_base.rBodyCreateShapeFixture(this.m_body, this, this.ho.hoX, this.ho.hoY, this.ho.roc.rcImage, 0, this.m_friction, this.m_restitution, this.m_scaleX, this.m_scaleY);
                break;
        }
    }

    @Override
	public void CreateJoint()
    {
        switch (this.m_jointType)
        {
            case CRunBox2DBase.JTYPE_REVOLUTE:
                this.m_base.rJointCreate(this, this.m_jointType, this.m_jointAnchor, this.m_jointName, this.m_jointObject, this.m_rJointLLimit, this.m_rJointULimit);
                break;
            case CRunBox2DBase.JTYPE_DISTANCE:
                this.m_base.rJointCreate(this, this.m_jointType, this.m_jointAnchor, this.m_jointName, this.m_jointObject, this.m_dJointFrequency, this.m_dJointDamping);
                break;
            case CRunBox2DBase.JTYPE_PRISMATIC:
                this.m_base.rJointCreate(this, this.m_jointType, this.m_jointAnchor, this.m_jointName, this.m_jointObject, this.m_pJointLLimit, this.m_pJointULimit);
                break;
            default:
                break;
        }
    }

    @Override
    public boolean move()
    {
        if (!this.CreateBody() || this.m_base.isPaused())
            return false;

        // Scale changed?
        if (this.ho.roc.rcScaleX != this.m_scaleX || this.ho.roc.rcScaleY != this.m_scaleY)
            this.CreateFixture();

        this.m_base.rGetBodyPosition(this.m_body, this.m_posAndAngle);
        this.m_currentAngle = this.m_posAndAngle.angle;
        if (this.m_moved > 0)
        {
            if (this.m_posAndAngle.x!=this.ho.hoX || this.m_posAndAngle.y!=this.ho.hoY)
            {
                this.ho.hoX=this.m_posAndAngle.x;
                this.ho.hoY=this.m_posAndAngle.y;
                this.ho.roc.rcChanged=true;
            }
            m_moved--;
        }
        if (this.m_currentAngle!=this.m_previousAngle)
        {
            this.m_previousAngle=this.m_currentAngle;
            this.ho.roc.rcAngle=(float)this.m_currentAngle;
            this.ho.roc.rcChanged=true;
            
            if ((this.m_flags&B2FLAG_ROTATE)!=0)
            {
                this.ho.roc.rcAngle=(float)this.m_currentAngle;
                this.ho.roc.rcDir=0;
            }
            else
            {
                this.ho.roc.rcDir=(int)(m_currentAngle/11.25);
                while(this.ho.roc.rcDir<0)
                    this.ho.roc.rcDir+=32;
                while(this.ho.roc.rcDir>=32)
                    this.ho.roc.rcDir-=32;
            }
        }
        animations(CAnim.ANIMID_STOP);
        return this.ho.roc.rcChanged;
    }

    @Override
	public void SetFriction(int friction)
    {
        this.m_friction=friction/100.0f;
        this.m_fixture.setFriction(this.m_friction);
    }
    @Override
	public void SetRestitution(int restitution)
    {
        this.m_restitution=restitution/100.0f;
        this.m_fixture.setRestitution(this.m_restitution);
    }

    @Override
    public void setAngle(float angle)
    {
        this.m_base.rBodySetAngle(this.m_body, angle);
    }

    @Override
    public float getAngle()
    {
        if ((this.m_flags&B2FLAG_ROTATE)!=0)
        {
            double angle = this.m_currentAngle;
            while (angle >= 360.0)
                angle -= 360.0;
            while (angle < 0)
                angle += 360;
            return (float)angle;
        }
        return CRunMBase.ANGLE_MAGIC;
    }

    @Override
    public void setPosition(int x, int y)
    {
        if (x!=this.ho.hoX || y!=this.ho.hoY)
        {
            this.m_base.rBodySetPosition(this.m_body, x, y);
            this.m_moved = 10;
        }
    }
    @Override
    public void setXPosition(int x)
    {
        if (x!=this.ho.hoX)
        {
            this.m_base.rBodySetPosition(this.m_body, x, CRunBox2DBase.POSDEFAULT);
            this.m_moved = 10;
        }
    }
    @Override
    public void setYPosition(int y)
    {
        if (y!=this.ho.hoY)
        {
            this.m_base.rBodySetPosition(this.m_body, CRunBox2DBase.POSDEFAULT, y);
            this.m_moved = 10;
        }
    }

    @Override
    public double actionEntry(int action)
    {
        if (this.m_base == null)
            return 0;

        switch (action)
        {
            case CAct.NACT_EXTSETFRICTION:
                this.SetFriction((int)this.getParam1());
                break;
            case CAct.NACT_EXTSETELASTICITY:
                this.SetRestitution((int)this.getParam1());
                break;
            case CExp.NEXP_EXTGETFRICTION:
                return this.m_friction * 100;
            case CExp.NEXP_EXTGETRESTITUTION:
                return this.m_restitution * 100;
            default:
                break;
        }
        return 0;
    }
}
