package Extensions;
import android.util.Log;
import java.nio.ByteBuffer;
import java.io.InputStream;
import java.io.IOException;
import Services.CBinaryFile;
import Runtime.MMFRuntime;
import Objects.CExtension;
import RunLoop.CCreateObjectInfo;
import Conditions.CCndExtension;
import Expressions.CExpExtension;
import Actions.CActExtension;
import Expressions.CValue;
import Application.CRunFrame;

public class CRunMvtTimerCtrl extends CRunExtension
{
	final int CON_COMPAREBASE = 0;
	final int CON_COMPAREMVTTIMERSTATE = 1;
	final int CON_LAST = 2;
	
	final int ACT_SETBASE = 0;
	final int ACT_SETMVTTIMERSTATE = 1;
	final int ACT_SETMVTTIMERPRECISION = 2;
	
	final int EXP_GETBASE = 0;
	final int EXP_GETMVTTIMERSTATE = 1;
	final int EXP_BASETOPERCENT = 2;
	final int EXP_PERCENTTOBASE = 3;
	final int EXP_DELTATIME = 4;
	final int EXP_BASETOFLOAT = 5;
	final int EXP_FLOATTOBASE = 6;
	
	double Delta = 0;
	long TimerOld = 0;
	private static boolean PropsInitiated = false;
	private static boolean DoubleMvtTimerCoef = false;
	
	double setPrecision(double num, int precision) {
		double scale = Math.pow(10.0, precision);
		return Math.round(num * scale) / scale;
	}
	
	public CRunMvtTimerCtrl()
	{
	}
    
    @Override
	public int getNumberOfConditions()
    {
    	return 0;
    }
    
    @Override
	public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
		file.skipBytes(20);
		if (!PropsInitiated && file.readByte() == 2)
		{
			DoubleMvtTimerCoef = true;
		}
		PropsInitiated = true;
		
		return true;
    }

    @Override
	public int handleRunObject()
    {
		if (DoubleMvtTimerCoef == true) {
			Delta = (this.ho.hoAdRunHeader.rhTimer - TimerOld) / setPrecision(1000.0 / this.ho.hoAdRunHeader.rhFrame.m_dwMvtTimerBase, 3);
			TimerOld = this.ho.hoAdRunHeader.rhTimer;
		
			ho.hoAdRunHeader.rh4MvtTimerCoef = Delta; // Increases MvtTimerCoef precision
		}
		
    	return 1;
    }
        
	public void displayRunObject()
    {
    	
    }
    
    @Override
	public void destroyRunObject(boolean bFast)
    {
    }
    
    @Override
	public void pauseRunObject()
	{
    }
    
    @Override
	public void continueRunObject()
	{
    }
    
    @Override
	public boolean condition(int num, CCndExtension cnd)
	{
		switch (num)
        {
            case CON_COMPAREBASE: return cnd.getParamExpString (rh, 0).equals (ho.hoAdRunHeader.rhFrame.m_dwMvtTimerBase);
			case CON_COMPAREMVTTIMERSTATE: return (ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0;
        }

        return false;
    }
    
    @Override
	public void action(int num, CActExtension act)
	{
		switch (num)
        {
            case ACT_SETBASE: ho.hoAdRunHeader.rhFrame.m_dwMvtTimerBase = act.getParamExpression(rh, 0); break;
			case ACT_SETMVTTIMERSTATE:
				if (act.getParamExpression(rh, 0) <= 0)
					ho.hoAdRunHeader.rhFrame.leFlags &= ~CRunFrame.LEF_TIMEDMVTS;
				else
					ho.hoAdRunHeader.rhFrame.leFlags |= CRunFrame.LEF_TIMEDMVTS;
				break;
			case ACT_SETMVTTIMERPRECISION:
				if (act.getParamExpression(rh, 0) > 0)
				{
					TimerOld = this.ho.hoAdRunHeader.rhTimer;
					DoubleMvtTimerCoef = true;
				}
				else
					DoubleMvtTimerCoef = false;
                break;
        }
    }
    
	@Override
	public CValue expression(int num) {
		switch (num) {
			case EXP_GETBASE: return new CValue(ho.hoAdRunHeader.rhFrame.m_dwMvtTimerBase);
			case EXP_GETMVTTIMERSTATE: return new CValue((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0 ? 1 : 0);
			case EXP_PERCENTTOBASE: return new CValue((this.ho.getExpParam().getDouble() / 100.0f) * 60.0f);
			case EXP_BASETOPERCENT: return new CValue((this.ho.getExpParam().getDouble() / 60.0f) * 100.0f);
			case EXP_DELTATIME: return new CValue((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0 ? ho.hoAdRunHeader.rh4MvtTimerCoef : 1);
			case EXP_FLOATTOBASE: return new CValue(this.ho.getExpParam().getDouble() * 60.0f);
			case EXP_BASETOFLOAT: return new CValue(this.ho.getExpParam().getDouble() / 60.0f);
		}
		return new CValue(0);
	}
}
