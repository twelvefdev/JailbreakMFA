/* Copyright (c) 1996-2014 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 *
 * Permission is hereby granted to any person obtaining a legal copy
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for
 * debugging, optimizing, or customizing applications created with
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import java.io.IOException;
import java.io.InputStream;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

import Actions.CActExtension;
import Application.CJoystickEmulated;
import Application.CRunApp;
import Conditions.CCndExtension;
import Expressions.CValue;
import Extensions.ScreenListener.OnScreenResultListener;
import RunLoop.CCreateObjectInfo;
import RunLoop.CRun;
import Runtime.Log;
import Runtime.MMFRuntime;
import Services.CBinaryFile;
import Services.CServices;

import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Point;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.Parameters;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Debug;
import android.os.Environment;
import android.os.Handler;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;
import android.provider.Settings.System;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.common.AccountPicker;

import static android.content.Context.POWER_SERVICE;

@SuppressLint({ "NewApi", "CommitPrefEdits" })
public class CRunAndroidPlus extends CRunExtension {
	// <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
	public static final int CNDDISPLAYCENTER = 0;
	public static final int CNDDISPLAYADJUST = 1;
	public static final int CNDDISPLAYFITI = 2;
	public static final int CNDDISPLAYFITIA = 3;
	public static final int CNDDISPLAYFITO = 4;
	public static final int CNDDISPLAYSTRETCH = 5;
	public static final int CNDDISTOUCHENABLE = 6;
	public static final int CNDDISTABLET = 7;
	public static final int CNDDISLANDSCAPE = 8;
	public static final int CNDSHAREOK = 9;
	public static final int CNDLOCALELIST = 10;
	public static final int CNDTIMEZONELIST = 11;
	public static final int CNDISEXPAVAILABLE = 12;
	public static final int CNDAPPFROMPAUSE = 13;
	public static final int CNDSHAREWITHRESULT = 14;
	public static final int CNDACCOUNTOK = 15;
	public static final int CNDACCOUNTCANCEL = 16;
	public static final int CNDISBATTOPTIGNORED = 17;

	public static final int CND_LAST = 18;

	public static final int ACTSAVEFLAG = 0;
	public static final int ACTSETFLAG = 1;
	public static final int ACTRESTOREFLAG = 2;
	public static final int ACTREFRESH = 3;
	public static final int ACTDISABLETOUCH = 4;
	public static final int ACTENABLETOUCH = 5;
	public static final int ACTSTARTEMULJOYSTICK = 6;
	public static final int ACTEMULATEJOYSTICK = 7;
	public static final int ACTRELEASEJOYSTICK = 8;
	public static final int ACTSETPREFNAME = 9;
	public static final int ACTSETPREFSTRING = 10;
	public static final int ACTSETPREFINT = 11;
	public static final int ACTSETPREFFLOAT = 12;
	public static final int ACTSETPREFBOOL = 13;
	public static final int ACTSHAREIMAGE = 14;
	public static final int ACTSHARETEXT = 15;
	public static final int ACTSETLOCALBRIGHT = 16;
	public static final int ACTSETSYSBRIGHT = 17;
	public static final int ACTREADLOCALE = 18;
	public static final int ACTSETLANGUAGE = 19;
	public static final int ACTREADTIMEZONE = 20;
	public static final int ACTCHANGEDATETIME = 21;
	public static final int ACTSTARTSLEEP = 22;
	public static final int ACTINJECTKEY = 23;
	public static final int ACTSTARTAPK = 24;
	public static final int ACTFLASHLIGHT = 25;
	public static final int ACTWAKEUP = 26;
	public static final int ACTPORTRAIT = 27;
	public static final int ACTLANDSCAPE = 28;
	public static final int ACTTOANY = 29;
	public static final int ACTDEVICEVOL = 30;
	public static final int ACTSETINMERSIVE = 31;
	public static final int ACTBARCOLOR = 32;
	public static final int ACTBARTXTCOLOR = 33;
	public static final int ACTSTATUSCOLOR = 34;
	public static final int ACTDISPTITLE = 35;
	public static final int ACTDISPLOGO = 36;
	public static final int ACTDISPHOME = 37;
	public static final int ACTBARTITLE = 38;
	public static final int ACTMENTXTCOLOR = 39;
	public static final int ACTDISPMENU = 40;
	public static final int ACTSETICON = 41;
	public static final int ACTSETLOGO = 42;
	public static final int ACTSETHOME = 43;
	public static final int ACTSETMENU = 44;
	public static final int ACTSHORTCUT = 45;
	public static final int ACTMSGALIGN = 46;
	public static final int ACTMSGDURATION = 47;
	public static final int ACTMSGHOFFSET = 48;
	public static final int ACTMSGVOFSSET = 49;
	public static final int ACTMSGSHOW = 50;
	public static final int ACTASKACCOUNT = 51;
	public static final int ACTREQBATTOPTIGNORED = 52;
	public static final int ACTASKFORGC = 53;
	public static final int ACTSTARTREADMEM = 54;
	public static final int ACTSTOPREADMEM = 55;
	public static final int ACTSTATUSCOLTR = 56;

	public static final int EXPGETDMODE = 0;
	public static final int EXPGETSAVEDMODE = 1;
	public static final int EXPGETORIGDMODE = 2;
	public static final int EXPGETSCREENSIZE = 3;
	public static final int EXPGETSCREENWIDTH = 4;
	public static final int EXPGETSCREENHEIGHT = 5;
	public static final int EXPGETSCREENDPIHORZ = 6;
	public static final int EXPGETSCREENDPIVERT = 7;
	public static final int EXPGETSCREENDENSITY = 8;
	public static final int EXPGETSCREENDENSRATIO = 9;
	public static final int EXPGETPREFSTRING = 10;
	public static final int EXPGETPREFINTEGER = 11;
	public static final int EXPGETPREFFLOAT = 12;
	public static final int EXPGETPREFBOOL = 13;
	public static final int EXPGETLOCALBRIGHT = 14;
	public static final int EXPGETSYSBRIGHT = 15;
	public static final int EXPGETLOCALEQTY = 16;
	public static final int EXPGETLOCALE = 17;
	public static final int EXPGETLOCALECOUNTRY = 18;
	public static final int EXPGETDEFAULTLOCALE = 19;
	public static final int EXPGETTIMEZONEQTY = 20;
	public static final int EXPGETTIMEZONEID = 21;
	public static final int EXPGETTIMEZONEGMT = 22;
	public static final int EXPGETDEFAULTTIMEZONEID = 23;
	public static final int EXPGETDEFAULTTIMEZONEGMT = 24;
	public static final int EXPGETUNIQUEHARDID = 25;
	public static final int EXPGETDEVICEVOL = 26;
	public static final int EXPGETDARKERCOLOR = 27;
	public static final int EXPGETLIGHTERCOLOR = 28;
	public static final int EXPGETACTIONBARHEIGHT = 29;
	public static final int EXPGETACTIONBARCOLOR = 30;
	public static final int EXPGETGOOGLEACCOUNT = 31;
	public static final int EXPGETTOTALMEM = 32;
	public static final int EXPGETFREEMEM = 33;
	public static final int EXPGETUSEDMEM = 34;
	public static final int EXPGETMAXMEM = 35;
	public static final int EXPGETNATIVEMEM = 36;

	public static final int SHARED_OK = 10012345;
	public static final int REQUEST_ACCOUNTCODE = 177612345;

	static short HOF_TRUEEVENT = 0x0002;

	// </editor-fold>
	private int SavedMode;
	private int ActualMode;
	private int OriginalMode;

	private boolean islandscape = false;
	private boolean istablet = false;
	private boolean isBatteryOptimized = false;

	private double screenSizeInches = -1;
	private static double screenSizeWidth = -1;
	private static double screenSizeHeight = -1;
	private static double screenSizeDpiHorz = 0;
	private static double screenSizeDpiVert = 0;
	private static int screenSizeDensDPI = 0;
	private static float screenSizeDensRatio = 0.0f;

	private String[] timezones;
	private Locale[] locs = null;
	private float screenbright;
	private int systembright;

	private int localeEvent;
	private int timezoneEvent;

	private int emulEvent;
	private int autorelease;
	private byte lastCmd;

	private SharedPreferences prefsPrivate;
	private String PreferenceName;

	private Boolean shareRet;
	private int shareRes;

	private CRunApp app = null;
	private CRun run = null;

	private int toastGravity;
	private int horizontalOffset;
	private int verticalOffset;
	private int toastDuration;

	private String googleAccount;
	private int googleAcctRet;

	private CValue dRet;

	private double freeSize = 0;
	private double totalSize = 0;
	private double usedSize = -1;
	private double maxSize = -1;
	private double nativeSize = -1;
	private int ReadMemoryDelay;

	@SuppressWarnings("deprecation")
	public static Point screenSize() {
		Display display = MMFRuntime.inst.getWindowManager().getDefaultDisplay();
		Point point = new Point();

		if (Build.VERSION.SDK_INT > 13) {
			display.getSize(point);
		} else {
			//Below API 13
			point.x = display.getWidth();  // deprecated
			point.y = display.getHeight();  // deprecated
		}

		return point;
	}


	public static boolean isLandscape() {
		Point point = screenSize();
		return point.x > point.y;
	}


	public static int screenOffDuration() {
		return Settings.System.getInt(MMFRuntime.inst.getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, 15000);
	}


	public static boolean isScreenOn() {
		PowerManager powerManger = (PowerManager) MMFRuntime.inst.getSystemService(POWER_SERVICE);
		return powerManger.isScreenOn();
	}


	public static double deviceInch(Activity activity) {
		DisplayMetrics matrix = new DisplayMetrics();
		activity.getWindowManager().getDefaultDisplay().getMetrics(matrix);

		int width = matrix.widthPixels;
		int height = matrix.heightPixels;

		float xdpi = matrix.xdpi;
		float ydpi = matrix.ydpi;

		screenSizeWidth = width / xdpi;
		screenSizeHeight = height / ydpi;
		screenSizeDpiHorz = xdpi;
		screenSizeDpiVert = ydpi;
		screenSizeDensDPI = matrix.densityDpi;
		screenSizeDensRatio = matrix.density;

		double display = Math.sqrt(screenSizeWidth * screenSizeWidth + screenSizeHeight * screenSizeHeight);
		return display;
	}

	public static boolean isTenInch(Context context) {
		// Configuration.SCREENLAYOUT_SIZE_XLARGE = 4
		return (context.getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) >= 4;
	}

	public static boolean isTablet(Context context) {
		// Configuration.SCREENLAYOUT_SIZE_LARGE = 3
		return (context.getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) >= 3;
	}

	public CRunAndroidPlus() {
		handlerMem = new Handler();
		dRet = new CValue(0);
	}

	public @Override
	int getNumberOfConditions() {
		return CND_LAST;
	}

	public @Override
	boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version) {
		run = ho.hoAdRunHeader;
		app = run.rhApp;

		ActualMode = app.viewMode;
		OriginalMode = app.viewMode;
		islandscape = isLandscape();
		istablet = isTablet(ho.getControlsContext());
		screenSizeInches = deviceInch(MMFRuntime.inst);

		emulEvent = -1;

		//Get the current system brightness
		try {
			systembright = Settings.System.getInt(MMFRuntime.inst.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
			MMFRuntime.inst.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					WindowManager.LayoutParams layout = MMFRuntime.inst.getWindow().getAttributes();
					screenbright = layout.screenBrightness;
				}
			});
		} catch (SettingNotFoundException e) {
		}

		toastDuration = Toast.LENGTH_SHORT;
		toastGravity = Gravity.CENTER;

		isBatteryOptimized = false;
		if (MMFRuntime.deviceApi >= 23) {
			PowerManager pm = (PowerManager) MMFRuntime.inst.getSystemService(POWER_SERVICE);
			isBatteryOptimized = pm.isIgnoringBatteryOptimizations(MMFRuntime.inst.getPackageName());
		}

		ReadMemoryDelay = Integer.MAX_VALUE;
		return false;
	}

	public @Override
	void destroyRunObject(boolean bFast) {
		MMFRuntime.joystickEmul = false;
		CJoystickEmulated.autorelease = false;
	}

	public @Override
	int handleRunObject() {
		if (CJoystickEmulated.autorelease && ho.getEventCount() <= emulEvent)
			CJoystickEmulated.release();
		return 0;
	}

	public @Override
	void continueRunObject() {
		if (this.shareRet != null && this.shareRet) {
			if (shareRes == Activity.RESULT_OK)
				ho.pushEvent(CNDSHAREOK, 0);
			ho.pushEvent(CNDSHAREWITHRESULT, 0);
			this.shareRet = false;
		}
		if (googleAcctRet == 1)
			ho.pushEvent(CNDACCOUNTOK, 0);
		if (googleAcctRet == 2)
			ho.pushEvent(CNDACCOUNTCANCEL, 0);

		ho.pushEvent(CNDAPPFROMPAUSE, 0);

		isBatteryOptimized = false;
		if (MMFRuntime.deviceApi >= 23) {
			PowerManager pm = (PowerManager) MMFRuntime.inst.getSystemService(POWER_SERVICE);
			isBatteryOptimized = pm.isIgnoringBatteryOptimizations(MMFRuntime.inst.getPackageName());
			RestoreAutoEnd();
		}
	}


	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == SHARED_OK) {
			shareRes = resultCode;
			shareRet = true;
		}
		if (requestCode == REQUEST_ACCOUNTCODE) {
			googleAcctRet = 0;
			if (resultCode == Activity.RESULT_OK) {
				googleAccount = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
				googleAcctRet = 1;
			} else {
				googleAccount = null;
				googleAcctRet = 2;
			}
		}
		RestoreAutoEnd();
	}


	private boolean appEndOn = false;
	//////////////////////////////////////////////////////////////////////
	//
	//			Control functions
	//
	/////////////////////////////////////////////////////////////////////

	private void RestoreAutoEnd() {
		if (appEndOn) {
			appEndOn = false;
			MMFRuntime.inst.app.hdr2Options |= CRunApp.AH2OPT_AUTOEND;
		}
	}

	private void SuspendAutoEnd() {
		//AH2OPT_AUTOEND
		if (!appEndOn && MMFRuntime.inst.app != null && (MMFRuntime.inst.app.hdr2Options & CRunApp.AH2OPT_AUTOEND) != 0) {
			appEndOn = true;
			MMFRuntime.inst.app.hdr2Options &= ~CRunApp.AH2OPT_AUTOEND;
		}
	}


	/**
	 * Enables/Disables all child views in a view group.
	 *
	 * @param viewGroup the view group
	 * @param enabled   <code>true</code> to enable, <code>false</code> to disable
	 *                  the views.
	 */
	public static void enableDisableViewGroup(ViewGroup viewGroup, boolean enabled) {
		int childCount = viewGroup.getChildCount();
		for (int i = 0; i < childCount; i++) {
			View view = viewGroup.getChildAt(i);
			view.setEnabled(enabled);
			if (view instanceof ViewGroup) {
				enableDisableViewGroup((ViewGroup) view, enabled);
			}
		}
	}

	// Conditions
	// -------------------------------------------------
	public @Override
	boolean condition(int num, CCndExtension cnd) {
		switch (num) {
			case CNDDISPLAYCENTER:
				return cndDisplaycenter(cnd);
			case CNDDISPLAYADJUST:
				return cndDisplayAdjust(cnd);
			case CNDDISPLAYFITI:
				return cndDisplayFitI(cnd);
			case CNDDISPLAYFITIA:
				return cndDisplayFitIA(cnd);
			case CNDDISPLAYFITO:
				return cndDisplayFitO(cnd);
			case CNDDISPLAYSTRETCH:
				return cndDisplayStretch(cnd);
			case CNDDISTOUCHENABLE:
				return cndTouchEnable(cnd);
			case CNDDISTABLET:
				return cndIsTablet(cnd);
			case CNDDISLANDSCAPE:
				return cndIsLandscape(cnd);
			case CNDSHAREOK:
				return true;
			case CNDLOCALELIST:
				return isLocale();
			case CNDTIMEZONELIST:
				return isTimeZone();
			case CNDISEXPAVAILABLE:
				return MMFRuntime.inst.obbAvailable;
			case CNDAPPFROMPAUSE:
				return true;
			case CNDSHAREWITHRESULT:
				return cndSharewithResult(cnd);
			case CNDACCOUNTOK:
				return true;
			case CNDACCOUNTCANCEL:
				return true;
			case CNDISBATTOPTIGNORED:
				return isBatteryOptimized;
		}
		return false;
	}

	private boolean isLocale() {
		CRun rhPtr = ho.hoAdRunHeader;
		if (localeEvent == -1) {
			return false;
		}
		if ((ho.hoFlags & HOF_TRUEEVENT) != 0) {
			return true;
		}
		if (rhPtr.rh4EventCount == localeEvent) {
			return true;
		}
		return false;
	}

	private boolean isTimeZone() {
		CRun rhPtr = ho.hoAdRunHeader;
		if (timezoneEvent == -1) {
			return false;
		}
		if ((ho.hoFlags & HOF_TRUEEVENT) != 0) {
			return true;
		}
		if (rhPtr.rh4EventCount == timezoneEvent) {
			return true;
		}
		return false;
	}

	// Actions
	// -------------------------------------------------
	public @Override
	void action(int num, CActExtension act) {
		switch (num) {
			case ACTSAVEFLAG:
				actSaveFlag(act);
				break;
			case ACTSETFLAG:
				actSetFlag(act);
				break;
			case ACTRESTOREFLAG:
				actRestoreFlag(act);
				break;
			case ACTREFRESH:
				actRefresh(act);
				break;
			case ACTDISABLETOUCH:
				actDisableTouch(act);
				break;
			case ACTENABLETOUCH:
				actEnableTouch(act);
				break;
			case ACTSTARTEMULJOYSTICK:
				actStartEmulJoystick(act);
				break;
			case ACTEMULATEJOYSTICK:
				actEmulateJoystick(act);
				break;
			case ACTRELEASEJOYSTICK:
				actReleaseJoystick(act);
				break;
			case ACTSETPREFNAME:
				actSetPrefName(act);
				break;
			case ACTSETPREFSTRING:
				actSetPrefString(act);
				break;
			case ACTSETPREFINT:
				actSetPrefInteger(act);
				break;
			case ACTSETPREFFLOAT:
				actSetPrefFloat(act);
				break;
			case ACTSETPREFBOOL:
				actSetPrefBool(act);
				break;
			case ACTSHAREIMAGE:
				actShareImage(act);
				break;
			case ACTSHARETEXT:
				actShareText(act);
				break;
			case ACTSETLOCALBRIGHT:
				actSetLocalBright(act);
				break;
			case ACTSETSYSBRIGHT:
				actSetSystemBright(act);
				break;
			case ACTREADLOCALE:
				actReadLocale(act);
				break;
			case ACTSETLANGUAGE:
				actSetlanguage(act);
				break;
			case ACTREADTIMEZONE:
				actReadTimezone(act);
				break;
			//case ACTSETTIMEZONE:
			//	actSetTimezone(act);
			//	break;
			case ACTCHANGEDATETIME:
				actChangeTimeSettings(act);
				break;
			case ACTSTARTSLEEP:
				actStartToSleep(act);
				break;
			case ACTINJECTKEY:
				actInjectKey(act);
				break;
			case ACTSTARTAPK:
				actStartApk(act);
				break;
			case ACTFLASHLIGHT:
				actFlashLight(act);
				break;
			case ACTWAKEUP:
				actWakeUp(act);
				break;
			case ACTPORTRAIT:
				actPortrait(act);
				break;
			case ACTLANDSCAPE:
				actLandscape(act);
				break;
			case ACTTOANY:
				actToAny(act);
				break;
			case ACTDEVICEVOL:
				actDeviceVolume(act);
				break;
			case ACTSETINMERSIVE:
				actSetImmersive(act);
				break;
			case ACTBARCOLOR:
				actBarColor(act);
				break;
			case ACTBARTXTCOLOR:
				actBarTextColor(act);
				break;
			case ACTSTATUSCOLOR:
				actStatusColor(act);
				break;
			case ACTDISPTITLE:
				actDisplayTitle(act);
				break;
			case ACTDISPLOGO:
				actDisplayLogo(act);
				break;
			case ACTDISPHOME:
				actDisplayHomeUp(act);
				break;
			case ACTBARTITLE:
				actActionBarTitle(act);
				break;
			case ACTMENTXTCOLOR:
				actMenuTextColor(act);
				break;
			case ACTDISPMENU:
				actDisplayMenuMode(act);
				break;
			case ACTSETICON:
				actSetIcon(act);
				break;
			case ACTSETLOGO:
				actSetLogo(act);
				break;
			case ACTSETHOME:
				actSetHomeIcon(act);
				break;
			case ACTSETMENU:
				actSetMenuIcon(act);
				break;
			case ACTSHORTCUT:
				actSetShortcutInstall(act);
				break;
			case ACTMSGALIGN:
				actToastAlign(act);
				break;
			case ACTMSGDURATION:
				actToastDuration(act);
				break;
			case ACTMSGHOFFSET:
				actToastHorzOffset(act);
				break;
			case ACTMSGVOFSSET:
				actToastVertOffset(act);
				break;
			case ACTMSGSHOW:
				actToastShow(act);
				break;
			case ACTASKACCOUNT:
				actAskAccount(act);
				break;
			case ACTREQBATTOPTIGNORED:
				actReqIgnoreBattOpt(act);
				break;
			case ACTASKFORGC:
				actAskGCforFreeMemory(act);
				break;
			case ACTSTARTREADMEM:
				actStartMemoryRead(act);
				break;
			case ACTSTOPREADMEM:
				actStopMemoryRead(act);
				break;
			case ACTSTATUSCOLTR:
				actStatusColorAlpha(act);

		}
	}

	// Expressions
	// -------------------------------------------------
	public @Override
	CValue expression(int num) {
		switch (num) {
			case EXPGETDMODE:
				return expGetDMode();
			case EXPGETSAVEDMODE:
				return expGetSaveDMode();
			case EXPGETORIGDMODE:
				return expGetOrigDMode();
			case EXPGETSCREENSIZE:
				return expGetScreenSize();
			case EXPGETSCREENWIDTH:
				return expGetScreenWidth();
			case EXPGETSCREENHEIGHT:
				return expGetScreenHeight();
			case EXPGETSCREENDPIHORZ:
				return expGetScreenDPIHorizontal();
			case EXPGETSCREENDPIVERT:
				return expGetScreenDPIVertical();
			case EXPGETSCREENDENSITY:
				return expGetScreenDensityDPI();
			case EXPGETSCREENDENSRATIO:
				return expGetScreenDensityRatio();
			case EXPGETPREFSTRING:
				return expGetPrefString();
			case EXPGETPREFINTEGER:
				return expGetPrefInteger();
			case EXPGETPREFFLOAT:
				return expGetPrefFloat();
			case EXPGETPREFBOOL:
				return expGetPrefBool();
			case EXPGETLOCALBRIGHT:
				return expGetLocalBright();
			case EXPGETSYSBRIGHT:
				return expGetSystemBright();
			case EXPGETLOCALEQTY:
				return expGetLocaleQty();
			case EXPGETLOCALE:
				return expGetLocale();
			case EXPGETLOCALECOUNTRY:
				return expGetLocaleCountry();
			case EXPGETDEFAULTLOCALE:
				return expGetDefaultLocale();
			case EXPGETTIMEZONEQTY:
				return expGetTimeZoneQty();
			case EXPGETTIMEZONEID:
				return expGetTimeZoneID();
			case EXPGETTIMEZONEGMT:
				return expGetTimeZoneGMT();
			case EXPGETDEFAULTTIMEZONEID:
				return expGetDefaultTimeZoneID();
			case EXPGETDEFAULTTIMEZONEGMT:
				return expGetDefaultTimeZoneGMT();
			case EXPGETUNIQUEHARDID:
				return expGetUniqueHardwareID();
			case EXPGETDEVICEVOL:
				return expGetDeviceVolume();
			case EXPGETDARKERCOLOR:
				return expGetDarkerColor();
			case EXPGETLIGHTERCOLOR:
				return expGetLighterColor();
			case EXPGETACTIONBARHEIGHT:
				return expGetActionBarHeight();
			case EXPGETACTIONBARCOLOR:
				return expGetActionBarColor();
			case EXPGETGOOGLEACCOUNT:
				return expGetGoogleAccount();
			case EXPGETTOTALMEM:
				return expGetTotalMemoryMB();
			case EXPGETFREEMEM:
				return expGetFreeMemoryMB();
			case EXPGETUSEDMEM:
				return expGetUsedMemoryMB();
			case EXPGETMAXMEM:
				return expGetMaxMemoryMB();
			case EXPGETNATIVEMEM:
				return expGetNativeMemoryMB();
		}
		return null;
	}

	////////////////////////////////////////////////////////////////////////////////////////
	//
	//								CONDITIONS
	//
	////////////////////////////////////////////////////////////////////////////////////////

	private boolean cndDisplaycenter(CCndExtension cnd) {
		if (ActualMode == CRunApp.VIEWMODE_CENTER)
			return true;
		return false;
	}

	private boolean cndDisplayAdjust(CCndExtension cnd) {
		if (ActualMode == CRunApp.VIEWMODE_ADJUSTWINDOW)
			return true;
		return false;
	}

	private boolean cndDisplayFitI(CCndExtension cnd) {
		if (ActualMode == CRunApp.VIEWMODE_FITINSIDE_BORDERS)
			return true;
		return false;
	}

	private boolean cndDisplayFitIA(CCndExtension cnd) {
		if (ActualMode == CRunApp.VIEWMODE_FITINSIDE_ADJUSTWINDOW)
			return true;
		return false;
	}

	private boolean cndDisplayFitO(CCndExtension cnd) {
		if (ActualMode == CRunApp.VIEWMODE_FITOUTSIDE)
			return true;
		return false;
	}

	private boolean cndDisplayStretch(CCndExtension cnd) {
		if (ActualMode == CRunApp.VIEWMODE_STRETCH)
			return true;
		return false;
	}

	private boolean cndTouchEnable(CCndExtension cnd) {
		if (MMFRuntime.inst.mainView != null && MMFRuntime.inst.mainView.isFocusableInTouchMode())
			return true;
		return false;
	}

	private boolean cndIsTablet(CCndExtension cnd) {
		if (MMFRuntime.inst.mainView != null && istablet)
			return true;
		return false;
	}

	private boolean cndIsLandscape(CCndExtension cnd) {
		if (MMFRuntime.inst.mainView != null && islandscape)
			return true;
		return false;
	}

	private boolean cndSharewithResult(CCndExtension cnd) {
		int param0 = cnd.getParamExpression(rh, 0);
		int toCmp = -2;
		if (param0 == 0)
			toCmp = Activity.RESULT_OK;
		if (param0 == 1)
			toCmp = Activity.RESULT_CANCELED;
		if (param0 == 2)
			toCmp = Activity.RESULT_FIRST_USER;
		if (toCmp == shareRes)
			return true;
		return false;
	}

	////////////////////////////////////////////////////////////////////////
	//
	//                    ACTIONS
	//
	////////////////////////////////////////////////////////////////////////

	private void actSaveFlag(CActExtension act) {
		SavedMode = ActualMode;
	}

	private void actSetFlag(CActExtension act) {
		int param0 = act.getParamExpression(rh, 0);
		if (param0 > -1 && param0 < 6) {
			ActualMode = param0;
			app.viewMode = (short) ActualMode;
		}
	}

	private void actRestoreFlag(CActExtension act) {
		ActualMode = SavedMode;
	}

	private void actRefresh(CActExtension act) {
		MMFRuntime.inst.updateViewport();
	}

	private void actDisableTouch(CActExtension act) {

		if (MMFRuntime.inst.mainView != null) {
			enableDisableViewGroup(MMFRuntime.inst.mainView, false);
		}

	}

	private void actEnableTouch(CActExtension act) {

		if (MMFRuntime.inst.mainView != null) {
			enableDisableViewGroup(MMFRuntime.inst.mainView, true);
		}

	}

	private void actStartEmulJoystick(CActExtension act) {
		int param0 = act.getParamExpression(rh, 0);
		autorelease = act.getParamExpression(rh, 1);
		if (param0 != 0)
			MMFRuntime.joystickEmul = true;
		else
			MMFRuntime.joystickEmul = false;

		CJoystickEmulated.autorelease = (autorelease != 0 ? true : false);
	}

	private void actEmulateJoystick(CActExtension act) {
		int joyPlayer = act.getParamExpression(rh, 0);
		int joyValue = act.getParamExpression(rh, 1);

		if (!MMFRuntime.joystickEmul)
			return;

		if (joyPlayer < 1 && joyPlayer > 4)
			return;

		if (joyValue < 0 && joyValue > 63)
			return;

		--joyPlayer;

		final byte[] rhPlayer = CJoystickEmulated.rhPlayer;

		if (CJoystickEmulated.autorelease && (lastCmd & 0x30) != 0)
			rhPlayer[joyPlayer] &= 0x0F;

		rhPlayer[joyPlayer] |= lastCmd = (byte) (joyValue & 0x3F);

		emulEvent = ho.getEventCount() + 1;
	}

	private void actReleaseJoystick(CActExtension act) {
		int joyPlayer = act.getParamExpression(rh, 0);

		if (!MMFRuntime.joystickEmul)
			return;

		if (joyPlayer < 1 || joyPlayer > 4)
			return;

		--joyPlayer;

		final byte[] rhPlayer = CJoystickEmulated.rhPlayer;
		rhPlayer[joyPlayer] &= 0x00;
	}

	private void actSetPrefName(CActExtension act) {
		String param0 = act.getParamExpString(rh, 0);
		PreferenceName = null;
		if (param0.length() > 0) {
			PreferenceName = param0;
			prefsPrivate = MMFRuntime.inst.getSharedPreferences(PreferenceName, Context.MODE_PRIVATE);
		}
	}

	private void actSetPrefString(CActExtension act) {
		String field = act.getParamExpString(rh, 0);
		String value = act.getParamExpString(rh, 1);
		if (prefsPrivate != null && field.length() > 0) {
			Editor prefsPrivateEditor = prefsPrivate.edit();
			prefsPrivateEditor.putString(field, value);
			prefsPrivateEditor.commit();
		}
	}

	private void actSetPrefInteger(CActExtension act) {
		String field = act.getParamExpString(rh, 0);
		int value = act.getParamExpression(rh, 1);
		if (prefsPrivate != null && field.length() > 0) {
			Editor prefsPrivateEditor = prefsPrivate.edit();
			prefsPrivateEditor.putInt(field, value);
			prefsPrivateEditor.commit();
		}
	}

	private void actSetPrefFloat(CActExtension act) {
		String field = act.getParamExpString(rh, 0);
		float value = act.getParamExpFloat(rh, 1);
		if (prefsPrivate != null && field.length() > 0) {
			Editor prefsPrivateEditor = prefsPrivate.edit();
			prefsPrivateEditor.putFloat(field, value);
			prefsPrivateEditor.commit();
		}
	}

	private void actSetPrefBool(CActExtension act) {
		String field = act.getParamExpString(rh, 0);
		int value = act.getParamExpression(rh, 1);
		if (prefsPrivate != null && field.length() > 0) {
			Editor prefsPrivateEditor = prefsPrivate.edit();
			if (value != 0)
				prefsPrivateEditor.putBoolean(field, true);
			else
				prefsPrivateEditor.putBoolean(field, false);
		}
	}

	private void actShareImage(CActExtension act) {
		String param0 = act.getParamExpString(rh, 0);
		String param1 = act.getParamExpString(rh, 1);

		Intent share = new Intent(Intent.ACTION_SEND);

		if (param0.length() > 0) {
			share.setType("image/jpeg");

			if (param0.contains("http"))
				share.putExtra(Intent.EXTRA_STREAM,
						Uri.parse(param0));
			else
				share.putExtra(Intent.EXTRA_STREAM,
						Uri.parse("file://" + param0));
		}

		if (param0.length() == 0 && param1.length() > 0)
			share.setType("text/plain");

		if (param1.length() > 0)
			share.putExtra(Intent.EXTRA_TEXT, param1);

		SuspendAutoEnd();
		shareRet = false;
		MMFRuntime.inst.startActivityForResult(Intent.createChooser(share, "Share Image and Text"), SHARED_OK);
	}

	private void actShareText(CActExtension act) {
		String param0 = act.getParamExpString(rh, 0);
		Intent share = new Intent(Intent.ACTION_SEND);
		share.setType("text/plain");
		share.putExtra(Intent.EXTRA_TEXT, param0);
		SuspendAutoEnd();
		shareRet = false;
		MMFRuntime.inst.startActivityForResult(Intent.createChooser(share, "Share Text"), SHARED_OK);
	}

	private void actSetLocalBright(CActExtension act) {
		final float param0 = (float) act.getParamExpDouble(rh, 0) / 100.0f;
		if (param0 >= 0 && param0 <= 1.0) {
			MMFRuntime.inst.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					WindowManager.LayoutParams layout = MMFRuntime.inst.getWindow().getAttributes();
					layout.screenBrightness = param0;
					MMFRuntime.inst.getWindow().setAttributes(layout);
					screenbright = layout.screenBrightness;
				}
			});
		}
	}

	private void actSetSystemBright(CActExtension act) {
		final int param0 = (int) (act.getParamExpression(rh, 0) * 2.55);
		if (param0 >= 0 && param0 <= 255) {
			try {
				ContentResolver cResolver = MMFRuntime.inst.getApplicationContext().getContentResolver();
				Settings.System.putInt(cResolver, Settings.System.SCREEN_BRIGHTNESS, param0);
				systembright = Settings.System.getInt(MMFRuntime.inst.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
			} catch (SettingNotFoundException e) {
			}

		}
	}

	private void actReadLocale(CActExtension act) {
		if (locs != null) {
			locs = null;
		}

		locs = Locale.getAvailableLocales();

		if (locs != null) {
			localeEvent = ho.getEventCount();
			ho.generateEvent(CNDLOCALELIST, 0);
		}
	}

	private void actSetlanguage(CActExtension act) {
		String param0 = act.getParamExpString(rh, 0);
		if (param0.length() < 2 || !param0.contains("_"))
			return;

		Context context = MMFRuntime.inst.getBaseContext();
		String lang = "";
		String country = "";

		try {
			String field[] = param0.split("_");

			if (field[0].length() > 0)
				lang = field[0];
			if (field[1].length() > 0)
				country = field[1];

			if (lang.length() > 2 || country.length() > 2)
				return;

			Locale locale = new Locale(lang, country);

			Locale.setDefault(locale);

			Configuration config = new Configuration();
			config.locale = locale;
			context.getResources().updateConfiguration(config,
					context.getResources().getDisplayMetrics());
		} catch (ArrayIndexOutOfBoundsException e) {
			Log.Log("Malformed Language string ...");
		}
	}


	private void actReadTimezone(CActExtension act) {
		if (timezones != null)
			timezones = null;

		timezones = TimeZone.getAvailableIDs();

		if (timezones != null) {
			timezoneEvent = ho.getEventCount();
			ho.generateEvent(CNDTIMEZONELIST, 0);
		}

	}

	private void actChangeTimeSettings(CActExtension act) {
		Intent dateIntent = new Intent(android.provider.Settings.ACTION_DATE_SETTINGS);
		SuspendAutoEnd();
		MMFRuntime.inst.startActivity(dateIntent);
	}

	private void actStartToSleep(CActExtension act) {
		final int time = act.getParamExpression(rh, 0) * 1000;
		turnScreenOff(time);
	}

	private void actInjectKey(CActExtension act) {
		final int key = act.getParamExpression(rh, 0);
		CServices.simulateKey(key);
	}

	private void actStartApk(CActExtension act) {
		String name = act.getParamExpString(rh, 0);

		Intent i;
		PackageManager manager = MMFRuntime.inst.getPackageManager();
		try {
			i = manager.getLaunchIntentForPackage(name);
			if (i == null)
				throw new PackageManager.NameNotFoundException();
			i.addCategory(Intent.CATEGORY_LAUNCHER);

			MMFRuntime.inst.startActivity(i);
		} catch (PackageManager.NameNotFoundException e) {
			Log.Log("Package Not Found ...");

		}
	}

	@SuppressWarnings("deprecation")
	private void actSetShortcutInstall(CActExtension act) {
		String name = act.getParamExpString(rh, 0);
		Intent shortcutIntent = new Intent(MMFRuntime.inst.getApplicationContext(), MMFRuntime.inst.getClass());
		shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

		Intent addIntent = new Intent();
		addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
		addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, name);
		addIntent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
				Intent.ShortcutIconResource.fromContext(MMFRuntime.inst.getApplicationContext(),
						MMFRuntime.inst.getResourceID("drawable/launcher")));
		addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
		MMFRuntime.inst.getApplicationContext().sendBroadcast(addIntent);
	}

	private Camera camera;

	@SuppressWarnings("deprecation")
	void LedON() {
		if (camera != null)
			camera.release();
		camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_BACK);
		camera.startPreview();
		camera.autoFocus(new AutoFocusCallback() {
			@Override
			public void onAutoFocus(boolean success, Camera camera) {
			}
		});

		Parameters params = camera.getParameters();
		params.setFlashMode(Parameters.FLASH_MODE_TORCH);
		camera.setParameters(params);
	}

	void LedOFF() {
		if (camera != null) {
			Camera.Parameters p = camera.getParameters();
			p.setFlashMode(Parameters.FLASH_MODE_OFF);
			camera.setParameters(p);
			camera.release();
		}
	}

	private void actFlashLight(CActExtension act) {
		final int enable = act.getParamExpression(rh, 0);
		try {
			if (enable != 0) {
				LedON();
			} else {
				LedOFF();
			}

		} catch (Exception e) {
			Log.Log("Error " + e.getMessage());
		}
	}

	@SuppressLint("Wakelock")
	private void actWakeUp(CActExtension act) {
		try {
			PowerManager pm = (PowerManager) MMFRuntime.inst.getSystemService(POWER_SERVICE);
			PowerManager.WakeLock wl = pm.newWakeLock(
					PowerManager.PARTIAL_WAKE_LOCK //| PowerManager.ACQUIRE_CAUSES_WAKEUP,
					, "ALARMFUSION");

			//Acquire the lock
			wl.acquire();
			SystemClock.sleep(1000);
			wl.release();
		} catch (Exception e) {
			Log.Log("Error " + e.getMessage());
		}
	}

	private void actPortrait(CActExtension act) {
		int tmp;
		try {
			tmp = act.getParamExpression(rh, 0);
		} catch (Exception e) {
			tmp = 0;
		}
		final int flg = tmp;
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.isShortOut = true;
					if (flg != 0)
						MMFRuntime.inst.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
					else
						MMFRuntime.inst.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
				}
			}

		});
	}

	private void actLandscape(CActExtension act) {
		int tmp;
		try {
			tmp = act.getParamExpression(rh, 0);
		} catch (Exception e) {
			tmp = 0;
		}
		final int flg = tmp;
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.isShortOut = true;
					if (flg != 0)
						MMFRuntime.inst.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
					else
						MMFRuntime.inst.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
				}
			}

		});

	}

	private void actToAny(CActExtension act) {
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.isShortOut = true;
					MMFRuntime.inst.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
				}
			}

		});

	}

	private void actDeviceVolume(CActExtension act) {

		float vol = act.getParamExpression(rh, 0);

		if (vol > 100.0f)
			vol = 100.0f;

		if (vol < 0.0f)
			vol = 0.0f;

		if (getDeviceVolume() == vol)
			return;

		AudioManager audioMgr = (AudioManager) MMFRuntime.inst.getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
		if (audioMgr != null) {
			int max = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

			int hard_vol = Math.round(vol / 100.0f * (max));
			audioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, hard_vol, 0);
		}
	}

	public float getDeviceVolume() {
		AudioManager audioMgr = (AudioManager) MMFRuntime.inst.getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
		if (audioMgr != null) {
			float streamVolumeCurrent = audioMgr.getStreamVolume(AudioManager.STREAM_MUSIC);
			float streamVolumeMax = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
			return Math.round((streamVolumeCurrent / streamVolumeMax) * 100.0f);
		}
		return 0;
	}

	private void actSetImmersive(CActExtension act) {
		final int var = act.getParamExpression(rh, 0);
		if (MMFRuntime.deviceApi >= 19) {
			MMFRuntime.inst.runOnUiThread(new Runnable() {

				@Override
				public void run() {
					synchronized (MMFRuntime.inst) {
						if (var != 0)
							MMFRuntime.inst.hideSystemUI();
						else
							MMFRuntime.inst.showSystemUI();
					}
				}

			});
		}

	}

	private void actBarColor(CActExtension act) {
		final int color = act.getParamColour(rh, 0);
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setActionBarColor(color);
				}
			}

		});

	}

	private void actBarTextColor(CActExtension act) {
		final int color = act.getParamColour(rh, 0);
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setActionBarTextColor(color);
				}
			}

		});

	}

	private void actStatusColor(CActExtension act) {
		final int colored = act.getParamColour(rh, 0);
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setStatusBarColor(colored);
				}
			}

		});

	}

	private void actDisplayTitle(CActExtension act) {
		final int flag = act.getParamExpression(rh, 0);
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setDisplayTitle(flag);
				}
			}

		});

	}

	private void actDisplayLogo(CActExtension act) {
		final int flag = act.getParamExpression(rh, 0);
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setDisplayLogo(flag);
				}
			}

		});

	}

	private void actDisplayHomeUp(CActExtension act) {
		final int flag = act.getParamExpression(rh, 0);
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setDisplayHomeUp(flag);
				}
			}

		});

	}

	private void actActionBarTitle(CActExtension act) {
		final String title = act.getParamExpString(rh, 0);
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setActionBarTitle(title);
				}
			}

		});

	}

	private void actMenuTextColor(CActExtension act) {
		MMFRuntime.inst.colorMenuItem = act.getParamColour(rh, 0);
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.invalidateOptionsMenu();
				}
			}

		});
	}

	private void actDisplayMenuMode(CActExtension act) {
		if (act.getParamExpression(rh, 0) != 0)
			MMFRuntime.inst.menuMode = true;
		else
			MMFRuntime.inst.menuMode = false;

		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.invalidateOptionsMenu();
				}
			}

		});

	}

	private void actSetIcon(CActExtension act) {
		String param0 = act.getParamExpString(rh, 0).trim();
		if (param0.length() != 0)
			MMFRuntime.inst.IconActionBar = param0;
		else
			MMFRuntime.inst.IconActionBar = null;

		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setDisplayLogo(-1);
				}
			}

		});
	}

	private void actSetLogo(CActExtension act) {
		String param0 = act.getParamExpString(rh, 0).trim();
		if (param0.length() != 0)
			MMFRuntime.inst.LogoActionBar = param0;
		else
			MMFRuntime.inst.LogoActionBar = null;

		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setDisplayLogo(-1);
				}
			}

		});
	}

	private void actSetHomeIcon(CActExtension act) {
		String param0 = act.getParamExpString(rh, 0).trim();
		if (param0.length() != 0)
			MMFRuntime.inst.HomeActionBar = param0;
		else
			MMFRuntime.inst.HomeActionBar = null;

		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setDisplayHomeUp(-1);
				}
			}

		});
	}

	private void actSetMenuIcon(CActExtension act) {
		String param0 = act.getParamExpString(rh, 0).trim();
		if (param0.length() != 0)
			MMFRuntime.inst.MenuActionBar = param0;
		else
			MMFRuntime.inst.MenuActionBar = null;

		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.invalidateOptionsMenu();
				}
			}

		});

	}

	private void actToastAlign(CActExtension act) {
		int key = act.getParamExpression(rh, 0);

		toastGravity = 0;

		if ((key & 1) != 0) {
			toastGravity |= Gravity.CENTER_HORIZONTAL;
		}
		if ((key & 2) != 0) {
			toastGravity |= Gravity.CENTER_VERTICAL;
		}
		if ((key & 4) != 0) {
			toastGravity |= Gravity.LEFT;
		}
		if ((key & 8) != 0) {
			toastGravity |= Gravity.TOP;
		}
		if ((key & 16) != 0) {
			toastGravity |= Gravity.RIGHT;
		}
		if ((key & 32) != 0) {
			toastGravity |= Gravity.BOTTOM;
		}
	}

	private void actToastDuration(CActExtension act) {
		int selection = act.getParamExpression(rh, 0);
		if (selection == 1)
			toastDuration = Toast.LENGTH_LONG;
		else
			toastDuration = Toast.LENGTH_SHORT;
	}

	private void actToastHorzOffset(CActExtension act) {
		horizontalOffset = act.getParamExpression(rh, 0);
	}

	private void actToastVertOffset(CActExtension act) {
		verticalOffset = act.getParamExpression(rh, 0);
	}

	@SuppressWarnings("unused")
	private void actToastShow(CActExtension act) {
		String message = act.getParamExpString(rh, 0);

		try {
			Toast toast = Toast.makeText(MMFRuntime.inst, message, toastDuration);
			if (toast == null)
				throw new Exception("failed");

			toast.setGravity(toastGravity, horizontalOffset, verticalOffset);
			toast.show();
		} catch (Exception e) {
			Log.Log("Toast failed ...");

		}
	}

	private void actAskAccount(CActExtension act) {
		try {
			Intent googlePicker = AccountPicker.newChooseAccountIntent(null, null, new String[]{GoogleAuthUtil.GOOGLE_ACCOUNT_TYPE}, false, null, null, null, null);
			SuspendAutoEnd();
			MMFRuntime.inst.startActivityForResult(googlePicker, REQUEST_ACCOUNTCODE);
		} catch (ActivityNotFoundException e) {
			Log.Log("Activity not found");
		}
	}

	private void actReqIgnoreBattOpt(CActExtension act) {
		try {
			if (MMFRuntime.deviceApi >= 23) {
				Intent intent = new Intent();
				String packageName = MMFRuntime.inst.getPackageName();
				PowerManager pm = (PowerManager) MMFRuntime.inst.getSystemService(POWER_SERVICE);
				if (pm.isIgnoringBatteryOptimizations(packageName))
					intent.setAction(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
				else {
					intent.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
					intent.setData(Uri.parse("package:" + packageName));
				}
				SuspendAutoEnd();
				MMFRuntime.inst.startActivity(intent);
			}
		} catch (Exception e) {
			Log.Log("Request failed ...");

		}

	}

	private void actAskGCforFreeMemory(CActExtension act) {
		try {
			Runtime runtime = Runtime.getRuntime();
			runtime.gc();
			Log.Log("Used memory(MB): " + (int) (getUsedMemorySize() / 1024.0 / 1024.0));
		} catch (Exception e) {
			Log.Log("Request failed with error:" + e.getMessage());

		}

	}

	private void actStartMemoryRead(CActExtension act) {
		ReadMemoryDelay = act.getParamExpression(rh, 0);
		handlerMem.removeCallbacks(runMem);
		handlerMem.postDelayed(runMem, ReadMemoryDelay);
	}

	private void actStopMemoryRead(CActExtension act) {
		ReadMemoryDelay = Integer.MAX_VALUE;
		handlerMem.removeCallbacks(runMem);
	}


	private void actStatusColorAlpha(CActExtension act) {
		final int colored = act.getParamColour(rh, 0);
		final int alpha = Math.min(255, Math.max(0, act.getParamExpression(rh, 1)));
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				synchronized (MMFRuntime.inst) {
					MMFRuntime.inst.setStatusBarColor(colored, alpha);
				}
			}

		});

	}
	//////////////////////////////////////////////////////////////////////////////
	//
	//                         EXPRESSION
	//
	//////////////////////////////////////////////////////////////////////////////

	private CValue expGetDMode() {
		dRet.forceInt(ActualMode);
		return dRet;
	}

	private CValue expGetSaveDMode() {
		dRet.forceInt(SavedMode);
		return dRet;
	}

	private CValue expGetOrigDMode() {
		dRet.forceInt(ActualMode);
		return dRet;
	}

	private CValue expGetScreenSize() {
		dRet.forceDouble(screenSizeInches);
		return dRet;
	}

	private CValue expGetScreenWidth() {
		dRet.forceDouble(screenSizeWidth);
		return dRet;
	}

	private CValue expGetScreenHeight() {
		dRet.forceDouble(screenSizeHeight);
		return dRet;
	}

	private CValue expGetScreenDPIHorizontal() {
		dRet.forceDouble(screenSizeDpiHorz);
		return dRet;
	}

	private CValue expGetScreenDPIVertical() {
		dRet.forceDouble(screenSizeDpiVert);
		return dRet;
	}

	private CValue expGetScreenDensityDPI() {
		dRet.forceInt(screenSizeDensDPI);
		return dRet;
	}

	private CValue expGetScreenDensityRatio() {
		dRet.forceDouble(screenSizeDensRatio);
		return dRet;
	}

	private CValue expGetPrefString() {
		String field = ho.getExpParam().getString();
		dRet.forceString("<noprefs>");
		if (prefsPrivate != null && field.length() > 0) {
			String szRet = prefsPrivate.getString(field, "<empty>");
			dRet.forceString(szRet);
		}
		return dRet;
	}

	private CValue expGetPrefInteger() {
		String field = ho.getExpParam().getString();
		dRet.forceInt(-1);
		if (prefsPrivate != null && field.length() > 0) {
			dRet.forceInt(prefsPrivate.getInt(field, -1));
		}
		return dRet;
	}

	private CValue expGetPrefFloat() {
		String field = ho.getExpParam().getString();
		if (prefsPrivate != null && field.length() > 0) {
			float szRet = prefsPrivate.getFloat(field, -1);
			dRet.forceDouble(szRet);
		}
		return dRet;
	}

	private CValue expGetPrefBool() {
		String field = ho.getExpParam().getString();
		if (prefsPrivate != null && field.length() > 0) {
			int szRet = (prefsPrivate.getBoolean(field, false) ? 1 : 0);
			dRet.forceInt(szRet);
		}
		return dRet;
	}

	private CValue expGetLocalBright() {
		dRet.forceDouble(Math.abs(screenbright) * 100.0f);
		return dRet;
	}

	private CValue expGetSystemBright() {
		dRet.forceDouble(Math.round(systembright / 2.55f));
		return dRet;
	}

	private CValue expGetLocaleQty() {
		dRet.forceInt(-1);
		if (locs != null && locs.length > 0)
			dRet.forceInt(locs.length);
		return dRet;
	}

	private CValue expGetLocale() {
		int index = ho.getExpParam().getInt();
		dRet.forceString("");
		if (locs != null && index < locs.length)
			dRet.forceString(locs[index].getLanguage());
		return dRet;
	}

	private CValue expGetLocaleCountry() {
		int index = ho.getExpParam().getInt();
		dRet.forceString("");
		if (locs != null && index < locs.length)
			dRet.forceString(locs[index].getCountry());
		return dRet;
	}

	private CValue expGetDefaultLocale() {
		dRet.forceString(Locale.getDefault().getLanguage());
		return dRet;
	}

	private CValue expGetTimeZoneQty() {
		dRet.forceInt(-1);
		if (timezones != null && timezones.length > 0)
			dRet.forceInt(timezones.length);
		return dRet;
	}

	private CValue expGetTimeZoneID() {
		int index = ho.getExpParam().getInt();
		dRet.forceString("");
		if (timezones != null && index < timezones.length) {
			dRet.forceString(timezones[index]);
		}
		return dRet;
	}

	private CValue expGetTimeZoneGMT() {
		int index = ho.getExpParam().getInt();
		dRet.forceString("");
		if (timezones != null && index < timezones.length) {
			TimeZone tz = TimeZone.getTimeZone(timezones[index]);
			dRet.forceString(tz.getDisplayName(false, TimeZone.SHORT));
		}
		return dRet;
	}

	private CValue expGetDefaultTimeZoneID() {
		dRet.forceString(TimeZone.getDefault().getID());
		return dRet;
	}

	private CValue expGetDefaultTimeZoneGMT() {
		dRet.forceString(TimeZone.getDefault().getDisplayName(false, TimeZone.SHORT));
		return dRet;
	}

	private CValue expGetUniqueHardwareID() {

		dRet.forceString(getUniqueBuildID());
		return dRet;
	}

	private CValue expGetDeviceVolume() {

		dRet.forceDouble(getDeviceVolume());
		return dRet;
	}

	private CValue expGetDarkerColor() {

		int color = ho.getExpParam().getInt();
		dRet.forceInt((color & 0x0FEFEFE) >> 1);
		return dRet;
	}

	private CValue expGetLighterColor() {
		int color = ho.getExpParam().getInt();
		dRet.forceInt((color & 0x7F7F7F) << 1);
		return dRet;
	}

	private CValue expGetActionBarHeight() {

		TypedValue tv = new TypedValue();
		int actionBarHeight = 0;
		if (MMFRuntime.inst.deviceApi >= 11) {
			if (MMFRuntime.inst.getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true))
				actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, MMFRuntime.inst.getResources().getDisplayMetrics());
			if (actionBarHeight == 0) {
				ActionBar actionBar;
				actionBar = MMFRuntime.inst.getActionBar();
				actionBarHeight = actionBar.getHeight();
			}
		}
		dRet.forceInt(actionBarHeight);
		return dRet;
	}

	private CValue expGetActionBarColor() {

		TypedValue tv = new TypedValue();
		int color = 0;
		if (MMFRuntime.inst.deviceApi >= 11) {
			if (MMFRuntime.inst.getTheme().resolveAttribute(android.R.attr.actionModeBackground, tv, true))
				color = TypedValue.complexToDimensionPixelSize(tv.data, MMFRuntime.inst.getResources().getDisplayMetrics());
		}
		dRet.forceInt(color & 0x00FFFFFF);
		return dRet;
	}

	private CValue expGetGoogleAccount() {
		dRet.forceString("");
		if (googleAccount != null) {
			dRet.forceString(googleAccount);
		}
		return dRet;
	}

	private CValue expGetTotalMemoryMB() {

		dRet.forceDouble(totalSize);
		return dRet;
	}

	private CValue expGetFreeMemoryMB() {

		dRet.forceDouble(freeSize);
		return dRet;
	}

	private CValue expGetUsedMemoryMB() {

		dRet.forceDouble(usedSize);
		return dRet;
	}

	private CValue expGetMaxMemoryMB() {

		dRet.forceDouble(maxSize);
		return dRet;
	}

	private CValue expGetNativeMemoryMB() {

		dRet.forceDouble(nativeSize);
		return dRet;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//                                                UTLITIES
	//
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public class ScreenSynchronize {

		public void doWait(long l) {
			synchronized (this) {
				try {
					this.wait(l);
				} catch (InterruptedException e) {
				}
			}
		}

		public void doNotify() {
			synchronized (this) {
				this.notify();
			}
		}

		public void doWait() {
			synchronized (this) {
				try {
					this.wait();
				} catch (InterruptedException e) {
				}
			}
		}
	}

	private OnScreenResultListener screenListener = new OnScreenResultListener() {

		@Override
		public void onScreenOFF() {
			screenSync.doNotify();
		}
	};

	ScreenSynchronize screenSync = new ScreenSynchronize();

	public void turnScreenOff(int wait) {


		final Context context = MMFRuntime.inst;

		IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_ON);
		filter.addAction(Intent.ACTION_SCREEN_OFF);

		BroadcastReceiver mReceiver = new ScreenListener(screenListener);
		context.registerReceiver(mReceiver, filter);


		//set Development --> disable STAY_ON_WHILE_PLUGGED_IN
		Settings.System.putInt(context.getContentResolver(), Settings.System.STAY_ON_WHILE_PLUGGED_IN, 0);

		// take current screen off time 
		int defTimeOut = Settings.System.getInt(
				context.getContentResolver(),
				Settings.System.SCREEN_OFF_TIMEOUT,
				0);


		// set wait sec
		Settings.System.putInt(
				context.getContentResolver(),
				Settings.System.SCREEN_OFF_TIMEOUT,
				10);


		// wait X sec till get response from BroadcastReceiver on Screen Off
		screenSync.doWait(wait);


		// set previous settings
		Settings.System.putInt(context.getContentResolver(),
				Settings.System.SCREEN_OFF_TIMEOUT, defTimeOut);

		// switch back previous state
		Settings.System.putInt(context.getContentResolver(), Settings.System.STAY_ON_WHILE_PLUGGED_IN, BatteryManager.BATTERY_PLUGGED_USB | BatteryManager.BATTERY_PLUGGED_AC);


		context.unregisterReceiver(mReceiver);
	}

	private static String getMACAddress(String interfaceName) {
		try {
			List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
			for (NetworkInterface intf : interfaces) {
				if (interfaceName != null) {
					if (!intf.getName().equalsIgnoreCase(interfaceName)) continue;
				}
				byte[] mac = intf.getHardwareAddress();
				if (mac == null) return "";
				StringBuilder buf = new StringBuilder();
				for (int idx = 0; idx < mac.length; idx++)
					buf.append(String.format("%02Xy", mac[idx]));
				if (buf.length() > 0) buf.deleteCharAt(buf.length() - 1);
				return buf.toString();
			}
		} catch (Exception ex) {
		} // for now eat exceptions
		return "";
	}

	private static String ReadCPUinfo() {
		ProcessBuilder cmd;
		StringBuilder result = new StringBuilder();
		result.append("");

		try {
			String[] args = {"/system/bin/cat", "/proc/cpuinfo"};
			cmd = new ProcessBuilder(args);

			Process process = cmd.start();
			InputStream in = process.getInputStream();
			byte[] re = new byte[1024];

			while (in.read(re) != -1) {
				result.append(new String(re));
			}
			in.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return result.toString();
	}

	private static String getIMEI(Activity activity) {
		TelephonyManager telephonyManager = (TelephonyManager) activity
				.getSystemService(Context.TELEPHONY_SERVICE);
		return telephonyManager.getDeviceId();
	}

	private static boolean CheckCPU(String s) {

		int leng = s.length();
		int check = 0;
		char[] a = s.toCharArray();
		for (int i = 0; i < leng; i++) {
			if (a[i] == '0')
				check++;
			if (check > (leng / 2))
				return false;

		}

		return true;
	}

	private static String getUniqueBuildID() {
		String cpuinfo = ReadCPUinfo();
		String header = "";
		int mark1sz = 2;
		int mark1 = cpuinfo.lastIndexOf(": ");
		if (mark1 < 0) {
			mark1sz = 1;
			mark1 = cpuinfo.lastIndexOf(":");
		}
		if (mark1 >= 0) {
			int mark2 = cpuinfo.lastIndexOf("\n");
			if (mark2 < mark1 + mark1sz)
				header = cpuinfo.substring(mark1 + mark1sz);
			else
				header = cpuinfo.substring(mark1 + mark1sz, mark2);
		}
		String m_szDevIDShort;

		if (MMFRuntime.deviceApi < 23)
			m_szDevIDShort = header
					+ ((Build.BOARD.length() % 10)
					+ (Build.BRAND.length() % 10)
					+ (Build.CPU_ABI.length() % 10)
					+ (Build.DEVICE.length() % 10)
					+ (Build.MANUFACTURER.length() % 10)
					+ (Build.MODEL.length() % 10)
					+ (Build.PRODUCT.length() % 10));
		else
			m_szDevIDShort = header
					+ ((Build.BOARD.length() % 10)
					+ (Build.BRAND.length() % 10)
					+ (Build.DEVICE.length() % 10)
					+ (Build.MANUFACTURER.length() % 10)
					+ (Build.MODEL.length() % 10)
					+ (Build.PRODUCT.length() % 10));

		String serial = null;
		if (CheckCPU(header))
			serial = header;
		if (serial == null && MMFRuntime.inst.checkCallingOrSelfPermission("android.permission.READ_PHONE_STATE") == PackageManager.PERMISSION_GRANTED)
			serial = getIMEI(MMFRuntime.inst);
		if (serial == null)
			serial = System.getString(MMFRuntime.inst.getContentResolver(), System.ANDROID_ID);
		if (serial == null || serial.length() == 0)
			serial = getMACAddress("wlan0");

		return new UUID(m_szDevIDShort.hashCode(), serial.hashCode()).toString();
	}

	public static boolean isExternalStorageReadOnly() {
		String extStorageState = Environment.getExternalStorageState();
		if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStorageState)) {
			return true;
		}
		return false;
	}

	public static boolean isExternalStorageAvailable() {
		String extStorageState = Environment.getExternalStorageState();
		if (Environment.MEDIA_MOUNTED.equals(extStorageState)) {
			return true;
		}
		return false;
	}

	public long getUsedMemorySize() {

		long lfreeSize = 0L;
		long ltotalSize = 0L;
		long lusedSize = -1L;
		try {
			Runtime info = Runtime.getRuntime();
			lfreeSize = info.freeMemory();
			ltotalSize = info.totalMemory();
			lusedSize = ltotalSize - lfreeSize;

			freeSize = (int) (lfreeSize / 1048576.0 * 1000) / 1000.0;
			totalSize = (int) (ltotalSize / 1048576.0 * 1000) / 1000.0;
			usedSize = (int) (lusedSize / 1048576.0 * 1000) / 1000.0;
			maxSize = (int) (info.maxMemory() / 1048576.0 * 1000) / 1000.0;
			nativeSize = (int) (Debug.getNativeHeapAllocatedSize() / 1048576.0 * 1000) / 1000.0;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lusedSize;

	}

	private final Handler handlerMem;
	private final Runnable runMem = new Runnable() {
		@Override
		public void run() {
			getUsedMemorySize();
			handlerMem.postDelayed(this, ReadMemoryDelay);
		}
	};

}