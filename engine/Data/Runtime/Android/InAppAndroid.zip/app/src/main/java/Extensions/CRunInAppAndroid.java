/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;

import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;

import Actions.CActExtension;
import Application.CRunApp;
import Conditions.CCndExtension;
import Expressions.CValue;
import Extensions.InAppBroadcastReceiver.InAppBroadcastListener;
import RunLoop.CCreateObjectInfo;
import Runtime.Log;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunInAppAndroid extends CRunExtension
{
	// <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
	public static final int CNDONQUERYINVENTORY = 0;
	public static final int CNDONPURCHASEOK = 1;
	public static final int CNDONPURCHASEFAIL = 2;
	public static final int CNDONSUBSCRIPTIONOK = 3;
	public static final int CNDONSUBSCRIPTIONFAIL = 4;
	public static final int CNDONPURCHASECONSUME = 5;
	public static final int CNDONSUBSCRIPTIONCONSUME = 6;
	public static final int CNDISPURCHASED = 7;
	public static final int CNDISSUBSCIPTION = 8;
	public static final int CNDISBILLING = 9;
	public static final int CNDISBILLBUSY = 10;
	public static final int CNDONERROR = 11;
	public static final int CNDONNOTIFY = 12;
	public static final int CNDISREFUNDED = 13;
	public static final int CNDISCANCELED = 14;
	public static final int CNDONUPDATE = 15;
	public static final int CND_LAST = 16;

	public static final int ACTQUERYINVENTORY = 0;
	public static final int ACTSETDEVPAYLOAD = 1;
	public static final int ACTPURCHASEITEM = 2;
	public static final int ACTSUBSCRIPTIONITEM = 3;
	public static final int ACTDOCONSUME = 4;
	public static final int ACTSAVESTRING = 5;
	public static final int ACTSAVEINT = 6;

	public static final int EXPERROR = 0;
	public static final int EXPSTRERROR = 1;
	public static final int EXPRESPONSE = 2;
	public static final int EXPSTRRESPONSE = 3;
	public static final int EXPINVENTORY = 4;
	public static final int EXPPURCHASE = 5;
	public static final int EXPDATASTRING = 6;
	public static final int EXPDATAINT = 7;
	public static final int EXPDETAILSID = 8;
	public static final int EXPDETAILSTYPE = 9;
	public static final int EXPDETAILSPRICE = 10;
	public static final int EXPDETAILSTITLE = 11;
	public static final int EXPDETAILSDESCRIPTION = 12;
	public static final int EXPPURORDERID = 13;
	public static final int EXPPURPACKAGE = 14;
	public static final int EXPPURPRODUCTID = 15;
	public static final int EXPPURTIME = 16;
	public static final int EXPPURSTATE = 17;
	public static final int EXPDEVPAYLOAD = 18;
	public static final int EXPOURTOKEN = 19;
	public static final int EXPDETAILSAMOUNT = 20;
	public static final int EXPDETAILSCURRENCY = 21;
	public static final int EXPGETTOKEN = 22;

	// </editor-fold>

	private InAppControl IAControl = null;

	private Inventory IAInventory = null;

	private List<String> Skus;

	private int InventoryQty = 0;
	private int PurchaseQty = 0;

	private String InPurchasedType= "";
	private int	   InLastOperationId  = -1;
	
	private String DevPayLoad = "";

	private boolean IsBillingOk = false;
	private boolean IsBillingBusy = false;
	private boolean IsRefunded = false;
	
	private boolean CanSubscription = false;
	private boolean InAppSetUp = false;
	
	private boolean appEndOn = false;
	private int purchaseReturn = 0;
	
	private int	Error;
	private String strError = ""; 
	private int LastResult;
	private String strLastResult = "";

	static final int RC_REQUEST = 10101;

	static final String TAG = "InApp";
	
	private CValue expRet;

    private SharedPreferences.Editor spe = null;

    private InAppBroadcastReceiver mBroadcastReceiver;
    
    private InAppBroadcastListener mBroadcastListener = new InAppBroadcastListener() {

		@Override
		public void receivedBroadcast() {
	        // Received a broadcast notification that the inventory of items has changed
	        Log.Log("Received broadcast notification. Querying inventory.");
	        try 
	        {
	        	if(IAControl != null) {
					IAControl.queryInventoryAsync(ReadInventoryListener, true);
					ho.pushEvent(CNDONNOTIFY, 0);
					ho.pushEvent(CNDONQUERYINVENTORY, 0);
				}
	        }
	        catch (InApp_Exception e)
	        {
				Error = 12;
				strError = "12:Another async operation is in progress.";
				ho.pushEvent(CNDONERROR, 0);
	        }
		}
    	
    };
    
	///////////////////////////////////////////////////////
	//
	//		In-App Billing Android
	//
	//		Requires BILLING permissions
	//
	///////////////////////////////////////////////////////

	private void RestoreAutoEnd() {
		if(appEndOn) {
			appEndOn = false;
			MMFRuntime.inst.app.hdr2Options |= CRunApp.AH2OPT_AUTOEND;
		}
	}

	private void SuspendAutoEnd() {
		//AH2OPT_AUTOEND
		if (!appEndOn && MMFRuntime.inst.app != null && (MMFRuntime.inst.app.hdr2Options & CRunApp.AH2OPT_AUTOEND) != 0) {
			appEndOn = true;
			MMFRuntime.inst.app.hdr2Options &= ~ CRunApp.AH2OPT_AUTOEND;
		}
	}

	boolean verifyDeveloperPayload(Purchase p) 
	{
		String payload = p.getDeveloperPayload();

		return true;
	}

	InAppControl.QueryInventoryFinishedListener ReadInventoryListener = new InAppControl.QueryInventoryFinishedListener() {
		@Override
		public void onQueryInventoryFinished(InApp_Result result, Inventory inventory, boolean override) {
			Log.Log("Query inventory finished.");

			PurchaseQty  = 0;
			InventoryQty = 0;

			if (result.isFailure())
			{
				Error = result.getResponse();
				strError = InAppControl.getResponseDesc(result.getResponse());
				IsBillingBusy = false;
				ho.pushEvent(CNDONERROR, 0);
				return;
			}
			if(override)
			{
				Error = 0;
				strError = "";
			}
			LastResult = result.getResponse();
			strLastResult = InAppControl.getResponseDesc(result.getResponse());

			InventoryQty = inventory.getSkuQuantity();

			if(inventory.getAllPurchases().size() > 0) {
				PurchaseQty = inventory.getAllPurchases().size();
			}
			IAInventory = null;
			try {
				IAInventory = inventory.clone();
			} 
			catch (CloneNotSupportedException e) {
				Error= 10;
				strError = "10:Inventory could not be readed";
				ho.pushEvent(CNDONERROR, 0);
				e.printStackTrace();
			}

			LastResult = result.getResponse();
			strLastResult = InAppControl.getResponseDesc(result.getResponse());
			ho.pushEvent(CNDONQUERYINVENTORY, 0);
			IsBillingBusy = false;
			Log.Log("Query inventory was successful and busy:"+(IsBillingBusy ? "yes" : "no"));

		}
	};

	// Callback for when a purchase is finished
	InAppControl.PurchaseFinishedListener purchaseListener = new InAppControl.PurchaseFinishedListener() {
		@Override
		public void PurchaseFinished(InApp_Result result, int iD, Purchase purchase) {
			Log.Log("Purchase finished: " + result + ", purchase: " + purchase + ", iD: " + iD);
			IsBillingBusy = false;
			
			Error = LastResult = result.getResponse();
			strError = strLastResult = InAppControl.getResponseDesc(result.getResponse());
			
			purchaseReturn = 20;
			InPurchasedType= "";
			InLastOperationId = iD;
			RestoreAutoEnd();
			
			if(purchase != null)
			{
				InPurchasedType= purchase.mItemType;
				purchaseReturn = ((InPurchasedType.contentEquals(InAppControl.ITEM_TYPE_INAPP)) ? 1 : 2);
				
				if (IAInventory == null) return;
				
				if (result.isFailure()) {
					purchaseReturn += 20;
					if(purchaseReturn == 21)
						ho.activityEvent(CNDONPURCHASEFAIL, 0);
					else
						ho.activityEvent(CNDONSUBSCRIPTIONFAIL, 0);
					
	                //Toast.makeText(ho.getControlsContext(), "Out of Purchased with failure", Toast.LENGTH_LONG).show();
					return;
				}
				if (purchase != null && !verifyDeveloperPayload(purchase)) {
					purchaseReturn += 20;
					Error = 11;
					strError = "11:Error purchasing. Authenticity verification failed.";
					ho.activityEvent(CNDONERROR, 0);
	                //Toast.makeText(ho.getControlsContext(), "Out of Purchased with verification failure", Toast.LENGTH_LONG).show();
					return;
				}
				if(IAInventory!= null)
				{
					if(IAInventory.addPurchase(purchase))
					{
						PurchaseQty = IAInventory.getAllPurchases().size();
						ho.activityEvent(CNDONUPDATE,0);
					}
				}
				if(purchaseReturn == 1)
					ho.activityEvent(CNDONPURCHASEOK, 0);
				else
					ho.activityEvent(CNDONSUBSCRIPTIONOK, 0);
				
				purchaseReturn += 10;
                //Toast.makeText(ho.getControlsContext(), "Out of Purchased Ok with Id"+iD, Toast.LENGTH_LONG).show();

				Log.Log("Purchase successful and busy:"+(IsBillingBusy ? "yes" : "no"));
			}
			else
			{
				ho.activityEvent(CNDONERROR, 0);
			}

		}
	};    

	// Called when consumption is complete
	InAppControl.OnConsumeFinishedListener consumeListener = new InAppControl.OnConsumeFinishedListener() {
		@Override
		public void onConsumeFinished(Purchase purchase, int iD, InApp_Result result) {
			InLastOperationId = iD;
			Log.Log("Consumption finished. Purchase: " + purchase + ", result: " + result);
			if (result.isSuccess()) {
				Error = 0;
				strError = "";				
				Log.Log("Consumption successful. Provisioning.");
			}
			else {
				Error = result.getResponse();
				strError = InAppControl.getResponseDesc(result.getResponse());
				ho.pushEvent(CNDONERROR, 0);

			}
			Log.Log("End consumption flow.");
			if(IAInventory != null && purchase.getSku() != null) {
				if(IAInventory.erasePurchase(purchase.getSku()))
				{
					PurchaseQty = IAInventory.getAllPurchases().size();
					ho.pushEvent(CNDONUPDATE,0);
					
					if(purchase.getItemType().contentEquals(InAppControl.ITEM_TYPE_INAPP))
						ho.pushEvent(CNDONPURCHASECONSUME, 0);
					
					if(purchase.getItemType().contentEquals(InAppControl.ITEM_TYPE_SUBS))
						ho.pushEvent(CNDONSUBSCRIPTIONCONSUME, 0);
				}
			}
			
			IsBillingBusy = false;
			LastResult = result.getResponse();
			strLastResult = InAppControl.getResponseDesc(result.getResponse());
		}
	};

	InAppControl.OnSetupFinishedListener setupListener = new InAppControl.OnSetupFinishedListener() {
		@Override
		public void onSetupFinished(InApp_Result result) {
			Log.Log("Setup finished.");

			if (!result.isSuccess()) {
				Error = result.getResponse();
				strError = result.getMessage();
				IsBillingOk = false;
				InAppSetUp = false;
				CanSubscription = IAControl.subscriptionsSupported();
				ho.pushEvent(CNDONERROR, 0);
				return;
			}
			mBroadcastReceiver = new InAppBroadcastReceiver(mBroadcastListener);
			IntentFilter filter = new IntentFilter();
			filter.addAction(InAppBroadcastReceiver.ACTION_NOTIFY);
			filter.addAction(InAppBroadcastReceiver.ACTION_UPDATED);
			MMFRuntime.inst.registerReceiver(mBroadcastReceiver, filter);
			CanSubscription = IAControl.subscriptionsSupported();
			IsBillingOk = true;
			InAppSetUp = true;
		}
	};

	///////////////////////////////////////////////////////
	public CRunInAppAndroid()
	{
		expRet = new CValue(0);
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if(IAControl == null)
			return;
		
		Log.Log("onActivityResult(" + requestCode + "," + resultCode + "," + data);

		// Pass on the activity result to the helper for handling
		IAControl.handleActivityResult(requestCode, resultCode, data);
	}

    	
    @Override
	public int getNumberOfConditions()
	{
		return CND_LAST;
	}

	@Override
	public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
	{
		// Read the edit time structure values
		// a UTF-16 editdata structure
	   	file.bUnicode = true;
		file.readShort();
		file.readShort();
		file.readShort();
		file.readShort();
		String base64EncodedPublicKey = file.readString(450).replaceAll(" ", "").replaceAll("[\\t\\n\\r]", "");

		PurchaseQty  = 0;
		InventoryQty = 0;
		LastResult = 0;
		strLastResult = "";
		InAppSetUp = false;

		if(IAControl == null)
			IAControl = InAppControl.getInstance();

		if(IAControl != null && !IAControl.isStarted()) {
			IAControl.initAppControl(MMFRuntime.inst,  base64EncodedPublicKey);
			IAControl.startSetup(setupListener);
		}
		return false;
	}

	@Override
	public void destroyRunObject(boolean bFast)
	{
		RestoreAutoEnd();
		if(mBroadcastReceiver != null)
		{
			MMFRuntime.inst.unregisterReceiver(mBroadcastReceiver);		
			mBroadcastReceiver = null;
		}
		if (IAControl != null && !IAControl.isStarted())
			IAControl.startSetup(null);
		if(!bFast) {
			if (IAControl != null) {
				IAControl.disposeWhenFinished();
			}
			IAControl = null;
		}

	}
	
	@Override
	public int handleRunObject()
	{
		if(IAControl != null && IAControl.isStarted() && !IAControl.AsyncInProgress()) {
			CanSubscription = IAControl.subscriptionsSupported();
			IsBillingOk = true;
			InAppSetUp = true;
			queryInventory(null, true);
			return REFLAG_ONESHOT;
		}
		return 0;
	}

	public @Override void pauseRunObject()
	{
        if(mBroadcastReceiver != null)
        {
            MMFRuntime.inst.unregisterReceiver(mBroadcastReceiver);
            if(IAControl != null)
            	IAControl.pause(!MMFRuntime.inst.isScreenOn);
            mBroadcastReceiver = null;
        }

	}
	
	public @Override void continueRunObject()
	{

		////////////////////////////////////////////////////////
		//
		//        We put the events generation here since 
		//             the object is in pause
		//          in this mode no event is register
		//
		////////////////////////////////////////////////////////

		// If the screen is off then the device has been locked
        if(mBroadcastReceiver == null)
        {
	        IntentFilter filter = new IntentFilter();
	        filter.addAction(InAppBroadcastReceiver.ACTION_NOTIFY);
	        filter.addAction(InAppBroadcastReceiver.ACTION_UPDATED);	                
	        MMFRuntime.inst.registerReceiver(mBroadcastReceiver, filter);
        }

		if(ho == null)
			return;

		purchaseReturn = -1;
		if(IAControl != null) {
			IAControl.resume();
			if(IAControl.isStarted())
				IsBillingBusy = IAControl.AsyncInProgress();
		}
 	}

 	// Conditions
	// -------------------------------------------------
	public @Override boolean condition(int num, CCndExtension cnd)
	{
		switch (num)
		{
		case CNDONQUERYINVENTORY:
			return cndOnQueryInventory(cnd);
		case CNDONPURCHASEOK:
			return cndOnPurchaseOk(cnd);
		case CNDONPURCHASEFAIL:
			return cndOnPurchaseFail(cnd);
		case CNDONSUBSCRIPTIONOK:
			return cndOnSubscriptionOk(cnd);
		case CNDONSUBSCRIPTIONFAIL:
			return cndOnSubscriptionFail(cnd);
		case CNDONPURCHASECONSUME:
			return cndOnPurchaseConsumed(cnd);
		case CNDONSUBSCRIPTIONCONSUME:
			return cndOnSubscriptionConsumed(cnd);
		case CNDISPURCHASED:
			return cndIsPurchased(cnd);
		case CNDISSUBSCIPTION:
			return cndIsSubsciption(cnd);
		case CNDISBILLING:
			return cndIsBilling(cnd);
		case CNDISBILLBUSY:
			return cndIsBillBusy(cnd);
		case CNDONERROR:
			return cndOnError(cnd);
		case CNDONNOTIFY:
			return cndOnNotify(cnd);
		case CNDISREFUNDED:
			return cndIsRefunded(cnd);
		case CNDISCANCELED:
			return cndIsCanceled(cnd);
		case CNDONUPDATE:
			return cndOnUpdate(cnd);
		}
		return false;
	}

	// Actions
	// -------------------------------------------------
	public @Override void action(int num, CActExtension act)
	{
		switch (num)
		{
		case ACTQUERYINVENTORY:
			actQueryInventory(act);
			break;
		case ACTSETDEVPAYLOAD:
			actSetDevPayLoad(act);
			break;
		case ACTPURCHASEITEM:
			actPurchaseItem(act);
			break;
		case ACTSUBSCRIPTIONITEM:
			actSubscriptionItem(act);
			break;
		case ACTDOCONSUME:
			actDoConsume(act);
			break;
		case ACTSAVESTRING:
			actSaveString(act);
			break;
		case ACTSAVEINT:
			actSaveInt(act);
			break;
		}
	}

	// Expressions
	// -------------------------------------------------
	public @Override CValue expression(int num)
	{
		switch (num)
		{
		case EXPERROR:
			return expError();
		case EXPSTRERROR:
			return expStrError();
		case EXPRESPONSE:
			return expResponse();
		case EXPSTRRESPONSE:
			return expStrResponse();
		case EXPINVENTORY:
			return expInventory();
		case EXPPURCHASE:
			return expPurchase();
		case EXPDATASTRING:
			return expDataString();
		case EXPDATAINT:
			return expDataInt();
		case EXPDETAILSID:
			return expDetailsId();
		case EXPDETAILSTYPE:
			return expDetailsType();
		case EXPDETAILSPRICE:
			return expDetailsPrice();
		case EXPDETAILSTITLE:
			return expDetailsTitle();
		case EXPDETAILSDESCRIPTION:
			return expDetailsDescription();
		case EXPPURORDERID:
			return expPurOrderId();
		case EXPPURPACKAGE:
			return expPurPackage();
		case EXPPURPRODUCTID:
			return expPurProductId();
		case EXPPURTIME:
			return expPurTime();
		case EXPPURSTATE:
			return expPurState();
		case EXPDEVPAYLOAD:
			return expDevpayLoad();
		case EXPOURTOKEN:
			return expOurToken();
		case EXPDETAILSAMOUNT:
			return expDetailsAmount();
		case EXPDETAILSCURRENCY:
			return expDetailsCurrency();
		case EXPGETTOKEN:
			return expGetToken();
		}
		return null;
	}


	//////////////////////////////////////////////////////
	//
	//			Conditions Routines
	//
	//////////////////////////////////////////////////////

	private boolean cndOnQueryInventory(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndOnPurchaseOk(CCndExtension cnd)
	{
		int param0 = cnd.getParamExpression(rh, 0);
		if(IAControl != null && IAControl.isStarted() && InLastOperationId == param0)
			return true;
		
		return false;
	}

	private boolean cndOnPurchaseFail(CCndExtension cnd)
	{
		int param0 = cnd.getParamExpression(rh, 0);
		if(IAControl != null && IAControl.isStarted() && InLastOperationId == param0)
			return true;
		
		return false;
	}

	private boolean cndOnSubscriptionOk(CCndExtension cnd)
	{
		int param0 = cnd.getParamExpression(rh, 0);
		if(IAControl != null && IAControl.isStarted() && InLastOperationId == param0)
			return true;
		
		return false;
	}

	private boolean cndOnSubscriptionFail(CCndExtension cnd)
	{
		int param0 = cnd.getParamExpression(rh, 0);
		if(IAControl != null && IAControl.isStarted() && InLastOperationId == param0)
			return true;
		
		return false;
	}

	private boolean cndOnPurchaseConsumed(CCndExtension cnd)
	{
		int param0 = cnd.getParamExpression(rh, 0);
		if(IAControl != null && IAControl.isStarted() && InLastOperationId == param0)
			return true;
		
		return false;
	}

	private boolean cndOnSubscriptionConsumed(CCndExtension cnd)
	{
		int param0 = cnd.getParamExpression(rh, 0);
		if(IAControl != null && IAControl.isStarted() && InLastOperationId == param0)
			return true;
		
		return false;
	}

	private boolean cndIsPurchased(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		
		if(IAControl != null && IAControl.isStarted() && IAInventory != null)
			return IAInventory.hasPurchase(param0);
		
		return false;
	}

	private boolean cndIsSubsciption(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(IAControl != null && IAControl.isStarted() && IAInventory != null)
			return  IAInventory.hasPurchase(param0);
		
		return false;
	}

	private boolean cndIsBilling(CCndExtension cnd)
	{
		return IsBillingOk;
	}

	private boolean cndIsBillBusy(CCndExtension cnd)
	{
		return IsBillingBusy;
	}	
	
	private boolean cndOnError(CCndExtension cnd)
	{
		return true;
	}
	
	private boolean cndOnNotify(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndIsRefunded(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(IAControl != null && IAControl.isStarted() && IAInventory != null)
			return  IAInventory.hasRefunded(param0);
		
		return false;
	}

	private boolean cndIsCanceled(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(IAControl != null && IAControl.isStarted() && IAInventory != null)
			return  IAInventory.hasCanceled(param0);
		
		return false;
	}

	private boolean cndOnUpdate(CCndExtension cnd)
	{
		return true;
	}

	
	//////////////////////////////////////////////////////
	//
	//			Private Actions Routines
	//
	////////////////////////////////////////////////////// 

	private void purchaseSku(Activity act, String Sku, int iD, String devPayload) {
		if(IAControl != null && IAControl.isStarted() && !IsBillingBusy) {
			if(!IAControl.AsyncInProgress()) {
				purchaseReturn = 0;
				IsBillingBusy = true;
				SuspendAutoEnd();
	    		purchaseReturn = -1;
				IAControl.startPurchaseProcess(act, Sku, 10101, iD, purchaseListener, devPayload);
			}
			else {
				IsBillingBusy = false;
				Error = 12;
				strError = "12:Another async operation is in progress.";
				ho.pushEvent(CNDONERROR, 0);
			}
		}
	}

	private void subscriptionSku(Activity act, String Sku, int iD, String devPayload) {
		if(IAControl != null && IAControl.isStarted() && !IsBillingBusy) {
			if(!IAControl.AsyncInProgress()) {
				IsBillingBusy = true;
				SuspendAutoEnd();
				IAControl.launchSubscriptionPurchaseFlow(act, Sku, 10101, iD, purchaseListener, devPayload);
			}
			else {
				IsBillingBusy = false;
				Error = 12;
				strError = "12:Another async operation is in progress.";
				ho.pushEvent(CNDONERROR, 0);
			}
		}
	}

	private void consumeSku(String Sku, int iD) {
		if(IAControl != null && IAControl.isStarted() && !IsBillingBusy) {
			if(!IAControl.AsyncInProgress()) {
				if(IAInventory != null) {
					Purchase mPurchase = IAInventory.getPurchase(Sku);				
					IsBillingBusy = true;
					try 
					{
						IAControl.consumeAsync(mPurchase, iD, consumeListener);
					} 
					catch (InApp_Exception e) 
					{
						InApp_Result r = e.getResult();
						Error = r.getResponse();
						strError = String.valueOf(Error)+":"+r.getMessage();
						ho.pushEvent(CNDONERROR, 0);
					} 
				}
				else {
					IsBillingBusy = false;
					Error = 13;
					strError = "13:Inventory does not exist ...";
					ho.pushEvent(CNDONERROR, 0);					
				}
					
			}
			else {
				IsBillingBusy = false;
				Error = 12;
				strError = "12:Another async operation is in progress.";
				ho.pushEvent(CNDONERROR, 0);
			}
		}
	}

	private void queryInventory(List<String> mSkus, boolean override) {
		if(IAControl != null && IAControl.isStarted() && !IsBillingBusy) {
			if(!IAControl.AsyncInProgress()) {
				IsBillingBusy = true;
				try
				{
					IAControl.setSkus(mSkus);
					if(mSkus != null) {
						IAControl.queryInventoryAsync(true, mSkus, ReadInventoryListener, override);
					}
					else
						IAControl.queryInventoryAsync(ReadInventoryListener, override);
				} 
				catch (InApp_Exception e) 
				{
					IsBillingBusy = false;
					Error = 12;
					strError = "12:Another async operation is in progress.";
					ho.pushEvent(CNDONERROR, 0);
				}
			}
			else {
				IsBillingBusy = false;
				Error = 12;
				strError = "12:Another async operation is in progress.";
				ho.pushEvent(CNDONERROR, 0);
			}
		}

	}

	//////////////////////////////////////////////////////
	//
	//			Actions Routines
	//
	////////////////////////////////////////////////////// 

	private void actQueryInventory(CActExtension act)
	{
		String param0 = act.getParamExpString(rh, 0);
		if(param0.length() > 0) {
			Skus = Arrays.asList(param0.trim().split("/"));
			queryInventory(Skus, true);
		}
	}

	private void actSetDevPayLoad(CActExtension act)
	{
		String param0 = act.getParamExpString(rh, 0);
		if(param0.length() > 0)
			DevPayLoad = param0;
	}

	private void actPurchaseItem(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		   int param1 = act.getParamExpression(rh, 1);
		if(IAControl != null && param0.length() > 0) {
			purchaseSku(MMFRuntime.inst, param0, param1, DevPayLoad);
		}

	}

	private void actSubscriptionItem(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		   int param1 = act.getParamExpression(rh, 1);
		if(IAControl != null && param0.length() > 0) {
			subscriptionSku(MMFRuntime.inst, param0, param1, DevPayLoad);
		}
	}

	private void actDoConsume(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		int param1 = act.getParamExpression(rh, 1);
		
		if(IAControl != null && param0.length() > 0)
		{
			consumeSku(param0, param1);
		}
		else
		{
			Error = 14;
			strError = "14:No Sku to consume";
			ho.pushEvent(CNDONERROR, 0);
			
		}
	}

	private void actSaveString(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		String param1 = act.getParamExpString(rh,1);

		if(param1.length() > 0) {
			spe = MMFRuntime.inst.getPreferences(Context.MODE_PRIVATE).edit();
			spe.putString(param1, param0);
			spe.commit();
		}
	}

	private void actSaveInt(CActExtension act)
	{
		   int param0 = act.getParamExpression(rh,0);
		String param1 = act.getParamExpString(rh,1);

		if(param1.length() > 0) {
			spe = MMFRuntime.inst.getPreferences(Context.MODE_PRIVATE).edit();
			spe.putInt(param1, param0);
			spe.commit();
		}
	}

	//////////////////////////////////////////////////////
	//
	//			Private Expressions Routines
	//
	//////////////////////////////////////////////////////

	private SkuDetails getInventory(int idx) {
		int count = 0;
		for(Entry<String, SkuDetails> i : (IAInventory.mSkuMap).entrySet()) {
			if(idx == count) {
				return i.getValue();
			}
			count ++;
		}
		return null;
	}

	private Purchase getPurchase(int idx) {
		int count = 0;
		for(Entry<String, Purchase> i : (IAInventory.mPurchaseMap).entrySet()) {
			if(idx == count) {
				return i.getValue();
			}
			count ++;
		}
		return null;
	}

	//////////////////////////////////////////////////////
	//
	//			Expressions Routines
	//
	//////////////////////////////////////////////////////

	private CValue expError()
	{
		expRet.forceInt(Error);
		return expRet;
	}

	private CValue expStrError()
	{
		expRet.forceString(strError);
		return expRet;
	}

	private CValue expResponse()
	{
		expRet.forceInt(LastResult);
		return expRet;
	}

	private CValue expStrResponse()
	{
		expRet.forceString(strLastResult);
		return expRet;
	}

	private CValue expInventory()
	{
		expRet.forceInt(InventoryQty);
		return expRet;
	}

	private CValue expPurchase()
	{
		expRet.forceInt(PurchaseQty);
		return expRet;
	}

	private CValue expDataString()
	{
		expRet.forceString("");
		String param0 = ho.getExpParam().getString();
		if(param0.length() > 0) {
			SharedPreferences sp = MMFRuntime.inst.getPreferences(Context.MODE_PRIVATE);
			expRet.forceString(sp.getString(param0, ""));
		}
		return expRet;
	}

	private CValue expDataInt()
	{
		expRet.forceInt(0);
		String param0 = ho.getExpParam().getString();
		if(param0.length() > 0) {
			SharedPreferences sp = MMFRuntime.inst.getPreferences(Context.MODE_PRIVATE);
			expRet.forceInt(sp.getInt(param0, 0));
		}
		return expRet;
	}

	private CValue expDetailsId()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < InventoryQty) {
			SkuDetails sku = getInventory(param0);
			if(sku != null && sku.getSku() != null)
				expRet.forceString(sku.getSku());
		}
		return expRet;
	}

	private CValue expDetailsType()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < InventoryQty) {
			SkuDetails sku = getInventory(param0);
			if(sku != null && sku.getType() != null)
				expRet.forceString(sku.getType());
		}
		return expRet;
	}

	private CValue expDetailsPrice()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < InventoryQty) {
			SkuDetails sku = getInventory(param0);
			if(sku != null && sku.getPrice() != null)
				expRet.forceString(sku.getPrice());
		}
		return expRet;
	}

	private CValue expDetailsTitle()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < InventoryQty) {
			SkuDetails sku = getInventory(param0);
			if(sku != null && sku.getTitle() != null)
				expRet.forceString(sku.getTitle());
		}
		return expRet;
	}

	private CValue expDetailsDescription()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < InventoryQty) {
			SkuDetails sku = getInventory(param0);
			if(sku != null && sku.getDescription() != null)
				expRet.forceString(sku.getDescription());
		}
		return expRet;
	}

	private CValue expPurOrderId()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < PurchaseQty) {
			Purchase p = getPurchase(param0);
			if(p != null && p.getOrderId() != null)
				expRet.forceString(p.getOrderId());
		}
		return expRet;
	}

	private CValue expPurPackage()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < PurchaseQty) {
			Purchase p = getPurchase(param0);
			if(p != null && p.getPackageName() != null)
				expRet.forceString(p.getPackageName());
		}
		return expRet;
	}

	private CValue expPurProductId()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < PurchaseQty) {
			Purchase p = getPurchase(param0);
			if(p != null && p.getSku() != null)
				expRet.forceString(p.getSku());
		}
		return expRet;
	}

	private CValue expPurTime()
	{
		expRet.forceInt(0);
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < PurchaseQty) {
			Purchase p = getPurchase(param0);
			if(p != null) {
				int nRet = (int)p.getPurchaseTime();
				expRet.forceInt(nRet);
			}
		}
		return expRet;
	}

	private CValue expPurState()
	{
		expRet.forceInt(0);
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < PurchaseQty) {
			Purchase p = getPurchase(param0);
			if(p != null)
				return new CValue(p.getPurchaseState());
			expRet.forceInt(p.getPurchaseState());
		}
		return expRet;
	}

	private CValue expDevpayLoad()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < PurchaseQty) {
			Purchase p = getPurchase(param0);
			if(p != null && p.getDeveloperPayload() != null)
				expRet.forceString(p.getDeveloperPayload());
		}
		return expRet;
	}

	private CValue expOurToken()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < PurchaseQty) {
			Purchase p = getPurchase(param0);
			if(p != null && p.getToken() != null)
				expRet.forceString(p.getToken());
		}
		return expRet;
	}

	private CValue expDetailsAmount()
	{
		expRet.forceInt(0);
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < InventoryQty) {
			SkuDetails sku = getInventory(param0);
			if(sku != null)
				expRet.forceInt(sku.getAmount());
		}
		return expRet;
	}

	private CValue expDetailsCurrency()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 >= 0 && param0 < InventoryQty) {
			SkuDetails sku = getInventory(param0);
			if(sku != null && sku.getCurrency() != null)
				expRet.forceString(sku.getCurrency());
		}
		return expRet;
	}

	private CValue expGetToken()
	{
		expRet.forceString("");
		int param0 = ho.getExpParam().getInt();
		if(param0 > 0 && param0 < 36) {
			RandomString p = new RandomString(param0);
			expRet.forceString(p.nextString());
		}
		return expRet;
	}

	//////////////////////////////////////////////////////////////////////////////////////////
	public class RandomString
	{

		/*
		 * static { for (int idx = 0; idx < 10; ++idx) symbols[idx] = (char)
		 * ('0' + idx); for (int idx = 10; idx < 36; ++idx) symbols[idx] =
		 * (char) ('a' + idx - 10); }
		 */
		private final char[] symbols = new char[36];

		private final Random random = new Random();

		private final char[] buf;

		public RandomString(int length) 
		{
			for (int idx = 0; idx < 10; ++idx)
				symbols[idx] = (char) ('0' + idx);
			for (int idx = 10; idx < 36; ++idx)
				symbols[idx] = (char) ('a' + idx - 10);
			
			if (length < 1)
				throw new IllegalArgumentException("length < 1: " + length);
			buf = new char[length];
		}

		public String nextString() 
		{
			for (int idx = 0; idx < buf.length; ++idx)
				buf[idx] = symbols[random.nextInt(symbols.length)];
			return new String(buf);
		}

	}

}

