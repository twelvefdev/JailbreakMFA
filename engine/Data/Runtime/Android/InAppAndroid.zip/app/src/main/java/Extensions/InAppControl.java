package Extensions;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.TextUtils;

import com.android.vending.billing.IInAppBillingService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import Runtime.Log;
import Util.Security;

public class InAppControl {

    // Is setup done?
    private boolean setupDone = false;
    
 
    // Has this object been disposed of? (If so, we should ignore callbacks, etc)
    boolean mDisposed = false;
    
    boolean mDisposeAfterAsync = false;

    // Are subscriptions supported?
    private boolean subscriptionsSupported = false;
    private boolean subscriptionUpdateSupported = false;
    // Is an asynchronous operation in progress?
    // (only one at a time can be in progress)
    private boolean asyncInProgress = false;

    // (for logging/debugging)
    // if mAsyncInProgress == true, what asynchronous operation is in progress?
    private String asyncOperation = "";

    // Context we were passed during initialization
    private static Context context;

    // Connection to the service
    private static IInAppBillingService service;
    private static ServiceConnection serviceConn;

    boolean mAsyncInProgress = false;
    private final Object mAsyncInProgressLock = new Object();
    
    // The request code used to launch purchase flow
    private int requestCode;
    
    // The item type of the current purchase flow
    private String purchasingItemType;

    // The iD for the purchase call, since intent is not taking, it will be put it here
    private int purchaseID = -1;
    
    // Public key for verifying signature, in base64 encoding
    private String signatureBase64 = null;
    
    private int InvQuantity =0;
    private int PurQuantity =0;
    
    public Inventory defInventory = null;
    private String appPackageName;
    private boolean ispaused;
    private List<String> Skus;

    // Billing response codes
    public static final int BILLING_RESPONSE_RESULT_OK 					= 0;
    public static final int BILLING_RESPONSE_RESULT_USER_CANCELED 		= 1;
    public static final int BILLING_RESPONSE_RESULT_BILLING_UNAVAILABLE = 3;
    public static final int BILLING_RESPONSE_RESULT_ITEM_UNAVAILABLE 	= 4;
    public static final int BILLING_RESPONSE_RESULT_DEVELOPER_ERROR 	= 5;
    public static final int BILLING_RESPONSE_RESULT_ERROR 				= 6;
    public static final int BILLING_RESPONSE_RESULT_ITEM_ALREADY_OWNED 	= 7;
    public static final int BILLING_RESPONSE_RESULT_ITEM_NOT_OWNED 		= 8;

    // InApp Control error codes
    public static final int INAPPMNGR_ERROR_BASE 					= -10000;
    public static final int INAPPMNGR_REMOTE_EXCEPTION 				= -10001;
    public static final int INAPPMNGR_BAD_RESPONSE 					= -10002;
    public static final int INAPPMNGR_VERIFICATION_FAILED 			= -10003;
    public static final int INAPPMNGR_SEND_INTENT_FAILED 			= -10004;
    public static final int INAPPMNGR_USER_CANCELLED 				= -10005;
    public static final int INAPPMNGR_UNKNOWN_PURCHASE_RESPONSE	 	= -10006;
    public static final int INAPPMNGR_MISSING_TOKEN 				= -10007;
    public static final int INAPPMNGR_UNKNOWN_ERROR 				= -10008;
    public static final int INAPPMNGR_SUBSCRIPTIONS_NOT_AVAILABLE 	= -10009;
    public static final int INAPPMNGR_INVALID_CONSUMPTION 			= -10010;
    public static final int INAPPMNGR_SUBSCRIPTION_UPDATE_NOT_AVAILABLE = -1011;

    // Keys for the responses from InAppBillingService
    public static final String RESPONSE_CODE = "RESPONSE_CODE";
    public static final String RESPONSE_GET_SKU_DETAILS_LIST = "DETAILS_LIST";
    public static final String RESPONSE_BUY_INTENT = "BUY_INTENT";
    public static final String RESPONSE_INAPP_PURCHASE_DATA = "INAPP_PURCHASE_DATA";
    public static final String RESPONSE_INAPP_SIGNATURE = "INAPP_DATA_SIGNATURE";
    public static final String RESPONSE_INAPP_ITEM_LIST = "INAPP_PURCHASE_ITEM_LIST";
    public static final String RESPONSE_INAPP_PURCHASE_DATA_LIST = "INAPP_PURCHASE_DATA_LIST";
    public static final String RESPONSE_INAPP_SIGNATURE_LIST = "INAPP_DATA_SIGNATURE_LIST";
    public static final String INAPP_CONTINUATION_TOKEN = "INAPP_CONTINUATION_TOKEN";

    // Item types
    public static final String ITEM_TYPE_INAPP = "inapp";
    public static final String ITEM_TYPE_SUBS = "subs";

    // some fields on the getSkuDetails response bundle
    public static final String GET_SKU_DETAILS_ITEM_LIST = "ITEM_ID_LIST";
    public static final String GET_SKU_DETAILS_ITEM_TYPE_LIST = "ITEM_TYPE_LIST";

    private static InAppControl instance;
    private static OnSetupFinishedListener mSetupListener;

    static {
        instance = new InAppControl();
    }

    private InAppControl() {
        context = null;
        signatureBase64 = null;
        Log.Log("InApp Manager created.");
        appPackageName = "";
    }

    public static InAppControl getInstance() {
        return InAppControl.instance;
    }

    public void initAppControl(Context mcontext, String base64PublicKey) {
        context = mcontext;
        if(base64PublicKey.length() > 0)
            signatureBase64 = base64PublicKey;
        appPackageName = mcontext.getPackageName();
    }

    public String getBase64PublicKey() {
        return signatureBase64;
    }

    public boolean isStarted() {
        return setupDone;
    }

    public void setSkus(List<String> mSkus) {
        if(mSkus == null)
            return;
        if(Skus == null)
            Skus = new ArrayList<>();
        Skus.clear();
        Skus.addAll(mSkus);

    }
    public interface OnSetupFinishedListener {
        /**
         * Called to notify that setup is complete.
         *
         * @param InApp_Result The result of the setup process.
         */
        public void onSetupFinished(InApp_Result InApp_Result);
    }

    /**
     * Starts the setup process. This will start up the setup process asynchronously.
     * You will be notified through the listener when the setup process is complete.
     * This method is safe to call from a UI thread.
     *
     * @param listener The listener to notify when the setup process is complete.
     */
    public void startSetup(final OnSetupFinishedListener listener) {
        // If already set up, can't do it again.
    	//checkNotDisposed();
        //if (setupDone) throw new IllegalStateException("InApp is already set up.");
        mSetupListener = listener;
        if(!mDisposed)
        {
            if(setupDone) {
                if (listener != null) {
                    listener.onSetupFinished(new InApp_Result(BILLING_RESPONSE_RESULT_OK, "Setup successful."));
                }
            }
        }
        else
            throw new IllegalStateException("InApp was disposed of, so it cannot be used.");

        // Connection to InAppBilling service
        Log.Log("Starting InApp billing setup.");
        serviceConn = new ServiceConnection() {
            @Override
            public void onServiceDisconnected(ComponentName name) {
                Log.Log("Billing service disconnected.");
                service = null;
            }

            @Override
            public void onServiceConnected(ComponentName name, IBinder mservice) {
            	if (mDisposed) return;
            	Log.Log("Billing service connected.");
                service = IInAppBillingService.Stub.asInterface(mservice);
                setupDone = false;
                try {
                    Log.Log("Checking for InApp billing 3 support.");
                    
                    // check for in-app billing v3 support
                    int response = service.isBillingSupported(3, appPackageName, ITEM_TYPE_INAPP);
                    if (response != BILLING_RESPONSE_RESULT_OK) {
                        if (listener != null) listener.onSetupFinished(new InApp_Result(response,
                                "Error checking for billing v3 support."));
                        
                        // if in-app purchases aren't supported, neither are subscriptions.
                        subscriptionsSupported = false;
                        subscriptionUpdateSupported = false;
                        return;
                    }
                    Log.Log("InApp billing version 3 supported for " + appPackageName);
                    
                    // check for v3 subscriptions support
                    response = service.isBillingSupported(5, appPackageName, ITEM_TYPE_SUBS);
                    if (response == BILLING_RESPONSE_RESULT_OK) {
                        Log.Log("Subscriptions AVAILABLE.");
                        subscriptionUpdateSupported = true;
                    }
                    else {
                        Log.Log("Subscriptions NOT AVAILABLE. Response: " + response);
                        subscriptionUpdateSupported = false;
                    }
                    
                    if (subscriptionsSupported) 
                    {
                        subscriptionsSupported = true;
                    } 
                    else 
                    {
                        // check for v3 subscriptions support
                        response =service.isBillingSupported(3, appPackageName, ITEM_TYPE_SUBS);
                        if (response == BILLING_RESPONSE_RESULT_OK) {
                            Log.Log("Subscriptions AVAILABLE.");
                            subscriptionsSupported = true;
                        } else {
                            Log.Log("Subscriptions NOT AVAILABLE. Response: " + response);
                            subscriptionsSupported = false;
                            subscriptionUpdateSupported = false;
                        }
                    }

                    setupDone = true;
                }
                catch (RemoteException e) {
                    if (listener != null) {
                        listener.onSetupFinished(new InApp_Result(INAPPMNGR_REMOTE_EXCEPTION,
                                                    "RemoteException while setting up InApp billing."));
                    }
                    e.printStackTrace();
                    return;
                }

                if (listener != null) {
                     listener.onSetupFinished(new InApp_Result(BILLING_RESPONSE_RESULT_OK, "Setup successful."));
                }
            }
        };
        
        Intent serviceIntent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
        serviceIntent.setPackage("com.android.vending");
        
        if(context != null)
        {
	        List<ResolveInfo> intentServices = context.getPackageManager().queryIntentServices(serviceIntent, 0);
	
	        if (intentServices != null && !intentServices.isEmpty()) 
	        {
	            // service available to handle that Intent      	
	            context.bindService(serviceIntent, serviceConn, Context.BIND_AUTO_CREATE);
	        }
	        else 
	        {
	            // no service available to handle that Intent
	            if (listener != null) 
	            {
	                listener.onSetupFinished(
	                        new InApp_Result(BILLING_RESPONSE_RESULT_BILLING_UNAVAILABLE,
	                        "Billing service unavailable on device.")); 
	            }
	        }
        }
    }

    /**
     * Dispose of object, releasing resources. It's very important to call this
     * method when you are done with this object. It will release any resources
     * used by it such as service connections. Naturally, once the object is
     * disposed of, it can't be used again.
     */
    public void dispose() throws InAppAsyncInProgressException {
    	
        synchronized (mAsyncInProgressLock) 
        {
            if (mAsyncInProgress) {
                throw new InAppAsyncInProgressException("Can't dispose because an async operation " +
                    "(" + asyncOperation + ") is in progress.");
            }
        }

        Log.Log("Disposing.");
        setupDone = false;
        if (serviceConn != null) {
            Log.Log("Unbinding from service.");
            synchronized(context)
            {
            	if (context != null) 
            		context.unbindService(serviceConn);
            }
        }
        mDisposed = true;
		serviceConn = null;
		service = null;
		purchaseListener = null;
    }
    
    public void disposeWhenFinished() {
        synchronized (mAsyncInProgressLock) {
            if (mAsyncInProgress) {
                Log.Log("Will dispose after async operation finishes.");
                mDisposeAfterAsync = true;
            } else {
                try {
                    dispose();
                } catch (InAppAsyncInProgressException e) {
                    // Should never be thrown, because we call dispose() only after checking that
                    // there's not already an async operation in progress.
                }
            }
        }
    }
    
    private void checkNotDisposed() {
    	if (mDisposed) throw new IllegalStateException("InApp was disposed of, so it cannot be used.");
    }
    
    /** Returns whether subscriptions are supported. */
    public boolean subscriptionsSupported() {
    	checkNotDisposed();
        return subscriptionsSupported;
    }
    
    public void pause(boolean off)
    {
        ispaused = true;
        if(off) {
            disposeWhenFinished();
            mDisposed = false;
        }

    }

    public void resume()
    {
        ispaused = false;
        if(mSetupListener != null && serviceConn == null)
        {
            startSetup(mSetupListener);
        }
    }

    /**
     * Callback that notifies when a purchase is finished.
     */
    public interface PurchaseFinishedListener {
        /**
         * Called to notify that an in-app purchase finished. If the purchase was successful,
         * then the sku parameter specifies which item was purchased. If the purchase failed,
         * the sku and extraData parameters may or may not be null, depending on how far the purchase
         * process went.
         *
         * @param result The result of the purchase.
         * @param info The purchase information (null if purchase failed)
         */
        public void PurchaseFinished(InApp_Result result, int iD, Purchase info);
    }

    // The listener registered on startPurchaseProcess, which we have to call back when
    // the purchase finishes
    PurchaseFinishedListener purchaseListener;

    public void startPurchaseProcess(Activity act, String sku, int requestCode, int iD, PurchaseFinishedListener listener) {
        startPurchaseProcess(act, sku, requestCode, iD, listener, "");
    }
    
    public void startPurchaseProcess(Activity act, String sku, int requestCode,
                                     int iD, PurchaseFinishedListener listener, String extraData) {
        startPurchaseProcess(act, sku, ITEM_TYPE_INAPP, null, requestCode, iD, listener, extraData); 
    }
    
    public void launchSubscriptionPurchaseFlow(Activity act, String sku, int requestCode,
                                               int iD, PurchaseFinishedListener listener) {
        launchSubscriptionPurchaseFlow(act, sku, requestCode, iD, listener, "");
    }
    
    public void launchSubscriptionPurchaseFlow(Activity act, String sku, int requestCode,
                                               int iD, PurchaseFinishedListener listener, String extraData) {
        startPurchaseProcess(act, sku, ITEM_TYPE_SUBS, null, requestCode, iD, listener, extraData); 
    }
    
    /**
     * Initiate the UI flow for an in-app purchase. Call this method to initiate an in-app purchase,
     * which will involve bringing up the Google Play screen. The calling activity will be paused while
     * the user interacts with Google Play, and the result will be delivered via the activity's
     * {@link Activity#onActivityResult} method, at which point you must call
     * this object's {@link #handleActivityResult} method to continue the purchase flow. This method
     * MUST be called from the UI thread of the Activity.
     *
     * @param act The calling activity.
     * @param sku The sku of the item to purchase.
     * @param itemType indicates if it's a product or a subscription (ITEM_TYPE_INAPP or ITEM_TYPE_SUBS)
     * @param requestCode A request code (to differentiate from other responses --
     *     as in {@link Activity#startActivityForResult}).
     * @param listener The listener to notify when the purchase process finishes
     * @param extraData Extra data (developer payload), which will be returned with the purchase data
     *     when the purchase completes. This extra data will be permanently bound to that purchase
     *     and will always be returned when the purchase is queried.
     */
    public void startPurchaseProcess(Activity act, String sku, String itemType, List<String> oldSkus,
                                     int mrequestCode, int iD, PurchaseFinishedListener listener, String extraData) {
    	checkNotDisposed();
        checkSetupDone("startPurchaseProcess");
        flagStartAsync("startPurchaseProcess");
        InApp_Result result;
        
        if (itemType.equals(ITEM_TYPE_SUBS) && !subscriptionsSupported) {
            InApp_Result r = new InApp_Result(INAPPMNGR_SUBSCRIPTIONS_NOT_AVAILABLE,
                    "Subscriptions are not available.");
            flagEndAsync();
            if (listener != null) 
            	listener.PurchaseFinished(r, iD, null);
            return;
        }

        try {
            Log.Log("Constructing buy intent for " + sku + ", item type: " + itemType);
            Bundle buyIntentBundle;
            if (oldSkus == null || oldSkus.isEmpty())
            {
                // Purchasing a new item or subscription re-signup
                buyIntentBundle = service.getBuyIntent(3, appPackageName, sku, itemType,
                        extraData);
            } 
            else
            {
                // Subscription upgrade/downgrade
                if (!subscriptionUpdateSupported) 
                {
                    InApp_Result r = new InApp_Result(INAPPMNGR_SUBSCRIPTION_UPDATE_NOT_AVAILABLE,
                            "Subscription updates are not available.");
                    flagEndAsync();
                    if (listener != null) listener.PurchaseFinished(r, iD, null);
                    return;
                }
                buyIntentBundle = service.getBuyIntentToReplaceSkus(5, appPackageName,
                        oldSkus, sku, itemType, extraData);
                
            }

            int response = getResponseCodeFromBundle(buyIntentBundle);
            if (response != BILLING_RESPONSE_RESULT_OK) {
                Log.Log("Unable to buy item, Error response: " + getResponseDesc(response));
                flagEndAsync();
                result = new InApp_Result(response, "Unable to buy item");
                if (listener != null) 
                	listener.PurchaseFinished(result, iD, null);
                return;
            }

            PendingIntent pendingIntent = buyIntentBundle.getParcelable(RESPONSE_BUY_INTENT);
            Intent purchaseIntent = new Intent();
            Log.Log("Launching buy intent for " + sku + ". Request code: " + mrequestCode);
            requestCode = mrequestCode;
            purchaseListener = listener;
            purchasingItemType = itemType;
            purchaseID = iD;
            
            act.startIntentSenderForResult(pendingIntent.getIntentSender(),
                                           requestCode, purchaseIntent,
                                           Integer.valueOf(0), Integer.valueOf(0),
                                           Integer.valueOf(0));
        }
        catch (SendIntentException e) {
            Log.Log("SendIntentException while launching purchase flow for sku " + sku);
            e.printStackTrace();
            flagEndAsync();
            result = new InApp_Result(INAPPMNGR_SEND_INTENT_FAILED, "Failed to send intent.");
            if (listener != null) 
            	listener.PurchaseFinished(result, iD, null);
        }
        catch (RemoteException e) {
            Log.Log("RemoteException while launching purchase flow for sku " + sku);
            e.printStackTrace();

            result = new InApp_Result(INAPPMNGR_REMOTE_EXCEPTION, "Remote exception while starting purchase flow");
            if (listener != null) 
            	listener.PurchaseFinished(result, iD, null);
            flagEndAsync();
        }
        catch (Exception e) {
            Log.Log("Exception while launching purchase flow for sku " + sku);
            e.printStackTrace();

            result = new InApp_Result(INAPPMNGR_REMOTE_EXCEPTION, "Unknown exception while starting purchase flow");
            if (listener != null) 
            	listener.PurchaseFinished(result, iD, null);
            flagEndAsync();
        }
        
        Log.Log("Finished buy intent");
              
    }

    
    /**
     * Handles an activity result that's part of the purchase flow in in-app billing. If you
     * are calling {@link #launchPurchaseFlow}, then you must call this method from your
     * Activity's {@link Activity @onActivityResult} method. This method
     * MUST be called from the UI thread of the Activity.
     * 
     * @param requestCode
     *            The requestCode as you received it.
     * @param resultCode
     *            The resultCode as you received it.
     * @param data
     *            The data (Intent) as you received it.
     * @return Returns true if the result was related to a purchase flow and was handled;
     *         false if the result was not related to a purchase, in which case you should
     *         handle it normally.
     */
    public boolean handleActivityResult(int mrequestCode, int resultCode, Intent data) {
        InApp_Result result;
        int iD = purchaseID;
        
        if (requestCode != mrequestCode)
            return false;
        checkNotDisposed();
        checkSetupDone("handleActivityResult");

        // end of async purchase operation
        flagEndAsync();

        if (data == null) {
            Log.Log("Null data in InApp activity result.");
            result = new InApp_Result(INAPPMNGR_BAD_RESPONSE, "Null data in InApp result");
            if (purchaseListener != null) {
                purchaseListener.PurchaseFinished(result, iD, null);
            }
            return true;
        }

	    int responseCode = getResponseCodeFromIntent(data);
	    String purchaseData = data.getStringExtra(RESPONSE_INAPP_PURCHASE_DATA);
	    String dataSignature = data.getStringExtra(RESPONSE_INAPP_SIGNATURE);

        if (resultCode == Activity.RESULT_OK && responseCode == BILLING_RESPONSE_RESULT_OK) {
        	Log.Log("Successful resultcode from purchase activity.");
        	Log.Log("Purchase data: " + purchaseData);
        	Log.Log("Data signature: " + dataSignature);
        	Log.Log("Extras: " + data.getExtras());

            if (purchaseData == null || dataSignature == null) {
            	Log.Log("BUG: either purchaseData or dataSignature is null.");
            	Log.Log("Extras: " + data.getExtras().toString());
                result = new InApp_Result(INAPPMNGR_UNKNOWN_ERROR, "InApp returned null purchaseData or dataSignature");
                if (purchaseListener != null) {
                    purchaseListener.PurchaseFinished(result, iD, null);
                }
                return true;
            }

            Purchase purchase = null;
            try {
                purchase = new Purchase(purchasingItemType, purchaseData, dataSignature);
                String sku = purchase.getSku();

                // Verify signature
                if (!Security.verifyPurchase(signatureBase64, purchaseData, dataSignature)) {
                	Log.Log("Purchase signature verification FAILED for sku " + sku);
                    result = new InApp_Result(INAPPMNGR_VERIFICATION_FAILED, "Signature verification failed for sku " + sku);
                    if (purchaseListener != null) {
                        purchaseListener.PurchaseFinished(result, iD, purchase);
                    }
                    return true;
                }
                Log.Log("Purchase signature successfully verified.");
            } catch (JSONException e) {
            	Log.Log("Failed to parse purchase data.");
                e.printStackTrace();
                result = new InApp_Result(INAPPMNGR_BAD_RESPONSE, "Failed to parse purchase data.");
                if (purchaseListener != null) {
                    purchaseListener.PurchaseFinished(result, iD, null);
                }
                return true;
            }

            if (purchaseListener != null) {
                purchaseListener.PurchaseFinished(new InApp_Result(BILLING_RESPONSE_RESULT_OK, "Success"), iD, purchase);
            }
        }
        else if (resultCode == Activity.RESULT_OK) {
            // result code was OK, but in-app billing response was not OK.
        	Log.Log("Result code was OK but in-app billing response was not OK: " + getResponseDesc(responseCode));
            if (purchaseListener != null) {
                result = new InApp_Result(responseCode, "Problem purchashing item.");
                purchaseListener.PurchaseFinished(result, iD, null);
            }
        }
        else if (resultCode == Activity.RESULT_CANCELED) {
        	Log.Log("Purchase canceled - Response: " + getResponseDesc(responseCode));
            result = new InApp_Result(INAPPMNGR_USER_CANCELLED, "User canceled.");
            if (purchaseListener != null) {
                purchaseListener.PurchaseFinished(result, iD,null);
            }
        }
        else {
        	Log.Log("Purchase failed. Result code: " + Integer.toString(resultCode)
                    + ". Response: " + getResponseDesc(responseCode));
            result = new InApp_Result(INAPPMNGR_UNKNOWN_PURCHASE_RESPONSE, "Unknown purchase response.");
            if (purchaseListener != null) {
                purchaseListener.PurchaseFinished(result, iD, null);
            }
        }
        return true;
    }    
    
    
    /**
     * Returns a human-readable description for the given response code.
     *
     * @param code The response code
     * @return A human-readable string explaining the result code.
     *     It also includes the result code numerically.
     */
    public static String getResponseDesc(int code) {
        String[] inapp_b_msgs = ("0:Response OK/1:User Canceled/2:Unknown-No purchase available/" +
                				"3:Billing Unavailable/4:Item unavailable/" +
                				"5:Developer Error/6:Error refreshing inventory/7:Item Already Owned/" +
                				"8:Item not owned").split("/");
        String[] inapp_msgs = ("0:OK/-10001:Remote exception during initialization/" +
                                   "-10002:Bad response received/" +
                                   "-10003:Purchase signature verification failed/" +
                                   "-10004:Send intent failed/" +
                                   "-10005:User cancelled/" +
                                   "-10006:Unknown purchase response/" +
                                   "-10007:Missing token/" +
                                   "-10008:Failed purchase error/" +
                                   "-10009:Subscriptions not available/" +
                                   "-10010:Invalid consumption attempt").split("/");

        if (code <= INAPPMNGR_ERROR_BASE) {
            int index = INAPPMNGR_ERROR_BASE - code;
            if (index >= 0 && index < inapp_msgs.length) return inapp_msgs[index];
            else return String.valueOf(code) + ":Unknown InApp Control Error";
        }
        else if (code < 0 || code >= inapp_b_msgs.length)
            return String.valueOf(code) + ":Unknown";
        else
            return inapp_b_msgs[code];
    }


    // Checks that setup was done; if not, throws an exception.
    void checkSetupDone(String operation) {
        if (!setupDone) {
            Log.Log("Illegal state for operation (" + operation + "): InApp control is not set up.");
            throw new IllegalStateException("InApp is not set up. Can't perform operation: " + operation);
        }
    }

    // Workaround to bug where sometimes response codes come as Long instead of Integer
    int getResponseCodeFromBundle(Bundle b) {
        Object o = b.get(RESPONSE_CODE);
        if (o == null) {
            Log.Log("Bundle with null response code, assuming OK (known issue)");
            return BILLING_RESPONSE_RESULT_OK;
        }
        else if (o instanceof Integer) return ((Integer)o).intValue();
        else if (o instanceof Long) return (int)((Long)o).longValue();
        else {
            Log.Log("Unexpected type for bundle response code.");
            Log.Log(o.getClass().getName());
            throw new RuntimeException("Unexpected type for bundle response code: " + o.getClass().getName());
        }
    }

    // Workaround to bug where sometimes response codes come as Long instead of Integer
    int getResponseCodeFromIntent(Intent i) {
        Object o = i.getExtras().get(RESPONSE_CODE);
        if (o == null) {
            Log.Log("Intent with no response code, assuming OK (known issue)");
            return BILLING_RESPONSE_RESULT_OK;
        }
        else if (o instanceof Integer) return ((Integer)o).intValue();
        else if (o instanceof Long) return (int)((Long)o).longValue();
        else {
            Log.Log("Unexpected type for intent response code.");
            Log.Log(o.getClass().getName());
            throw new RuntimeException("Unexpected type for intent response code: " + o.getClass().getName());
        }
    }

    void flagStartAsync(String operation) {
        if (asyncInProgress) throw new IllegalStateException("Can't start async operation (" +
                operation + ") because another async operation(" + asyncOperation + ") is in progress.");
        asyncOperation = operation;
        asyncInProgress = true;
        Log.Log("Starting async operation: " + operation);
    }

    void flagEndAsync() {
        Log.Log("Ending async operation: " + asyncOperation);
        asyncOperation = "";
        asyncInProgress = false;
        if (mDisposeAfterAsync) {
            try {
                dispose();
            } catch (InAppAsyncInProgressException e) {
            }
        }
    }

    int queryPurchases(Inventory inv, String itemType) throws JSONException, RemoteException {
        // Query purchases
        Log.Log("Querying owned items, item type: " + itemType);
        Log.Log("Package name: " + appPackageName);
        boolean verificationFailed = false;
        String continueToken = null;
        PurQuantity = 0;
        checkNotDisposed();
        do {
            Log.Log("Calling getPurchases with continuation token: " + continueToken);
            if (context == null || context.getPackageName() == null || service == null)
                return INAPPMNGR_BAD_RESPONSE;
            Bundle ownedItems = service.getPurchases(3, appPackageName,
                    itemType, continueToken);

            int response = getResponseCodeFromBundle(ownedItems);
            Log.Log("Owned items response: " + String.valueOf(response));
            if (response != BILLING_RESPONSE_RESULT_OK) {
                Log.Log("getPurchases() failed: " + getResponseDesc(response));
                return response;
            }
            if (!ownedItems.containsKey(RESPONSE_INAPP_ITEM_LIST)
                    || !ownedItems.containsKey(RESPONSE_INAPP_PURCHASE_DATA_LIST)
                    || !ownedItems.containsKey(RESPONSE_INAPP_SIGNATURE_LIST)) {
                Log.Log("Bundle returned from getPurchases() doesn't contain required fields.");
                return INAPPMNGR_BAD_RESPONSE;
            }

            ArrayList<String> ownedSkus = ownedItems.getStringArrayList(
                    RESPONSE_INAPP_ITEM_LIST);
            ArrayList<String> purchaseDataList = ownedItems.getStringArrayList(
                    RESPONSE_INAPP_PURCHASE_DATA_LIST);
            ArrayList<String> signatureList = ownedItems.getStringArrayList(
                    RESPONSE_INAPP_SIGNATURE_LIST);

            for (int i = 0; i < purchaseDataList.size(); ++i) {
                String purchaseData = purchaseDataList.get(i);
                String signature = signatureList.get(i);
                String sku = ownedSkus.get(i);
                if (Security.verifyPurchase(signatureBase64, purchaseData, signature)) {
                    Log.Log("Sku is owned: " + sku);
                    Purchase purchase = new Purchase(itemType, purchaseData, signature);

                    if (TextUtils.isEmpty(purchase.getToken())) {
                        Log.Log("BUG: empty/null token!");
                        Log.Log("Purchase data: " + purchaseData);
                    }

                    // Record ownership and token
                    inv.addPurchase(purchase);
                } else {
                    Log.Log("Purchase signature verification **FAILED**. Not adding item.");
                    Log.Log("   Purchase data: " + purchaseData);
                    Log.Log("   Signature: " + signature);
                    verificationFailed = true;
                }
            }

            PurQuantity = purchaseDataList.size();

            continueToken = ownedItems.getString(INAPP_CONTINUATION_TOKEN);
            Log.Log("Continuation token: " + continueToken);
        } while (!TextUtils.isEmpty(continueToken));
        return verificationFailed ? INAPPMNGR_VERIFICATION_FAILED : BILLING_RESPONSE_RESULT_OK;
    }

    int querySkuDetails(String itemType, Inventory inv, List<String> moreSkus)
                                throws RemoteException, JSONException {
    	Log.Log("Querying SKU details.");
        ArrayList<String> skuList = new ArrayList<String>();
        skuList.addAll(inv.getAllOwnedSkus(itemType));
        if (moreSkus != null) //skuList.addAll(moreSkus);
        {
        	for (String sku : moreSkus) {
        		if (!skuList.contains(sku)) {
        			skuList.add(sku);
        		}
        	}
        	
        }
        
        if (skuList.size() == 0) {
        	Log.Log("queryPrices: nothing to do because there are no SKUs.");
            return BILLING_RESPONSE_RESULT_OK;
        }
        checkNotDisposed();
        Bundle querySkus = new Bundle();
        querySkus.putStringArrayList(GET_SKU_DETAILS_ITEM_LIST, skuList);
        Bundle skuDetails = service.getSkuDetails(3, appPackageName,
                itemType, querySkus);
        
        if (!skuDetails.containsKey(RESPONSE_GET_SKU_DETAILS_LIST)) {
        	int response = getResponseCodeFromBundle(skuDetails);
            if (response != BILLING_RESPONSE_RESULT_OK) {
            	Log.Log("getSkuDetails() failed: " + getResponseDesc(response));
                return response;
            }
            else {
            	Log.Log("getSkuDetails() returned a bundle with neither an error nor a detail list.");
                return INAPPMNGR_BAD_RESPONSE;
            }
        }

        ArrayList<String> responseList = skuDetails.getStringArrayList(RESPONSE_GET_SKU_DETAILS_LIST);
        
        InvQuantity = responseList.size();
	      
        for (String thisResponse : responseList) {
            SkuDetails d = new SkuDetails(itemType, thisResponse);
            //Log.Log("Got sku details: " + d);
            inv.addSkuDetails(d);
        }
        return BILLING_RESPONSE_RESULT_OK;
    }


    void consumeAsyncInternal(final List<Purchase> purchases,
    						  final int iD,
                              final OnConsumeFinishedListener singleListener,
                              final OnConsumeMultiFinishedListener multiListener) 
                              throws InApp_Exception {
        final Handler handler = new Handler();
        flagStartAsync("consume");
        (new Thread(new Runnable() {
            @Override
			public void run() {
                final List<InApp_Result> results = new ArrayList<InApp_Result>();
                for (Purchase purchase : purchases) {
                    try {
                    	if(purchase == null)
                    		continue;
                        consume(purchase, iD);
                        results.add(new InApp_Result(BILLING_RESPONSE_RESULT_OK, "Successful consume of sku " + purchase.getSku()));
                    }
                    catch (InApp_Exception ex) {
                        results.add(ex.getResult());
                    }
                }

                flagEndAsync();
                if (!mDisposed && singleListener != null) {
                    handler.post(new Runnable() {
                        @Override
						public void run() {
                        	if(purchases != null && results != null && !ispaused)
                        		singleListener.onConsumeFinished(purchases.get(0), iD, results.get(0));
                        }
                    });
                }
                if (!mDisposed && multiListener != null && !ispaused) {
                    handler.post(new Runnable() {
                        @Override
						public void run() {
                            multiListener.onConsumeMultiFinished(purchases, results);
                        }
                    });
                }
            }
        })).start();
    }
    
    public Inventory queryInventory(boolean querySkuDetails, List<String> moreSkus) throws InApp_Exception {
        return queryInventory(querySkuDetails, moreSkus, null);
    }
    
    /**
     * Queries the inventory. This will query all owned items from the server, as well as
     * information on additional skus, if specified. This method may block or take long to execute.
     * Do not call from a UI thread. For that, use the non-blocking version {@link #refreshInventoryAsync}.
     *
     * @param querySkuDetails if true, SKU details (price, description, etc) will be queried as well
     *     as purchase information.
     * @param moreItemSkus additional PRODUCT skus to query information on, regardless of ownership. 
     *     Ignored if null or if querySkuDetails is false.
     * @param moreSubsSkus additional SUBSCRIPTIONS skus to query information on, regardless of ownership. 
     *     Ignored if null or if querySkuDetails is false.
     * @throws InApp_Exception if a problem occurs while refreshing the inventory.
     */
    public Inventory queryInventory(boolean querySkuDetails, List<String> moreItemSkus,
                                    List<String> moreSubsSkus) throws InApp_Exception {
    	checkNotDisposed();
    	checkSetupDone("queryInventory");
        try {
            Inventory inv = new Inventory();

            int r = queryPurchases(inv, ITEM_TYPE_INAPP);
            if (r != BILLING_RESPONSE_RESULT_OK) {
                throw new InApp_Exception(r, "Error refreshing inventory (querying owned items).");
            }

            if (querySkuDetails) {
                r = querySkuDetails(ITEM_TYPE_INAPP, inv, moreItemSkus);
                if (r != BILLING_RESPONSE_RESULT_OK) {
                    throw new InApp_Exception(r, "Error refreshing inventory (querying prices of items).");
                }
            }
            
            // if subscriptions are supported, then also query for subscriptions
            if (subscriptionsSupported) {
                r = queryPurchases(inv, ITEM_TYPE_SUBS);
                if (r != BILLING_RESPONSE_RESULT_OK) {
                    throw new InApp_Exception(r, "Error refreshing inventory (querying owned subscriptions).");
                }
                
                if (querySkuDetails) {
                    r = querySkuDetails(ITEM_TYPE_SUBS, inv, moreItemSkus);
                    if (r != BILLING_RESPONSE_RESULT_OK) {
                        throw new InApp_Exception(r, "Error refreshing inventory (querying prices of subscriptions).");
                    }
                }                
            }
            
            return inv;
        }
        catch (RemoteException e) {
            throw new InApp_Exception(INAPPMNGR_REMOTE_EXCEPTION, "Remote exception while refreshing inventory.", e);
        }
        catch (JSONException e) {
            throw new InApp_Exception(INAPPMNGR_BAD_RESPONSE, "Error parsing JSON response while refreshing inventory.", e);
        }
    }

    /**
     * Listener that notifies when an inventory query operation completes.
     */
    public interface QueryInventoryFinishedListener {
        /**
         * Called to notify that an inventory query operation completed.
         *
         * @param result The result of the operation.
         * @param inv The inventory.
         */
        public void onQueryInventoryFinished(InApp_Result result, Inventory inv, boolean override);
    }


    /**
     * Asynchronous wrapper for inventory query. This will perform an inventory
     * query as described in {@link #queryInventory}, but will do so asynchronously
     * and call back the specified listener upon completion. This method is safe to
     * call from a UI thread.

     * @param querySkuDetails as in {@link #queryInventory}
     * @param moreSkus as in {@link #queryInventory}
     * @param listener The listener to notify when the refresh operation completes.
     */
    public void queryInventoryAsync(final boolean querySkuDetails,
    		final List<String> moreSkus,
    		final QueryInventoryFinishedListener listener,
    		final boolean override) 
    				 throws InApp_Exception {
    	final Handler handler = new Handler();
    	checkNotDisposed();
    	checkSetupDone("queryInventory");
    	flagStartAsync("refresh inventory"); 
    	(new Thread(new Runnable() {
    		@Override
			public void run() {
    			InApp_Result result = new InApp_Result(BILLING_RESPONSE_RESULT_OK, "Inventory refresh successful.");
    			Inventory inv = null;
    			try {
    				inv = queryInventory(querySkuDetails, moreSkus);
    			}
    			catch(IllegalStateException ex) {
    			    result = new InApp_Result(BILLING_RESPONSE_RESULT_ERROR, "InApp is not setup.");
    			}
    			catch (InApp_Exception ex) {
    				result = ex.getResult();
    			}
    			flagEndAsync();

    			final InApp_Result result_f = result;
    			final Inventory inv_f = inv;
    			final boolean inv_override = override;
    			if (!mDisposed && listener != null && !ispaused) {
    					handler.post(new Runnable() {
    						@Override
							public void run() {
    							listener.onQueryInventoryFinished(result_f, inv_f, inv_override);   							
    						} 	
    					}); 	
    			}

    		}
    	})).start();
    }

    public void queryInventoryAsync(QueryInventoryFinishedListener listener, boolean override) throws InApp_Exception {
        queryInventoryAsync(true, null, listener, override);
    }

    public void queryInventoryAsync(boolean querySkuDetails, QueryInventoryFinishedListener listener, boolean override) throws InApp_Exception {
        queryInventoryAsync(querySkuDetails, null, listener, override);
    }


    /**
     * Consumes a given in-app product. Consuming can only be done on an item
     * that's owned, and as a result of consumption, the user will no longer own it.
     * This method may block or take long to return. Do not call from the UI thread.
     * For that, see {@link #consumeAsync}.
     *
     * @param itemInfo The PurchaseInfo that represents the item to consume.
     * @throws InApp_Exception if there is a problem during consumption.
     */
    void consume(Purchase itemInfo, int iD) throws InApp_Exception {
        checkSetupDone("consume");
        
        if(itemInfo == null)
        	return;
        
        if (!itemInfo.mItemType.equals(ITEM_TYPE_INAPP)) {
            throw new InApp_Exception(INAPPMNGR_INVALID_CONSUMPTION,
                    "Items of type '" + itemInfo.mItemType + "' can't be consumed.");
        }
        
        try {
            String token = itemInfo.getToken();
            String sku = itemInfo.getSku();
            if (token == null || token.equals("")) {
            	Log.Log("Can't consume "+ sku + ". No token.");
               throw new InApp_Exception(INAPPMNGR_MISSING_TOKEN, "PurchaseInfo is missing token for sku: "
                   + sku + " " + itemInfo);
            }

            Log.Log("Consuming sku: " + sku + ", token: " + token);
            int response = service.consumePurchase(3, appPackageName, token);
            if (response == BILLING_RESPONSE_RESULT_OK) {
            	Log.Log("Successfully consumed sku: " + sku);
            }
            else {
               Log.Log("Error consuming consuming sku " + sku + ". " + getResponseDesc(response));
               throw new InApp_Exception(response, "Error consuming sku " + sku);
            }
        }
        catch (RemoteException e) {
            throw new InApp_Exception(INAPPMNGR_REMOTE_EXCEPTION, "Remote exception while consuming. PurchaseInfo: " + itemInfo, e);
        }
    }

    /**
     * Callback that notifies when a consumption operation finishes.
     */
    public interface OnConsumeFinishedListener {
        /**
         * Called to notify that a consumption has finished.
         *
         * @param purchase The purchase that was (or was to be) consumed.
         * @param result The result of the consumption operation.
         */
        public void onConsumeFinished(Purchase purchase, int iD, InApp_Result result);
    }

    /**
     * Callback that notifies when a multi-item consumption operation finishes.
     */
    public interface OnConsumeMultiFinishedListener {
        /**
         * Called to notify that a consumption of multiple items has finished.
         *
         * @param purchases The purchases that were (or were to be) consumed.
         * @param results The results of each consumption operation, corresponding to each
         *     sku.
         */
        public void onConsumeMultiFinished(List<Purchase> purchases, List<InApp_Result> results);
    }

    /**
     * Asynchronous wrapper to item consumption. Works like {@link #consume}, but
     * performs the consumption in the background and notifies completion through
     * the provided listener. This method is safe to call from a UI thread.
     *
     * @param purchase The purchase to be consumed.
     * @param listener The listener to notify when the consumption operation finishes.
     */
    public void consumeAsync(Purchase purchase, int iD, OnConsumeFinishedListener listener) throws InApp_Exception {
    	checkNotDisposed();
    	checkSetupDone("consume");
        List<Purchase> purchases = new ArrayList<Purchase>();
        purchases.add(purchase);
        consumeAsyncInternal(purchases, iD, listener, null);
    }

    /**
     * Same as {@link consumeAsync}, but for multiple items at once.
     * @param purchases The list of PurchaseInfo objects representing the purchases to consume.
     * @param listener The listener to notify when the consumption operation finishes.
     */
    public void consumeAsync(List<Purchase> purchases, int iD, OnConsumeMultiFinishedListener listener) throws InApp_Exception {
    	checkNotDisposed();
    	checkSetupDone("consume");
        consumeAsyncInternal(purchases, iD, null, listener);
    }
    
    public boolean AsyncInProgress() {
    	return asyncInProgress;
    }
}

//////////////////////////////////////////////////////////////////
//
//					Class to Handle Operations results
//
//////////////////////////////////////////////////////////////////

class InApp_Result {
    int mResponse;
    String mMessage;

    public InApp_Result(int response, String message) {
        mResponse = response;
        if (message == null || message.trim().length() == 0) {
            mMessage = InAppControl.getResponseDesc(response);
        }
        else {
            mMessage = message + " (Response: " + InAppControl.getResponseDesc(response) + ")";
        }
    }
    public int getResponse() 
    { 
    	return mResponse; 
    }
    public String getMessage()
    { 
    	return mMessage; 
    }
    public boolean isSuccess() 
    { 
    	return mResponse == InAppControl.BILLING_RESPONSE_RESULT_OK;
    }
    public boolean isFailure() 
    { 
    	return !isSuccess(); 
    }
    @Override
	public String toString()
    { 
    	return "Result: " + getMessage(); 
    }
}

//////////////////////////////////////////////////////////////////
//
//		Class that represent all in-app products
//
//////////////////////////////////////////////////////////////////
class SkuDetails {
    String mItemType;
    String mSku;
    String mType;
    String mPrice;
    String mTitle;
    String mDescription;
    String mJson;
    String mCurrency;
    int    mAmount;
    
    public SkuDetails(String jsonSkuDetails) throws JSONException {
        this(InAppControl.ITEM_TYPE_INAPP, jsonSkuDetails);
    }
    
    public SkuDetails(String itemType, String jsonSkuDetails) throws JSONException {
        mItemType    = itemType;
        mJson        = jsonSkuDetails;
        JSONObject oj = new JSONObject(mJson);
        
        mSku         = oj.optString("productId").replace("&nbsp;"," ");
        mType        = oj.optString("type").replace("&nbsp;"," ");
        mPrice       = oj.optString("price").replace("&nbsp;"," ");
        mTitle       = oj.optString("title").replace("&nbsp;"," ");
        mDescription = oj.optString("description").replace("&nbsp;"," ");
        mCurrency    = oj.optString("price_currency_code").replace("&nbsp;"," ");
        mAmount      = oj.optInt("price_amount_micros");
    }

    public String getSku() {
    	return mSku; 
    }
    public String getType() {
    	return mType; 
    }
    public String getPrice() {
    	return mPrice; 
    }
    public String getTitle() {
    	return mTitle; 
    }
    public String getDescription() {
    	return mDescription; 
    }
    public String getCurrency() {
    	return mCurrency; 
    }
    public int getAmount() {
    	return mAmount; 
    }
    @Override
    public String toString() {
        return "SkuDetails:" + mJson;
    }
}

//////////////////////////////////////////////////////////////////
//
//Class to handle Purchased
//
//////////////////////////////////////////////////////////////////

class Purchase {
	String mItemType;  // ITEM_TYPE_INAPP or ITEM_TYPE_SUBS
	String mOrderId;
	String mPackageName;
	String mSku;
	long mPurchaseTime;
	int mPurchaseState;
	String mDeveloperPayload;
	String mToken;
	String mOriginalJson;
	String mSignature;

	public Purchase(String itemType, String jsonPurchaseInfo, String signature) throws JSONException {
		mItemType = itemType;
		mOriginalJson = jsonPurchaseInfo;
		JSONObject oj = new JSONObject(mOriginalJson);
		mOrderId          = oj.optString("orderId");
		mPackageName      = oj.optString("packageName");
		mSku              = oj.optString("productId");
		mPurchaseTime     = oj.optLong("purchaseTime");
		mPurchaseState    = oj.optInt("purchaseState");
		mDeveloperPayload = oj.optString("developerPayload");
		mToken            = oj.optString("token", oj.optString("purchaseToken"));
		mSignature        = signature;
	}

	public String getItemType()
	{ 
		return mItemType; 
	}
	public String getOrderId()
	{ 
		return mOrderId; 
	}
	public String getPackageName()
	{ 
		return mPackageName; 
	}
	public String getSku()
	{ 
		return mSku; 
	}
	public long getPurchaseTime() 
	{ 
		return mPurchaseTime; 
	}
	public int getPurchaseState() 
	{ 
		return mPurchaseState; 
	}
	public String getDeveloperPayload()
	{ 
		return mDeveloperPayload; 
	}
	public String getToken()
	{ 
		return mToken; 
	}
	public String getOriginalJson()
	{ 
		return mOriginalJson; 
	}
	public String getSignature()
	{ 
		return mSignature; 
	}

	@Override
	public String toString()
	{ 
		return "PurchaseInfo(type:" + mItemType + "):" + mOriginalJson; 
	}
}

//////////////////////////////////////////////////////////////////
//
//	Class that organize and separate all purchased products
//
//////////////////////////////////////////////////////////////////

class Inventory  implements Cloneable {
	// Entries to save sku details and inventory
    HashMap<String, SkuDetails> mSkuMap;
    HashMap<String, Purchase> mPurchaseMap;

    Inventory() 
    { 
        mSkuMap = new HashMap<String, SkuDetails>();
        mPurchaseMap = new HashMap<String, Purchase>();
    }

    // Returns a clone of the Inventory.
    @Override
	protected Inventory clone() throws CloneNotSupportedException {
    	return (Inventory) super.clone();
    }
    
    // Returns the listing details for an in-app product.
    public SkuDetails getSkuDetails(String sku) {
        return mSkuMap.get(sku);
    }

    // Returns purchase information for a given product, or null if there is no purchase.
    public Purchase getPurchase(String sku) {
        return mPurchaseMap.get(sku);
    }

    // Returns whether or not there exists a purchase of the given product.
    public boolean hasPurchase(String sku) {
    	if(mPurchaseMap.containsKey(sku))
    	{
    		Purchase p = mPurchaseMap.get(sku);
    		if(p.getPurchaseState() == 0)
    			return true;
    	}
    	return false;
    }

    // Return whether or not details about the given product are available.
    public boolean hasDetails(String sku) {
        return mSkuMap.containsKey(sku);
    }

    // Returns whether or not a purchase is refunded.
    public boolean hasRefunded(String sku) {
    	if(mPurchaseMap.containsKey(sku))
    	{
    		Purchase p = mPurchaseMap.get(sku);
    		if(p.getPurchaseState() == 2)
    			return true;
    	}
    	return false;
    }

    // Returns whether or not a purchase is refunded.
    public boolean hasCanceled(String sku) {
    	if(mPurchaseMap.containsKey(sku))
    	{
    		Purchase p = mPurchaseMap.get(sku);
    		if(p.getPurchaseState() == 1)
    			return true;
    	}
    	return false;
    }

    // Erase local inventory not at the server, just to delete after consumed

	public boolean erasePurchase(String sku) {
        if (mPurchaseMap.containsKey(sku))
        {
        	mPurchaseMap.remove(sku);
        	return true;
        }
        return false;
    }

    // Returns a list of all owned product IDs.
    List<String> getAllOwnedSkus() {
        return new ArrayList<String>(mPurchaseMap.keySet());
    }
    
    // Returns a list of all owned product IDs of a given type */
    List<String> getAllOwnedSkus(String itemType) {
        List<String> result = new ArrayList<String>();
        for (Purchase p : mPurchaseMap.values()) {
            if (p.getItemType().equals(itemType)) result.add(p.getSku());
        }
        return result;
    }

    // Returns a list of all purchases. 
    List<Purchase> getAllPurchases() {
        return new ArrayList<Purchase>(mPurchaseMap.values());
    }

    int getPurchaseQuantity() {
    	return (mPurchaseMap.size());
    }
    
    int getSkuQuantity() {
    	return (mSkuMap.size());
    }
    
    void addSkuDetails(SkuDetails d) {
        mSkuMap.put(d.getSku(), d);
    }

    boolean addPurchase(Purchase p) {
    	int l = mPurchaseMap.size();
        mPurchaseMap.put(p.getSku(), p);
        if(++l == mPurchaseMap.size())
        	return true;
        			
        return false;		
    }
}


//////////////////////////////////////////////////////////////////
//
//			Class to handle exceptions
//
//////////////////////////////////////////////////////////////////


class InApp_Exception extends Exception {
    InApp_Result mResult;

    public InApp_Exception(InApp_Result r) {
        this(r, null);
    }
    public InApp_Exception(int response, String message) {
        this(new InApp_Result(response, message));
    }
    public InApp_Exception(InApp_Result r, Exception cause) {
        super(r.getMessage(), cause);
        mResult = r;
    }
    public InApp_Exception(int response, String message, Exception cause) {
        this(new InApp_Result(response, message), cause);
    }
    /** Returns the InApp Result (error) that this exception signals. */
    public InApp_Result getResult() { return mResult; }
}

class InAppAsyncInProgressException extends Exception {
	
    public InAppAsyncInProgressException(String message) {
        super(message);
    }
}

