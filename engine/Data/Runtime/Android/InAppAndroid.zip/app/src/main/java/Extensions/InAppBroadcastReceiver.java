package Extensions;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class InAppBroadcastReceiver extends BroadcastReceiver 
{

	    /**
	     * Listener interface for received broadcast messages.
	     */
	    public interface InAppBroadcastListener 
	    {
	        void receivedBroadcast();
	    }

	    /**
	     * The Intent action that this Receiver should filter for.
	     */
	    public static final String ACTION_UPDATED = "com.android.vending.billing.PURCHASES_UPDATED";
	    public static final String ACTION_NOTIFY = "com.android.vending.billing.IN_APP_NOTIFY";

	    private final InAppBroadcastListener mListener;

	    public InAppBroadcastReceiver(InAppBroadcastListener listener) 
	    {
	        mListener = listener;
	    }

	    @Override
	    public void onReceive(Context context, Intent intent) 
	    {
	        if (mListener != null) {
	            mListener.receivedBroadcast();
	        }
	    }
}

