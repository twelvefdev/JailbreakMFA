/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import Actions.CActExtension;
import Application.CRunApp;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Runtime.SurfaceView;
import Services.CBinaryFile;
import android.Manifest;
import android.annotation.SuppressLint;

import android.content.Context;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.VideoView;

public class CRunVideoAndroid extends CRunViewExtension
{
	// <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
	public static final int CNDONSTART = 0;
	public static final int CNDONEND = 1;
	public static final int CNDONPOSITION = 2;
	public static final int CNDONTAP = 3;
	public static final int CNDISPLAYING = 4;
	public static final int CNDONERROR = 5;
	public static final int CNDONPREPARED = 6;
	public static final int CND_LAST = 7;

	public static final int ACTVIDEOURL = 0;
	public static final int ACTVIDEOFILE = 1;
	public static final int ACTPLAY = 2;
	public static final int ACTRESUME = 3;
	public static final int ACTSTOP = 4;
	public static final int ACTPAUSE = 5;
	public static final int ACTSEEKTO = 6;
	public static final int ACTGOEND = 7;
	public static final int ACTGOBEG = 8;
	public static final int ACTWIDTH = 9;
	public static final int ACTHEIGHT = 10;
	public static final int ACTSHOW = 11;
	public static final int ACTHIDE = 12;
	public static final int ACTBCOLOR= 13;
	public static final int ACTMUTE = 14;
	public static final int ACTUNMUTE = 15;
	public static final int ACTSETVOLUME= 16;
	public static final int ACTVIDEORESC= 17;
	public static final int ACTSETBAR= 18;

	public static final int EXPERROR = 0;
	public static final int EXPGETPOSITION = 1;
	public static final int EXPGETPOSHMS = 2;
	public static final int EXPGETFILE = 3;
	public static final int EXPGETURL = 4;
	public static final int EXPGETVWIDTH = 5;
	public static final int EXPGETVHEIGHT = 6;
	public static final int EXPGETVIDDUR = 7;
	public static final int EXPGETWIDTH = 8;
	public static final int EXPGETHEIGHT = 9;

	// </editor-fold>
	private VideoView mVideoView;
	private MediaPlayer mediaPlayer;
	private RelativeLayout VidLayout;
	private mMediaController mediaController;

	private int	VidViewWidth = 0;
	private int	VidViewHeight = 0;
	private int VidColor = 0;

	private int	VidProgress = 0;
	private long VidPosition = 0;

	private long VidDuration = 0;
	private int stopPosition = 0;

	private float volume = 1.0f;

	private int VidWidth =0;
	private int VidHeight =0;
	private int	androidapi = 0;

	private String VideoURL =null;
	private String VideoFile = null;
	private String VideoReso = null;
	private String mPath = null;
	private String current = null;

	private int barTimeout;
	private boolean wasplaying = false;
	private boolean selfrepeat = false;
	private boolean onprepared = false;
	private boolean onpause = false;
	
	private boolean once = false;

	public int VidError = 0;
	public int VidType = -1;
	
	private int interval;

	final String AUTHORITY =  MMFRuntime.inst.getPackageName();
	final String CONTENT_URI_STRING =  "content://" + AUTHORITY;
	final Uri CONTENT_URI = Uri.parse(CONTENT_URI_STRING);
	final Uri RESOURCE_URI = Uri.parse("android.resource://"+ AUTHORITY);
	
	private static int PERMISSIONS_VIDEO_REQUEST = 12377867;
	private HashMap<String, String> permissionsApi23;
	private boolean enabled_perms;
	private boolean api23_fromaction;
	private boolean was_mediacontroller;
	
	private CValue expRet;
	
	private Runnable onEveryIntervalSecond=new Runnable() {

		@Override
		public void run() {

			if(mVideoView != null) {
				checkVideoStatus();
				
				if(selfrepeat)
					mVideoView.postDelayed(onEveryIntervalSecond, interval);
			}

		}
	};
	
	private void checkVideoStatus()
	{
		VidPosition = mVideoView.getCurrentPosition();

		VidHeight   = mVideoView.getHeight();
		VidWidth    = mVideoView.getWidth();
		VidDuration = mVideoView.getDuration();

		if(VidPosition <= 15 && selfrepeat && !once)
		{
			once = true;
			ho.pushEvent(CNDONSTART, 0);
			//Toast.makeText(ho.getControlsContext(), "Video on Start", Toast.LENGTH_LONG).show();
			Log.d("VideoAndroid", "Video is at Start");
		}

		if(VidPosition > 10)
			once = false;
		
		if(mVideoView.isPlaying())
			wasplaying = true;
		else
			wasplaying = false;

	}
	
	private FileOutputStream out;


	public class mMediaController extends MediaController {
		
		
		public mMediaController(Context context, AttributeSet attrs) {
			super(context, attrs);
		}

		public mMediaController(Context context, boolean useFastForward) {
			super(context, useFastForward);
		}

		public mMediaController(Context context) {
			super(context);
		}

		@Override
		public void show(int timeout) {
			super.show(timeout);
		}
		
		@Override
		public void hide() {
			super.hide();
		}

		@Override
		public boolean dispatchKeyEvent(KeyEvent event) {
			return super.dispatchKeyEvent(event);
		}

	}


	public CRunVideoAndroid()
	{
		androidapi = MMFRuntime.deviceApi;
	}

	public @Override int getNumberOfConditions()
	{
		return CND_LAST;
	}

	@SuppressLint("InlinedApi")
	@Override
	public void createRunView(CBinaryFile file, CCreateObjectInfo cob, int version) {

		ho.hoImgWidth = file.readShort();
		ho.hoImgHeight = file.readShort();

		barTimeout = 0;
		
		interval = 500;
		
		// Container Layout Relative for center purpose  for the Video View
		VidLayout = new RelativeLayout(ho.getControlsContext());
				//VidLayout.setId(232);
				VidLayout.setGravity(Gravity.CENTER);
				VidLayout.setBackgroundColor(Color.TRANSPARENT);

				android.widget.RelativeLayout.LayoutParams VidLayoutParms = 
						new android.widget.RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 
								ViewGroup.LayoutParams.WRAP_CONTENT);
				VidLayout.setLayoutParams(VidLayoutParms);	

				// Now create the Video Window
				mVideoView = new VideoView(ho.getControlsContext()) {
					@Override
					public boolean onKeyDown(int keyCode, KeyEvent event) {
					      return SurfaceView.inst.onKeyDown(keyCode, event);
					}
					@Override
					public boolean onKeyUp(int keyCode, KeyEvent event) {
					      return SurfaceView.inst.onKeyUp(keyCode, event);
					}
				};

				//if VideoView was created
				if(mVideoView != null) {       	

					android.widget.RelativeLayout.LayoutParams VidLayoutParmsIn = 
							new android.widget.RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 
									ViewGroup.LayoutParams.MATCH_PARENT);

					//Add the View with some rules
					VidLayout.addView(mVideoView, VidLayoutParmsIn);

					// a Must have to avoid the SurfaceView sandwich
					mVideoView.setZOrderOnTop(true); 

					mVideoView.setBackgroundColor(Color.TRANSPARENT);

					//Adding and Attaching Media Controller to VideoView 
					mediaController = new mMediaController(ho.getControlsContext());

					mediaController.setAnchorView(VidLayout);
					mediaController.setMediaPlayer(mVideoView);

					mVideoView.setMediaController(null);

					//Setting Media player when Video View is prepared
					mVideoView.setOnPreparedListener(new OnPreparedListener() {

						@Override
						public void onPrepared(MediaPlayer mPlayer) { 
							mediaPlayer = mPlayer;
							onprepared = true;
							//mediaController.hide();
							if(barTimeout != 0 ) {
								mVideoView.setMediaController(mediaController);
								mediaController.show(barTimeout+1);
							}
							else {
								mediaController.hide();
								mVideoView.setMediaController(null);
							}
							ho.generateEvent(CNDONPREPARED, 0);
                            was_mediacontroller = true;
							if(!onpause)
								mVideoView.start();
						}

					});

					//Setting all the event to the VideoView
					mVideoView.setOnCompletionListener(new OnCompletionListener() {

						@Override
						public void onCompletion(MediaPlayer mp) {
							VidPosition = mVideoView.getCurrentPosition();
							ho.pushEvent(CNDONEND, 0);
							//Toast.makeText(ho.getControlsContext(), "Video completed", Toast.LENGTH_LONG).show();
							Log.d("VideoAndroid", "Video is at End");

						}

					});

					mVideoView.setOnErrorListener(new OnErrorListener() {
						@Override
						public boolean onError(MediaPlayer mp, int err, int extra) {
							VidError = err;
							ho.pushEvent(CNDONERROR, 0);
							// we did take care of the error
							return true; 
						}
					});

					mVideoView.setOnTouchListener(new OnTouchListener() {

						@Override
						public boolean onTouch(View view, MotionEvent mEvent) {
							ho.pushEvent(CNDONTAP, 0);
							if(mediaController != null && onprepared) {
								if(barTimeout != 0 ) {
									mVideoView.setMediaController(mediaController);
									mediaController.show(barTimeout+1);
									was_mediacontroller = true;
								}
								else {
									mediaController.hide();
									mVideoView.setMediaController(null);
								}
							}
							return false;
						}

					});
					
					

					//Internal Controller
					mVideoView.postDelayed(onEveryIntervalSecond, interval);

					mVideoView.requestFocus();

					setView(VidLayout);

					mVideoView.requestLayout();
					mVideoView.invalidate();
					mediaController.requestFocus();
				}
				
		        enabled_perms = false;
		        
				if(MMFRuntime.deviceApi > 22) {
					permissionsApi23 = new HashMap<String, String>();
					permissionsApi23.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, "Write Storage");
					permissionsApi23.put(Manifest.permission.READ_EXTERNAL_STORAGE, "Read Storage");
					if(!MMFRuntime.inst.verifyOkPermissionsApi23(permissionsApi23))
						MMFRuntime.inst.pushForPermissions(permissionsApi23, PERMISSIONS_VIDEO_REQUEST);
					else
						enabled_perms = true;
				}
				else
					enabled_perms = true;
				
			expRet = new CValue(0);
	}

	public @Override void destroyRunObject(boolean bFast)
	{
		setView(null);
		VidLayout.removeAllViews();
		mVideoView.stopPlayback();
		mediaController = null;
		mVideoView = null;
		VidLayout = null;
		once = false;
	}

	@Override
	public void pauseRunObject() {
		Log.d("VideoAndroid","onPause called");
	    stopPosition = mVideoView.getCurrentPosition(); //stopPosition
	    mVideoView.pause();
	}
	
	@Override
	public void continueRunObject() {
		Log.d("VideoAndroid","onResume called");
	    mVideoView.seekTo(stopPosition);
	    mVideoView.start(); //Or use resume() if it doesn't work. I'm not sure
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults, List<Integer> permissionsReturned) {
		if(permissionsReturned.contains(PERMISSIONS_VIDEO_REQUEST)) {
			enabled_perms = verifyResponseApi23(permissions, permissionsApi23);
			if(enabled_perms && api23_fromaction)
				playVideo();
		}
		else
			enabled_perms = false;
	} 
	private void playVideo() {
		try {
			selfrepeat = true;
			mVideoView.setVisibility(View.INVISIBLE);
			VidError = 0;			
			wasplaying = false;

			final String path = mPath.toString();
			Log.v("VideoAndroid", "path: " + path);
			if (path == null || path.length() == 0) {
				VidError = 300;
				ho.pushEvent(CNDONERROR, 0);				
				//Toast.makeText(ho.getControlsContext(), "File URL/path is empty",
				//		Toast.LENGTH_LONG).show();

			} else {
				// If the path has not changed, just start the media player
				if (path.equals(current) && mVideoView != null) {
					mVideoView.start();
					mVideoView.setVisibility(View.VISIBLE);
					mVideoView.requestFocus();
					mVideoView.postDelayed(onEveryIntervalSecond, interval);
					return;
				}
				current = path;

				Runtime.getRuntime().gc();
				
				//Just to accomplish with security policy in api 11 or above
				if(androidapi < 11 && VidType != 3 && (mPath.contains("http") || mPath.contains("rstp"))) {
					mVideoView.setVideoPath(getDataSource(path));
				}
				else {

					if(VidType != 3)
						mVideoView.setVideoPath(mPath);

					else{
						String[] file = mPath.split("\\.(?=[^\\.]+$)");
						if(file.length > 0) {
							int l = file.length;
							Uri uri = null;				
							if(MMFRuntime.inst.obbAvailable) {
								uri = Uri.parse(CONTENT_URI_STRING + "/res/raw/" + mPath);
							}
							else
								uri = Uri.parse(RESOURCE_URI+ "/raw/" +file[(l > 1 ? l-2 : 0)]);
							
							Log.v("VideoAndroid","Video URI: "+uri.toString());
							if(uri != null)
							    mVideoView.setVideoURI(uri);
						}
					}
				}
				mVideoView.setVisibility(View.VISIBLE);
				mVideoView.requestFocus();
				mVideoView.forceLayout();
				mVideoView.postDelayed(onEveryIntervalSecond, interval);

			}
		} catch (Exception e) {
			Log.e("VideoAndroid", "error: " + e.getMessage(), e);
			VidError = 100;
			ho.pushEvent(CNDONERROR, 0);
			if (mVideoView != null) {
				selfrepeat = false;
				mVideoView.stopPlayback();
			}
		}
	}

	private String getDataSource(String path) throws IOException {

		if (!URLUtil.isNetworkUrl(path)) {
			return path;
		} else {
			URL url = new URL(path);
			URLConnection cn = url.openConnection();
			cn.connect();
			InputStream stream = cn.getInputStream();

			if (stream == null)
				throw new RuntimeException("Stream is null");

			File temp = File.createTempFile("VideoPlayTemp", "dat");
			temp.deleteOnExit();
			String tempPath = temp.getAbsolutePath();
			out = new FileOutputStream(temp);

			byte buf[] = new byte[4096];

			do {
				int numread = stream.read(buf);
				if (numread <= 0)
					break;
				out.write(buf, 0, numread);
			} while (true);
			try {
				stream.close();
			} catch (IOException ex) {
				Log.e("VideoAndroid", "error: " + ex.getMessage(), ex);
				VidError = 200;
				ho.pushEvent(CNDONERROR, 0);
			}
			return tempPath;
		}
	}


	// Conditions
	// -------------------------------------------------
	public @Override boolean condition(int num, CCndExtension cnd)
	{
		switch (num)
		{
		case CNDONSTART:
			return cndOnStart(cnd);
		case CNDONEND:
			return cndOnEnd(cnd);
		case CNDONPOSITION:
			return cndOnPosition(cnd);
		case CNDONTAP:
			return cndOnTap(cnd);
		case CNDISPLAYING:
			return cndIsPlaying(cnd);
		case CNDONERROR:
			return cndOnError(cnd);
		case CNDONPREPARED:
			return cndOnPrepared(cnd);
		}
		return false;
	}

	// Actions
	// -------------------------------------------------
	public @Override void action(int num, CActExtension act)
	{
		switch (num)
		{
		case ACTVIDEOURL:
			actVideoURL(act);
			break;
		case ACTVIDEOFILE:
			actVideoFile(act);
			break;
		case ACTPLAY:
			actPlay(act);
			break;
		case ACTRESUME:
			actResume(act);
			break;
		case ACTSTOP:
			actStop(act);
			break;
		case ACTPAUSE:
			actPause(act);
			break;
		case ACTSEEKTO:
			actSeekTo(act);
			break;
		case ACTGOEND:
			actGoEnd(act);
			break;
		case ACTGOBEG:
			actGoBeg(act);
			break;
		case ACTWIDTH:
			actWidth(act);
			break;
		case ACTHEIGHT:
			actHeight(act);
			break;
		case ACTSHOW:
			actShow(act);
			break;
		case ACTHIDE:
			actHide(act);
			break;
		case ACTBCOLOR:
			actBckColor(act);
			break;
		case ACTMUTE:
			actMute(act);
			break;
		case ACTUNMUTE:
			actUnmute(act);
			break;
		case ACTSETVOLUME:
			actSetVolume(act);
			break;
		case ACTVIDEORESC:
			actVideoResource(act);
			break;
		case ACTSETBAR:
			actSetBar(act);
			break;
		}
	}

	// Expressions
	// -------------------------------------------------
	public @Override CValue expression(int num)
	{
		switch (num)
		{
		case EXPERROR:
			return expError();
		case EXPGETPOSITION:
			return expGetPosition();
		case EXPGETPOSHMS:
			return expGetPosHMS();
		case EXPGETFILE:
			return expGetFile();
		case EXPGETURL:
			return expGetURL();
		case EXPGETVWIDTH:
			return expGetVideoWidth();
		case EXPGETVHEIGHT:
			return expGetVideoHeight();
		case EXPGETVIDDUR:
			return expGetDuration();
		case EXPGETWIDTH:
			return expGetWidth();
		case EXPGETHEIGHT:
			return expGetHeight();
		}
		return null;
	}

	//////////////////////////////////////////////////////////////////////////////////////////
	//
	//						CONDITIONS
	//
	//////////////////////////////////////////////////////////////////////////////////////////

	private boolean cndOnStart(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndOnEnd(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndOnPosition(CCndExtension cnd)
	{
		int position = (int)(cnd.getParamExpFloat(rh,0) * 1000);

		if(mVideoView != null) {
			if(Math.abs(mVideoView.getCurrentPosition() - position) < 50)
				return true;
		}
		return false;
	}

	private boolean cndOnTap(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndIsPlaying(CCndExtension cnd)
	{
		return wasplaying;
	}

	private boolean cndOnError(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndOnPrepared(CCndExtension cnd)
	{
		return true;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////
	//
	//						ACTIONS
	//
	//////////////////////////////////////////////////////////////////////////////////////////

	private void actVideoURL(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			VideoURL = param0;
			VideoFile= null;
			VideoReso= null;      	
			mPath = VideoURL;
			VidType = 1;			
		}

	}

	private void actVideoFile(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			VideoURL = null;
			VideoFile= param0;
			VideoReso= null;      	
			mPath = VideoFile;
			VidType = 2;			
		}
	}

	private void actPlay(CActExtension act)
	{
		if(mVideoView != null) {
			onpause = false;
			api23_fromaction = false;
			if(!enabled_perms) {
				MMFRuntime.inst.askForPermissionsApi23();
				api23_fromaction = true;
				return;
			}
			playVideo();
		}
	}

	private void actResume(CActExtension act)
	{
		if(mVideoView != null) {
			onpause = false;
			mVideoView.start();
		}

	}


	private void actStop(CActExtension act)
	{
		if(mVideoView != null) {
			mVideoView.pause();
			mVideoView.seekTo(0);
		}
	}

	private void actPause(CActExtension act)
	{
		if(mVideoView != null) {
			VidPosition = mVideoView.getCurrentPosition();
			onpause = true;
			mVideoView.pause(); 
		}
	}

	private void actSeekTo(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(mVideoView != null && param0 >= 0) {
			//Converting seconds to MClickT/RuntimeAndroidillisecs
			mVideoView.seekTo(param0*1000);
		}
	}

	private void actGoEnd(CActExtension act)
	{
		if(mVideoView != null) {
			if(!wasplaying) {
				mVideoView.resume();
			}
			mVideoView.seekTo(mVideoView.getDuration()-100);
			if(!wasplaying) {
				mVideoView.pause();
			}
		}
	}

	private void actGoBeg(CActExtension act)
	{
		if(mVideoView != null) {
			mVideoView.pause();
			mVideoView.seekTo(0);
			if(wasplaying)
				mVideoView.resume();
		}
	}

	private void actWidth(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 >= 0) {
			setViewWidth(param0);
		}
	}

	private void actHeight(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 >= 0) {
			setViewHeight(param0);
		}
	}

	private void actShow(CActExtension act)
	{
		if(mVideoView != null) {
			mVideoView.setVisibility(View.VISIBLE);
		}

	}

	private void actHide(CActExtension act)
	{
		if(mVideoView != null) {
			mVideoView.setVisibility(View.INVISIBLE);
		}
	}

	private void actBckColor(CActExtension act)
	{
		int param0 = act.getParamColour(rh,0);
		if(VidLayout != null && param0 >= 0) {
			//Adding opaque to alpha
			VidColor = (0xFF << 24) + param0;  		
			VidLayout.setBackgroundColor(VidColor);
			mVideoView.setBackgroundColor(VidColor);
		}
	}

	private void actMute(CActExtension act)
	{
		if(mVideoView != null && mediaPlayer != null) {
			mediaPlayer.setVolume(0.0f, 0.0f);
		}

	}

	private void actUnmute(CActExtension act)
	{
		if(mVideoView != null && mediaPlayer != null) {
			mediaPlayer.setVolume(volume, volume);
		}

	}

	private void actSetVolume(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(mVideoView != null && mediaPlayer != null && param0 >= 0) {
			volume = ((param0 > 100) ? 100 : param0)/100.0f;
			mediaPlayer.setVolume(volume, volume);
		}
	}  

	private void actVideoResource(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			VideoURL = null;
			VideoFile= null;
			VideoReso= param0;      	
			mPath = VideoReso;
			VidType = 3;			
		}

	}

	private void actSetBar(CActExtension act)
	{
		barTimeout = (act.getParamExpression(rh,0) * 1000);
				
		if(barTimeout < 0)
			barTimeout = -1;
		
		if(mediaController != null) {
			if(barTimeout != 0 ) {
				mVideoView.setMediaController(mediaController);
				mediaController.show(barTimeout+1);
				was_mediacontroller = true;
			}
			else {
				mediaController.hide();
				mVideoView.setMediaController(null);
			}
		}

	}

	//////////////////////////////////////////////////////////////////////////////////////////
	//
	//						EXPRESSIONS
	//
	//////////////////////////////////////////////////////////////////////////////////////////

	private CValue expError()
	{
		expRet.forceInt(VidError);
		return expRet;
	}

	private CValue expGetPosition()
	{
		expRet.forceInt(Math.round(VidPosition/1000.0f));
		return expRet;
	}

	private CValue expGetPosHMS()
	{
		int param0 = ho.getExpParam().getInt();
		int hours = 0;
		int mins  = 0;
		int secs  = 0;

		if(param0 > 0) {
			hours = param0 / 3600;
			mins = (param0 % 3600) / 60;
			secs = param0 % 60;     	
		}

		String hms = String.format("%02d:%02d:%02d", hours, mins, secs);
		expRet.forceString(hms);       	
		return expRet;
	}

	private CValue expGetFile()
	{
		expRet.forceString("");
		if(VideoFile != null)
			expRet.forceString(VideoFile);

		return expRet;
	}

	private CValue expGetURL()
	{
		expRet.forceString("");
		if(VideoURL != null)
			expRet.forceString(VideoURL);

		return expRet;
	}

	private CValue expGetVideoWidth()
	{
		expRet.forceInt(0);
		if(mVideoView != null)
			expRet.forceInt(VidWidth);

		return expRet;
	}

	private CValue expGetVideoHeight()
	{
		expRet.forceInt(0);
		if(mVideoView != null)
			expRet.forceInt(VidHeight);

		return expRet;
	}

	private CValue expGetDuration()
	{
		expRet.forceInt(0);
		if(mVideoView != null)
			expRet.forceInt(Math.round(VidDuration/1000.0f));

		return expRet;
	}

	private CValue expGetWidth()
	{
		expRet.forceInt(0);
		if(VidLayout != null)
			expRet.forceInt(ho.hoImgWidth);

		return expRet;
	}

	private CValue expGetHeight()
	{
		
		expRet.forceInt(0);
		if(VidLayout != null)
			expRet.forceInt(ho.hoImgHeight);

		return expRet;
	}

}

