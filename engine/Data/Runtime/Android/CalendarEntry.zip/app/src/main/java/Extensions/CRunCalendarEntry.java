/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;
import android.Manifest;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract.Calendars;
import android.util.Log;


public class CRunCalendarEntry extends CRunExtension
{
	// <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
    public static final int CONDENTRYWRITTEN = 0;
    public static final int CONDENTRYFAIL = 1;
    public static final int CONDCALENDARREAD = 2;
    public static final int CONDENTRYREAD = 3;
    public static final int CONDENTRYERROR = 4;
    public static final int CND_LAST = 5;

    public static final int ACTSETCALENDAR = 0;
    public static final int ACTEVTTITLE = 1;
    public static final int ACTEVTLOCATION = 2;
    public static final int ACTEVTNOTES = 3;
    public static final int ACTEVTSTARTD = 4;
    public static final int ACTEVTSTARTT = 5;
    public static final int ACTEVTENDD = 6;
    public static final int ACTEVTENDT = 7;
    public static final int ACTEVTDURATION = 8;
    public static final int ACTEVTALL = 9;
    public static final int ACTEVTTIMEZONE = 10;
    public static final int ACTEVTCFGACCESS = 11;
    public static final int ACTEVTCFGAVAILABILITY = 12;
    public static final int ACTEVTFREQUENCY = 13;
    public static final int ACTEVTINTERVAL = 14;
    public static final int ACTEVTCOUNT = 15;
    public static final int ACTEVTBYMINUTE = 16;
    public static final int ACTEVTBYHOUR = 17;
    public static final int ACTEVTBYDAY = 18;
    public static final int ACTEVTBYMONTH = 19;
    public static final int ACTEVTBYMONTHDAY = 20;
    public static final int ACTEVTMAKE = 21;
    public static final int ACTCALREAD = 22;
    public static final int ACTEVTREAD = 23;
    public static final int ACTEVTDELETE = 24;
    public static final int ACTEVTDELALL = 25;
    public static final int ACTCREATECAL = 26;

    public static final int EXPGETERROR = 0;
    public static final int EXPGETCALIDX = 1;
    public static final int EXPGETCALNAME = 2;
    public static final int EXPGETEVTIDX = 3;
    public static final int EXPGETID = 4;
    public static final int EXPGETTITLE = 5;
    public static final int EXPGETLOC = 6;
    public static final int EXPGETNOTES = 7;
    public static final int EXPGETSTARTD = 8;
    public static final int EXPGETSTARTT = 9;
    public static final int EXPGETENDD = 10;
    public static final int EXPGETENDT = 11;
    public static final int EXPGETDUR = 12;
    public static final int EXPGETALLDAY = 13;
    public static final int EXPGETTIMEZONE = 14;
    public static final int EXPGETALARM = 15;
    public static final int EXPGETRFREQUENCY = 16;
    public static final int EXPGETRINTERVAL = 17;
    public static final int EXPGETRCOUNT = 18;
    public static final int EXPGETRBYMINUTE = 19;
    public static final int EXPGETRBYHOUR = 20;
    public static final int EXPGETRBYDAY = 21;
    public static final int EXPGETRBYMONTH = 22;
    public static final int EXPGETRBYMONTHDAY = 23;
    public static final int EXPGETSECFROMTIME = 24;
    public static final int EXPGETTIMEFROMSEC = 25;
    public static final int EXPGETDEFTIMEZONE = 26;
    public static final int EXPGETTIMEZONEID = 27;
    public static final int EXPMAKEDATESTRING = 28;
    public static final int EXPMAKEHOURSTRING = 29;

    // </editor-fold>

    public int nError = 0;
    public int androidapi=0;
    public int gCal_Id = 1;
    public int Cal_numbers = 0;
    public int Events_numbers = 0;
    
    private CValue expRet;
    
	private static int PERMISSIONS_CALENDAR_REQUEST = 125577848;
	private HashMap<String, String> permissionsApi23;
	private boolean enabled_perms;
	private int action_perm;

	class zCalendars {   	
    	public int Index;
    	public String Name;
    	//public String Account_name;
    	//public String Account_type;
    };

    class zTimeDate {
    	public int Year;
    	public int Month;
    	public int Day;
    	public int Hours;
    	public int Minutes;
    	public int Seconds;
    	public TimeZone tz;
    };

    class zEvents {
    	public int Index;
    	public int Cal_id;
    	public String Title;
    	public String Location;
    	public String Notes;
    	public String StartDate;
    	public String StartTime;
    	public String EndDate;
    	public String EndTime;
    	public String RRules;
    	public String Duration;
    	public int AllDay;
    	public int AccessLevel;
    	public int Availability;
    	public String Timezone;
    	public int hasAlarm;
    	public int Status;
    }
    
    class zEvent {
    	public int Index;
    	public int Cal_id;
    	public String Title;
    	public String Location;
    	public String Notes;
    	public zTimeDate StartDate;
    	public zTimeDate EndDate;
    	public String TimezoneStr;
    	public int Duration;
    	public int AllDay;
    	public int Status;
   	
    	public String RRules;
    	public String ByMinute;
    	public String ByHour;
    	public String ByDay;
    	public String ByMonth;
    	public String ByMonthDay;
    	
    	public int Frequency;
    	public int Interval;
    	public int Count;
    	
    	public int AccessLevel;
    	public int Availability;
    	public int hasAlarm;
    } 
    
    private void CreateLocalCalendar(String name, String displayname, String owner) {
    	ContentValues lcalendar = new ContentValues();
    	Uri l_calendars;
    	if(name.length() > 0 && displayname.length() > 0 && owner.length() > 0) {

    		if (androidapi >= 8 ) {
    			l_calendars = Uri.parse("content://com.android.calendar/calendars");
    		} else {
    			l_calendars = Uri.parse("content://calendar/calendars");
    		}
    		
			lcalendar.put(Calendars.ACCOUNT_NAME, name);
			lcalendar.put(Calendars.ACCOUNT_TYPE, "LOCAL");
			lcalendar.put(Calendars.NAME, name);
			lcalendar.put(Calendars.CALENDAR_DISPLAY_NAME, displayname);
			lcalendar.put(Calendars.CALENDAR_TIME_ZONE, TimeZone.getDefault().getID());
			lcalendar.put(Calendars.CALENDAR_COLOR, 0xFF008080);
    		lcalendar.put(Calendars.CALENDAR_ACCESS_LEVEL, 700);
    		lcalendar.put(Calendars.SYNC_EVENTS, 1);
    		lcalendar.put(Calendars.OWNER_ACCOUNT, owner);

			l_calendars = l_calendars.buildUpon()
					.appendQueryParameter(android.provider.CalendarContract.CALLER_IS_SYNCADAPTER,"true")
					.appendQueryParameter(Calendars.ACCOUNT_NAME, name)
					.appendQueryParameter(Calendars.ACCOUNT_TYPE, "LOCAL")
					.build();
    		Uri result = MMFRuntime.inst.getContentResolver().insert(l_calendars, lcalendar);
    	}
    }
       	 
   	 private void getCalendars() {
   		 final String[] l_field;
   		 if(androidapi > 13) {
   			 l_field = new String[]{"_id", "name"};
   		 }
   		 else {
   			 l_field = new String[]{"_id", "displayName"};
   		 }
   		 
        Uri l_calendars;
        if (androidapi >= 8 ) {
        	l_calendars = Uri.parse("content://com.android.calendar/calendars");
        } else {
        	l_calendars = Uri.parse("content://calendar/calendars");
        }

        Cursor l_Cursor = MMFRuntime.inst.getContentResolver().query(l_calendars, l_field, null, null, null);

        l_Cursor.moveToFirst();
        
        if (l_Cursor.moveToFirst()) {
        	myCalendars.clear();
        	Cal_numbers = 0;
        	int l_idxCol   = l_Cursor.getColumnIndex(l_field[0]);
        	int l_nameCol  = l_Cursor.getColumnIndex(l_field[1]);
        	//int l_accName  = l_Cursor.getColumnIndex(l_field[2]);
        	//int l_accType  = l_Cursor.getColumnIndex(l_field[3]);
       	
        	do {
            	zCalendars gCalendars = new zCalendars();
        		gCalendars.Name  = l_Cursor.getString(l_nameCol);
        		gCalendars.Index = Integer.parseInt(l_Cursor.getString(l_idxCol));
        		//gCalendars.Account_name = l_Cursor.getString(l_accName);
        		//gCalendars.Account_type = l_Cursor.getString(l_accType);
        		
        		myCalendars.add(gCalendars);
        		
        		++Cal_numbers;
        	} while (l_Cursor.moveToNext());
        	nError = 0;
        	ho.pushEvent(CONDCALENDARREAD, 0);
        }
        else
        	nError = 2;
        
        l_Cursor.close();
   	 }    
    
   	 private void getEvents() {
   		 final String[] l_field;
   		 if(androidapi > 13) {
   	   		 l_field = new String[]{"_id","calendar_id","title","description","eventLocation",
						"dtstart", "dtend", "duration", "allDay", "eventStatus", "eventTimezone",
						"accessLevel", "availability","hasAlarm","rrule"};
   		 }
   		 else {
   	   		 l_field = new String[]{"_id","calendar_id","title","description","eventLocation",
						"dtstart", "dtend", "duration", "allDay", "eventStatus", "timezone",
						"visibility", "transparency","hasAlarm","rrule"};
   		 }
   		 
         Uri l_events;
         if (androidapi >= 8 ) {
         	l_events = Uri.parse("content://com.android.calendar/events");
         } else {
         	l_events = Uri.parse("content://calendar/events");
         }

         Cursor l_Cursor = null;
         try {
        	 l_Cursor = MMFRuntime.inst.getContentResolver().query(l_events, l_field, null, null, null); 
         }
         catch (Exception e) {
        	 Log.v("CalendarEntry", e.getMessage());     	 
         }
         
         if (l_Cursor.moveToFirst()) {
         	myEvents.clear();
         	Events_numbers = 0;
         	
         	int part = 0;

         	int l_Index 		= l_Cursor.getColumnIndex(l_field[0]);
         	int l_Cal_id 		= l_Cursor.getColumnIndex(l_field[1]);
         	int l_Title 		= l_Cursor.getColumnIndex(l_field[2]);
         	int l_Notes 		= l_Cursor.getColumnIndex(l_field[3]);
         	int l_Location 		= l_Cursor.getColumnIndex(l_field[4]);
        	int l_StartDate 	= l_Cursor.getColumnIndex(l_field[5]);
         	int l_EndDate 		= l_Cursor.getColumnIndex(l_field[6]);
         	int l_Duration 		= l_Cursor.getColumnIndex(l_field[7]);
         	int l_AllDay 		= l_Cursor.getColumnIndex(l_field[8]);
         	int l_Status 		= l_Cursor.getColumnIndex(l_field[9]);
         	int l_Timezone 		= l_Cursor.getColumnIndex(l_field[10]);
        	int l_AccessLevel 	= l_Cursor.getColumnIndex(l_field[11]);
         	int l_Availability 	= l_Cursor.getColumnIndex(l_field[12]);
         	int l_hasAlarm 		= l_Cursor.getColumnIndex(l_field[13]);        	
         	int l_RRules 		= l_Cursor.getColumnIndex(l_field[14]);

         	do {
             	zEvents gEvent = new zEvents();
             	
         		gEvent.Index 		= Int2String(l_Cursor.getString(l_Index));
         		gEvent.Cal_id 		= Int2String(l_Cursor.getString(l_Cal_id));;
         		gEvent.Title 		= String2String(l_Cursor.getString(l_Title));
         		gEvent.Location 	= String2String(l_Cursor.getString(l_Location));
         		gEvent.Notes 		= String2String(l_Cursor.getString(l_Notes));
         		gEvent.Timezone 	= String2String(l_Cursor.getString(l_Timezone));
         		
         		String StartD		= getDate(Long2String(l_Cursor.getString(l_StartDate)), gEvent.Timezone);
         		part = 0;
         		for (String token : StartD.split(" ")) {
         			if(part == 0) {
                 		gEvent.StartDate 	= token;
                 	}
         			else if (part ==1) {
         				gEvent.StartTime	= token;
         			}
         			part++;
         		} 

         		gEvent.RRules 		= String2String(l_Cursor.getString(l_RRules));

         		gEvent.Duration 	= String2String(l_Cursor.getString(l_Duration));
         		
         		if(gEvent.Duration.length() > 0) {
             		String EndD			= getDate(Long2String(l_Cursor.getString(l_StartDate)) + Sec2Duration(gEvent.Duration)*1000, gEvent.Timezone);
             		part = 0;
             		for (String token : EndD.split(" ")) {
             			if(part == 0) {
                     		gEvent.EndDate 	= token;
                     	}
             			else if (part ==1) {
             				gEvent.EndTime	= token;
             			}
             			part++;
             		}         		
              			
         		} else {
             		String EndD			= getDate(Long2String(l_Cursor.getString(l_EndDate)), gEvent.Timezone);
             		part = 0;
             		for (String token : EndD.split(" ")) {
             			if(part == 0) {
                     		gEvent.EndDate 	= token;
                     	}
             			else if (part ==1) {
             				gEvent.EndTime	= token;
             			}
             			part++;
             		}         		
         		}
       		
         		gEvent.AllDay 		= Int2String(l_Cursor.getString(l_AllDay));
         		gEvent.Status	 	= Int2String(l_Cursor.getString(l_Status));
         		gEvent.Timezone 	= String2String(l_Cursor.getString(l_Timezone));
        		gEvent.AccessLevel 	= Int2String(l_Cursor.getString(l_AccessLevel));
         		gEvent.Availability = Int2String(l_Cursor.getString(l_Availability));
         		gEvent.hasAlarm 	= Int2String(l_Cursor.getString(l_hasAlarm));         		
         		
         		myEvents.add(gEvent);
         		
         		++Events_numbers;
         	} while (l_Cursor.moveToNext());
         	ho.pushEvent(CONDENTRYREAD, 0);
         }
         
         if(l_Cursor != null)
        	 l_Cursor.close();
    }
     
    private List<zCalendars> myCalendars;    
    private List<zEvents> myEvents;
    private zEvent wriEvent;
    
    private long Sec2Duration(String l_duration) {
    	long l_Result = 0;
    	Pattern pattern = Pattern.compile("(\\p{Alpha}+)(\\d+)(\\p{Alpha}+)");
    	Matcher matcher = pattern.matcher(l_duration);
    	matcher.find();
    	try {
	    	String dValue = matcher.group(2);
	    	l_Result = Long.parseLong(dValue);
	    	return l_Result; 	    	
    	} catch (Exception e) {
    		return l_Result;
    	}
    }
    
    private int Int2String(String szValue) {
    	if(szValue != null) {
    		try {
    			return Integer.parseInt(szValue); 
    		} catch (Exception e) {
    			return 0;
    		}
    	} else {
    		return 0;
    	}
    }
    
    private long Long2String(String szValue) {
    	if(szValue != null) {
    		return Long.parseLong(szValue);
    	} else {
    		return 0;
    	}
    }
   
    private String MakeDurationStr(int duration) {
    	String l_ResStr = "";
    	if(duration > 0) {
    		l_ResStr = "P"+String.valueOf(duration)+"S";
    	}
    	return l_ResStr;
    }
    
    private String String2String(String szValue) {
    	if(szValue != null)
    		return szValue;
    	else
    		return "";
    }
    
    private void EventWrite(zEvent lEvent) {
    	if(!enabled_perms) {
   			MMFRuntime.inst.askForPermissionsApi23();
   			return;
    	}
    	/*Write an event to calendar*/
	   	 ContentValues l_event = new ContentValues();
	   	 l_event.put("calendar_id", lEvent.Cal_id);
	   	 l_event.put("title", lEvent.Title);
	   	 l_event.put("description", lEvent.Notes);
	   	 l_event.put("eventLocation", lEvent.Location);

	   	 Long lStartMillis = DateToMillis(lEvent.StartDate.Month, lEvent.StartDate.Day, lEvent.StartDate.Year,
					 lEvent.StartDate.Hours, lEvent.StartDate.Minutes, lEvent.StartDate.Seconds,
					 TimeZone.getTimeZone(lEvent.TimezoneStr));
	   	 
   		 long lEndMillis   = DateToMillis(lEvent.EndDate.Month, lEvent.EndDate.Day, lEvent.EndDate.Year,
				 lEvent.EndDate.Hours, lEvent.EndDate.Minutes, lEvent.EndDate.Seconds,
				 TimeZone.getTimeZone(lEvent.TimezoneStr));

   		 l_event.put("dtstart", lStartMillis);
   		 
	   	 if(lEvent.Duration > 0) {
	       	 l_event.put("duration", MakeDurationStr(lEvent.Duration));
	   	 } else {
	       	 l_event.put("dtend",  lEndMillis);
	   	 }
	   	 l_event.put("allDay", lEvent.AllDay);

	   	 l_event.put("eventStatus", 1);

	   	 if(androidapi < 14) {
	   		 l_event.put("visibility", lEvent.AccessLevel);
	   		 l_event.put("transparency", lEvent.Availability);
	   	 } else {
		     l_event.put("accessLevel", lEvent.AccessLevel);
		     l_event.put("availability", lEvent.Availability);
	   	 }
	   	 l_event.put("eventTimezone", lEvent.TimezoneStr);

	   	 l_event.put("hasAlarm", lEvent.hasAlarm);
	   	 
	   	 lEvent.RRules = DoMakeRRules(lEvent);
	   	 if(lEvent.RRules.length() > 0)
	   		 l_event.put("rrule", lEvent.RRules);
	   	 
	   	 Uri l_eventUri;
	   	 if (androidapi > 7 ) {
	   		 l_eventUri = Uri.parse("content://com.android.calendar/events");
	   	 } else {
	   		 l_eventUri = Uri.parse("content://calendar/events");
	   	 }
	   	 
	   	
	   	 try {
	   		 Uri l_uri = null;
	   		 l_uri = MMFRuntime.inst.getContentResolver().insert(l_eventUri, l_event);
	   		 Log.v("CalendarEntry", l_uri.toString());
	   		 
	   		 if(lEvent.hasAlarm == 1) {
		   		 // reminder insert
		   		 Uri l_remindUri = null;
		   		 if (androidapi > 7 ) {
		   			 l_remindUri = Uri.parse("content://com.android.calendar/reminders");
		   		 } else {
		    	   	l_remindUri = Uri.parse("content://calendar/reminders");
		   		 }
		   		 ContentValues l_remind = new ContentValues();
		   		 long l_id = Long2String(l_uri.getLastPathSegment());
		   		 l_remind.put("event_id", l_id);
		   		 l_remind.put( "method", 1 );
		   		 l_remind.put( "minutes", 10 );
		   		 Uri l_ruri = null;
		   		 l_ruri = MMFRuntime.inst.getContentResolver().insert( l_remindUri, l_remind );
		   		 Log.v("CalendarEntry", l_ruri.toString());
	   		 }
	   		 
	   		 ho.pushEvent(CONDENTRYWRITTEN, 0);
	   	 }
	   	 catch (Exception e){
	   		 nError = 2;
	   		 Log.v("CalendarEntry", e.getMessage());
	        	 ho.pushEvent(CONDENTRYFAIL, 0);
	   	 }
    }
    	
    private void DoWriteEvent(zEvent lEvent){
    		EventWrite(lEvent);
    }
    
    public void DeleteEvents(int Id, int Cal_Id) {
    	if(!enabled_perms) {
    		MMFRuntime.inst.askForPermissionsApi23();
    		return;
    	}

    	Uri l_eventUri = null;

    	if (androidapi > 7 ) {
    		l_eventUri = Uri.parse("content://com.android.calendar/events");
    	} else {
    		l_eventUri = Uri.parse("content://calendar/events");
    	}

    	Cursor l_Cursor;

    	l_Cursor = MMFRuntime.inst.getContentResolver().query(l_eventUri, new String[]{"_id", "calendar_id"}, "calendar_id = " + Cal_Id, null, null);

    	if(l_Cursor.moveToFirst()) {
    		do {   		 
    			Uri deleteUri = ContentUris.withAppendedId(l_eventUri, l_Cursor.getInt(0));
    			long id = l_Cursor.getLong(l_Cursor.getColumnIndex("_id"));
    			if(Id == -1 || Id == id) {
    				int delQty = MMFRuntime.inst.getContentResolver().delete(deleteUri, null, null);
    				Log.d("CalendarEntry", "Delete ID: " + id + " DelQty: " + delQty); 
    			}
    		} while(l_Cursor.moveToNext());
    	}

    	if(l_Cursor != null)
    		l_Cursor.close();

    }
 
    public long DateToMillis(int month, int day, int year, int hour, int minute, int seconds, TimeZone tz) { 
        Calendar calendar = new GregorianCalendar();
        calendar.setTimeZone(tz);
         calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month -1); 
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, seconds);
        long mseconds = calendar.getTimeInMillis();
        return mseconds;  
    }
        
    public String getDate(long milliSeconds, String TimeZoneID) {
        SimpleDateFormat l_formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
        Calendar l_calendar = Calendar.getInstance();
        l_calendar.setTimeZone(TimeZone.getTimeZone(TimeZoneID));
        l_calendar.setTimeInMillis(milliSeconds);
        return l_formatter.format(l_calendar.getTime());
    }

    public long getSeconds(String szDate, int flag) {
        long l_Result = 0;
        SimpleDateFormat l_formatter;
        
        if(flag == 1) {
            l_formatter = new SimpleDateFormat("MM/dd/yyyy");
        }else if(flag ==2) {
            l_formatter = new SimpleDateFormat("hh:mm:ss");
        } else {
            l_formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
        }

        Calendar l_date = Calendar.getInstance();
        l_date.setTimeZone(TimeZone.getDefault());
        try {
        	l_date.setTime(l_formatter.parse(szDate));
        	l_Result = l_date.getTimeInMillis();
        }catch(ParseException e)  {
        }
        return l_Result;
    
    }
    
    public String GetRRules(String l_RRules, String l_Filter, String Default) {
    	String l_RResult = Default;
    	
    	boolean getit = false;
    	for (String token1 : l_RRules.split(";")) {
        	for (String token2 : token1.split("=")) {
        		if(getit) {
        			l_RResult = token2;
       	    	 	break;
           		}
        		if(token2.equalsIgnoreCase(l_Filter) != true) {
      	    	 	getit = false;
        			break; 
        		} else {
        			getit = true;
        		}

        	}
    		if(getit) {
    			//l_RResult = token2;
   	    	 	break;
       		}

    	}
    	return l_RResult;
    }
    
    public String DoMakeRRules(zEvent l_Event) {
    	String l_Result = "";
    	//    	MINUTELY	HOURLY    	DAILY    	WEEKLY    	MONTHLY    	YEARLY
    	if(l_Event.Frequency > 0) {
	    	switch(l_Event.Frequency) {
    			case 1:
    				l_Result = l_Result + "FREQ=MINUTELY";
    				break;
	    		case 2:
	    			l_Result = l_Result + "FREQ=HOURLY";
	    			break;
	    		case 3:
	    			l_Result = l_Result + "FREQ=DAILY";
	    			break;
	    		case 4:
	    			l_Result = l_Result + "FREQ=WEEKLY";
	    			break;
	    		case 5:
	    			l_Result = l_Result + "FREQ=MONTHLY";
	    			break;
	    		case 6:
	    			l_Result = l_Result + "FREQ=YEARLY";
	    			break;
	    	}
		
	    	if(l_Event.Interval > 0) {
	        	l_Result = l_Result + ";";
	   			l_Result = l_Result + "INTERVAL="+Integer.toString(l_Event.Interval);
	    	}
			
	    	if(l_Event.Count > 0) {
	        	l_Result = l_Result + ";";
	  			l_Result = l_Result + "COUNT="+Integer.toString(l_Event.Count);
	  		}
			
	    	if(l_Event.ByMinute.length() > 0) {
	        	l_Result = l_Result + ";";
	   			l_Result = l_Result + "BYMINUTE="+l_Event.ByMinute;
	   		}
	    	
	    	if(l_Event.ByHour.length() > 0) {
	        	l_Result = l_Result + ";";
	   			l_Result = l_Result + "BYHOUR="+l_Event.ByHour;
	    	}
	    	
	    	if(l_Event.ByDay.length() > 0) {
	        	l_Result = l_Result + ";";
	   			l_Result = l_Result + "BYDAY="+l_Event.ByDay;
	    	}
	    	
	    	if(l_Event.ByMonth.length() > 0) {
	        	l_Result = l_Result + ";";
	   			l_Result = l_Result + "BYMONTH="+l_Event.ByMonth;
	    	}
	    	
	    	if(l_Event.ByMonthDay.length() > 0) {
	        	l_Result = l_Result + ";";
	   			l_Result = l_Result + "BYMONTHDAY="+l_Event.ByMonthDay;
	    	}
    	}
    	return l_Result;
    }
    
    public CRunCalendarEntry()
    {
		androidapi = android.os.Build.VERSION.SDK_INT;
		myCalendars 	= new ArrayList <zCalendars>();
		myEvents 		= new ArrayList <zEvents>();
		// it will be only one
		wriEvent 		= new zEvent();
		expRet = new CValue(0);
    }
    
    public @Override int getNumberOfConditions()
    {
	    return CND_LAST;
    }
    
    private void ClearWriEvent() {
    	wriEvent.Index = 0;
    	wriEvent.Cal_id = 0;
    	wriEvent.Title = "";
    	wriEvent.Location = "";
    	wriEvent.Notes = "";
    	wriEvent.StartDate = new zTimeDate();
    	wriEvent.EndDate = new zTimeDate();
    	wriEvent.Duration = 0;
    	wriEvent.AllDay = 0;
    	    	
    	wriEvent.RRules = "";
    	wriEvent.ByMinute = "";
    	wriEvent.ByHour = "";
    	wriEvent.ByDay = "";
    	wriEvent.ByMonth = "";
    	wriEvent.ByMonthDay = "";
    	wriEvent.Frequency = 0;
    	wriEvent.Interval = 0;
    	wriEvent.Count = 0;
    	    	
    	wriEvent.AccessLevel = 0;
    	wriEvent.Availability = 0;
    	wriEvent.hasAlarm = 0;
    	
    }
    public @Override boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    { 	
		ClearWriEvent();
  		
    		// For Api 23
    		enabled_perms = false;
    		
    		if(androidapi > 22) {
    			permissionsApi23 = new HashMap<String, String>();
    			permissionsApi23.put(Manifest.permission.READ_CALENDAR, "Read Calendar");
    			permissionsApi23.put(Manifest.permission.WRITE_CALENDAR, "Write Calendar");
    			MMFRuntime.inst.pushForPermissions(permissionsApi23, PERMISSIONS_CALENDAR_REQUEST);
    		}
			else
				enabled_perms = true;

    		if(enabled_perms)
    			getCalendars();
    		else
    		    action_perm = 1;

    		return false;
    }
    public @Override void destroyRunObject(boolean bFast)
    {
		myCalendars.clear();
		myEvents.clear();
    }
    
    public @Override int handleRunObject()
    {
		if(MMFRuntime.inst != null) {
			MMFRuntime.inst.askForPermissionsApi23();		
		}
        return REFLAG_ONESHOT;
    }

    public @Override void pauseRunObject()
    {
    }
    public @Override void continueRunObject()
    {
    }
 
	@Override
	public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults, List<Integer> permissionsReturned) {
		if(permissionsReturned.contains(PERMISSIONS_CALENDAR_REQUEST))
			enabled_perms = verifyResponseApi23(permissions, permissionsApi23);
		else
			enabled_perms = false;
		
		if(enabled_perms && action_perm == 1)
			getCalendars();
		if(enabled_perms && action_perm == 2)
			getEvents();
    	if(enabled_perms && action_perm == 3)
    		DoWriteEvent(wriEvent);
		action_perm = 0;
	}


    // Conditions
    // -------------------------------------------------
    public @Override boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
        {
            case CONDENTRYWRITTEN:
                return condEntryWritten(cnd);
            case CONDENTRYFAIL:
                return condEntryFail(cnd);
            case CONDCALENDARREAD:
                return condCalendarRead(cnd);
            case CONDENTRYREAD:
                return condEntryRead(cnd);
            case CONDENTRYERROR:
                return condEntryError(cnd);
        }
        return false;
    }

    // Actions
    // -------------------------------------------------
    public @Override void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACTSETCALENDAR:
                actSetCalendar(act);
                break;
            case ACTEVTTITLE:
                actEvtTitle(act);
                break;
            case ACTEVTLOCATION:
                actEvtLocation(act);
                break;
            case ACTEVTNOTES:
                actEvtNotes(act);
                break;
            case ACTEVTSTARTD:
                actEvtStartD(act);
                break;
            case ACTEVTSTARTT:
                actEvtStartT(act);
                break;
            case ACTEVTENDD:
                actEvtEndD(act);
                break;
            case ACTEVTENDT:
                actEvtEndT(act);
                break;
            case ACTEVTDURATION:
                actEvtDuration(act);
                break;
            case ACTEVTALL:
                actEvtAll(act);
                break;
            case ACTEVTTIMEZONE:
                actEvtTimeZone(act);
                break;
            case ACTEVTCFGACCESS:
                actEvtCfgAccess(act);
                break;
            case ACTEVTCFGAVAILABILITY:
                actEvtCfgAvailability(act);
                break;
            case ACTEVTFREQUENCY:
                actEvtFrequency(act);
                break;
            case ACTEVTINTERVAL:
                actEvtInterval(act);
                break;
            case ACTEVTCOUNT:
                actEvtCount(act);
                break;
            case ACTEVTBYMINUTE:
                actEvtByMinute(act);
                break;
            case ACTEVTBYHOUR:
                actEvtByHour(act);
                break;
            case ACTEVTBYDAY:
                actEvtByDay(act);
                break;
            case ACTEVTBYMONTH:
                actEvtByMonth(act);
                break;
            case ACTEVTBYMONTHDAY:
                actEvtByMonthDay(act);
                break;
            case ACTEVTMAKE:
                actEvtMake(act);
                break;
            case ACTCALREAD:
                actCalRead(act);
                break;
            case ACTEVTREAD:
                actEvtRead(act);
                break;
            case ACTEVTDELETE:
                actEvtDelete(act);
                break;
            case ACTEVTDELALL:
                actEvtDeleteAll(act);
                break;
            case ACTCREATECAL:
                actCreateCalendar(act);
                break;
        }
    }

    // Expressions
    // -------------------------------------------------
    public @Override CValue expression(int num)
    {
        switch (num)
        {
            case EXPGETERROR:
                return expGetError();
            case EXPGETCALIDX:
                return expGetCalIdx();
            case EXPGETCALNAME:
                return expGetCalName();
            case EXPGETEVTIDX:
                return expGetEvtIdx();
            case EXPGETID:
                return expGetId();
            case EXPGETTITLE:
                return expGetTitle();
            case EXPGETLOC:
                return expGetLoc();
            case EXPGETNOTES:
                return expGetNotes();
            case EXPGETSTARTD:
                return expGetStartD();
            case EXPGETSTARTT:
                return expGetStartT();
            case EXPGETENDD:
                return expGetEndD();
            case EXPGETENDT:
                return expGetEndT();
            case EXPGETDUR:
                return expGetDur();
            case EXPGETALLDAY:
                return expGetAllDay();
            case EXPGETTIMEZONE:
                return expGetTimezone();
            case EXPGETALARM:
                return expGetAlarm();
            case EXPGETRFREQUENCY:
                return expGetRFrequency();
            case EXPGETRINTERVAL:
                return expGetRInterval();
            case EXPGETRCOUNT:
                return expGetRCount();
            case EXPGETRBYMINUTE:
                return expGetRByMinute();
            case EXPGETRBYHOUR:
                return expGetRByHour();
            case EXPGETRBYDAY:
                return expGetRByDay();
            case EXPGETRBYMONTH:
                return expGetRByMonth();
            case EXPGETRBYMONTHDAY:
                return expGetRByMonthDay();
            case EXPGETSECFROMTIME:
                return expGetSecFromTime();
            case EXPGETTIMEFROMSEC:
                return expGetTimeFromSec();
            case EXPGETDEFTIMEZONE:
                return expGetDefTimeZone();
            case EXPGETTIMEZONEID:
                return expGetTimeZoneID();
            case EXPMAKEDATESTRING:
                return expMakeDateString();
            case EXPMAKEHOURSTRING:
                return expMakeHourString();
        }
        return null;
    }

    private boolean condEntryWritten(CCndExtension cnd)
    {
        return true;
    }

    private boolean condEntryFail(CCndExtension cnd)
    {
        return true;
    }

    private boolean condCalendarRead(CCndExtension cnd)
    {
        return true;
    }

    private boolean condEntryRead(CCndExtension cnd)
    {
        return true;
    }

    private boolean condEntryError(CCndExtension cnd)
    {
        //if(nError != 0)
        //	return true;
        //else
        //	return false;
        return (nError != 0);
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private void actSetCalendar(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        if(param0 > 0 && param0 < Cal_numbers+1) {
        	wriEvent.Cal_id = param0;
        }      
    }

    private void actEvtTitle(CActExtension act)
    {
        String param0 = act.getParamExpString(rh,0);
        if(param0.length() > 0) {
        	wriEvent.Title = param0;
        }
    }

    private void actEvtLocation(CActExtension act)
    {
        String param0 = act.getParamExpString(rh,0);
        if(param0.length() > 0) {
        	wriEvent.Location = param0;
        }
    }

    private void actEvtNotes(CActExtension act)
    {
        String param0 = act.getParamExpString(rh,0);
        if(param0.length() > 0) {
        	wriEvent.Notes = param0;
        }
    }

    private void actEvtStartD(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        int param1 = act.getParamExpression(rh,1);
        int param2 = act.getParamExpression(rh,2);
     	wriEvent.StartDate.Day 	 = param0; 
     	wriEvent.StartDate.Month = param1; 
     	wriEvent.StartDate.Year  = param2;
        
       	
    }

    private void actEvtStartT(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        int param1 = act.getParamExpression(rh,1);
     	wriEvent.StartDate.Hours   = param0; 
     	wriEvent.StartDate.Minutes = param1;
    }

    private void actEvtEndD(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        int param1 = act.getParamExpression(rh,1);
        int param2 = act.getParamExpression(rh,2);
     	wriEvent.EndDate.Day   = param0; 
     	wriEvent.EndDate.Month = param1; 
     	wriEvent.EndDate.Year  = param2; 
       
    }

    private void actEvtEndT(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        int param1 = act.getParamExpression(rh,1);
        
     	wriEvent.EndDate.Hours   = param0; 
     	wriEvent.EndDate.Minutes = param1;
    }

    private void actEvtDuration(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        if(param0 > 0) {
        	wriEvent.Duration = param0;
        }
        else {
        	wriEvent.Duration = 0;
        }
    }

    private void actEvtAll(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        if(param0 > -1 && param0 < 2) {
        	wriEvent.AllDay = param0;
        }
    }

    private void actEvtTimeZone(CActExtension act)
    {
        String param0 = act.getParamExpString(rh,0);
        if(param0.length() > 0) {
        	wriEvent.TimezoneStr = param0;
        }
    }

    private void actEvtCfgAccess(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        if(param0 > -1 && param0 < 4) {
        	wriEvent.AccessLevel = param0;
        }
    }

    private void actEvtCfgAvailability(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        if(param0 > -1 && param0 < 2) {
        	wriEvent.Availability = param0;
        }
    }

    private void actEvtFrequency(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        if(param0 > -1 && param0 < 5) {
        	wriEvent.Frequency = param0;
        }
    }

    private void actEvtInterval(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
       	wriEvent.Interval = param0;
    }

    private void actEvtCount(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        wriEvent.Count = param0;
    }

    private void actEvtByMinute(CActExtension act)
    {
        String param0 = act.getParamExpString(rh,0);
        if(param0.length() > 0) {
        	wriEvent.ByMinute = param0;
        }
    }

    private void actEvtByHour(CActExtension act)
    {
        String param0 = act.getParamExpString(rh,0);
        if(param0.length() > 0) {
        	wriEvent.ByHour = param0;
        }
    }

    private void actEvtByDay(CActExtension act)
    {
        String param0 = act.getParamExpString(rh,0);
        if(param0.length() > 0) {
        	wriEvent.ByDay = param0;
        }
    }

    private void actEvtByMonth(CActExtension act)
    {
        String param0 = act.getParamExpString(rh,0);
        if(param0.length() > 0) {
        	wriEvent.ByMonth = param0;
        }
    }

    private void actEvtByMonthDay(CActExtension act)
    {
        String param0 = act.getParamExpString(rh,0);
        if(param0.length() > 0) {
        	wriEvent.ByMonthDay = param0;
        }
    }

    private void actEvtMake(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        if(param0 > -1 && param0 < 2) {
        	wriEvent.hasAlarm = param0;
        }
        
    	if(wriEvent.Cal_id == 0)
    		wriEvent.Cal_id = gCal_Id;
    	
    	if(enabled_perms)
    		DoWriteEvent(wriEvent);
    	else
    	{
			MMFRuntime.inst.askForPermissionsApi23();		
			action_perm = 3;
    	}
   }

    private void actCalRead(CActExtension act)
    {
    	if(enabled_perms)
    		getCalendars();
    	else
    	{
			MMFRuntime.inst.askForPermissionsApi23();		
			action_perm = 1;
    	}
    }

    private void actEvtRead(CActExtension act)
    {
       	if(enabled_perms)
       		getEvents();
    	else
    	{
			MMFRuntime.inst.askForPermissionsApi23();		
			action_perm = 2;
    	}
    }
    
    private void actEvtDelete(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        int param1 = act.getParamExpression(rh,1);
        if(param0 > 0 && param1 > 0 && param1 < Cal_numbers+1) {
        	if(enabled_perms)
        		DeleteEvents(param0, param1);
        	else
    			MMFRuntime.inst.askForPermissionsApi23();		
        }
    	
     }

    private void actEvtDeleteAll(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
        if(enabled_perms)
        	DeleteEvents(-1, param0);
    	else
 			MMFRuntime.inst.askForPermissionsApi23();		
   }
    
    private void actCreateCalendar(CActExtension act)
    {
        String name = act.getParamExpString(rh,0);
        String display = act.getParamExpString(rh,1);
        String owner = act.getParamExpString(rh,2);
        if(enabled_perms)
        	CreateLocalCalendar(name, display, owner);
    	else
  			MMFRuntime.inst.askForPermissionsApi23();		
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    private CValue expGetError()
    {
        expRet.forceInt(nError);
        return expRet;
    }

    private CValue expGetCalIdx()
    {
        expRet.forceInt(Cal_numbers);
        return expRet;
    }

    private CValue expGetCalName()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myCalendars != null && param0 < Cal_numbers) {
        	expRet.forceString(myCalendars.get(param0).Name);
        }
        return expRet;
    }

    private CValue expGetEvtIdx()
    {
        expRet.forceInt(Events_numbers);
        return expRet;
    }

    private CValue expGetId()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(String.valueOf(myEvents.get(param0).Index));
        }
        return expRet;
    }
   
    private CValue expGetTitle()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(myEvents.get(param0).Title);
        }
        return expRet;
    }

    private CValue expGetLoc()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(myEvents.get(param0).Location);
        }
        return expRet;
    }

    private CValue expGetNotes()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(myEvents.get(param0).Notes);
        }
        return expRet;
    }

    private CValue expGetStartD()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(myEvents.get(param0).StartDate);
        }
        return expRet;
    }

    private CValue expGetStartT()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(myEvents.get(param0).StartTime);
        }
        return expRet;
    }

    private CValue expGetEndD()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(myEvents.get(param0).EndDate);
        }
        return expRet;
    }

    private CValue expGetEndT()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(myEvents.get(param0).EndTime);
        }
        return expRet;
    }

    private CValue expGetDur()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(myEvents.get(param0).Duration);
         }
        return expRet;
    }

    private CValue expGetAllDay()
    {
        int param0 = ho.getExpParam().getInt()-1;
        expRet.forceInt(0);
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceInt(myEvents.get(param0).AllDay);
        }
        return expRet;
    }
    
    private CValue expGetTimezone()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(myEvents.get(param0).Timezone);
        }
        return expRet;
    }

    private CValue expGetAlarm()
    {
        int param0 = ho.getExpParam().getInt()-1;
        expRet.forceInt(0);
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceInt(myEvents.get(param0).hasAlarm);
        }
        return expRet;
    }

    private CValue expGetRFrequency()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(GetRRules(myEvents.get(param0).RRules, "FREQ", ""));
        }
        return expRet;
    }

    private CValue expGetRInterval()
    {
        int param0 = ho.getExpParam().getInt()-1;
        expRet.forceInt(0);
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
            expRet.forceInt(Integer.parseInt(GetRRules(myEvents.get(param0).RRules, "INTERVAL", "0")));
        }
        return expRet;
    }

    private CValue expGetRCount()
    {
        int param0 = ho.getExpParam().getInt()-1;
        expRet.forceInt(0);
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
            expRet.forceInt(Integer.parseInt(GetRRules(myEvents.get(param0).RRules, "COUNT", "0")));
        }
        return expRet;
    }

    private CValue expGetRByMinute()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(GetRRules(myEvents.get(param0).RRules, "BYMINUTE", ""));
        }
        return expRet;
    }

    private CValue expGetRByHour()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(GetRRules(myEvents.get(param0).RRules, "BYHOUR", ""));
        }
        return expRet;
    }

    private CValue expGetRByDay()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(GetRRules(myEvents.get(param0).RRules, "BYDAY", ""));
        }
        return expRet;
    }

    private CValue expGetRByMonth()
    {
        int param0 = ho.getExpParam().getInt()-1;
    	expRet.forceString("");
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(GetRRules(myEvents.get(param0).RRules, "BYMONTH", ""));
        }
        return expRet;
    }

    private CValue expGetRByMonthDay()
    {
    	expRet.forceString("");
        int param0 = ho.getExpParam().getInt()-1;
        if(myEvents != null && param0 > -1 && param0 < Events_numbers) {
        	expRet.forceString(GetRRules(myEvents.get(param0).RRules, "BYMONTHDAY", ""));
        }
        return expRet;
    }

    private CValue expGetSecFromTime()
    {
        String param0 = ho.getExpParam().getString();
        long nResult = 0;
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss", Locale.getDefault());
        Date nDate = new Date();
        try {
        	nDate = formatter.parse(param0);
        	nResult = nDate.getTime()/1000;
        }catch(ParseException e)  {
        	nError = 1;
        }
        expRet.forceInt((int)nResult);
        return expRet;
    }

    private CValue expGetTimeFromSec()
    {
        int param0 = ho.getExpParam().getInt();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.getDefault());
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(param0*1000);
        String szDate = formatter.format(calendar.getTime());
        expRet.forceString(szDate);
        return expRet;
    }
    
    private CValue expGetDefTimeZone()
    {
    	Calendar cal = Calendar.getInstance();
    	TimeZone tz = cal.getTimeZone();
    	expRet.forceString(tz.getID());
        return expRet;
    }

    private CValue expGetTimeZoneID()
    {
        String param0 = ho.getExpParam().getString();
    	TimeZone tz = TimeZone.getDefault();
    	tz = TimeZone.getTimeZone(param0);  	
    	expRet.forceString(tz.getID());
        return expRet;
    }
    
    private CValue expMakeDateString()
    {
        int param0 = ho.getExpParam().getInt();
        int param1 = ho.getExpParam().getInt();
        int param2 = ho.getExpParam().getInt();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Calendar calendar = new GregorianCalendar();
        //calendar.set(param2, param0, param1);
        
        calendar.set(Calendar.DAY_OF_MONTH, param1);
        calendar.set(Calendar.MONTH, param0-1);
        calendar.set(Calendar.YEAR, param2);
        
        String mdy = formatter.format(calendar.getTime());
        expRet.forceString(mdy);
        return expRet;
    }

    private CValue expMakeHourString()
    {
        int param0 = ho.getExpParam().getInt();
        int param1 = ho.getExpParam().getInt();
        int param2 = ho.getExpParam().getInt();
        
        String hms = String.format("%02d:%02d:%02d", param0, param1, param2);
        expRet.forceString(hms);
        return expRet;
    }   
}
