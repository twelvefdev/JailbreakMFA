/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 *
 * Permission is hereby granted to any person obtaining a legal copy
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for
 * debugging, optimizing, or customizing applications created with
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// 8 directions box 2d movement
//
//----------------------------------------------------------------------------------
package Movements;

import Actions.CAct;
import Animations.CAnim;
import Banks.CImage;
import Expressions.CExp;
import Extensions.CRunBox2DBase;
import Extensions.CRunBox2DBasePosAndAngle;
import Objects.CExtension;
import Objects.CObject;
import RunLoop.CRun;
import RunLoop.CRunMBase;
import Services.CBinaryFile;
import android.util.Log;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Fixture;

public class CRunMvtbox2dracecar extends CRunMBase
{
	public static final int B2FLAG_ROTATE=0x0001;
	public static final int RCFLAG_REVERSE = 0x0002;
	public static final int RCFLAG_FINECOLLISIONS = 0x0008;
	public static final float ACCMULT=1.0f;
	public static final float DECMULT=1.0f;
	public static final float ROTMULT=15.0f/0.2830f;	
	public static final float SPEEDMULT=0.20f;
	public static final float FORCEMULT=3.534f;

	public CRunBox2DBase m_base;
	public float m_friction = 0;
	public float m_gravity = 0;
	public float m_density = 0;
	public float m_restitution = 0;
	public int m_shape = 0;
	public int m_flags = 0;
	public float m_previousX = 0;
	public float m_previousY = 0;
	public Fixture m_fixture = null;
	public double m_previousAngle = 0;
	public float m_speed = 0;
	public float m_acceleration = 0;
	public float m_deceleration = 0;
	public int m_player = 0;
	public int m_dirs = 0;
	public float m_currentSpeed = 0;
	public float m_angleSpeed = 0;
	public double m_angleCalculation = 0;
	public CRunBox2DBasePosAndAngle m_posAndAngle = new CRunBox2DBasePosAndAngle();
	public int m_imgWidth = 0;
	public int m_imgHeight = 0;
	public float m_scaleX = 1.0f;
	public float m_scaleY = 1.0f;
	public short m_jointType = 0;
	public short m_jointAnchor = 0;
	public float m_rJointLLimit = 0;
	public float m_rJointULimit = 0;
	public float m_dJointFrequency = 0;
	public float m_dJointDamping = 0;
	public float m_pJointLLimit = 0;
	public float m_pJointULimit = 0;
	public String m_jointName = null;
	public String m_jointObject = null;
	public boolean m_started = false;

	public int AnglePointer;
	
    // Build 283.3 increasing performance
    private CRunBox2DBase GetBase()
    {
        int nObjects = this.rh.rhNObjects;
        CObject[] localObjectList=this.rh.rhObjectList;
        for (CObject pObject : localObjectList)
        {
            if (pObject != null) {
            	--nObjects;
	            if(pObject.hoType>=32)
	            {
	                if (pObject.hoCommon.ocIdentifier == CRun.BASEIDENTIFIER)
	                {
	                    CRunBox2DBase pBase = (CRunBox2DBase)((CExtension)pObject).ext;
	                    if (pBase.identifier == this.m_identifier)
	                    {
	                        return pBase;
	                    }
	                }
	            }
            }
            if(nObjects==0)
            	break;
        }
        return null;
    }

	@Override
	public void initialize(CBinaryFile file)
	{
		file.skipBytes(1);
		this.m_angleCalculation=this.dirAtStart(file.readInt())*180.0f/16.0f;
		this.m_friction=file.readInt()/100.0f;
		this.m_gravity=0.0000f;
		file.skipBytes(4);
		this.m_density=file.readInt()/100.0f;
		this.m_restitution=file.readInt()/100.0f;
		this.m_flags=file.readInt();
		this.m_shape=file.readShort();
		int speed = file.readInt();
		this.m_speed=speed * SPEEDMULT;
		this.m_acceleration=file.readInt()/(100.0f*ACCMULT);
		this.m_deceleration=file.readInt()/(100.0f*DECMULT);
		this.m_angleSpeed=file.readInt()/100.0f*ROTMULT;
		this.m_identifier=file.readInt();
		this.m_player = file.readInt();
		this.m_jointType = file.readShort();
		this.m_jointAnchor = file.readShort();
		this.m_jointName = file.readString(CRunBox2DBase.MAX_JOINTNAME);
		this.m_jointObject = file.readString(CRunBox2DBase.MAX_JOINTOBJECT);
		this.m_rJointLLimit = (float)(file.readInt() * Math.PI / 180.0);
		this.m_rJointULimit = (float)(file.readInt() * Math.PI / 180.0);
		this.m_dJointFrequency = file.readInt();
		this.m_dJointDamping = file.readInt() / 100.0f;
		this.m_pJointLLimit = file.readInt();
		this.m_pJointULimit = file.readInt();

		this.m_started = false;
		this.m_currentSpeed=0;
		this.m_currentAngle=(float)((Math.floor(this.m_angleCalculation/11.25))*11.25);
		this.ho.roc.rcMinSpeed=0;
		this.ho.roc.rcMinSpeed=speed;
		this.m_addVX=0;
		this.m_addVY=0;
		this.m_addVFlag=false;
		this.m_previousAngle=-1;

		
		this.m_base=this.GetBase();
		this.m_body=null;
		this.InitBase(this.ho, CRunMBase.MTYPE_OBJECT);
	}

	@Override
	public void kill()
	{
		CRunBox2DBase pBase=this.GetBase();
		if (pBase!=null)
		{
			pBase.rDestroyBody(this.m_body);
		}
	}

	@Override
	public Boolean CreateBody()
	{
		if (this.m_body!=null)
			return true;

		if (this.m_base==null)
		{
			this.m_base=this.GetBase();
			if (this.m_base == null)
				return false;
		}

		this.m_body = this.m_base.rCreateBody(BodyDef.BodyType.DynamicBody, this.ho.hoX, this.ho.hoY, this.m_angle, this.m_gravity, this, 0, 0);
		if (this.ho.roa == null)
		{
			this.m_shape = 0;
			this.m_imgWidth = this.ho.hoImgWidth;
			this.m_imgHeight = this.ho.hoImgHeight;
		}
		else
		{
			this.m_image = this.ho.roc.rcImage;
			CImage img = this.rh.rhApp.imageBank.getImageFromHandle(this.m_image);
			this.m_imgWidth = img.getWidth();
			this.m_imgHeight = img.getHeight();
		}
		this.CreateFixture();

		Vector2 position=this.m_body.getPosition();
		this.m_previousX=position.x;
		this.m_previousY=position.y;

		return true;
	}

	private void CreateFixture()
	{
		if (this.m_fixture != null)
		{
			this.m_body.destroyFixture(this.m_fixture);
		}
		this.m_scaleX = this.ho.roc.rcScaleX;
		this.m_scaleY = this.ho.roc.rcScaleY;
		switch (this.m_shape)
		{
		case 0:
			this.m_fixture = this.m_base.rBodyCreateBoxFixture(this.m_body, this, this.ho.hoX, this.ho.hoY, (int)(this.m_imgWidth * this.m_scaleX), (int)(this.m_imgHeight * this.m_scaleY), this.m_density, this.m_friction, this.m_restitution);
			break;
		case 1:
			this.m_fixture = this.m_base.rBodyCreateCircleFixture(this.m_body, this, this.ho.hoX, this.ho.hoY, (int)((this.ho.hoImgWidth + this.ho.hoImgHeight) / 4 * (this.m_scaleX + this.m_scaleY) / 2), this.m_density, this.m_friction, this.m_restitution);
			break;
		case 2:
			this.m_fixture = this.m_base.rBodyCreateShapeFixture(this.m_body, this, this.ho.hoX, this.ho.hoY, this.ho.roc.rcImage, this.m_density, this.m_friction, this.m_restitution, this.m_scaleX, this.m_scaleY);
			break;
		}
	}

	@Override
	public void CreateJoint()
	{
		switch (this.m_jointType)
		{
		case CRunBox2DBase.JTYPE_REVOLUTE:
			this.m_base.rJointCreate(this, this.m_jointType, this.m_jointAnchor, this.m_jointName, this.m_jointObject, this.m_rJointLLimit, this.m_rJointULimit);
			break;
		case CRunBox2DBase.JTYPE_DISTANCE:
			this.m_base.rJointCreate(this, this.m_jointType, this.m_jointAnchor, this.m_jointName, this.m_jointObject, this.m_dJointFrequency, this.m_dJointDamping);
			break;
		case CRunBox2DBase.JTYPE_PRISMATIC:
			this.m_base.rJointCreate(this, this.m_jointType, this.m_jointAnchor, this.m_jointName, this.m_jointObject, this.m_pJointLLimit, this.m_pJointULimit);
			break;
		default:
			break;
		}
	}

	@Override
	public boolean move()
	{
		if (!this.CreateBody() || this.m_base.isPaused())
			return false;

		// Scale changed?
				if (this.ho.roc.rcScaleX != this.m_scaleX || this.ho.roc.rcScaleY != this.m_scaleY)
					this.CreateFixture();

		// Get the joystick
		byte j=this.rh.rhPlayer[this.m_player];

		Vector2 v =this.m_body.getLinearVelocity();
		this.m_currentSpeed = (float)Math.sqrt(v.x * v.x + v.y * v.y);

		// Rotation of the ship
		int anim=CAnim.ANIMID_STOP;
		if ((j&1)!=0)
		{
			AnglePointer = 0;
			if (this.m_currentSpeed<this.m_speed)
			{
				if (this.m_acceleration==1.0)
					this.m_currentSpeed=this.m_speed;
				else
					this.m_currentSpeed=Math.min(this.m_speed, this.m_currentSpeed+this.m_acceleration);
			}
			anim=CAnim.ANIMID_WALK;
		}
		if ((j&2)!=0)
		{
			float baseSpeed=0;
			AnglePointer = 180;
			if ((this.m_flags&RCFLAG_REVERSE)!=0)
				baseSpeed=-this.m_speed;
			if (this.m_currentSpeed>baseSpeed)
			{
				if (this.m_deceleration==1.0)
					this.m_currentSpeed=baseSpeed;
				else
					this.m_currentSpeed=Math.max(baseSpeed, this.m_currentSpeed+this.m_deceleration);
			}
		}
		if ((j&4)!=0)
		{
			this.m_angleCalculation+=this.m_angleSpeed;
			//if (this.m_angleCalculation>360.0)
			//    this.m_angleCalculation-=360.0;
			this.m_angleCalculation = this.m_angleCalculation % 360.0f;
		}
		if ((j&8)!=0)
		{
			this.m_angleCalculation-=this.m_angleSpeed;
			//if (this.m_angleCalculation<0.0)
			//    this.m_angleCalculation+=360.0;
			this.m_angleCalculation = this.m_angleCalculation % 360.0f;
		}

		if(j == 0)
		{
			if(this.m_currentSpeed > 0.001)
				this.m_currentSpeed=this.m_currentSpeed-this.m_deceleration;
			if(this.m_currentSpeed < 0)
				this.m_currentSpeed=0;
		}

		this.m_currentAngle=this.m_angleCalculation;
		
		this.m_base.rBodySetLinearVelocity(this.m_body, this.m_currentSpeed, (float)this.m_currentAngle+AnglePointer);
		
		m_base.rBodyAddVelocity(m_body, m_addVX, m_addVY);
		ResetAddVelocity();
		m_base.rBodySetAngle(m_body, (float)this.m_currentAngle);

		this.m_base.rGetBodyPosition(this.m_body, this.m_posAndAngle);
		if (this.m_posAndAngle.x!=this.ho.hoX || this.m_posAndAngle.y!=this.ho.hoY)
		{
			this.ho.hoX=this.m_posAndAngle.x;
			this.ho.hoY=this.m_posAndAngle.y;
			this.m_started = true;
			this.ho.roc.rcChanged=true;
		}
		SetCurrentAngle();

		Vector2 position=this.m_body.getPosition();
		float deltaX=(position.x-this.m_previousX)*this.m_base.factor;
		float deltaY=(position.y-this.m_previousY)*this.m_base.factor;
		this.m_previousX=position.x;
		this.m_previousY=position.y;
		double length=Math.sqrt(deltaX*deltaX+deltaY*deltaY);
		this.ho.roc.rcSpeed=(int)Math.floor((50.0*length/7.0)*this.rh.rh4MvtTimerCoef);
		this.ho.roc.rcSpeed=Math.min(this.ho.roc.rcSpeed, 250);

		this.animations(anim);
		if ((m_flags & RCFLAG_FINECOLLISIONS) != 0)
			this.collisions();

		// The object has been moved
		return this.ho.roc.rcChanged;
	}
	public void SetCurrentAngle()
	{
		if (this.m_currentAngle!=this.m_previousAngle)
		{
			this.m_previousAngle=this.m_currentAngle;
			this.ho.roc.rcChanged=true;
			if ((this.m_flags&B2FLAG_ROTATE)!=0)
			{
				this.ho.roc.rcAngle=(float)this.m_currentAngle;
				this.ho.roc.rcDir=0;
			}
			else
			{
				this.ho.roc.rcDir=AngleToDir(this.m_currentAngle);
			}
		}
	}
	@Override
	public void SetFriction(int friction)
	{
		this.m_friction=friction/100.0f;
		this.m_fixture.setFriction(this.m_friction);
	}
	@Override
	public void SetGravity(int gravity)
	{
		this.m_gravity=gravity/100.0f;
		this.m_body.setGravityScale(this.m_gravity);
	}
	@Override
	public void SetDensity(int density)
	{
		this.m_density=density/100.0f;
		this.m_fixture.setDensity(this.m_density);
		this.m_base.rBodyResetMassData(this.m_body);
	}
	@Override
	public void SetRestitution(int restitution)
	{
		this.m_restitution=restitution/100.0f;
		this.m_fixture.setRestitution(this.m_restitution);
	}

	@Override
	public void setAngle(float angle)
	{
		this.m_angleCalculation = angle;
		if (!m_started)
		{
			this.m_currentAngle = angle;
			SetCurrentAngle();
		}
	}

	@Override
	public float getAngle()
	{
		if ((this.m_flags&CRunMvtbox2dracecar.B2FLAG_ROTATE)!=0)
		{
			double angle = this.m_currentAngle;
			while (angle >= 360.0)
				angle -= 360.0;
			while (angle < 0)
				angle += 360;
			return (float)angle;
		}
		return CRunMBase.ANGLE_MAGIC;
	}

	@Override
	public void setPosition(int x, int y)
	{
		if (x!=this.ho.hoX || y!=this.ho.hoY)
		{
			if (!m_started)
			{
				this.ho.hoX = x;
				this.ho.hoY = y;
			}
			this.m_base.rBodySetPosition(this.m_body, x, y);
		}
	}
	@Override
	public void setXPosition(int x)
	{
		if (x!=this.ho.hoX)
		{
			if (!m_started)
				this.ho.hoX = x;
			this.m_base.rBodySetPosition(this.m_body, x, CRunBox2DBase.POSDEFAULT);
		}
	}
	@Override
	public void setYPosition(int y)
	{
		if (y!=this.ho.hoY)
		{
			if (!m_started)
				this.ho.hoY = y;
			this.m_base.rBodySetPosition(this.m_body, CRunBox2DBase.POSDEFAULT, y);
		}
	}
	@Override
	public void stop(boolean bCurrent)
	{
		this.SetStopFlag(true);
		if (this.m_eventCount!=this.rh.rh4EventCount)
		{
			this.m_base.rBodySetLinearVelocityAdd(this.m_body, 0, 0, 0, 0);
		}
	}
	@Override
	public void setSpeed(int speed)
	{
		float speedf = speed * SPEEDMULT;
		//speedf = Math.min(m_speed, speedf);
		//speedf = Math.max(m_speed, 0);
		m_currentSpeed = speedf;
	}

	@Override
	public void setMaxSpeed(int speed){}

	@Override
	public void setDir(int dir)
	{
		this.m_angleCalculation=(float)(dir*11.25);
		this.m_currentAngle=(float)((Math.floor(this.m_angleCalculation/11.25))*11.25);
		if (!m_started)
			SetCurrentAngle();
	}

	@Override
	public int getDir()
	{
		if ((this.m_flags&CRunMvtbox2dracecar.B2FLAG_ROTATE)!=0)
			return AngleToDir(this.m_currentAngle);
		else
			return this.ho.roc.rcDir;
	}

	@Override
	public void setGravity(int gravity)
	{
		this.m_gravity=gravity/100.0f;
		this.m_body.setGravityScale(this.m_gravity);
	}

	@Override
	public int getSpeed()
	{
		return this.ho.roc.rcSpeed;
	}

	@Override
	public int getGravity()
	{
		return (int)(this.m_gravity*100.0);
	}

	@Override
	public void setAcc(int acc)
	{
		this.m_acceleration=acc/(100.0f*ACCMULT);
	}

	@Override
	public void setDec(int dec)
	{
		this.m_deceleration=dec/(100.0f*DECMULT);
		this.m_body.setLinearDamping(this.m_deceleration);
	}

	@Override
	public void setRotSpeed(int speed)
	{
		this.m_angleSpeed=(float)(speed/100.0*ROTMULT);
	}

	@Override
	public int getAcceleration()
	{
		return (int)(this.m_acceleration*(100.0*ACCMULT));
	}

	@Override
	public int getDeceleration()
	{
		return (int)(this.m_deceleration*(100.0*DECMULT));
	}

	@Override
	public double actionEntry(int action)
	{
		if (this.m_base == null)
			return 0;

		float force;
		float angle;
		//float torque;
		Vector2 v;
		switch (action)
		{
		case CAct.NACT_EXTSETGRAVITYSCALE:
			this.SetGravity((int)this.getParam1());
			break;
		case CAct.NACT_EXTSETFRICTION:
			this.SetFriction((int)this.getParam1());
			break;
		case CAct.NACT_EXTSETELASTICITY:
			this.SetRestitution((int)this.getParam1());
			break;
		case CAct.NACT_EXTSETDENSITY:
			this.SetDensity((int)this.getParam1());
			break;
		case CAct.NACT_EXTAPPLYIMPULSE:
			force=(float)this.getParam1()/100.0f*CRunBox2DBase.APPLYIMPULSE_MULT;
			angle=(float)this.getParam2();
			this.m_base.rBodyApplyMMFImpulse(this.m_body, force, angle);
			break;
		case CAct.NACT_EXTAPPLYFORCE:
			force=(float)this.getParam1()/100.0f*CRunBox2DBase.APPLYFORCE_MULT*FORCEMULT;
			angle=(float)this.getParam2();
			this.m_base.rBodyApplyForce(this.m_body, force, angle);
			break;
		case CAct.NACT_EXTSETLINEARVELOCITY:
			force=(float)this.getParam1()/100.0f*CRunBox2DBase.SETVELOCITY_MULT;
			angle=(float)this.getParam2();
			this.m_base.rBodySetLinearVelocity(this.m_body, force, angle);
			break;
		case CAct.NACT_EXTSTOPFORCE:
			this.m_base.rBodyStopForce(this.m_body);
			break;
		case CExp.NEXP_EXTGETFRICTION:
			return this.m_friction * 100;
		case CExp.NEXP_EXTGETRESTITUTION:
			return this.m_restitution * 100;
		case CExp.NEXP_EXTGETDENSITY:
			return this.m_density * 100;
		case CExp.NEXP_EXTGETVELOCITY:
			v = this.m_body.getLinearVelocity();
			double velocity =  Math.sqrt(v.x * v.x + v.y * v.y)*100.0/CRunBox2DBase.SETVELOCITY_MULT;
			if (velocity < 0.001)
				return 0;
			return velocity;
		case CExp.NEXP_EXTGETANGLE:
			v = m_body.getLinearVelocity();
			if (Math.abs(v.x) < 0.001 && Math.abs(v.y) < 0.001)
				return -1;
			angle=(float)(Math.atan2(v.y, v.x)*180.0/Math.PI);
			if (angle<0)
				angle=360+angle;
			return angle;
		case CExp.NEXP_EXTGETMASS:
			return this.m_body.getMass();
		case CExp.NEXP_EXTGETANGULARVELOCITY:
			return (this.m_body.getAngularVelocity() * 100.0) / CRunBox2DBase.SETANGULARVELOCITY_MULT;
		default:
			break;
		}
		return 0;
	}
}
