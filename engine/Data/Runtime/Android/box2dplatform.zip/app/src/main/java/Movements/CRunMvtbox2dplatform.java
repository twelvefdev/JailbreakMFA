/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 *
 * Permission is hereby granted to any person obtaining a legal copy
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for
 * debugging, optimizing, or customizing applications created with
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// 8 directions box 2d movement
//
//----------------------------------------------------------------------------------
package Movements;

import Actions.CAct;
import Expressions.CExp;
import Extensions.CRunBox2DBase;
import Extensions.CRunBox2DBaseImageDimension;
import Extensions.CRunBox2DBasePosAndAngle;
import Objects.CExtension;
import Objects.CObject;
import RunLoop.CRun;
import RunLoop.CRunMBase;
import Services.*;
import Animations.*;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Fixture;

public class CRunMvtbox2dplatform extends CRunMBase
{
    public static final int MPFLAG_CONTROLJUMP=0x0001;
    public static final int MPFLAG_ALLOWCROUCH=0x0002;
    public static final int MPFLAG_JUMPCROUCHED=0x0004;
    public static final int MPFLAG_ACCMOVEMENTS=0x0008;
    public static final int MPFLAG_FINECOLLISIONS=0x0010;
    public static final int MPFLAG_JUMPSTOPXIFNOINPUT=0x0020;
    public static final float ACCMULT=1.0f;
    public static final float DECMULT=1.0f;
    private static final int GDIR_BOTTOM = 0;
    private static final int GDIR_TOP = 1;
    private static final int GDIR_LEFT = 2;
    private static final int GDIR_RIGHT = 3;

    public CRunBox2DBase m_base;
    public float m_friction = 0;
    public float m_gravity = 0;
    public float m_density = 0;
    public float m_restitution = 0;
    public int m_flags = 0;
    public float m_previousX = 0;
    public float m_previousY = 0;
    public Fixture m_fixture = null;
    public double m_previousAngle = 0;
    public float m_speed = 0;
    public float m_acceleration = 0;
    public float m_deceleration = 0;
    public int m_player = 0;
    public float m_currentSpeed = 0;
    public float m_strength = 0;
    public float m_strength2 = 0;
    public int m_jumps = 0;
    public short m_control = 0;
    public int m_offsetY = 0;
    public boolean m_previousJump = false;
    public int m_jump = 0;
    public int m_jumpCounter = 0;
    public float m_crouchSpeed = 0;
    public float m_deltaX = 0;
    public float m_deltaY = 0;
    public float m_climbingSpeed = 0;
    public int m_offsetX = 0;
    public int m_angle = 0;
    public float m_scaleX = 1.0f;
    public float m_scaleY = 1.0f;
    public int m_imgWidth = 0;
    public int m_imgHeight = 0;
    public CRunBox2DBasePosAndAngle m_posAndAngle = new CRunBox2DBasePosAndAngle();
    public float m_maskWidth;
    public CRunMBase m_platformUnder;
    public CRunMBase m_previousPlatformUnder;
    public int m_platformPositionX;
    public int m_platformPositionY;
    public int m_loopCollision = -10;
    public boolean m_previousLadder = false;
    public int m_previousLadderDir = 0;
    public int m_previousLadderEnd = 0;
    public boolean m_onLadder = false;
    public boolean m_noStop = false;
    public int m_falling = 0;
    
    public float zero_factor=0.1f;

    // Build 283.3 increasing performance
    private CRunBox2DBase GetBase()
    {
        int nObjects = this.rh.rhNObjects;
        CObject[] localObjectList=this.rh.rhObjectList;
        for (CObject pObject : localObjectList)
        {
            if (pObject != null) {
            	--nObjects;
	            if(pObject.hoType>=32)
	            {
	                if (pObject.hoCommon.ocIdentifier == CRun.BASEIDENTIFIER)
	                {
	                    CRunBox2DBase pBase = (CRunBox2DBase)((CExtension)pObject).ext;
	                    if (pBase.identifier == this.m_identifier)
	                    {
	                        return pBase;
	                    }
	                }
	            }
            }
            if(nObjects==0)
            	break;
        }
        return null;
    }

    @Override
    public void initialize(CBinaryFile file)
    {
        // Store pointer to edit data
        file.skipBytes(1);
        this.m_angle=file.readInt();
        this.m_strength2=(float)(file.readInt())/100.0f*25.0f;
        this.m_gravity=(float)(file.readInt())/100.0f;
        this.m_density=(float)(file.readInt())/100.0f;
        this.m_restitution=(float)(file.readInt())/100.0f;
        this.m_flags=file.readInt();
        int speed = file.readInt();
        this.m_speed=(float)(speed)/100.0f*10.0f;
        this.m_acceleration=(float)(file.readInt())/(100.0f*ACCMULT);
        this.m_deceleration=(float)(file.readInt())/(100.0f*DECMULT);
        this.m_strength=(float)(file.readInt())/100.0f*25.0f;
        this.m_jumps=file.readInt();
        this.m_control=file.readShort();
        this.m_crouchSpeed = (float)(file.readInt()) / 100.0f * 10.0f;
        this.m_friction=0;
        this.m_player = file.readInt();
        this.m_identifier=file.readInt();
        this.m_climbingSpeed = (float)(file.readInt()) / 100.0f * 10.0f;
        this.m_maskWidth = (float)(file.readInt()) / 100.0f;

        this.m_platformUnder = null;
        this.m_currentSpeed=0;
        this.m_previousJump=false;
        this.m_jump=0;
        this.ho.roc.rcMinSpeed=0;
        this.ho.roc.rcMaxSpeed=speed;
        this.m_previousAngle=-1;

        this.m_base=this.GetBase();
        this.m_body=null;
        this.InitBase(this.ho, CRunMBase.MTYPE_OBJECT);
        this.m_platform = true;
        m_previousLadder = false;
        m_previousLadderDir = 0;
        m_previousLadderEnd = 0;
        m_onLadder = false;
        m_noStop = false;
        m_falling = 0;
        zero_factor = 0.01f;
    }

    @Override
    public void kill()
    {
        CRunBox2DBase pBase=this.GetBase();
        if (pBase!=null)
        {
            pBase.rDestroyBody(this.m_body);
        }
    }

    @Override
    public Boolean CreateBody()
    {
        if (this.m_body!=null)
            return true;
        if (this.ho.roa == null)
            return false;

        if (this.m_base==null)
        {
            this.m_base=this.GetBase();
            if (this.m_base==null)
                return false;
        }

        this.ho.roc.rcDir=((this.m_angle&31)/16)*16;
		this.m_currentAngle = 0.0;
		if (this.ho.roc.rcDir == 16)
			this.m_currentAngle = 180.0;
        this.ho.roc.rcSpeed=0;
        this.animations(CAnim.ANIMID_STOP);

        this.m_body = this.m_base.rCreateBody(BodyDef.BodyType.DynamicBody, this.ho.hoX, this.ho.hoY, 0, this.m_gravity, this, CRunBox2DBase.CBFLAG_FIXEDROTATION, 0);
        this.CreateFixture();

        Vector2 position = this.m_body.getPosition();
        this.m_previousX=position.x;
        this.m_previousY=position.y;

        return true;
    }

    private void CreateFixture()
    {
        if (this.m_fixture != null)
        {
            this.m_body.destroyFixture(this.m_fixture);
        }
        this.m_scaleX = this.ho.roc.rcScaleX;
        this.m_scaleY = this.ho.roc.rcScaleY;

        CRunBox2DBaseImageDimension o = new CRunBox2DBaseImageDimension();
        this.m_fixture = this.m_base.rBodyCreatePlatformFixture(this.m_body, this, this.ho.roc.rcImage, 0, this.m_density, this.m_friction, this.m_restitution, o, this.m_scaleX, this.m_scaleY, this.m_maskWidth);

        this.m_offsetX = 0;
        this.m_offsetY = 0;
    }

    @Override
    public boolean move()
    {
        if (!this.CreateBody() || this.m_base.isPaused())
            return false;

        // Scale changed?
        if (this.ho.roc.rcScaleX != this.m_scaleX || this.ho.roc.rcScaleY != this.m_scaleY)
            this.CreateFixture();

        // Get the joystick
        byte joyDir=this.rh.rhPlayer[this.m_player];
        int anim=CAnim.ANIMID_STOP;
        boolean flag=false;
        Vector2 velocity=this.m_body.getLinearVelocity();

        // Previous position
        Vector2 position=m_body.getPosition();
        m_deltaX=(position.x-m_previousX)*m_base.factor;
        m_deltaY=(position.y-m_previousY)*m_base.factor;
        m_previousX=position.x;
        m_previousY=position.y;
        
        double length = Math.sqrt(m_deltaX*m_deltaX+m_deltaY*m_deltaY);
    	ho.roc.rcSpeed=(int)((50.0f*length/7.0f)*ho.hoAdRunHeader.rh4MvtTimerCoef);
    	ho.roc.rcSpeed=Math.min(ho.roc.rcSpeed, 250);	

        this.m_base.rGetBodyPosition(this.m_body, this.m_posAndAngle);
        if (this.m_posAndAngle.x + m_offsetX!=ho.hoX || this.m_posAndAngle.y + m_offsetY != ho.hoY)
        {
            ho.hoX = this.m_posAndAngle.x + m_offsetX;
            ho.hoY = this.m_posAndAngle.y + m_offsetY;
            ho.roc.rcChanged=true;
        }
        ho.roc.rcDir=AngleToDir(m_currentAngle);

        if (m_currentAngle!=m_previousAngle)
        {
            m_previousAngle=m_currentAngle;
            ho.roc.rcChanged=true;
        }
        boolean bCrouching=false;
        int yLadder = 0;
        CRect rc = rh.y_GetLadderAt(-1, ho.hoX-rh.rhWindowX, ho.hoY-rh.rhWindowY);
        boolean bLadder=(rc != null ? true : false);
        if (bLadder)
            yLadder = rc.top;

        float ySpeed=0;
        //float xSpeed=0;
        float speed=m_speed;
        int ladderDir = 0;

        int ladderEnd = 0;

        if (m_jump == 0)
            m_jumpCounter = m_jumps;

        if ((joyDir&2)!=0 && m_jump==0)
        {
            if (!bLadder)
            {
                if ((m_flags&MPFLAG_ALLOWCROUCH)!=0)
                {
                    speed=m_crouchSpeed;
                    bCrouching=true;
                }
            }
            else
            {
                if (rh.y_GetLadderAt(-1, ho.hoX-rh.rhWindowX, ho.hoY - rh.rhWindowY + 2) != null)
                {
                    ySpeed=-m_climbingSpeed;
                    ladderDir = 24;
                    m_onLadder = true;
                }
            }
        }
        if ((joyDir&1)!=0 && m_jump==0)
        {
            if (bLadder)
            {
                if (rh.y_GetLadderAt(-1, ho.hoX-rh.rhWindowX, ho.hoY-rh.rhWindowY - 2) != null)
                {
                    ySpeed=m_climbingSpeed;
                    ladderDir = 8;
                    m_onLadder = true;
                }
            }
            else
            {
                if (Math.abs(velocity.x) < zero_factor && m_previousLadder)
                {
                    m_base.rBodySetPosition(m_body, CRunBox2DBase.POSDEFAULT, m_previousLadderEnd);
                    velocity.y = 0;
                }
            }
        }
        if (bLadder)
        {
            ladderEnd = yLadder + rh.rhWindowY;
            if (m_jump==0)
            {
                m_body.setGravityScale(0);
                velocity.y=ySpeed;
            }
            else
            {
                if (m_deltaY>0)
                    m_body.setGravityScale(m_gravity);
                else
                {
                    velocity.y=0;
                    m_body.setGravityScale(0);
                    m_jump=0;
                }
            }
        }
        else
        {
            m_body.setGravityScale(m_gravity);
            m_onLadder = false;
        }

        flag=false;
        if ((joyDir&(4|8))!=0)			// Gauche
        {
            m_onLadder = false;
            if (this.m_jump == 0 || (this.m_jump > 0 && (this.m_flags & CRunMvtbox2dplatform.MPFLAG_CONTROLJUMP) != 0))
            {
                if ((this.m_flags & CRunMvtbox2dplatform.MPFLAG_ACCMOVEMENTS) == 0)
                {
                    if (this.m_currentSpeed < speed)
                    {
                        this.m_currentSpeed += this.m_acceleration;
                    }
                    if (this.m_currentSpeed > speed)
                    {
                        this.m_currentSpeed -= this.m_deceleration;
                    }
                    if ((joyDir & 4)!=0)
                    {
                        this.m_currentAngle = 180.0f;
                        velocity.x = -this.m_currentSpeed;
                        flag = true;
                    }
                    if ((joyDir & 8)!=0)
                    {
                        this.m_currentAngle = 0.0f;
                        velocity.x = this.m_currentSpeed;
                        flag = true;
                    }
                }
                else
                {
                    if (Math.abs(velocity.x) <= zero_factor)
                        this.m_currentSpeed = 0;
                    
                    if ((joyDir & 4)!=0)
                    {
                    	if (this.m_currentAngle == 180.0f)
                        {
                            this.m_currentSpeed += this.m_acceleration;
                            this.m_currentSpeed = Math.min(speed, this.m_currentSpeed);
                            velocity.x = -this.m_currentSpeed;
                       }
                        else
                        {
                            this.m_currentSpeed -= this.m_deceleration;
                            if (this.m_currentSpeed < 0.0f)
                            {
                                this.m_currentAngle = 180.0f;
                                this.m_currentSpeed = 0;
                            }
                            velocity.x = this.m_currentSpeed;
                        }
                        flag = true;
                    }
                    if ((joyDir & 8)!=0)
                    {
                        if (this.m_currentAngle == 0.0f)
                        {
                            this.m_currentSpeed += this.m_acceleration;
                            this.m_currentSpeed = Math.min(speed, this.m_currentSpeed);
                            velocity.x = this.m_currentSpeed;
                       }
                        else
                        {
                            this.m_currentSpeed -= this.m_deceleration;
                            if (this.m_currentSpeed < 0.0f)
                            {
                                this.m_currentAngle = 0.0f;
                                this.m_currentSpeed = 0;
                            }
                            velocity.x = -this.m_currentSpeed;
                        }
                        flag = true;
                    }
                }
                anim = CAnim.ANIMID_WALK;
            }
        }
        if (!flag)
        {
            if (ladderDir == 0 && (this.m_jump==0 || ((this.m_flags & CRunMvtbox2dplatform.MPFLAG_JUMPSTOPXIFNOINPUT)!=0 && (joyDir&12) == 0)))
            {
                if (m_currentSpeed > 0.0f)
                {
                    m_currentSpeed-=m_deceleration;
                    m_currentSpeed=Math.max(m_currentSpeed, 0);
                }
                if (m_currentAngle==180.0f)
                    velocity.x=-m_currentSpeed;
                else
                    velocity.x=m_currentSpeed;
                if (this.m_jump==0 && m_currentSpeed != 0)
                    anim = CAnim.ANIMID_WALK;
            }
        }
        else
            m_previousLadder = false;

        // En train de tomber?
        if (bLadder == false && Math.abs(this.rh.rhLoopCount - m_loopCollision) > 5)
        {
            if (velocity.y < -0.5f)
            {
                m_falling = 2;
            }
        }

        // Teste le saut
        boolean bJump=false;
        int j=m_control;
        if (j!=0)
        {
            j--;
            if (j==0)
            {
                if ( (joyDir&5)==5 )
                    bJump=true;							// Haut gauche
                if ( (joyDir&9)==9 )
                    bJump=true;							// Haut droite
            }
            else
            {
                j<<=4;
                if ((joyDir&j)!=0)
                    bJump=true;
            }
        }
        float jumpVY=0;
        if (bCrouching && (this.m_flags & CRunMvtbox2dplatform.MPFLAG_JUMPCROUCHED) == 0)
            bJump = false;
        if (m_falling > 0 && m_jumps <= 1)
            bJump = false;
        if (bJump)
        {
            if (!m_previousJump)
            {
                m_previousJump=true;
                if (m_jump==0)
                {
                    m_jump=4;
                    jumpVY=m_strength;
                    m_jumpCounter=m_jumps - 1;
                }
                else
                {
                    if (m_jumpCounter>=0)
                    {
                        m_jumpCounter--;
                        if (m_jumpCounter>=0)
                        {
                            jumpVY=m_strength2;
                        }
                    }
                }
            }
        }
        else
        {
            m_previousJump=false;
        }
        if (jumpVY != 0)
            velocity.y = jumpVY;
        m_body.setLinearVelocity(velocity);
        m_base.rBodyAddVelocity(m_body, m_addVX+m_setVX, m_addVY+m_setVY);
        ResetAddVelocity();

        if (this.m_platformUnder != null && !bJump)
        {
            if (this.m_platformUnder != this.m_previousPlatformUnder)
            {
                this.m_previousPlatformUnder = this.m_platformUnder;
                this.m_platformPositionX = this.m_platformUnder.m_pHo.hoX;
            }
            Vector2 positionChar = this.m_body.getPosition();
            positionChar.x += (this.m_platformUnder.m_pHo.hoX - this.m_platformPositionX) / this.m_base.factor;
            float angle = this.m_body.getAngle();
            this.m_base.rBodySetTransform(this.m_body, positionChar, angle);
            this.m_platformPositionX = this.m_platformUnder.m_pHo.hoX;
        }
        else
        {
            this.m_previousPlatformUnder = null;
        }
        this.m_platformUnder = null;

        m_previousLadder = bLadder;
        m_previousLadderEnd = ladderEnd;

        if (bCrouching)
            anim=CAnim.ANIMID_CROUCH;
        if (bLadder)
        {
            if (ladderDir != 0)
            {
                anim=CAnim.ANIMID_CLIMB;
                ho.roc.rcDir = ladderDir;
                m_previousLadderDir = ladderDir;
            }
            else if (m_onLadder && m_previousLadder)
            {
                anim=CAnim.ANIMID_CLIMB;
                ho.roc.rcDir = m_previousLadderDir;
            }
        }
        if (m_jump>0)
        {
            anim=CAnim.ANIMID_JUMP;
            m_previousLadder = false;
        }
        if (m_falling > 0)
        {
            anim = CAnim.ANIMID_FALL;
            m_previousLadder = false;
            m_falling--;
        }
       
        animations(anim);
        if ((m_flags & MPFLAG_FINECOLLISIONS) != 0)
        {
            this.m_noStop = true;
            this.collisions();
            this.m_noStop = false;
        }

        return this.ho.roc.rcChanged;
    }

    public void SetFriction(int friction)
    {
        this.m_friction=(float)friction/100.0f;
        this.m_fixture.setFriction(this.m_friction);
    }
    public void SetGravity(int gravity)
    {
        this.m_gravity=(float)gravity/100.0f;
        this.m_body.setGravityScale(this.m_gravity);
    }
    public void SetDensity(int density)
    {
        this.m_density=(float)density/100.0f;
        this.m_fixture.setDensity(this.m_density);
        this.m_base.rBodyResetMassData(this.m_body);
    }
    public void SetRestitution(int restitution)
    {
        this.m_restitution=(float)restitution/100.0f;
        this.m_fixture.setRestitution(this.m_restitution);
    }


    @Override
    public void setPosition(int x, int y)
    {
        if (x!=this.ho.hoX || y!=this.ho.hoY)
            this.m_base.rBodySetPosition(this.m_body, x, y);
    }
    @Override
    public void setXPosition(int x)
    {
        if (x!=this.ho.hoX)
            this.m_base.rBodySetPosition(this.m_body, x, CRunBox2DBase.POSDEFAULT);
    }
    @Override
    public void setYPosition(int y)
    {
        if (y!=this.ho.hoY)
            this.m_base.rBodySetPosition(this.m_body, CRunBox2DBase.POSDEFAULT, y);
    }
    @Override
    public void stop(boolean bCurrent)
    {
        if (this.m_eventCount==this.rh.rh4EventCount)
        {
            if (this.m_noStop)
                return;

            if (this.rh.y_GetLadderAt(-1, this.ho.hoX-rh.rhWindowX, this.ho.hoY-rh.rhWindowY) == null)
            {
                this.SetStopFlag(true);
            }

            this.m_base.rGetBodyPosition(this.m_collidingObject.m_body, this.m_posAndAngle);
            int left = this.m_posAndAngle.x + this.m_collidingObject.rc.left;
            int right = this.m_posAndAngle.x + this.m_collidingObject.rc.right;
            int top = this.m_posAndAngle.y + this.m_collidingObject.rc.top;
            int bottom = this.m_posAndAngle.y + this.m_collidingObject.rc.bottom;

            if (m_collidingObject.m_subType == MSUBTYPE_BOTTOM)
            {
                m_loopCollision = this.rh.rhLoopCount;
                m_jump = Math.max(m_jump-1, 0);
            }
            else if ((this.ho.hoX >=left && this.ho.hoX <= right && this.ho.hoY <= bottom))
            {
                m_loopCollision = this.rh.rhLoopCount;
                this.m_jump = Math.max(m_jump-1, 0);
                if (this.m_collidingObject.m_type == CRunMBase.MTYPE_FAKEOBJECT)
                    this.m_platformUnder = this.m_collidingObject;
            }
        }
        else
        {
            this.m_base.rBodySetLinearVelocityAdd(this.m_body, 0, 0, 0, 0);
        }
    }

    @Override
    public int getDir()
    {
        return this.ho.roc.rcDir;
    }

    public float getAngle()
    {
        return 0;
    }

    @Override
    public void setGravity(int gravity)
    {
        this.m_gravity=(float)gravity/100.0f;
        this.m_body.setGravityScale(this.m_gravity);
    }
    
    @Override
    public void setAcc(int acc)
    {
        this.m_acceleration=(float)(acc)/(100.0f*ACCMULT*this.m_base.RunFactor);
    }

    @Override
    public void setDec(int dec)
    {
        this.m_deceleration=(float)(dec)/(100.0f*DECMULT*this.m_base.RunFactor);
    }
	
    @Override
    public void setSpeed(int speed)
    {
        this.m_currentSpeed = speed / 100.0f * 10.0f;
    }

    @Override
    public int getSpeed()
    {
        return this.ho.roc.rcSpeed;
    }

    @Override
    public int getGravity()
    {
        return (int)(this.m_gravity*100.0);
    }

    @Override
    public int getAcceleration()
    {
        return (int)(this.m_acceleration*(100.0*ACCMULT*this.m_base.RunFactor));
    }

    @Override
    public int getDeceleration()
    {
        return (int)(this.m_deceleration*(100.0*DECMULT*this.m_base.RunFactor));
    }

    @Override
    public double actionEntry(int action)
    {
        if (this.m_base == null)
            return 0;

        //float force;
        float angle;
        //float torque;
        Vector2 v;
        switch (action)
        {
            case CAct.NACT_EXTSETGRAVITYSCALE:
                this.SetGravity((int)this.getParam1());
                break;
            case CAct.NACT_EXTSETFRICTION:
                this.SetFriction((int)this.getParam1());
                break;
            case CAct.NACT_EXTSETELASTICITY:
                this.SetRestitution((int)this.getParam1());
                break;
            case CAct.NACT_EXTSETDENSITY:
                this.SetDensity((int)this.getParam1());
                break;
            case CExp.NEXP_EXTGETFRICTION:
                return this.m_friction * 100;
            case CExp.NEXP_EXTGETRESTITUTION:
                return this.m_restitution * 100;
            case CExp.NEXP_EXTGETDENSITY:
                return this.m_density * 100;
            case CExp.NEXP_EXTGETVELOCITY:
                v = this.m_body.getLinearVelocity();
                return Math.sqrt(v.x * v.x + v.y * v.y)*100.0/CRunBox2DBase.SETVELOCITY_MULT;
            case CExp.NEXP_EXTGETANGLE:
                v = m_body.getLinearVelocity();
                angle=(float)(Math.atan2(v.y, v.x)*180.0/Math.PI);
                if (angle<0)
                    angle=360+angle;
                return (double)angle;
			case CExp.NEXP_EXTGETMASS:
				return this.m_body.getMass();
			case CExp.NEXP_EXTGETANGULARVELOCITY:
				return (this.m_body.getAngularVelocity() * 100.0) / CRunBox2DBase.SETANGULARVELOCITY_MULT;
            default:
                break;
        }
        return 0;
    }
}
