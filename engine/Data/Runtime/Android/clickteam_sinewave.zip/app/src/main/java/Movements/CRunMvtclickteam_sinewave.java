/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// CRUNMVTSINWAVE
//
//----------------------------------------------------------------------------------

package Movements;

import Animations.CAnim;
import Application.CRunFrame;
import Services.CBinaryFile;

public class CRunMvtclickteam_sinewave extends CRunMvtExtension
{
    public static final int MFLAG1_MOVEATSTART = 1;
    public static final int ONEND_STOP = 0;
    public static final int ONEND_RESET = 1;
    public static final int ONEND_BOUNCE = 2;
    public static final int ONEND_REVERSE = 3;
    int m_dwFlags;
    int m_dwSpeed;
    int m_dwFinalX;
    int m_dwFinalY;
    int m_dwAmp;
    int m_dwAngVel;
    int m_dwStartAngle;
    int m_dwOnEnd;
    //*** General variables
    double r_CurrentX;
    double r_CurrentY;
    boolean r_Stopped;
    int r_OnEnd;

    //*** Line motion variables
    int r_Speed;
    int r_StartX;
    int r_StartY;
    int r_FinalX;
    int r_FinalY;
    double r_Dx;
    double r_Dy;
    double r_Steps;
    double r_Angle;

    //*** Sine motion variables
    double r_Amp;
    double r_AngVel;
    double r_CurrentAngle;
    double r_Cx;
    double r_Cy;

    public CRunMvtclickteam_sinewave()
    {
    }

    @Override
	public void initialize(CBinaryFile file)
    {
        file.skipBytes(1);
        m_dwFlags = file.readInt();
        m_dwSpeed = file.readInt();
        m_dwFinalX = file.readInt();
        m_dwFinalY = file.readInt();
        m_dwAmp = file.readInt();
        m_dwAngVel = file.readInt();
        m_dwStartAngle = file.readInt();
        m_dwOnEnd = file.readInt();

        r_StartX = ho.hoX;
        r_StartY = ho.hoY;
        r_FinalX = m_dwFinalX;
        r_FinalY = m_dwFinalY;
        r_CurrentX = r_StartX;
        r_CurrentY = r_StartY;
        r_Amp = m_dwAmp;
        r_AngVel = (m_dwAngVel * (Math.PI / 180.0)) / 50.0;
        r_CurrentAngle = m_dwStartAngle * (Math.PI / 180.0);
//	r_Stopped = (bool)( 1 - m_pMvt->m_dwFlags);
        r_Stopped = ((m_dwFlags & MFLAG1_MOVEATSTART) == 0);
        r_OnEnd = m_dwOnEnd;

        //*** Linear motion components;
        r_Speed = m_dwSpeed;
        ho.roc.rcSpeed = r_Speed;

        if (r_Speed != 0)
        {
            r_Angle = Math.atan2((r_FinalY - r_StartY), (r_FinalX - r_StartX));

            r_Cx = Math.cos(r_Angle + Math.PI * 0.5);
            r_Cy = Math.sin(r_Angle + Math.PI * 0.5);

            r_Dx = Math.cos(r_Angle) * (r_Speed / 50.0);
            r_Dy = Math.sin(r_Angle) * (r_Speed / 50.0);

            if (Math.abs(r_Dx) > 0.0001)
            {
                r_Steps = Math.abs((r_FinalX - r_StartX) / r_Dx);
            }
            else if (Math.abs(r_Dy) > 0.0001)
            {
                r_Steps = Math.abs((r_FinalY - r_StartY) / r_Dy);
            }
            else
            {
                r_Steps = 0.0;
            }
        }
        else
        {
            r_Dx = 0;
            r_Dy = 0;
            r_Steps = 0.0;
        }
    }

    @Override
	public void kill()
    {
    }

    @Override
	public boolean move()
    {
        //*** Object needs to be moved?
        if (r_Speed != 0 && !r_Stopped)
        {
            if (r_Steps > 0.0)
            {
                double calculs;

                //*** Ensure angle is in the range 0 to 360 degrees
                if (r_CurrentAngle < 0)
                {
                    r_CurrentAngle += 2 * Math.PI;
                }
                else if (r_CurrentAngle >= 2 * Math.PI)
                {
                    r_CurrentAngle -= 2 * Math.PI;
                }

                double angVel = r_AngVel;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    angVel = angVel * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                double dx = r_Dx;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    dx = dx * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                double dy = r_Dy;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    dy = dy * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }

                if (r_Steps > 1.0)
                {
                    //*** This is not the final section of movement
                    r_CurrentX += dx;
                    r_CurrentY += dy;
                    r_CurrentAngle -= angVel;
                    calculs = 1.0;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    r_Steps -= calculs;
                }
                else
                {
                    //**** Final section of movement, handle movement completion
                    r_CurrentX += r_Steps * dx;
                    r_CurrentY += r_Steps * dy;
                    r_CurrentAngle -= r_Steps * angVel;
                    calculs = 1.0;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    r_Steps -= calculs;

                    animations(CAnim.ANIMID_WALK);

                    if (r_OnEnd == ONEND_STOP)
                    {
                        double amp = r_Amp * Math.sin(r_CurrentAngle);

                        //*** Move object, run animation and collision detection
                        ho.hoX = (int) (r_CurrentX + r_Cx * amp);
                        ho.hoY = (int) (r_CurrentY + r_Cy * amp);
                        r_Stopped = true;
                    }
                    else if (r_OnEnd == ONEND_RESET)
                    {
                        reset();
                    }
                    else if (r_OnEnd == ONEND_BOUNCE)
                    {
                        bounce(false);
                    }
                    else if (r_OnEnd == ONEND_REVERSE)
                    {
                        reverse();
                    }

                    collisions();
                    return true;
                }

                //*** Sine motion amplitude
                double amp = r_Amp * Math.sin(r_CurrentAngle);

                //*** Move object, run animation and collision detection
                animations(CAnim.ANIMID_WALK);
                ho.hoX = (int) (r_CurrentX + r_Cx * amp);
                ho.hoY = (int) (r_CurrentY + r_Cy * amp);
                collisions();

                //*** Indicate the object has been moved
                return true;
            }
        }
        animations(CAnim.ANIMID_STOP);
        collisions();

        //*** The object has not been moved
        return false;
    }

    void reset()
    {
        ho.hoX = r_StartX;
        ho.hoY = r_StartY;

        r_CurrentX = r_StartX;
        r_CurrentY = r_StartY;
        r_CurrentAngle = (m_dwStartAngle) * (Math.PI / 180.0);

        if (r_Speed != 0)
        {
            r_Angle = Math.atan2((r_FinalY - r_StartY), (r_FinalX - r_StartX));

            r_Cx = Math.cos(r_Angle + Math.PI / 2);
            r_Cy = Math.sin(r_Angle + Math.PI / 2);

            r_Dx = Math.cos(r_Angle) * (r_Speed / 50.0);
            r_Dy = Math.sin(r_Angle) * (r_Speed / 50.0);

            if (Math.abs(r_Dx) > 0.0001)
            {
                r_Steps = Math.abs((r_FinalX - r_StartX) / r_Dx);
            }
            else if (Math.abs(r_Dy) > 0.0001)
            {
                r_Steps = Math.abs((r_FinalY - r_StartY) / r_Dy);
            }
            else
            {
                r_Steps = 0.0;
            }
        }
        else
        {
            r_Steps = 0.0;
        }
    }

    @Override
	public void setPosition(int x, int y)
    {
        r_CurrentX -= ho.hoX - x;
        r_CurrentY -= ho.hoY - y;

        ho.hoX = x;
        ho.hoY = y;
    }

    @Override
	public void setXPosition(int x)
    {
        r_CurrentX -= ho.hoX - x;
        ho.hoX = x;
    }

    @Override
	public void setYPosition(int y)
    {
        r_CurrentY -= ho.hoY - y;
        ho.hoY = y;
    }

    @Override
	public void stop(boolean bCurrent)
    {
        r_Stopped = true;
    }

    @Override
	public void bounce(boolean bCurrent)
    {
        double amp = r_Amp * Math.sin(r_CurrentAngle);
        ho.hoX = (int) (r_CurrentX + r_Cx * amp);
        ho.hoY = (int) (r_CurrentY + r_Cy * amp);

        int tmpX = r_FinalX;
        int tmpY = r_FinalY;

        r_FinalX = r_StartX;
        r_FinalY = r_StartY;

        r_StartX = tmpX;
        r_StartY = tmpY;

        r_Angle += Math.PI;

        if (r_Speed != 0)
        {
            r_Dx *= -1;
            r_Dy *= -1;

            if (Math.abs(r_Dx) > 0.0001)
            {
                r_Steps = Math.abs((r_FinalX - r_CurrentX) / r_Dx);
            }
            else if (Math.abs(r_Dy) > 0.0001)
            {
                r_Steps = Math.abs((r_FinalY - r_CurrentY) / r_Dy);
            }
            else
            {
                r_Steps = 0.0;
            }
        }
        else
        {
            r_Dx = 0;
            r_Dy = 0;
            r_Steps = 0.0;
        }
    }

    @Override
	public void reverse()
    {
        //*** Finish moving the object first *****
        double amp = r_Amp * Math.sin(r_CurrentAngle);
        ho.hoX = (int) (r_CurrentX + r_Cx * amp);
        ho.hoY = (int) (r_CurrentY + r_Cy * amp);

        int tmpX = r_FinalX;
        int tmpY = r_FinalY;

        r_FinalX = r_StartX;
        r_FinalY = r_StartY;

        r_StartX = tmpX;
        r_StartY = tmpY;

        r_AngVel *= -1;
        r_Angle += Math.PI;

        if (r_Speed != 0)
        {
            r_Dx *= -1;
            r_Dy *= -1;

            if (Math.abs(r_Dx) > 0.0001)
            {
                r_Steps = Math.abs((r_FinalX - r_CurrentX) / r_Dx);
            }
            else if (Math.abs(r_Dy) > 0.0001)
            {
                r_Steps = Math.abs((r_FinalY - r_CurrentY) / r_Dy);
            }
            else
            {
                r_Steps = 0.0;
            }
        }
        else
        {
            r_Dx = 0;
            r_Dy = 0;
            r_Steps = 0.0;
        }
    }

    @Override
	public void start()
    {
        r_Stopped = false;
    }

    @Override
	public void setSpeed(int speed)
    {
        if (speed < 0)
        {
            speed = 0; //** Do not allow negative speed
        }
        //*** Linear motion components;
        r_Speed = speed;
        ho.roc.rcSpeed = r_Speed;

        if (r_Speed != 0)
        {
            r_Dx = Math.cos(r_Angle) * (r_Speed / 50.0);
            r_Dy = Math.sin(r_Angle) * (r_Speed / 50.0);

            if (Math.abs(r_Dx) > 0.0001)
            {
                r_Steps = Math.abs((r_FinalX - r_CurrentX) / r_Dx);
            }
            else if (Math.abs(r_Dx) > 0.0001)
            {
                r_Steps = Math.abs((r_FinalY - r_CurrentY) / r_Dy);
            }
            else
            {
                r_Steps = 0.0;
            }
        }
        else
        {
            r_Dx = 0;
            r_Dy = 0;
            r_Steps = 0.0;
        }
    }

    @Override
	public void setMaxSpeed(int speed)
    {
    }

    @Override
	public void setDir(int dir)
    {
    }

    @Override
	public void setAcc(int acc)
    {
    }

    @Override
	public void setDec(int dec)
    {
    }

    @Override
	public void setRotSpeed(int speed)
    {
    }

    @Override
	public void set8Dirs(int dirs)
    {
    }

    @Override
	public void setGravity(int gravity)
    {
    }

    @Override
	public int extension(int function, int param)
    {
        return 0;
    }

    @Override
	public double actionEntry(int action)
    {
        int param;
        switch (action)
        {
            case 3545:	    // SET_SINEWAVE_SPEED = 3545,
                param = (int) getParamDouble();
                setSpeed(param);
                break;
            case 3546:	    // SET_SINEWAVE_STARTX,
                param = (int) getParamDouble();
                r_StartX = param;
                break;
            case 3547:	    // SET_SINEWAVE_STARTY,
                param = (int) getParamDouble();
                r_StartY = param;
                break;
            case 3548:	    // SET_SINEWAVE_FINALX,
                param = (int) getParamDouble();
                r_FinalX = param;
                break;
            case 3549:	    // SET_SINEWAVE_FINALY,
                param = (int) getParamDouble();
                r_FinalY = param;
                break;
            case 3550:	    // SET_SINEWAVE_AMPLITUDE,
                param = (int) getParamDouble();
                r_Amp = Math.max(param, 0);
                break;
            case 3551:	    // SET_SINEWAVE_ANGVEL,
                param = (int) getParamDouble();
                r_AngVel = param * (Math.PI / 180.0) / 50.0;
            case 3552:	    // SET_SINEWAVE_STARTANG,
                param = (int) getParamDouble();
                m_dwStartAngle = (int) Math.max(param * (Math.PI / 180.0), 0);
                break;
            case 3553:	    // SET_SINEWAVE_CURRENTANGLE,
                param = (int) getParamDouble();
                r_CurrentAngle = Math.max(param * (Math.PI / 180.0), 0);
                break;
            case 3554:	    // GET_SINEWAVE_SPEED,
                return ho.roc.rcSpeed;
            case 3555:	    // GET_SINEWAVE_STARTX,
                return r_Cx;
            case 3556:	    // GET_SINEWAVE_STARTY,
                return r_StartY;
            case 3557:	    // GET_SINEWAVE_FINALX,
                return r_FinalX;
            case 3558:	    // GET_SINEWAVE_FINALY,
                return r_FinalY;
            case 3559:	    // GET_SINEWAVE_AMPLITUDE,
                return r_Amp;
            case 3560:	    // GET_SINEWAVE_ANGVEL,
                return r_AngVel * 50.0 * (180.0 / Math.PI);
            case 3561:	    // GET_SINEWAVE_STARTANG,
                return m_dwStartAngle;
            case 3562:	    // GET_SINEWAVE_CURRENTANGLE,
                return r_CurrentAngle * (180.0 / Math.PI);
            case 3563:	    // RESET_SINEWAVE,
                reset();
                break;
            case 3564:	    // SET_SINEWAVE_ONCOMPLETION
                param = (int) getParamDouble();
                int option = param;
                if (option == ONEND_STOP)
                {
                    r_OnEnd = ONEND_STOP;
                }
                else if (option == ONEND_RESET)
                {
                    r_OnEnd = ONEND_RESET;
                }
                else if (option == ONEND_BOUNCE)
                {
                    r_OnEnd = ONEND_BOUNCE;
                }
                else if (option == ONEND_REVERSE)
                {
                    r_OnEnd = ONEND_REVERSE;
                }
                break;
        }
        return 0;
    }

    @Override
	public int getSpeed()
    {
        return ho.roc.rcSpeed;
    }

    @Override
	public int getAcceleration()
    {
        return 0;
    }

    @Override
	public int getDeceleration()
    {
        return 0;
    }

    @Override
	public int getGravity()
    {
        return 0;
    }

}
