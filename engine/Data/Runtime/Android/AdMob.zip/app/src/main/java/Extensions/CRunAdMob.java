/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

package Extensions;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.StringTokenizer;

import Actions.CActExtension;
import Application.CRunApp;
import Conditions.CCndExtension;
import Expressions.CValue;
import Objects.CObject;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Runtime.SurfaceView;
import Services.CBinaryFile;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.RelativeLayout;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardedVideoAd;


// Version 3 new iOS implementation
public class CRunAdMob extends CRunExtension
{
	// <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
	public static final int CNDRECEIVEDAD = 0;
	public static final int CNDFAILEDAD = 1;
	public static final int CNDONPRESENTSCREEN = 2;
	public static final int CNDONDISMISSSCREEN = 3;
	public static final int CNDONLEAVEAPPS = 4;
	public static final int CNDADSREADY = 5;
	public static final int CNDONACTIVITY = 6;
	public static final int CNDONERROR = 7;
	public static final int CNDONVIDEORECEIVED = 8;
	public static final int CNDONVIDEOFAILED = 9;
	public static final int CNDONVIDEOPRESENT = 10;
	public static final int CNDONVIDEODISMISS = 11;
	public static final int CNDONVIDEOLEAVEAPPS = 12;
	public static final int CNDVIDEOLOADED = 13;
	public static final int CNDONVIDEOSTARTED = 14;
	public static final int CNDONVIDEOREWARD = 15;
	public static final int CND_LAST = 22;

	public static final int ACTADSIZE = 0;
	public static final int ACTADPOS = 1;
	public static final int ACTADZORDER = 2;
	public static final int ACTADREQUEST = 3;
	public static final int ACTADSHOW = 4;
	public static final int ACTADDESTROY = 5;
	public static final int ACTINTERREQUEST = 6;
	public static final int ACTINTERSHOW = 7;
	public static final int ACTINTERDESTROY = 8;
	public static final int ACTSETGENDER = 9;
	public static final int ACTSETLOCATION = 10;
	public static final int ACTSETBIRTHDAY = 11;
	public static final int ACTCPPA = 12;
	public static final int ACTTESTDEVICE = 13;
	public static final int ACTBCKCOLOR = 14;
	public static final int ACTBORDERCOLOR = 15;
	public static final int ACTLINKCOLOR = 16;
	public static final int ACTTEXTCOLOR = 17;
	public static final int ACTURLCOLOR = 18;
    public static final int ACTVIDEOREQUEST = 19;
    public static final int ACTVIDEOSHOW = 20;
    public static final int ACTVIDEODESTROY = 21;
    public static final int ACTSETSTATUS = 22;

    public static final int EXPERROR = 0;
    public static final int EXPDEVID = 1;
    public static final int EXPREWARDTYPE = 2;
    public static final int EXPREWARDAMOUNT = 3;

	// </editor-fold>
	class AdMobAds {
        String AppID = null;
		String AdMobID = null;
		String IntersID = null;
		String VideoID = null;
		String adMobTestDeviceID = null;
		AdSize adSize;
		Location location = null;
		Date birthday;
		int gender = AdRequest.GENDER_UNKNOWN;
		int modify;
		int color_bg;
		int color_bg_top;
		int color_border;
		int color_link;
		int color_text;
		int color_url;
		int child_treat = 0;
		int displayWhere; 
		boolean enabled = true;  
		boolean displayOverFrame;   	
		boolean loaded;
		boolean testing;
		boolean leaving = false;
		int status;
		int GDPRstatus;
		
		public void init() {
			modify = 0;
			loaded = false;
			leaving = false;
			birthday = null;
			status = 0;
		}
	}

	public static int BCKCOLOR = 0x0001;
	public static int GRDCOLOR = 0x0002;
	public static int BRDCOLOR = 0x0004;
	public static int LNKCOLOR = 0x0010;
	public static int TXTCOLOR = 0x0020;
	public static int URLCOLOR = 0x0040;
	public static int CPPAFLAG = 0x0100;

	//private int ADMOB_TEST 	= 0x0001;
	//private int ADMOB_NOTIF 	= 0x0002;

	private int ADFLG_STAND 	= 0x0001;
	private int ADFLG_MEDIUM 	= 0x0002;
	private int ADFLG_FULL 		= 0x0004;
	private int ADFLG_LEADER 	= 0x0010;
	private int ADFLG_SMART 	= 0x0020;

	//private int ADFLG_NOTIF 	= 0x0040;

	private int ADFLG_BOTTOM 	= 0x0100;
	private int ADFLG_TOP 		= 0x0200;
	private int ADFLG_CENTER 	= 0x0400;

	private int ADFLG_ABOVE 	= 0x1000;
	//private int ADFLG_BEHIND 	= 0x2000;

	private static boolean adMobLib;
	
	private CValue expRet;
	
	private AdView adView = null;
	private InterstitialAd interstitial = null;
	private RewardedVideoAd videoreward = null;
	private boolean appEndOn = false;
	private String szError = null;

	private AdMobAds mmfAdMob = null;

    private String ADMOB_APP_ID = null;
	private String ADMOB_BANNER_ID = null;
	private String INTERSTITIAL_ID = null;
	private String VIDEOREWARD_ID = null;
	private String TESTLISTDEVICES = null;
		
	private int lastEvent;
	
	private String rewardType;
	private int rewardAmount;
	private int consentStatus;

	private String errorStringCode(int errorCode)
	{
		String error = "";
		switch(errorCode) {
		case AdRequest.ERROR_CODE_INTERNAL_ERROR:
			error = "Internal Error";
			break;
		case AdRequest.ERROR_CODE_INVALID_REQUEST:
			error = "Invalid Request";
		    break;
		case AdRequest.ERROR_CODE_NETWORK_ERROR:
			error = "Network Error";
		    break;
		case AdRequest.ERROR_CODE_NO_FILL:
			error = "Code Error - No Ads in inventory";
		    break;
		}
		return error;
	}
	
	private String ColorToRGB(int intColor) {
		return String.format("#%06X", 0xFFFFFF & intColor);
	}
	
	private void setInterstitial(final AdMobAds IntersAds) {

		if(IntersAds.IntersID == null)
			return;
		
		// Create the interstitial
        MobileAds.initialize(MMFRuntime.inst, IntersAds.AppID.replace("/", "~"));
		interstitial = new InterstitialAd(MMFRuntime.inst);
	    interstitial.setAdUnitId(IntersAds.IntersID);

		final AdRequest.Builder builder = new  AdRequest.Builder();

		if (IntersAds.adMobTestDeviceID != null && IntersAds.adMobTestDeviceID.length() != 0)
		{
			StringTokenizer tokenizer = new StringTokenizer(IntersAds.adMobTestDeviceID, ",");

			while (tokenizer.hasMoreElements())
			{
				String id = tokenizer.nextToken();

				Log.d ("AdMob", "Adding AdMob test device: " + id);
				builder.addTestDevice(id);
			}
		}

		builder.addTestDevice(AdRequest.DEVICE_ID_EMULATOR);
		// Setting Color is they where modify
		if(IntersAds.modify > 0) {
			Bundle bundle = new Bundle();
			
			builder.setGender(IntersAds.gender);
			
			if(IntersAds != null)
				builder.setBirthday(IntersAds.birthday);
			
			// Got a Location, use it.
			if(IntersAds.location != null)
				builder.setLocation(IntersAds.location);

			if((IntersAds.modify & CRunAdMob.CPPAFLAG) != 0) {
				if(IntersAds.child_treat != 0)
					builder.tagForChildDirectedTreatment(true);
				else
					builder.tagForChildDirectedTreatment(false);
			}
			if((IntersAds.modify & CRunAdMob.BCKCOLOR) != 0)
				bundle.putString("color_bg", ColorToRGB(IntersAds.color_bg));
			
			if((IntersAds.modify & CRunAdMob.GRDCOLOR) != 0)
				bundle.putString("color_bg_top", ColorToRGB(IntersAds.color_bg_top));
			
			if((IntersAds.modify & CRunAdMob.BRDCOLOR) != 0)
				bundle.putString("color_border", ColorToRGB(IntersAds.color_border));
			
			if((IntersAds.modify & CRunAdMob.LNKCOLOR) != 0)
				bundle.putString("color_link", ColorToRGB(IntersAds.color_link));
			
			if((IntersAds.modify & CRunAdMob.TXTCOLOR) != 0)
				bundle.putString("color_text", ColorToRGB(IntersAds.color_text));
			
			if((IntersAds.modify & CRunAdMob.URLCOLOR) != 0)
				bundle.putString("color_url", ColorToRGB(IntersAds.color_url));
			
			if(IntersAds.GDPRstatus == 1)
				bundle.putString("npa", "1");
			
			builder.addNetworkExtrasBundle(MediationAdapter.class, bundle);
		}

		IntersAds.init();
		
		// Set your AdListener
		interstitial.setAdListener(new AdListener () {

			@Override
			public void  onAdClosed() {
				Log.d("AdMob", "onDismissScreen");
	    		RestoreAutoEnd();
				lastEvent = rh.rh4EventCount;
				ho.activityEvent(CNDONDISMISSSCREEN, 0);
			}

			@Override
			public void onAdLeftApplication() {
				Log.d("AdMob", "onLeaveApplication");
	    		SuspendAutoEnd();
				mmfAdMob.leaving = true;
				mmfAdMob.status = 1;
				lastEvent = rh.rh4EventCount;
				ho.activityEvent(CNDONLEAVEAPPS, 0);
			}

			@Override
			public void onAdOpened() {
				Log.d("AdMob", "onPresentScreen");
	    		SuspendAutoEnd();
				lastEvent = rh.rh4EventCount;
				ho.activityEvent(CNDONPRESENTSCREEN, 0);
			}

			@Override
			public void onAdLoaded() {
				Log.d("AdMob", "Did Receive Ad");
	    		SuspendAutoEnd();
				lastEvent = rh.rh4EventCount;
				ho.pushEvent(CNDRECEIVEDAD, 0);
			}

			@Override
			public void onAdFailedToLoad(int errorCode) {
				Log.d("AdMob", "failed to receive ad (" + errorCode + ")");
	    		RestoreAutoEnd();
				szError = errorStringCode(errorCode);
				lastEvent = rh.rh4EventCount;
				ho.pushEvent(CNDONERROR, 0);
			}

		});

		final AdRequest request = builder.build();

		// and begin loading your Interstitial
		MMFRuntime.inst.runOnUiThread(new Runnable(){

			@Override
			public void run() {
				mmfAdMob.status = 0;
				interstitial.loadAd(request);
			}
			
		});

	}

	public void setAdMob (final AdMobAds xAds)
	{
		if(xAds.AdMobID == null)
			return;
		
		if (adView != null)
		{
		    adView.setEnabled(false);
		    adView.setVisibility(View.GONE);
		    adView.setAdListener(null);
			MMFRuntime.inst.container.removeView (adView);
			adView.destroy();
			adView = null;
			xAds.loaded = false;
			System.gc();
		}

		if (!xAds.enabled)
			return;

		// Create an ad using play services.
		// Initialize the Mobile Ads SDK.

        MobileAds.initialize(MMFRuntime.inst, xAds.AppID.replace("/", "~"));


	    adView = new AdView(MMFRuntime.inst);
	    
		if(adView == null)
			return;

	    adView.setAdSize(xAds.adSize);
	    adView.setAdUnitId(xAds.AdMobID);
		adView.setBackgroundColor(Color.TRANSPARENT);

		adView.setId(27772);

		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams
				(LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT);

		switch(xAds.displayWhere) {
		case 0:
			params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
			break;
		case 1:
			params.addRule(RelativeLayout.ALIGN_PARENT_TOP);
			break;
		case 2:
			params.addRule(RelativeLayout.CENTER_IN_PARENT);
			break;
		}
		

		if (!xAds.displayOverFrame)
			((RelativeLayout.LayoutParams) MMFRuntime.inst.mainView.getLayoutParams()).addRule
				(xAds.displayWhere != 1 ? RelativeLayout.ABOVE : RelativeLayout.BELOW, adView.getId());
		else {
			((RelativeLayout.LayoutParams) MMFRuntime.inst.mainView.getLayoutParams()).addRule
				(RelativeLayout.ABOVE, 0);
			((RelativeLayout.LayoutParams) MMFRuntime.inst.mainView.getLayoutParams()).addRule
				(RelativeLayout.BELOW, 0);
		}

		MMFRuntime.inst.container.addView(adView, params);
		
		final AdRequest.Builder builder = new  AdRequest.Builder();

		if (xAds.adMobTestDeviceID != null && xAds.adMobTestDeviceID.length() != 0)
		{
			StringTokenizer tokenizer = new StringTokenizer(xAds.adMobTestDeviceID, ",");

			while (tokenizer.hasMoreElements())
			{
				String id = tokenizer.nextToken();

				Log.d ("AdMob", "Adding AdMob test device: " + id);
				builder.addTestDevice(id);
			}
		}


		builder.addTestDevice(AdRequest.DEVICE_ID_EMULATOR);
		builder.setGender(xAds.gender);
		
		if(xAds != null)
			builder.setBirthday(xAds.birthday);
		

		// Got a Location, use it.
		if(xAds.location != null)
			builder.setLocation(xAds.location);

		// Setting Color is they where modify
		if(xAds.modify > 0) {
			Bundle bundle = new Bundle();
			
			if((xAds.modify & CRunAdMob.CPPAFLAG) != 0) {
				if(xAds.child_treat != 0)
					builder.tagForChildDirectedTreatment(true);
				else
					builder.tagForChildDirectedTreatment(false);
			}
				
			if((xAds.modify & CRunAdMob.BCKCOLOR) != 0)
				bundle.putString("color_bg", ColorToRGB(xAds.color_bg));
			
			if((xAds.modify & CRunAdMob.GRDCOLOR) != 0)
				bundle.putString("color_bg_top", ColorToRGB(xAds.color_bg_top));
			
			if((xAds.modify & CRunAdMob.BRDCOLOR) != 0)
				bundle.putString("color_border", ColorToRGB(xAds.color_border));
			
			if((xAds.modify & CRunAdMob.LNKCOLOR) != 0)
				bundle.putString("color_link", ColorToRGB(xAds.color_link));
			
			if((xAds.modify & CRunAdMob.TXTCOLOR) != 0)
				bundle.putString("color_text", ColorToRGB(xAds.color_text));
			
			if((xAds.modify & CRunAdMob.URLCOLOR) != 0)
				bundle.putString("color_url", ColorToRGB(xAds.color_url));
			
			if(xAds.GDPRstatus == 1)
				bundle.putString("npa", "1");
			
			builder.addNetworkExtrasBundle(MediationAdapter.class, bundle);
		}

		xAds.init();

		AdRequest request = builder.build();

		adView.setAdListener(new AdListener () {

			@Override
			public void  onAdClosed() {
				Log.d("AdMob", "onDismissScreen");
	    		RestoreAutoEnd();
				lastEvent = rh.rh4EventCount;
				ho.activityEvent(CNDONDISMISSSCREEN, 0);
			}

			@Override
			public void onAdLeftApplication() {
				Log.d("AdMob", "onLeaveApplication");
	    		SuspendAutoEnd();
	    		mmfAdMob.leaving = true;
				mmfAdMob.status = 1;
				lastEvent = rh.rh4EventCount;
				ho.pushEvent(CNDONLEAVEAPPS, 0);
			}

			@Override
			public void onAdOpened() {
				Log.d("AdMob", "onPresentScreen");
	    		SuspendAutoEnd();
				lastEvent = rh.rh4EventCount;
				ho.activityEvent(CNDONPRESENTSCREEN, 0);
			}

			@Override
			public void onAdLoaded() {
				Log.d("AdMob", "Did Receive Ad");
		        xAds.loaded = true;
	    		SuspendAutoEnd();
				lastEvent = rh.rh4EventCount;
				ho.pushEvent(CNDRECEIVEDAD, 0);
			}

			@Override
			public void onAdFailedToLoad(int errorCode) {
				Log.d("AdMob", "failed to receive ad (" + errorCode + ")");
		        xAds.loaded = false;
	    		RestoreAutoEnd();
				szError = errorStringCode(errorCode);
				lastEvent = rh.rh4EventCount;
				ho.pushEvent(CNDONERROR, 0);
			}

		});
		
		//final AdRequest frequest = request;
		adView.loadAd(request);
		request = null;
		mmfAdMob.loaded = true;
		/*
		MMFRuntime.inst.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				try
				{
					synchronized(SurfaceView.inst)
					{
						adView.loadAd(frequest);
						mmfAdMob.loaded = true;
					}
				}
				catch(Exception e)
				{
					Log.d("AdMob", "Exception error on banners");
				}
			}
			
		});
    	*/
				
	}

	private void setVideoReward(final AdMobAds VideoAds) {

		if(VideoAds.VideoID == null)
			return;
		
		// Create the interstitial
        MobileAds.initialize(MMFRuntime.inst, VideoAds.AppID.replace("/",  "~"));

        videoreward =  MobileAds.getRewardedVideoAdInstance((MMFRuntime.inst));

		final AdRequest.Builder builder = new  AdRequest.Builder();

		if (VideoAds.adMobTestDeviceID != null && VideoAds.adMobTestDeviceID.length() != 0)
		{
			StringTokenizer tokenizer = new StringTokenizer(VideoAds.adMobTestDeviceID, ",");

			while (tokenizer.hasMoreElements())
			{
				String id = tokenizer.nextToken();

				Log.d ("AdMob", "Adding AdMob test device: " + id);
				builder.addTestDevice(id);
			}
		}

		builder.addTestDevice(AdRequest.DEVICE_ID_EMULATOR);
		// Setting Color is they where modify
		if(VideoAds.modify > 0) {
			Bundle bundle = new Bundle();
			
			builder.setGender(VideoAds.gender);
			
			if(VideoAds != null)
				builder.setBirthday(VideoAds.birthday);
			
			// Got a Location, use it.
			if(VideoAds.location != null)
				builder.setLocation(VideoAds.location);

			if((VideoAds.modify & CRunAdMob.CPPAFLAG) != 0) {
				if(VideoAds.child_treat != 0)
					builder.tagForChildDirectedTreatment(true);
				else
					builder.tagForChildDirectedTreatment(false);
			}
			if((VideoAds.modify & CRunAdMob.BCKCOLOR) != 0)
				bundle.putString("color_bg", ColorToRGB(VideoAds.color_bg));
			
			if((VideoAds.modify & CRunAdMob.GRDCOLOR) != 0)
				bundle.putString("color_bg_top", ColorToRGB(VideoAds.color_bg_top));
			
			if((VideoAds.modify & CRunAdMob.BRDCOLOR) != 0)
				bundle.putString("color_border", ColorToRGB(VideoAds.color_border));
			
			if((VideoAds.modify & CRunAdMob.LNKCOLOR) != 0)
				bundle.putString("color_link", ColorToRGB(VideoAds.color_link));
			
			if((VideoAds.modify & CRunAdMob.TXTCOLOR) != 0)
				bundle.putString("color_text", ColorToRGB(VideoAds.color_text));
			
			if((VideoAds.modify & CRunAdMob.URLCOLOR) != 0)
				bundle.putString("color_url", ColorToRGB(VideoAds.color_url));
			
			if(VideoAds.GDPRstatus == 1)
				bundle.putString("npa", "1");
			
			builder.addNetworkExtrasBundle(MediationAdapter.class, bundle);
		}

		VideoAds.init();
		
		// Set your AdListener
		videoreward.setRewardedVideoAdListener(new RewardedVideoAdListener () {

			@Override
			public void onRewarded(RewardItem reward) {
				Log.d("AdMob", "onVideoRewarded");
	    		RestoreAutoEnd();
				lastEvent = rh.rh4EventCount;
				rewardType = reward.getType();
				rewardAmount = reward.getAmount();
				ho.activityEvent(CNDONVIDEOREWARD, 0);
			}

			@Override
			public void onRewardedVideoAdClosed() {
				Log.d("AdMob", "onVideoDismiss");
	    		RestoreAutoEnd();
				lastEvent = rh.rh4EventCount;
				ho.activityEvent(CNDONVIDEODISMISS, 0);
			}

			@Override
			public void onRewardedVideoAdFailedToLoad(int errorCode) {
				Log.d("AdMob", "failed to receive video (" + errorCode + ")");
	    		RestoreAutoEnd();
				szError = errorStringCode(errorCode);
				lastEvent = rh.rh4EventCount;
				ho.pushEvent(CNDONERROR, 0);
			}

			@Override
			public void onRewardedVideoAdLeftApplication() {
				Log.d("AdMob", "onLeaveApplication");
	    		SuspendAutoEnd();
				mmfAdMob.leaving = true;
				mmfAdMob.status = 1;
				lastEvent = rh.rh4EventCount;
				ho.activityEvent(CNDONVIDEOLEAVEAPPS, 0);
			}

			@Override
			public void onRewardedVideoAdLoaded() {
				Log.d("AdMob", "Did Receive Video");
	    		SuspendAutoEnd();
				lastEvent = rh.rh4EventCount;
				ho.pushEvent(CNDONVIDEORECEIVED, 0);				
			}

			@Override
			public void onRewardedVideoAdOpened() {
				Log.d("AdMob", "onVideoPresent");
	    		SuspendAutoEnd();
				lastEvent = rh.rh4EventCount;
				ho.activityEvent(CNDONVIDEOPRESENT, 0);
			}

			@Override
			public void onRewardedVideoStarted() {
				Log.d("AdMob", "onVideoStarted");
	    		SuspendAutoEnd();
				lastEvent = rh.rh4EventCount;
				ho.activityEvent(CNDONVIDEOSTARTED, 0);
			}
			@Override
			public void onRewardedVideoCompleted() {
				Log.d("AdMob", "onVideoCompleted");
				SuspendAutoEnd();
			}
		});

		AdRequest request = builder.build();
		// and begin loading your video ad
		videoreward.loadAd(VideoAds.VideoID, request);
		request = null;
		
		MMFRuntime.inst.runOnUiThread(new Runnable(){

			@Override
			public void run() {
				try
				{
					synchronized(SurfaceView.inst)
					{
						mmfAdMob.status = 0;
						videoreward.show();
					}
				}
				catch(Exception e)
				{
					Log.d("AdMob", "Exception error on video rewards");
				}
			}
			
		});		

	}

	//////////////////////////////////////////////////////////////////////
	//
	//			Control functions
	//
	/////////////////////////////////////////////////////////////////////

	private void RestoreAutoEnd() {
		if(appEndOn) {
			appEndOn = false;
			MMFRuntime.inst.app.hdr2Options |= CRunApp.AH2OPT_AUTOEND;
		}
	}

	private void SuspendAutoEnd() {
		//AH2OPT_AUTOEND
		if (!appEndOn && MMFRuntime.inst.app != null && (MMFRuntime.inst.app.hdr2Options & CRunApp.AH2OPT_AUTOEND) != 0) {
			appEndOn = true;
			MMFRuntime.inst.app.hdr2Options &= ~ CRunApp.AH2OPT_AUTOEND;
		}
	}

	public CRunAdMob()
	{
		MMFRuntime.ADMOB = true;
		expRet = new CValue(0);
	}

	public @Override int getNumberOfConditions()
	{
		return CND_LAST;
	}

	public @Override boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
	{
		file.bUnicode = true;
		file.readShort();
		file.readShort();
		file.readShort();
		file.readShort();

		short flag = file.readShort();
		short Adflag = file.readShort();
        if(version >= 5)
            ADMOB_APP_ID = file.readString(65);
		ADMOB_BANNER_ID = file.readString(65);
		INTERSTITIAL_ID = file.readString(65);
		if(version >=4)
			VIDEOREWARD_ID = file.readString(65);
       if(version >= 6)
	    file.readString(65);
		file.readString(65);
		file.readString(65);
		file.readString(65);
		TESTLISTDEVICES = file.readString(4097);
	
		
		mmfAdMob = new AdMobAds();

		mmfAdMob.adSize = AdSize.BANNER;

        if(ADMOB_APP_ID.length() >0)
            mmfAdMob.AppID = ADMOB_APP_ID.replaceAll("[\\r\\n]", "");

		if(ADMOB_BANNER_ID.length() >0)
			mmfAdMob.AdMobID = ADMOB_BANNER_ID.replaceAll("[\\r\\n]", "");
		
		// Don't take android properties value anymore from version 286

		if(INTERSTITIAL_ID.length() > 0)
			mmfAdMob.IntersID = INTERSTITIAL_ID.replaceAll("[\\r\\n]", "");
		
		if(version >= 4 && VIDEOREWARD_ID.length() > 0)
			mmfAdMob.VideoID = VIDEOREWARD_ID.replaceAll("[\\r\\n]", "");

		// Filtering Carry return Line Feed to commas and two commas to one
		TESTLISTDEVICES = TESTLISTDEVICES.replaceAll("[\\r\\n]", ",");
		TESTLISTDEVICES = TESTLISTDEVICES.replaceAll("[,,]", ",");
		
		if(TESTLISTDEVICES.length() > 0) {
			mmfAdMob.adMobTestDeviceID = TESTLISTDEVICES;
		}
		
		// Converting Size from structure
		if((Adflag & ADFLG_STAND) != 0)
			mmfAdMob.adSize = AdSize.BANNER;

		else if((Adflag & ADFLG_MEDIUM) != 0)
			mmfAdMob.adSize = AdSize.MEDIUM_RECTANGLE;

		else if((Adflag & ADFLG_FULL) != 0)
			mmfAdMob.adSize = AdSize.FULL_BANNER;

		else if((Adflag & ADFLG_LEADER) != 0)
			mmfAdMob.adSize = AdSize.LEADERBOARD;

		else if((Adflag & ADFLG_SMART) != 0)
			mmfAdMob.adSize = AdSize.SMART_BANNER;

		// Converting Align from structure
		if((Adflag & ADFLG_BOTTOM) != 0)
			mmfAdMob.displayWhere = 0;

		else if((Adflag & ADFLG_TOP) != 0)
			mmfAdMob.displayWhere = 1;

		else if((Adflag & ADFLG_CENTER) != 0)
			mmfAdMob.displayWhere = 2;

		// Converting ZOrder from structure
        mmfAdMob.displayOverFrame = (flag & ADFLG_ABOVE) != 0;


		rewardType = "";
		rewardAmount = 0;

		return false;
	}

	private void destroyAds()
	{
		if (adView != null)
		{
		    adView.setEnabled(false);
		    adView.setVisibility(View.GONE);
		    adView.setAdListener(null);
			MMFRuntime.inst.container.removeView (adView);
			adView.destroy();
			adView = null;
			mmfAdMob.loaded = false;
			System.gc();
		}
	}
	public @Override void destroyRunObject(boolean bFast)
	{
		Log.d("AdMob", "Destroying Admob Object");
		if (adView != null)
		{
			adView.pause();
			destroyAds();
			Log.d("AdMob", "Cleaning Done ...");
		}
		
		if(interstitial != null)
			interstitial = null;
		
		if(videoreward != null)
		{
		    videoreward.setRewardedVideoAdListener(null);
			videoreward = null;
		}
		RestoreAutoEnd();
		
		mmfAdMob = null;
		
	}

    public @Override void pauseRunObject()
    {
    	//Log.d("AdMob","AutoEnd is: "+((MMFRuntime.inst.app.hdr2Options & CRunApp.AH2OPT_AUTOEND) != 0 ? "yes":"no "));
    	Log.d("AdMob","Paused");
		if (adView != null && mmfAdMob.loaded) 
            adView.pause();
		
		if(videoreward != null)
			videoreward.pause(MMFRuntime.inst);
    }
    
    public @Override void continueRunObject()
    {
       	//Log.d("AdMob","AutoEnd is: "+((MMFRuntime.inst.app.hdr2Options & CRunApp.AH2OPT_AUTOEND) != 0 ? "yes":"no "));
    	Log.d("AdMob","Resumed");
     	if (adView != null)
			adView.resume();

    	if(videoreward != null)
    		videoreward.resume(MMFRuntime.inst);

    	if(MMFRuntime.inst.isScreenOn || mmfAdMob.leaving)
    		RestoreAutoEnd();
    	
		lastEvent = rh.rh4EventCount;
    	if(ho != null && mmfAdMob.status == 1 && mmfAdMob.leaving) 
    	{
    		ho.pushEvent(CNDONACTIVITY, 0);
			mmfAdMob.status = 0;
    	}
    }
    
    public @Override int handleRunObject()
    {
        return REFLAG_ONESHOT;
    }

    @Override
	public void onDestroy() {
		if (adView != null) {
			destroyAds();
	        Log.v("","Destroyed before end");
		}
		if(interstitial != null)
			interstitial = null;
		
		if(videoreward != null)
			videoreward = null;
		
	}
    
	// Conditions
	// -------------------------------------------------
	public @Override boolean condition(int num, CCndExtension cnd)
	{
		switch (num)
		{
		case CNDRECEIVEDAD:
			return cndReceivedAd(cnd);
		case CNDFAILEDAD:
			return cndFailedAd(cnd);
		case CNDONPRESENTSCREEN:
			return cndOnPresentScreen(cnd);
		case CNDONDISMISSSCREEN:
			return cndOnDismissScreen(cnd);
		case CNDONLEAVEAPPS:
			return cndOnLeaveApps(cnd);
		case CNDADSREADY:
			return cndIntersReady(cnd);
		case CNDONACTIVITY:
			return cndOnActivity(cnd);
		case CNDONERROR:
			return cndOnError(cnd);
        case CNDONVIDEORECEIVED:
            return cndOnVideoReceived(cnd);
        case CNDONVIDEOFAILED:
            return cndOnVideoFailed(cnd);
        case CNDONVIDEOPRESENT:
            return cndOnVideoPresent(cnd);
        case CNDONVIDEODISMISS:
            return cndOnVideoDismiss(cnd);
        case CNDONVIDEOLEAVEAPPS:
            return cndOnVideoLeaveApps(cnd);
        case CNDVIDEOLOADED:
            return cndVideoLoaded(cnd);
        case CNDONVIDEOSTARTED:
            return cndOnVideoStarted(cnd);
        case CNDONVIDEOREWARD:
            return cndOnVideoReward(cnd);
		}
		return false;
	}

	// Actions
	// -------------------------------------------------
	public @Override void action(int num, CActExtension act)
	{
		switch (num)
		{
		case ACTADSIZE:
			actAdSize(act);
			break;
		case ACTADPOS:
			actAdPos(act);
			break;
		case ACTADZORDER:
			actAdZOrder(act);
			break;
		case ACTADREQUEST:
			actAdRequest(act);
			break;
		case ACTADSHOW:
			actAdShow(act);
			break;
		case ACTADDESTROY:
			actAdDestroy(act);
			break;
		case ACTINTERREQUEST:
			actInterRequest(act);
			break;
		case ACTINTERSHOW:
			actInterShow(act);
			break;
		case ACTINTERDESTROY:
			actInterDestroy(act);
			break;
		case ACTSETGENDER:
			actSetGender(act);
			break;
		case ACTSETLOCATION:
			actSetLocation(act);
			break;
		case ACTSETBIRTHDAY:
			actSetBirthday(act);
			break;
		case ACTCPPA:
			actCPPA(act);
			break;
		case ACTTESTDEVICE:
			actTestDevice(act);
			break;
		case ACTBCKCOLOR:
			actBckColor(act);
			break;
		case ACTBORDERCOLOR:
			actBorderColor(act);
			break;
		case ACTLINKCOLOR:
			actLinkColor(act);
			break;
		case ACTTEXTCOLOR:
			actTextColor(act);
			break;
		case ACTURLCOLOR:
			actURLColor(act);
			break;
        case ACTVIDEOREQUEST:
            actVideoRequest(act);
            break;
        case ACTVIDEOSHOW:
            actVideoShow(act);
            break;
        case ACTVIDEODESTROY:
            actVideoDestroy(act);
            break;
        case ACTSETSTATUS:
            actSetEUStatus(act);
            break;
		}
	}

	// Expressions
	// -------------------------------------------------
	public @Override CValue expression(int num)
	{
		switch (num)
		{
		case EXPERROR:
			return expStringError();
		case EXPDEVID:
			return expDeviceId();
        case EXPREWARDTYPE:
            return expRewardType();
        case EXPREWARDAMOUNT:
            return expRewardAmount();
		}
		return null;
	}

	private boolean cndReceivedAd(CCndExtension cnd)
	{
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

	private boolean cndFailedAd(CCndExtension cnd)
	{
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

	private boolean cndOnPresentScreen(CCndExtension cnd)
	{
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

	private boolean cndOnDismissScreen(CCndExtension cnd)
	{
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

	private boolean cndOnLeaveApps(CCndExtension cnd)
	{
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

	private boolean cndIntersReady(CCndExtension cnd)
	{
        return interstitial != null && interstitial.isLoaded();

    }
	
	private boolean cndOnActivity(CCndExtension cnd)
	{
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

	private boolean cndOnError(CCndExtension cnd)
	{
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }
	
    private boolean cndOnVideoReceived(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

    private boolean cndOnVideoFailed(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

    private boolean cndOnVideoPresent(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

    private boolean cndOnVideoDismiss(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

    private boolean cndOnVideoLeaveApps(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

    private boolean cndVideoLoaded(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

    private boolean cndOnVideoStarted(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }

    private boolean cndOnVideoReward(CCndExtension cnd)
    {
		// If this condition is first, then always true
		if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		{
			return true;
		}

		// If condition second, check event number matches
        return rh.rh4EventCount == lastEvent;

    }
    
    
    //////////////////////////////////////////////////////////////
	//
	//				Actions
	//
	//////////////////////////////////////////////////////////////
	
	private void actAdSize(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		switch(param0) {
		case 0:
			mmfAdMob.adSize = AdSize.BANNER;
			break;

		case 1:
			mmfAdMob.adSize = AdSize.MEDIUM_RECTANGLE;
			break;

		case 2:
			mmfAdMob.adSize = AdSize.FULL_BANNER;
			break;

		case 3:
			mmfAdMob.adSize = AdSize.LEADERBOARD;
			break;

		case 4:
			mmfAdMob.adSize = AdSize.SMART_BANNER;
			break;
		}
		Log.d("AdMob", "set size ...");
	}

	private void actAdPos(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 == 0)
			mmfAdMob.displayWhere = 0;
		else if (param0 == 1)
			mmfAdMob.displayWhere = 1;
		else if (param0 == 2)
			mmfAdMob.displayWhere = 2;

	}

	private void actAdZOrder(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
        mmfAdMob.displayOverFrame = param0 == 0;
	}

	private void actAdRequest(CActExtension act)
	{
	}

	private void actAdShow(CActExtension act)
	{
		if(mmfAdMob != null) {
			try {
				mmfAdMob.GDPRstatus = this.consentStatus;
				this.setAdMob(mmfAdMob);
				Log.d("AdMob", "show banner ...");
			}
			catch (Exception e) {
				Log.e("AdMob","Problem integrating Ads, "+e.toString());
			}
		}
	}

	private void actAdDestroy(CActExtension act)
	{
		if (adView != null)
		{
			MMFRuntime.inst.container.removeView (adView);
			adView.destroy();
			adView.destroyDrawingCache();
			adView = null;
			mmfAdMob.init();
		}
	}

	private void actInterRequest(CActExtension act)
	{
		if(mmfAdMob != null)
		{
			mmfAdMob.GDPRstatus = this.consentStatus;
			this.setInterstitial(mmfAdMob);
		}
	}

	private void actInterShow(CActExtension act)
	{
		if(interstitial != null && interstitial.isLoaded())
		{
			interstitial.show();
		}
	}

	private void actInterDestroy(CActExtension act)
	{
		if (interstitial != null)
			interstitial = null;    	
		mmfAdMob.init();
	}

	private void actSetGender(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		switch(param0) {
		case 0:
			mmfAdMob.gender = AdRequest.GENDER_UNKNOWN;
			break;
		case 1:
			mmfAdMob.gender = AdRequest.GENDER_MALE;
			break;
		case 2:
			mmfAdMob.gender = AdRequest.GENDER_FEMALE;
			break;
		}
	}

	private void actSetLocation(CActExtension act)
	{
		float param0 = act.getParamExpFloat(rh,0);
		float param1 = act.getParamExpFloat(rh,1);

		if(mmfAdMob != null) {
			mmfAdMob.location = new Location("Here");
			mmfAdMob.location.setLatitude(param0);
			mmfAdMob.location.setLongitude(param1);
		}
	}

	private void actSetBirthday(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			try {
				int year = Integer.valueOf(param0.substring(0, 4));
				int month = Integer.valueOf(param0.substring(4, 6));
				int day = Integer.valueOf(param0.substring(6, 8));
				
				mmfAdMob.birthday = new GregorianCalendar(year, month, day).getTime();
			}
			catch (IndexOutOfBoundsException e) {
				Log.d("AdMob", "Wrong birthday data ...");
				mmfAdMob.birthday = null;
			}
		}

	}

	private void actCPPA(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(mmfAdMob != null  && param0 >=0 && param0 < 2) {
			mmfAdMob.child_treat = param0;
			mmfAdMob.modify |= CPPAFLAG;
		}

	}

	private void actTestDevice(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			// Filtering Carry return Line Feed to commas and two commas to one
			param0 = param0.replaceAll("[\\r\\n]", ",");
			param0 = param0.replaceAll("[,,]", ",");
			mmfAdMob.adMobTestDeviceID = TESTLISTDEVICES = param0;
		}
	}

	private void actBckColor(CActExtension act)
	{
		int param0 = act.getParamColour(rh, 0);
		if(mmfAdMob != null) {
			mmfAdMob.color_bg = param0; 
			mmfAdMob.modify |= BCKCOLOR;
		}

	}

	private void actBorderColor(CActExtension act)
	{
		int param0 = act.getParamColour(rh, 0);
		if(mmfAdMob != null) {
			mmfAdMob.color_bg = param0;
			mmfAdMob.modify |= BRDCOLOR;
		}
	}

	private void actLinkColor(CActExtension act)
	{
		int param0 = act.getParamColour(rh, 0);
		if(mmfAdMob != null) {
			mmfAdMob.color_bg = param0; 
			mmfAdMob.modify |= LNKCOLOR;
		}
	}

	private void actTextColor(CActExtension act)
	{
		int param0 = act.getParamColour(rh, 0);
		if(mmfAdMob != null) {
			mmfAdMob.color_bg = param0; 
			mmfAdMob.modify |= TXTCOLOR;
		}
	}

	private void actURLColor(CActExtension act)
	{
		int param0 = act.getParamColour(rh, 0);
		if(mmfAdMob != null) {
			mmfAdMob.color_bg = param0;
			mmfAdMob.modify |= URLCOLOR;
		}
	}
	
    private void actVideoRequest(CActExtension act)
    {
		if(mmfAdMob != null)
		{
			mmfAdMob.GDPRstatus = this.consentStatus;
			this.setVideoReward(mmfAdMob);
		}
    }

    private void actVideoShow(CActExtension act)
    {
		if(videoreward != null && videoreward.isLoaded())
		{
			videoreward.show();
		}
    }

    private void actVideoDestroy(CActExtension act)
    {
		if (videoreward != null)
			videoreward = null;    	
		mmfAdMob.init();
    }

	
	private void actSetEUStatus(CActExtension act)
	{
		int p1 = act.getParamExpression(rh, 0)+1;
		if(p1 < 0 || p1 > 2)
			return;
		
	}
	
	/////////////////////////////////////////////////////
	//
	//				Expression
	//
	/////////////////////////////////////////////////////
	private CValue expStringError()
	{
		expRet.forceString("");
		if(szError != null)
			expRet.forceString(szError);
		
		return expRet;
	}

	private CValue expDeviceId()
	{
		String androidId =  Settings.Secure.getString(MMFRuntime.inst.getContentResolver(), Settings.Secure.ANDROID_ID);
		String deviceId = MD5(androidId).toUpperCase(Locale.ENGLISH);
		expRet.forceString(deviceId);		
		return expRet;
	}
	
    private CValue expRewardType()
    {
        expRet.forceString(rewardType);
        return expRet;
    }

    private CValue expRewardAmount()
    {
        expRet.forceInt(rewardAmount);
        return expRet;
    }
	
	
	/////////////////////////////////////////////////////
	//
	//				Utilities
	//
	/////////////////////////////////////////////////////
	public String MD5(String md5) {
		try 
		{
			java.security.MessageDigest MsgD = java.security.MessageDigest.getInstance("MD5");
			byte[] bArray = MsgD.digest(md5.getBytes());
			StringBuffer sBuffer = new StringBuffer();
			for (int i = 0; i < bArray.length; ++i) {
				sBuffer.append(Integer.toHexString((bArray[i] & 0xFF) | 0x100).substring(1,3));
			}
			return sBuffer.toString();
		} 
		catch (java.security.NoSuchAlgorithmException e)
		{
			Log.d("AdMob", "Problem reading device id ...");
		}
		return "";
	}
	

}
