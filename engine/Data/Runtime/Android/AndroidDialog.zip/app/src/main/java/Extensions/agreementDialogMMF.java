/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;

public class agreementDialogMMF {
	
	private CExtension ho = null;
	private Dialog dlg= null;
	
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public String Title = null;
	public String Msg  = null;
	public String Icon  = null;
	public String Buttons = null;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;
	
	public int nTheme;
	public boolean bFontTheme;
	public int TitleColor;

	public Drawable dDraw = null;
	
	public String AgreeText = null;
	public String AgreeHTML = null;
	public String AcceptedLabel = null;
	public int AcceptedTerms;
	
	public String [] Button = null;
	
	public int RetAccepted;
	
	int width;
	int height;

	/////////////////////
	//
	// Constructors
	//
	/////////////////////
	
	public agreementDialogMMF(CExtension ho, OnAgreementResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
	}	
	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnAgreementResultListener mListener;
	
	public interface OnAgreementResultListener {
		public abstract void onClick(String Id, String bRet, int nRet, int Accepted);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnAgreementResultListener(OnAgreementResultListener listener) {
		mListener = listener;
	}
	
	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

    public void DoShow() {

       	UtilityDialog utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);
       	
       	AlertDialog agreementDialog = null;
       	
       	if(ctw == null) {
       		agreementDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
       	}
       	else
       		agreementDialog = new AlertDialog.Builder(ctw).create();
    		
    	
      		
    	
    	dlg = agreementDialog;
    	
    	if(TitleColor != -1) {
    		String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
    		agreementDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
    	}
    	else
    		agreementDialog.setTitle(Title);				 // Title Text
    	
    	agreementDialog.setIcon(dDraw); 					// Icon
    	
        LayoutInflater inflater = agreementDialog.getLayoutInflater();
        ////////////////////////////////////////////////////////////////
        //
        //                   GetResources IDs
        //
        ////////////////////////////////////////////////////////////////
        
        final View dialoglayout = inflater.inflate(utilityDialog.getLayoutByName("dialog_agreement"), null);
        agreementDialog.setView(dialoglayout);
    	
    	// Agreement Text control
		final TextView agreement = (TextView) dialoglayout.findViewById( utilityDialog.getIDsByName("agreement") );
		
		// Set CheckBox control and operations
		CheckBox accepted = (CheckBox) dialoglayout.findViewById( utilityDialog.getIDsByName("agreecheck") ); 

		if(accepted != null) {
			if(AcceptedLabel != null) {
				accepted.setChecked(AcceptedTerms == 1 ? true : false);
				accepted.setText(AcceptedLabel);

				accepted.setOnCheckedChangeListener(new OnCheckedChangeListener() {
					@Override
					public void onCheckedChanged(CompoundButton arg0, boolean isChecked) {
						RetAccepted = isChecked ? 1: 0;
					}
				});
			}
			else
				accepted.setVisibility(View.GONE);
		}
		
		
		/////////////////////////////////////////////////////////////////
		//
		//				Message for agreement
		//
		/////////////////////////////////////////////////////////////////
		AgreeText = Msg;
		
		if(agreement != null) {
			if(AgreeText != null)
				agreement.setText(AgreeText);
			if(AgreeHTML != null)
				agreement.setText(Html.fromHtml(AgreeHTML));
		}
		        	
 		int flag[] = {0,1,2};
 		
    	if(Buttons != null) {
    		int nCount = 0;
    		if(Buttons.lastIndexOf(",") != (Buttons.length()-1))
    			Buttons += ",";
    		
    		String[] items = Buttons.split(",");
    		Button = items.clone();
    		for (String item : items)
    		{
    			if(item.length() > 0) {
    				if(nCount == flag[0])
    					agreementDialog.setButton( DialogInterface.BUTTON_POSITIVE, item, new DialogInterface.OnClickListener() { //Button 1 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 1 was clicked?
    							nRet = 1;
    							bRet = Button[nRet-1];
      							onDismiss();

    						} });
    				if(nCount == flag[1])
    					agreementDialog.setButton(DialogInterface.BUTTON_NEUTRAL, item, new DialogInterface.OnClickListener() { //Button 2 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 2 was clicked?	  
    							nRet = 2;
    							bRet = Button[nRet-1];
    							onDismiss();

    						} });

    				if(nCount == flag[2])
    					agreementDialog.setButton(DialogInterface.BUTTON_NEGATIVE, item, new DialogInterface.OnClickListener() { //Button 3 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 3 was clicked?
    							nRet = 3;
    							bRet = Button[nRet-1];
    							onDismiss();

    						} });

    				nCount++;
    			}
    		}
    	}
    	
    	agreementDialog.setCancelable(false);
    	
    	utilityDialog.requestDialogFeatures(agreementDialog);
    	  	
    	utilityDialog.setWorkingView(dialoglayout);
    	
		agreementDialog.show(); //Show the dialog
    	
    	if(!bFontTheme) {
    		utilityDialog.resizeTitle(agreementDialog);
    		utilityDialog.resizeMessage(agreementDialog);
    	}

    	utilityDialog.updateSize(nSize, nAlign);
    }
	    
	public void clear(){
		// return Values
		Id = null;
		bRet = null;
		Tag = null;
		sRet = null;
		nRet = -1;

		Title = null;
		Msg   = null;
		Icon  = null;
		Buttons = null;

		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;
		bFontTheme = false;
		
		AgreeText = null;
	}
	
	private void onDismiss() {
		mListener.onClick(Id, bRet, nRet, RetAccepted);
	}

	public Dialog getDialog() {
		return dlg;
	}
}
