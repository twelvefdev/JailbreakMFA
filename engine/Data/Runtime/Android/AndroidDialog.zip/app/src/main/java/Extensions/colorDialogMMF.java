/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;


import Extensions.ColorPickerView.OnColorChangedListener;
import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;

public class colorDialogMMF {
	
	private CExtension ho = null;
	private Dialog dlg= null;
	
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public int Type = 1;

	public String Title   = null;
	public String Msg    = null;
	public String Icon    = null;
	public String Buttons = null;
	
	public String[] Button = null;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;
	
	public int nTheme;
	public boolean bFontTheme;
	
	public int TitleColor;
	
	public Drawable dDraw = null;
	
	public int RetColor;
	public int RetAlpha;
	
	int width;
	int height;
	
	private static AlertDialog colorDialog = null;

	/////////////////////
	//
	// Constructors
	//
	/////////////////////

	public colorDialogMMF(CExtension ho, OnColorResultListener listener) {
		this.ho = ho;
		this.mListener = listener;
	}
	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnColorResultListener mListener;
	
	public interface OnColorResultListener {
		public abstract void onClick(String Id, String bRet, int nRet, int RetColor, int RetAlpha);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnColorResultListener(OnColorResultListener listener) {
		mListener = listener;
	}
	
    private OnColorChangedListener cListener = new OnColorChangedListener() {
        @Override
		public void colorChanged(int color, boolean flag) {
            RetColor = (color & 0x00FF0000) >> 16 | (color & 0x0000FF00) | (color & 0x000000FF) << 16;
            RetAlpha = 256;
            if(Buttons == null && flag) {
            	colorDialog.dismiss();
				mListener.onClick(Id, "", -1, RetColor, RetAlpha);
            }	
        }
    };	
    
 	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////
    public void DoShow(int lColor) {
    	
       	UtilityDialog utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);
       	
       	if(ctw == null) {
       		colorDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
       	}
       	else
       		colorDialog = new AlertDialog.Builder(ctw).create();
		
    	dlg = colorDialog;
    	
    	// To Avoid color branding.
    	colorDialog.getWindow().setFormat(PixelFormat.RGBA_8888);

    	
    	if(TitleColor != -1) {
    		String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
    		colorDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
    	}
    	else
    		colorDialog.setTitle(Title);						// Title Text
    	
    	colorDialog.setMessage(Msg); 					 // Message Text
    	colorDialog.setIcon(dDraw); 					 // Icon
    	
        
        final LinearLayout dialoglayout = new LinearLayout(ctw);
        
        dialoglayout.setOrientation(LinearLayout.HORIZONTAL);
        dialoglayout.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        dialoglayout.setGravity(Gravity.CENTER);
        
        int ratio = 1;
        
        if(utilityDialog.getScreenHeight() > 700 || utilityDialog.getScreenWidth() > 500)
        	ratio = 2;
        if(utilityDialog.getScreenHeight() > 1200 || utilityDialog.getScreenWidth() > 1200)
        	ratio = 3;
        
        ColorPickerView mView = new ColorPickerView(ho.getControlsContext(), cListener, 0xFF000000 | (lColor & 0x00FF0000) >> 16 | (lColor & 0x0000FF00) | (lColor & 0x000000FF) << 16, 3);

        dialoglayout.addView(mView);
        
        colorDialog.setView(dialoglayout);
    	

 		int flag[] = {0,1,2};
 		
    	if(Buttons != null) {
    		int nCount = 0;
    		if(Buttons.lastIndexOf(",") != (Buttons.length()-1))
    			Buttons += ",";
    		
    		String[] items = Buttons.split(",");
    		Button = items.clone();
    		for (String item : items)
    		{
    			if(item.length() > 0) {
    				if(nCount == flag[0])
    					colorDialog.setButton( DialogInterface.BUTTON_POSITIVE, item, new DialogInterface.OnClickListener() { //Button 1 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 1 was clicked?
    							nRet = 1;
    							bRet = Button[nRet-1];
    							mListener.onClick(Id, bRet, nRet, RetColor, RetAlpha);

    						} });
    				if(nCount == flag[1])
    					colorDialog.setButton( DialogInterface.BUTTON_NEUTRAL, item, new DialogInterface.OnClickListener() { //Button 2 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 2 was clicked?	  
    							nRet = 2;
    							bRet = Button[nRet-1];
    							mListener.onClick(Id, bRet, nRet, RetColor, RetAlpha);

    						} });

    				if(nCount == flag[2])
    					colorDialog.setButton( DialogInterface.BUTTON_NEGATIVE, item, new DialogInterface.OnClickListener() { //Button 3 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 3 was clicked?
    							nRet = 3;
    							bRet = Button[nRet-1];
    							mListener.onClick(Id, bRet, nRet, RetColor, RetAlpha);

    						} });

    				nCount++;
    			}
    		}
    	} else {
    		colorDialog.setOnKeyListener(new Dialog.OnKeyListener() {

				@Override
				public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
					if (keyCode == KeyEvent.KEYCODE_BACK) {
						dialog.dismiss();
						return true;
					}
					return false;
				}				
			});
		}
    	
    	colorDialog.setCancelable(false);
    	
    	utilityDialog.requestDialogFeatures(colorDialog);
    	
    	utilityDialog.setWorkingView(mView);
    	
    	colorDialog.show(); //Show the dialog   	
 	
    	if(!bFontTheme) {
    		utilityDialog.resizeTitle(colorDialog);
    		utilityDialog.resizeMessage(colorDialog);
    	}
    	
    	if(Button == null && Title == null && Msg == null) 
    	{
    		utilityDialog.Align(nAlign);
    		utilityDialog.forceSize(250, 250);
    	}
    	else
    		utilityDialog.updateSize(nSize, nAlign);
    	
    	if(nSize > 2)
    		ratio =1;
    	
    	mView.setRatio(ratio);
    }

	public void clear(){
		// return Values
		Id   = null;
		bRet = null;
		Tag  = null;
		sRet = null;
		nRet = -1;

		Title   = null;
		Msg     = null;
		Icon    = null;
		Buttons = null;
		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;
		bFontTheme = false;
		RetColor = 0xFFFFFFFF;

	}

	public Dialog getDialog() {
		return dlg;
	}
	
}

