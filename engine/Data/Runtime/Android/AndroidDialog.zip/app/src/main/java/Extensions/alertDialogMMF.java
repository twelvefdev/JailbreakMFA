/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;


import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.view.ContextThemeWrapper;

public class alertDialogMMF {

	private CExtension ho = null;
	private Dialog dlg= null;
	
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public int Type = 1;

	public String Title   = null;
	public String Msg    = null;
	public String Icon    = null;
	public String Buttons = null;
	public boolean bFontTheme = false;
	
	public String[] Button = null;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;
	
	public int nTheme;
	public int TitleColor;
	public Drawable dDraw = null;
	
	int width;
	int height;
	
	/////////////////////
	//
	// Constructors
	//
	/////////////////////
	public alertDialogMMF(CExtension ho, OnAlertResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
	}
	
	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnAlertResultListener mListener;
	
	public interface OnAlertResultListener {
		public abstract void onClick(String Id, String bRet, int nRet);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnAlertResultListener(OnAlertResultListener listener) {
		mListener = listener;
	}
	
	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

    public void DoShow(String m) {
    	
       	UtilityDialog utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);
       	
       	AlertDialog alertDialog = null;
       	
       	if(ctw == null) {
      		alertDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
       	}
       	else
       		alertDialog = new AlertDialog.Builder(ctw).create();
   	
    	dlg = alertDialog;
   	    
    	if(TitleColor != -1) {
    		String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
    		alertDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
    	}
    	else
    		alertDialog.setTitle(Title);				 // Title Text
        
    	if(m.length() > 0)
        	alertDialog.setMessage(m); 					 // New Message Text
    	else
    		alertDialog.setMessage(Msg); 				 // Message Text
    	
    	alertDialog.setIcon(dDraw); 					 // Icon
    	
 		int flag[] = {0,1,2};
 		
    	if(Buttons != null) {
    		int nCount = 0;
    		if(Buttons.lastIndexOf(",") != (Buttons.length()-1))
    			Buttons += ",";
    		
    		String[] items = Buttons.split(",");
    		Button = items.clone();
    		for (String item : items)
    		{
    			if(item.length() > 0) {
    				if(nCount == flag[0])
    					alertDialog.setButton( DialogInterface.BUTTON_POSITIVE, item, new DialogInterface.OnClickListener() { //Button 1 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 1 was clicked?
    							nRet = 1;
    							bRet = Button[nRet-1];
    							mListener.onClick(Id, bRet, nRet);

    						} });
    				if(nCount == flag[1])
    					alertDialog.setButton( DialogInterface.BUTTON_NEUTRAL, item, new DialogInterface.OnClickListener() { //Button 2 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 2 was clicked?	  
    							nRet = 2;
    							bRet = Button[nRet-1];
    							mListener.onClick(Id, bRet, nRet);

    						} });

    				if(nCount == flag[2])
    					alertDialog.setButton( DialogInterface.BUTTON_NEGATIVE, item, new DialogInterface.OnClickListener() { //Button 3 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 3 was clicked?
    							nRet = 3;
    							bRet = Button[nRet-1];
    							mListener.onClick(Id, bRet, nRet);

    						} });

    				nCount++;
    			}
    		}
    	}
    	
    	alertDialog.setCancelable(false);
    	
    	utilityDialog.requestDialogFeatures(alertDialog);
    	
    	alertDialog.show(); //Show the dialog   	
 
    	if(!bFontTheme) {
    		utilityDialog.resizeTitle(alertDialog);
    		utilityDialog.resizeMessage(alertDialog);
    	}

    	utilityDialog.updateSize(nSize, nAlign);
    }

	public void clear(){
		// return Values
		Id   = null;
		bRet = null;
		Tag  = null;
		sRet = null;
		nRet = -1;

		Title   = null;
		Msg     = null;
		Icon    = null;
		Buttons = null;
		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;
		bFontTheme = false;

	}
	
	public Dialog getDialog() {
		return dlg;
	}

}
