package Extensions;

import Application.CRunApp;
import Objects.CExtension;
import Runtime.Log;
import Runtime.MMFRuntime;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

@SuppressLint("NewApi")
public class notificationDialogMMF {
	
	private CExtension ho = null;
	
	// return Values
	public String   Id = null;
	
	public String title = null;
	public String message = null;
	public String intent = null;
	public String ticker = null;
	public String icon = null;
	
	public int nAction;
	public int nSound;
	public int nVibrate;
	public int number;
	public int nSeconds;
	
	public Drawable dDraw = null;
	public String smallIcon=null;
	
	public notificationDialogMMF(CExtension ho, OnPushListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
	}

	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnPushListener mListener;
	
	public interface OnPushListener {
		public abstract void onNotification(String Id);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnPushListener(OnPushListener listener) {
		mListener = listener;
	}
	
	//////////////////////////////////////////////////////////////////////
	//
	//			Control functions
	//
	/////////////////////////////////////////////////////////////////////
	private boolean appEndOn = false;

	private void RestoreAutoEnd() {
		if(appEndOn) {
			appEndOn = false;
			MMFRuntime.inst.app.hdr2Options |= CRunApp.AH2OPT_AUTOEND;
		}
	}

	private void SuspendAutoEnd() {
		//AH2OPT_AUTOEND
		if (!appEndOn && MMFRuntime.inst.app != null && (MMFRuntime.inst.app.hdr2Options & CRunApp.AH2OPT_AUTOEND) != 0) {
			appEndOn = true;
			MMFRuntime.inst.app.hdr2Options &= ~ CRunApp.AH2OPT_AUTOEND;
		}
	}

	
	@SuppressWarnings("deprecation")
	public void DoPush() {

		Context context = ho.getControlsContext();

		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

		int mID = (int) (System.currentTimeMillis() & 0xFFFFFF);

		Intent mIntent = null;
		
		if(intent != null && intent.length() > 0) {
			switch(nAction) {
			case 0:		//View
				mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(intent));
				break;
			case 1:		//Dial
				mIntent = new Intent(Intent.ACTION_DIAL, Uri.parse(intent));
				break;
			case 2:		//Pick
				mIntent = new Intent(Intent.ACTION_PICK, Uri.parse(intent));
				break;
			case 3:		//Edit
				mIntent = new Intent(Intent.ACTION_EDIT, Uri.parse(intent));
				break;
			case 4:		//Main
				mIntent = new Intent(Intent.ACTION_MAIN, Uri.parse(intent));
				break;
			}
		}
		else
			mIntent = new Intent();

		try
		{

            int notificationId = createID();
            String channelID = null;
            if (MMFRuntime.deviceApi >= 26)
            {
                channelID = "channel-id";
                String channelName = "Channel Name";
                int importance = NotificationManager.IMPORTANCE_DEFAULT;
                NotificationChannel channel = new NotificationChannel(channelID, channelName, importance);
                channel.setDescription("application");
                notificationManager.createNotificationChannel(channel);
            }
            Notification notification = new NotificationCompat.Builder(MMFRuntime.inst)
                    .setAutoCancel(true)
                    .setContentIntent(PendingIntent.getActivity(MMFRuntime.inst, mID, mIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT))
                    .setContentTitle(title)
                    .setContentText(message)
                    .setVisibility(Notification.VISIBILITY_PRIVATE)
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setChannelId(channelID)
                    .setDefaults((nSound != 0 ? Notification.DEFAULT_SOUND : 0) | (nVibrate != 0 ? Notification.DEFAULT_VIBRATE : 0))
                    .setLights(Color.YELLOW, 500, 5000)
                    .setLargeIcon(dDraw != null ? drawableToBitmap(dDraw) : null)
                    .setSmallIcon(((smallIcon != null && smallIcon.length() > 0) ?
                            MMFRuntime.inst.getResourceID("drawable/" + smallIcon)
                            : MMFRuntime.inst.getResourceID("drawable/ic_small_notif_001")))
                     .build();

            notificationManager.notify(notificationId, notification);
            mListener.onNotification(Id);
        } catch (Exception e) {
            Log.Log("Error push notification " + e);
        }

	}

    public int createID() {
        Date now = new Date();
        int id = Integer.parseInt(new SimpleDateFormat("ddHHmmss", Locale.ENGLISH).format(now));
        return id;
    }

    void clear() {
    	Id = null;
    	title = null;
    	message = null;
    	intent = null;
    	ticker = null;
    	nSeconds=0;
   	
    }
    
    
    private static Bitmap drawableToBitmap (Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable)drawable).getBitmap();
        }
        if(drawable == null)
        	return null;
        
        int width = drawable.getIntrinsicWidth();
        width = width > 0 ? width : 1;
        int height = drawable.getIntrinsicHeight();
        height = height > 0 ? height : 1;

        Bitmap bitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap); 
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }
}
