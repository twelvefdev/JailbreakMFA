package Extensions;

import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;

public class loginDialogMMF {
	
	private CExtension ho = null;
	private Dialog dlg= null;
	
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public String Title = null;
	public String Msg  = null;
	public String Icon  = null;
	public String Buttons = null;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;
	
	public int nTheme;
	public int TitleColor;

	public Drawable dDraw = null;
	
	public String LogUser = null;
	public String UserInit = null;
	public String LogPass = null;
	public String LogRemm = null;
	public int PassRemember;
	
	public String [] Button = null;
	
	public String RetUser = null;
	public String RetPass = null;
	public int RetRemm;
	
	int width;
	int height;

	/////////////////////
	//
	// Constructors
	//
	/////////////////////
	
	public loginDialogMMF(CExtension ho, OnLoginResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
	}	
	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnLoginResultListener mListener;
	
	public interface OnLoginResultListener {
		public abstract void onClick(String Id, String bRet, int nRet, String RetUser, String RetPass, int RetRemm);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnLoginResultListener(OnLoginResultListener listener) {
		mListener = listener;
	}
	
	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

    public void DoShow(String usertxt) {

       	UtilityDialog utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);
       	
    	AlertDialog LoginDialog = null;
    	
    	if(ctw != null)
        	LoginDialog = new AlertDialog.Builder(ctw).create();
    	else
        	LoginDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
    	
    	dlg = LoginDialog;
    	
    	if(TitleColor != -1) {
    		String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
    		LoginDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
    	}
    	else
    		LoginDialog.setTitle(Title);				// Title Text

    	LoginDialog.setMessage(Msg); 					// Message Text
    	
    	LoginDialog.setIcon(dDraw); 					// Icon
        LayoutInflater inflater = LoginDialog.getLayoutInflater();
        ////////////////////////////////////////////////////////////////
        //
        //                   GetResources IDs
        //
        ////////////////////////////////////////////////////////////////
                        
    	final View dialoglayout = inflater.inflate(utilityDialog.getLayoutByName("dialog_login"), null);
    	LoginDialog.setView(dialoglayout);
    	
    	// Usename and Password EditText control
		final EditText user = (EditText) dialoglayout.findViewById( utilityDialog.getIDsByName("username") );
		final EditText pass = (EditText) dialoglayout.findViewById( utilityDialog.getIDsByName("password") );
		
		// Set CheckBox control and operations
		CheckBox remm = (CheckBox) dialoglayout.findViewById( utilityDialog.getIDsByName("checkBox1") ); 
		
		remm.setChecked(PassRemember == 1 ? true : false);
		
		remm.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean isChecked) {
				RetRemm = isChecked ? 1: 0;
			}
		});
		
		if(user != null) {
			user.setHint(LogUser);
			if(usertxt.length() == 0) { 
				if(UserInit.length() > 0)
					user.setText(UserInit);
			}
			else
				user.setText(usertxt);
		}
		
		if(pass != null)
			pass.setHint(LogPass);
		
		if(remm != null)
			remm.setText(LogRemm);
		        	
 		int flag[] = {0,1,2};
 		
    	if(Buttons != null) {
    		int nCount = 0;
    		if(Buttons.lastIndexOf(",") != (Buttons.length()-1))
    			Buttons += ",";
    		
    		String[] items = Buttons.split(",");
    		Button = items.clone();
    		for (String item : items)
    		{
    			if(item.length() > 0) {
    				if(nCount == flag[0])
    					LoginDialog.setButton( DialogInterface.BUTTON_POSITIVE, item, new DialogInterface.OnClickListener() { //Button 1 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 1 was clicked?
    							nRet = 1;
    							bRet = Button[nRet-1];
    							RetUser = user.getText().toString();
    							RetPass = pass.getText().toString();
    							dialog.dismiss();
    							onDismiss();

    						} });
    				if(nCount == flag[1])
    					LoginDialog.setButton(DialogInterface.BUTTON_NEUTRAL, item, new DialogInterface.OnClickListener() { //Button 2 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 2 was clicked?	  
    							nRet = 2;
    							bRet = Button[nRet-1];
    							RetUser = user.getText().toString();
    							RetPass = pass.getText().toString();
    							dialog.dismiss();
    							onDismiss();

    						} });

    				if(nCount == flag[2])
    					LoginDialog.setButton(DialogInterface.BUTTON_NEGATIVE, item, new DialogInterface.OnClickListener() { //Button 3 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 3 was clicked?
    							nRet = 3;
    							bRet = Button[nRet-1];
    							RetUser = user.getText().toString();
    							RetPass = pass.getText().toString();
    							dialog.dismiss();
    							onDismiss();

    						} });

    				nCount++;
    			}
    		}
    	}else {
    		LoginDialog.setOnKeyListener(new Dialog.OnKeyListener() {

				@Override
				public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
					if (keyCode == KeyEvent.KEYCODE_BACK) {
						dialog.dismiss();
						nRet = -1;
						bRet = "";
						RetUser = user.getText().toString();
						RetPass = pass.getText().toString();
						return true;
					}
					return false;
				}				
			});
		}
    	
    	LoginDialog.setCancelable(false);
    	
    	utilityDialog.requestDialogFeatures(LoginDialog);
	  	
		LoginDialog.show(); //Show the dialog
    	
    	utilityDialog.resizeTitle(LoginDialog);
    	utilityDialog.resizeMessage(LoginDialog);

     	utilityDialog.updateSize(nSize, nAlign);
		
    }
	
	public void clear(){
		// return Values
		Id = null;
		bRet = null;
		Tag = null;
		sRet = null;
		nRet = -1;

		Title = null;
		Msg   = null;
		Icon  = null;
		Buttons = null;

		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;

	}
	
	private void onDismiss() {
		
		mListener.onClick(Id, bRet, nRet, RetUser, RetPass, RetRemm);
	}

	public Dialog getDialog() {
		return dlg;
	}
	
	
}
