/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.text.Html;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;


public class fileDialogMMF {
	
	private CExtension ho = null;
	private Dialog dlg= null;
  	private AlertDialog fileDialog = null;
	private Context co;

	
    private File currentDir;
    private FileArrayAdapter adapter;
    private ListView ListFiles = null;
    private String pathDir;
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public String Title = null;
	public String Msg  = null;
	public String Icon  = null;
	public String Buttons = null;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;
	
	public int nTheme;
	public boolean bFontTheme;
	public int TitleColor;

	public Drawable dDraw = null;
	
	public Drawable dDrawFolder = null;
	public Drawable dDrawFiles = null;
	public boolean TypeFilePicker;
	
	public String DefaultDir = null;
	public String ParentTxt = "Parent Directory";
	public String FolderTxt = "Folder";
	public String FileTxt = "File Size";
	public String [] Button = null;
	public String sExt = null;
	
	public String RetFile = null;
	public int RetAccepted;
	
	int width;
	int height;
	
	int resFileView = -1;
	boolean once = true;
	
	/////////////////////
	//
	// Constructors
	//
	/////////////////////
    public fileDialogMMF(CExtension ho, OnFileSelResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		once = true;
		clear();
    }
    
	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnFileSelResultListener mListener;
	
	public interface OnFileSelResultListener {
		public abstract void onClick(String Id, String bRet, int nRet, String RetFile);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnFileSelResultListener(OnFileSelResultListener listener) {
		mListener = listener;
	}
	
	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

    public void DoShow(String d) {

       	UtilityDialog utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);
       	       	
       	if(ctw == null) {
       		fileDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
       	}
       	else
       		fileDialog = new AlertDialog.Builder(ctw).create();
    		
    	dlg = fileDialog;
    	
    	if(TitleColor != -1) {
    		String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
    		fileDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
    	}
    	else
    		fileDialog.setTitle(Title);				// Title Text
    	
    	fileDialog.setIcon(dDraw); 					// Icon
    	
        ////////////////////////////////////////////////////////////////
        //
        //                   GetResources IDs
        //
        ////////////////////////////////////////////////////////////////
 
        co = fileDialog.getContext();
        resFileView = utilityDialog.getLayoutByName("file_view");
         
        ListFiles = new ListView(co);
        
        String lDefaultDir = null;
        
        if(DefaultDir == null || DefaultDir.length() == 0)
        	lDefaultDir = Environment.getRootDirectory().getPath();
        else
        	lDefaultDir = DefaultDir;
    	
    	if(d.length() > 0)
    		lDefaultDir = d;
    	    	
        currentDir = new File(lDefaultDir);
        
		fill(currentDir, sExt);
        
    	ListFiles.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> l, View v, int position,	long id) {
	    		FileSelOption o = adapter.getItem(position);
	    		if(o.getData().equalsIgnoreCase(FolderTxt)||o.getData().equalsIgnoreCase(ParentTxt)){
	    			if(o!= null && o.getPath() != null) {
	    				currentDir = new File(o.getPath());
	    				fill(currentDir, sExt);
		    			if(TypeFilePicker && Buttons == null) {
		    				nRet = -1;
		    				bRet = "";
		    				RetFile = pathDir;
		    				fileDialog.dismiss();
		    				mListener.onClick(Id, bRet, nRet, RetFile);
		    			}
	    			}
	    		}
	    		else
	    		{
	    			onFileClick(o);
	    			if(!TypeFilePicker && Buttons == null) {
	    				nRet = -1;
	    				bRet = "";
	    				fileDialog.dismiss();
	    				mListener.onClick(Id, bRet, nRet, RetFile);
	    			}
	    		}
			}
    	});
  
    	ListFiles.setMinimumHeight(300);
        fileDialog.setView(ListFiles);

		if(Buttons == null) {
	        fileDialog.setOnKeyListener(new Dialog.OnKeyListener() {
	
				@Override
				public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
	                if (keyCode == KeyEvent.KEYCODE_BACK) {
	                    dialog.dismiss();
	    				mListener.onClick(Id, "", -1, "");
	                    return true;
	                }
	                return false;
	 			}				
			});
		}
		
 		int flag[] = {0,1,2};
 		
    	if(Buttons != null) {
    		int nCount = 0;
    		if(Buttons.lastIndexOf(",") != (Buttons.length()-1))
    			Buttons += ",";
    		
    		String[] items = Buttons.split(",");
    		Button = items.clone();
    		for (String item : items)
    		{
    			if(item.length() > 0) {
    				if(nCount == flag[0])
    					fileDialog.setButton( DialogInterface.BUTTON_POSITIVE, item, new DialogInterface.OnClickListener() { //Button 1 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 1 was clicked?
    							nRet = 1;
    							bRet = Button[nRet-1];
      							onDismiss(dialog);

    						} });
    				if(nCount == flag[1])
    					fileDialog.setButton(DialogInterface.BUTTON_NEUTRAL, item, new DialogInterface.OnClickListener() { //Button 2 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 2 was clicked?	  
    							nRet = 2;
    							bRet = Button[nRet-1];
    							onDismiss(dialog);

    						} });

    				if(nCount == flag[2])
    					fileDialog.setButton(DialogInterface.BUTTON_NEGATIVE, item, new DialogInterface.OnClickListener() { //Button 3 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 3 was clicked?
    							nRet = 3;
    							bRet = Button[nRet-1];
    							onDismiss(dialog);

    						} });

    				nCount++;
    			}
    		}
    	}
    	
    	fileDialog.setCancelable(false);

    	utilityDialog.requestDialogFeatures(fileDialog);
    	  	
    	utilityDialog.setWorkingView(ListFiles);
    	
		fileDialog.show(); //Show the dialog
    	
    	if(!bFontTheme) {
    		utilityDialog.resizeTitle(fileDialog);
    	}
    	
    	utilityDialog.updateSize(nSize, nAlign);
    }
	
	public void clear(){
		// return Values
		Id = null;
		bRet = null;
		Tag = null;
		sRet = null;
		nRet = -1;

		Title = null;
		Msg   = null;
		Icon  = null;
		Buttons = null;

		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;
		bFontTheme = false;
		
	}
	
    private void fill(File f, String ext)
    {
    	 File[]dirs = f.listFiles();
		 pathDir = f.getPath();
		 List<FileSelOption>dir = new ArrayList<FileSelOption>();
		 List<FileSelOption>fls = new ArrayList<FileSelOption>();
		 try{
			 for(File ff: dirs)
			 {
				if(ff.isDirectory())
					dir.add(new FileSelOption(ff.getName(), FolderTxt, ff.getAbsolutePath()));
				else
				{
					if(!TypeFilePicker && (ext == null || ext.length() == 0 || ff.getAbsolutePath().contains(ext)))
						fls.add(new FileSelOption(ff.getName(), FileTxt+ff.length(), ff.getAbsolutePath()));
				}
			 }
		 }catch(Exception e)
		 {
			 
		 }
		 Collections.sort(dir);
		 Collections.sort(fls);
		 dir.addAll(fls);
		 if(!f.getName().equalsIgnoreCase("sdcard"))
			 dir.add(0,new FileSelOption("..", ParentTxt, f.getParent()));
		 adapter = new FileArrayAdapter(co, resFileView, dir, once, ParentTxt, FolderTxt, dDrawFolder, dDrawFiles);
		 ListFiles.setAdapter(adapter);
		 once = adapter.getFirstTime();
    }
    
    private void onFileClick(FileSelOption o)
    {
    	if(!TypeFilePicker)
    		RetFile = currentDir.getPath() + File.separator + o.getName();
    	else
    		RetFile = pathDir;
    }
	
	private void onDismiss(DialogInterface dialog) {
    	if(TypeFilePicker)
    		RetFile = pathDir;
		
		dialog.dismiss();
		mListener.onClick(Id, bRet, nRet, RetFile);
	}

	public Dialog getDialog() {
		return dlg;
	}
	
}
