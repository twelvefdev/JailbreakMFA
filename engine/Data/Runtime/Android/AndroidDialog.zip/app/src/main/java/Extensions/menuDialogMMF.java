package Extensions;

import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioGroup.LayoutParams;
import android.widget.TextView;


public class menuDialogMMF {
	
	public CExtension ho = null;
	private Context context;
    private MenuArrayAdapter adapter;
    private ListView ListMenus = null;
	private UtilityDialog utilityDialog = null;
    private Dialog dlg;
	private AlertDialog menuDialog = null;
	
    
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public String Title = null;
	public String Msg  = null;
	public String Icon  = null;
	public String Buttons = null;

	public int nAlign;
	
	public int nTheme;
	public int TitleColor;

	public String Items = null;

	public Drawable [] dDraw = null;
	
	public int timeout;
	
	private String [] Item = null;
	
	
	public String RetMenu = null;
	public int RetItem;
	
	int width;
	int height;
	
	float avgwidth;
	
	private int resMenuView;
	private CountDownTimer mTimer =null;
	/////////////////////
	//
	// Constructors
	//
	/////////////////////
    public menuDialogMMF(CExtension ho, OnMenuResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
    }
    
	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnMenuResultListener mListener;
	
	public interface OnMenuResultListener {
		public abstract void onClick(String Id, String RetMenu, int RetItem);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnMenuResultListener(OnMenuResultListener listener) {
		mListener = listener;
	}
	
	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

    public void DoShow() {

       	utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);
       	
    	if(ctw != null)
        	menuDialog = new AlertDialog.Builder(ctw).create();
    	else
        	menuDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
    		
    	dlg = menuDialog;
        ////////////////////////////////////////////////////////////////
        //
        //                   GetResources IDs
        //
        ////////////////////////////////////////////////////////////////
        context = menuDialog.getContext();
        
        resMenuView = utilityDialog.getLayoutByName("menu_view");
        
        Item = Items.split(",");
        
        ListMenus = new ListView(context);
        
		adapter = new MenuArrayAdapter(context);
		ListMenus.setAdapter(adapter);

    	ListMenus.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> l, View v, int position,	long id) {
	    		RetMenu = Item[position];
	    		RetItem = position + 1;
	    		if(mTimer != null)
	    			mTimer.cancel();
	    		menuDialog.dismiss();
	    		mListener.onClick(Id, RetMenu, RetItem);
			}
    	});
  
        menuDialog.setView(ListMenus);
		    	
     	menuDialog.setCancelable(false);
    	
    	utilityDialog.requestDialogFeatures(menuDialog);
    	
		menuDialog.show(); //Show the dialog
    	
    	utilityDialog.Align(nAlign);
    	
   		utilityDialog.forceSize(UtilityDialog.getBestWidthList(ListMenus) + 80, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
    		
		if(timeout != -1) {
			long timer = Long.valueOf(timeout);

			mTimer = new CountDownTimer(timer, 1000)
			{
				@Override
				public void onTick(long millisUntilFinished)
				{
				}

				@Override
				public void onFinish()
				{
					//Finish dialog by Timeout
					menuDialog.dismiss();
					mListener.onClick(Id, "", -1);
				}
			};
			
			mTimer.start();
		}
    }
    
	public void clear(){
		// return Values
		Id = null;
		bRet = null;
		Tag = null;
		sRet = null;
		nRet = -1;

		Title = null;
		Msg   = null;
		//Icon  = null;
		Buttons = null;

		//nAlign = -1;
		
		Item = null;
		dDraw = null;
	}
	
	public Dialog getDialog() {
		return dlg;
	}
	
    private class MenuArrayAdapter extends BaseAdapter {

        private LayoutInflater inflater;

        public MenuArrayAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return Item.length;
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
        	View v = convertView;
        	if (v == null) {
        		v = inflater.inflate(resMenuView, null);
        	}
        	ImageView i1 = (ImageView) v.findViewById( utilityDialog.getIDsByName("imageMenu") );
        	TextView t1 = (TextView)  v.findViewById( utilityDialog.getIDsByName("textMenu") );

        	if(t1!=null && Item != null)
        		t1.setText(Item[position].toString()); 
        	
        	if(i1!=null && dDraw != null)
        		i1.setImageDrawable( dDraw[position] );
        	
        	return v;
        }
    }
    
}
