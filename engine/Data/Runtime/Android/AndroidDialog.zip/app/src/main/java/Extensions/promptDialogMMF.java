/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class promptDialogMMF {
	
	private CExtension ho = null;
	private Dialog dlg= null;
	
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public String Title = null;
	public String Msg  = null;
	public String Icon  = null;
	public String Buttons = null;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;
	
	public int nTheme;
	public boolean bFontTheme;
	public int TitleColor;

	public Drawable dDraw = null;
	
	public String Prompt = null;
	public String PromptInit = null;
	
	public String [] Button = null;
	
	public String RetPrompt = null;
	
	int width;
	int height;

	/////////////////////
	//
	// Constructors
	//
	/////////////////////
	
	public promptDialogMMF(CExtension ho, OnPromptResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
	}	
	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnPromptResultListener mListener;
	
	public interface OnPromptResultListener {
		public abstract void onClick(String Id, String bRet, int nRet, String RetPrompt);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnPromptResultListener(OnPromptResultListener listener) {
		mListener = listener;
	}
	
	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

    public void DoShow(String ptxt) {

       	UtilityDialog utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);
       	
    	AlertDialog PromptDialog = null;
    	
       	if(ctw == null) {
       		PromptDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
       	}
       	else
       		PromptDialog = new AlertDialog.Builder(ctw).create();
    		
    	dlg = PromptDialog;
    	
    	if(TitleColor != -1) {
    		String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
    		PromptDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
    	}
    	else
    		PromptDialog.setTitle(Title);	// Title Text

    	PromptDialog.setMessage(Msg); 					// Message Text
    	
    	PromptDialog.setIcon(dDraw); 					// Icon
        LayoutInflater inflater = PromptDialog.getLayoutInflater();
        
    	final View dialoglayout = inflater.inflate(utilityDialog.getLayoutByName("dialog_prompt"), null);
    	PromptDialog.setView(dialoglayout);
    	
    	// Prompt EditText control
		final EditText prompt = (EditText) dialoglayout.findViewById( utilityDialog.getIDsByName("prompttext") );
		
		
		if(prompt != null) {
			prompt.setHint(Prompt);
			if(ptxt.length() == 0) {
				if(PromptInit != null && PromptInit.length() > 0)
					prompt.setText(PromptInit);
			}
			else
				prompt.setText(ptxt);
		}
		        	
 		int flag[] = {0,1,2};
 		
    	if(Buttons != null) {
    		int nCount = 0;
    		if(Buttons.lastIndexOf(",") != (Buttons.length()-1))
    			Buttons += ",";
    		
    		String[] items = Buttons.split(",");
    		Button = items.clone();
    		for (String item : items)
    		{
    			if(item.length() > 0) {
    				if(nCount == flag[0])
    					PromptDialog.setButton( DialogInterface.BUTTON_POSITIVE, item, new DialogInterface.OnClickListener() { //Button 1 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 1 was clicked?
    							nRet = 1;
    							bRet = Button[nRet-1];
    							RetPrompt = prompt.getText().toString();
     							onDismiss();

    						} });
    				if(nCount == flag[1])
    					PromptDialog.setButton(DialogInterface.BUTTON_NEUTRAL, item, new DialogInterface.OnClickListener() { //Button 2 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 2 was clicked?	  
    							nRet = 2;
    							bRet = Button[nRet-1];
    							RetPrompt = prompt.getText().toString();
    							onDismiss();

    						} });

    				if(nCount == flag[2])
    					PromptDialog.setButton(DialogInterface.BUTTON_NEGATIVE, item, new DialogInterface.OnClickListener() { //Button 3 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 3 was clicked?
    							nRet = 3;
    							bRet = Button[nRet-1];
    							RetPrompt = prompt.getText().toString();
    							onDismiss();

    						} });

    				nCount++;
    			}
    		}
    	}
    	
    	PromptDialog.setCancelable(false);
    	
    	utilityDialog.requestDialogFeatures(PromptDialog);
	  	
    	utilityDialog.setWorkingView(dialoglayout);
    	
		PromptDialog.show(); //Show the dialog
    	
    	if(!bFontTheme) {
    		utilityDialog.resizeTitle(PromptDialog);
    		utilityDialog.resizeMessage(PromptDialog);
    	}
    	
    	utilityDialog.updateSize(nSize, nAlign);
    }
	
    public void clear(){
		// return Values
		Id = null;
		bRet = null;
		Tag = null;
		sRet = null;
		nRet = -1;

		Title = null;
		Msg   = null;
		Icon  = null;
		Buttons = null;

		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;

	}
	
	private void onDismiss() {
		if (mListener != null)
			mListener.onClick(Id, bRet, nRet, RetPrompt);
	}

	public Dialog getDialog() {
		return dlg;
	}
	
}
