/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class passwordDialogMMF {
	
	private Dialog dlg= null;
	
	private CExtension ho = null;
	
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public String Title = null;
	public String Msg  = null;
	public String Icon  = null;
	public String Buttons = null;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;
	
	public int nTheme;
	public boolean bFontTheme;
	public int TitleColor;

	public Drawable dDraw = null;
	
	public String OldPass = null;
	public String NewPass = null;
	public String ConPass = null;
	
	public String [] Button = null;
	
	public String RetOldPass = null;
	public String RetNewPass = null;
	public String RetConfirm = null;
	
	/////////////////////
	//
	// Constructors
	//
	/////////////////////
	
	public passwordDialogMMF(CExtension ho, OnPasswordResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
	}	
	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnPasswordResultListener mListener;
	
	public interface OnPasswordResultListener {
		public abstract void onClick(String Id, String bRet, int nRet, String RetOldPass, String RetNewPass, String RetConfirm);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnPasswordResultListener(OnPasswordResultListener listener) {
		mListener = listener;
	}
	
	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

    public void DoShow() {

       	UtilityDialog utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);     	

       	AlertDialog PasswordDialog = null;
       	
       	if(ctw == null) {
       		PasswordDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
       	}
       	else
       		PasswordDialog = new AlertDialog.Builder(ctw).create();

    	dlg = PasswordDialog;
    	
    	if(TitleColor != -1) {
    		String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
    		PasswordDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
    	}
    	else
    		PasswordDialog.setTitle(Title);		// Title Text
    	
    	PasswordDialog.setMessage(Msg); 					// Message Text
    	
    	PasswordDialog.setIcon(dDraw); 					// Icon
        LayoutInflater inflater = PasswordDialog.getLayoutInflater();
        
    	final View dialoglayout = inflater.inflate(utilityDialog.getLayoutByName("dialog_password"), null);
    	PasswordDialog.setView(dialoglayout);
    	
    	// Usename and Password EditText control
		final EditText oldx = (EditText) dialoglayout.findViewById( utilityDialog.getIDsByName("oldpass") );
		final EditText newx = (EditText) dialoglayout.findViewById( utilityDialog.getIDsByName("newpass") );
		final EditText conf = (EditText) dialoglayout.findViewById( utilityDialog.getIDsByName("confpass") );
		
		
		if(oldx != null)
			oldx.setHint(OldPass);
		
		if(newx != null)
			newx.setHint(NewPass);
		
		if(conf != null)
			conf.setHint(ConPass);
		        	
 		int flag[] = {0,1,2};
 		
    	if(Buttons != null) {
    		int nCount = 0;
    		if(Buttons.lastIndexOf(",") != (Buttons.length()-1))
    			Buttons += ",";
    		
    		String[] items = Buttons.split(",");
    		Button = items.clone();
    		for (String item : items)
    		{
    			if(item.length() > 0) {
    				if(nCount == flag[0])
    					PasswordDialog.setButton( DialogInterface.BUTTON_POSITIVE, item, new DialogInterface.OnClickListener() { //Button 1 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 1 was clicked?
    							nRet = 1;
    							bRet = Button[nRet-1];
    							RetOldPass = oldx.getText().toString();
    							RetNewPass = newx.getText().toString();
    							RetConfirm = conf.getText().toString();
    							onDismiss();

    						} });
    				if(nCount == flag[1])
    					PasswordDialog.setButton(DialogInterface.BUTTON_NEUTRAL, item, new DialogInterface.OnClickListener() { //Button 2 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 2 was clicked?	  
    							nRet = 2;
    							bRet = Button[nRet-1];
    							RetOldPass = oldx.getText().toString();
    							RetNewPass = newx.getText().toString();
    							RetConfirm = conf.getText().toString();
    							onDismiss();

    						} });

    				if(nCount == flag[2])
    					PasswordDialog.setButton(DialogInterface.BUTTON_NEGATIVE, item, new DialogInterface.OnClickListener() { //Button 3 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 3 was clicked?
    							nRet = 3;
    							bRet = Button[nRet-1];
    							RetOldPass = oldx.getText().toString();
    							RetNewPass = newx.getText().toString();
    							RetConfirm = conf.getText().toString();
    							onDismiss();

    						} });

    				nCount++;
    			}
    		}
    	}else {
    		PasswordDialog.setOnKeyListener(new Dialog.OnKeyListener() {

				@Override
				public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
					if (keyCode == KeyEvent.KEYCODE_BACK) {
						dialog.dismiss();
						nRet = -1;
						bRet = "";
						RetOldPass = oldx.getText().toString();
						RetNewPass = newx.getText().toString();
						RetConfirm = conf.getText().toString();
						onDismiss();
						return true;
					}
					return false;
				}				
			});
		}
    	
    	PasswordDialog.setCancelable(false);
    	
    	utilityDialog.requestDialogFeatures(PasswordDialog);
    	
    	utilityDialog.setWorkingView(dialoglayout);
    	
		PasswordDialog.show(); //Show the dialog
    	 
    	if(!bFontTheme) {
    		utilityDialog.resizeTitle(PasswordDialog);
    		utilityDialog.resizeMessage(PasswordDialog);
    	}
    	
     	utilityDialog.updateSize(nSize, nAlign);
    }
	
	public void clear(){
		// return Values
		Id = null;
		bRet = null;
		Tag = null;
		sRet = null;
		nRet = -1;

		Title = null;
		Msg   = null;
		Icon  = null;
		Buttons = null;

		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;
		bFontTheme = false;

	}
	
	private void onDismiss() {
		mListener.onClick(Id, bRet, nRet, RetOldPass, RetNewPass, RetConfirm);
	}

	public Dialog getDialog() {
		return dlg;
	}
	
}
