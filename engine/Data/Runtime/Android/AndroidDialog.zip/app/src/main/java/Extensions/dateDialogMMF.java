package Extensions;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Calendar;

import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.text.InputType;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.EditText;
import android.widget.TextView;

public class dateDialogMMF {

	private CExtension ho = null;
	private Dialog dlg= null;
	private DatePicker datepicker = null;
	
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public int Type = 1;

	public String Title   = null;
	public String Msg    = null;
	public String Icon    = null;
	public String Buttons = null;
	
	public String[] Button = null;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;
	
	public int nTheme;
	public boolean bFontTheme;
	public int TitleColor;
	
	public Drawable dDraw = null;
	
	public int what;
	public int calOff; 
	public int style;
	public int day;
	public int month;
	public int year;
	
	int width;
	int height;

	private int RetDay;
	private int RetMonth;
	private int RetYear;
	

	private EditText vDay   = null;
	private EditText vMonth = null;
	private EditText vYear  = null;
	
	private InputMethodManager imm = null;

	/////////////////////
	//
	// Constructors
	//
	/////////////////////
	public dateDialogMMF(CExtension ho, OnDateResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
	}
	
	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnDateResultListener mListener;
	
	public interface OnDateResultListener {
		public abstract void onClick(String Id, String bRet, int nRet, int RetDay, int RetMonth, int RetYear);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnDateResultListener(OnDateResultListener listener) {
		mListener = listener;
	}
	
	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

    public void DoShow(int d, int m, int y) {
    	
       	UtilityDialog utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);
       	
       	AlertDialog dateDialog = null;
       	
       	if(ctw == null) {
       		dateDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
       	}
       	else
       		dateDialog = new AlertDialog.Builder(ctw).create();
       	
    	dlg = dateDialog;
    	
    	if(TitleColor != -1) {
    		String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
    		dateDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
    	}
    	else
    		dateDialog.setTitle(Title);				 // Title Text
    	
    	dateDialog.setMessage(Msg); 				 // Message Text
    	dateDialog.setIcon(dDraw); 					 // Icon
    	    	
        LayoutInflater inflater = dateDialog.getLayoutInflater();
        ////////////////////////////////////////////////////////////////
        //
        //                   GetResources IDs
        //
        ////////////////////////////////////////////////////////////////
        
        final View dialoglayout = inflater.inflate(utilityDialog.getLayoutByName("dialog_date"), null);
        
        dateDialog.setView(dialoglayout);
    	
        final Calendar c = Calendar.getInstance();//To initialize with the current date 
        
        if(y < 0) {
	        if(year == -1 || y == -1)
		       	year = c.get(Calendar.YEAR);
        }
        else
        	year = y;
        	
        RetYear = year;
       
        if(m < 0) {
	        if(month == -1 || m == -1)
		       	month = c.get(Calendar.MONTH)+1;
        }
        else
        	month = m;
        
        RetMonth = month;
       
        if(d < 0) {
	        if(day == -1 || d == -1)
		       	day = c.get(Calendar.DAY_OF_MONTH);
        }
        else
        	day = d;
        
    	RetDay = day;
        
        datepicker = (DatePicker) dialoglayout.findViewById(utilityDialog.getIDsByName("datePicker1"));
        
        imm = (InputMethodManager) ho.getControlsContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        
		datepicker.init(year, month-1, day, new OnDateChangedListener(){

			@Override
			public void onDateChanged(DatePicker picker, int year, int month, int day) {
				/*
				if(what != 7) {
					if(what == 1 || what == 2 || what == 4)
						picker.requestFocus(View.FOCUS_UP);
					
					if(what == 1 || what == 4 || what == 5) {
						if(imm != null) {
							imm.hideSoftInputFromWindow(vMonth.getWindowToken(), 0); 
						}
					}
					if(what == 1 || what == 2 || what == 3) {
						if(imm != null) {
							imm.hideSoftInputFromWindow(vYear.getWindowToken(), 0);							
						}
					}
					if(what == 2 || what == 4 || what == 6) {
						if(imm != null) {
							imm.hideSoftInputFromWindow(vDay.getWindowToken(), 0);							
						}
					}
					
				}
				*/
			}
			
		});
               
        if(calOff == 1) {
        	if (android.os.Build.VERSION.SDK_INT >= 11) {
        		try {
        			Method mx = datepicker.getClass().getMethod("setCalendarViewShown", boolean.class);
        			mx.invoke(datepicker, false);
        		}
        		catch (Exception e) {
                	Log.d("ERROR", e.getMessage());
        		} //don't do anything
        	}
        }
        
        if(what != 7) {
            setDisabledTextViews(datepicker);
        }
        
        if (android.os.Build.VERSION.SDK_INT >= 21){
        	int daySpinnerId = Resources.getSystem().getIdentifier("day", "id", "android");
        	if (daySpinnerId != 0 && (what & 1) == 0)
        	{
        		View daySpinner = datepicker.findViewById(daySpinnerId);
        		if (daySpinner != null)
        		{
        			daySpinner.setVisibility(View.GONE);
        		}
        	}

        	int monthSpinnerId = Resources.getSystem().getIdentifier("month", "id", "android");
        	if (monthSpinnerId != 0)
        	{
        		View monthSpinner = datepicker.findViewById(monthSpinnerId);
        		if (monthSpinner != null && (what & 2) == 0)
        		{
        			monthSpinner.setVisibility(View.GONE);
        		}
        	}

        	int yearSpinnerId = Resources.getSystem().getIdentifier("year", "id", "android");
        	if (yearSpinnerId != 0)
        	{
        		View yearSpinner = datepicker.findViewById(yearSpinnerId);
        		if (yearSpinner != null && (what & 4) == 0)
        		{
        			yearSpinner.setVisibility(View.GONE);
        		}
        	}
        } 
        else { 
        	try {
        		Field f[] = datepicker.getClass().getDeclaredFields();
        		for (Field field : f) {
        			Log.d("date", field.toString());
        			if (field.getName().equals("mYearPicker") || field.getName().equals("mYearSpinner") || field.getName().equals("mYearSpinnerInput")) {
        				field.setAccessible(true);
        				Object yearPicker = new Object();
        				yearPicker = field.get(datepicker);
        				if((what & 4) == 0) {
        					((View) yearPicker).setEnabled(false);
        					((View) yearPicker).setVisibility(View.GONE);
        					if(field.getName().equals("mYearSpinnerInput")) {            				
        						vYear = ((EditText) yearPicker);
        						((EditText) yearPicker).setEnabled(false);
        						((EditText) yearPicker).setFocusable(false);
        					}
        				}
        			}
        			if (field.getName().equals("mMonthPicker") || field.getName().equals("mMonthSpinner") || field.getName().equals("mMonthSpinnerInput")) {
        				field.setAccessible(true);
        				Object monthPicker = new Object();
        				monthPicker = field.get(datepicker);
        				if((what & 2) == 0) {
        					((View)monthPicker).setEnabled(false);
        					((View)monthPicker).setVisibility(View.GONE);
        					if(field.getName().equals("mMonthSpinnerInput")) {
        						vMonth = ((EditText) monthPicker);
        						((EditText)monthPicker).setEnabled(false);
        						((EditText) monthPicker).setFocusable(false);
        					}
        				}
        			}
        			if (field.getName().equals("mDayPicker") || field.getName().equals("mDaySpinner") || field.getName().equals("mDaySpinnerInput")) {
        				field.setAccessible(true);
        				Object dayPicker = new Object();
        				dayPicker = field.get(datepicker);
        				if(((what & 1) == 0)) {
        					((View) dayPicker).setEnabled(false);		
        					((View) dayPicker).setVisibility(View.GONE);
        					if(field.getName().equals("mDaySpinnerInput")) {
        						vDay = ((EditText) dayPicker);
        						((EditText) dayPicker).setEnabled(false);		
        						((EditText) dayPicker).setFocusable(false);
        					}
        				}
        			}
        		}
        	} catch (SecurityException e) {
        		Log.d("ERROR", e.getMessage());
        	} catch (IllegalArgumentException e) {
        		Log.d("ERROR", e.getMessage());
        	} catch (IllegalAccessException e) {
        		Log.d("ERROR", e.getMessage());
        	}
        }
                
 		int flag[] = {0,1,2};
 		
    	if(Buttons != null) {
    		int nCount = 0;
    		if(Buttons.lastIndexOf(",") != (Buttons.length()-1))
    			Buttons += ",";
    		
    		String[] items = Buttons.split(",");
    		Button = items.clone();
    		for (String item : items)
    		{
    			if(item.length() > 0) {
    				if(nCount == flag[0])
    					dateDialog.setButton( DialogInterface.BUTTON_POSITIVE, item, new DialogInterface.OnClickListener() { //Button 1 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 1 was clicked?
    							nRet = 1;
    							bRet = Button[nRet-1];
    							getDate();
    							mListener.onClick(Id, bRet, nRet, RetDay, RetMonth, RetYear);

    						} });
    				if(nCount == flag[1])
    					dateDialog.setButton( DialogInterface.BUTTON_NEUTRAL, item, new DialogInterface.OnClickListener() { //Button 2 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 2 was clicked?	  
    							nRet = 2;
    							bRet = Button[nRet-1];
    							getDate();
    							mListener.onClick(Id, bRet, nRet, RetDay, RetMonth, RetYear);

    						} });

    				if(nCount == flag[2])
    					dateDialog.setButton( DialogInterface.BUTTON_NEGATIVE, item, new DialogInterface.OnClickListener() { //Button 3 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 3 was clicked?
    							nRet = 3;
    							bRet = Button[nRet-1];
    							getDate();
    							mListener.onClick(Id, bRet, nRet, RetDay, RetMonth, RetYear);

    						} });

    				nCount++;
    			}
    		}
    	}
    	
    	dateDialog.setCancelable(false);
    	
    	utilityDialog.requestDialogFeatures(dateDialog);
    	
    	utilityDialog.setWorkingView(datepicker);
    	
     	dateDialog.show(); //Show the dialog   	
 
    	utilityDialog.resizeTitle(dateDialog);
    	utilityDialog.resizeMessage(dateDialog);
    	
     	utilityDialog.updateSize(nSize, nAlign);
    	
   	
    }

	public void clear(){
		// return Values
		Id   = null;
		bRet = null;
		Tag  = null;
		sRet = null;
		nRet = -1;

		Title   = null;
		Msg     = null;
		Icon    = null;
		Buttons = null;
		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;
		bFontTheme = false;

	}
	
	public Dialog getDialog() {
		return dlg;
	}

    private void setDisabledTextViews(ViewGroup dp) {
        for (int i = 0, count = dp.getChildCount(); i < count; i++) {
                View v = dp.getChildAt(i);

                if (v instanceof TextView) {
                        //v.setEnabled(false);
                        ((TextView) v).setInputType(InputType.TYPE_NULL);
                        v.setFocusableInTouchMode(false);
                } 
                else if (v instanceof ViewGroup) {
                        setDisabledTextViews((ViewGroup)v);
                }
        }
        
    }
	
	
	public void getDate() {
		if(datepicker != null) {
			datepicker.clearFocus();
			datepicker.requestFocus(View.FOCUS_UP);
			RetYear = datepicker.getYear();	
			RetMonth = datepicker.getMonth()+1;
			RetDay = datepicker.getDayOfMonth();
		}
	}
}
