/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import Objects.CExtension;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.text.Html;
import android.view.ContextThemeWrapper;

public class progDialogMMF {

	private CExtension ho = null;
	private Dialog dlg= null;
		
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public int Type = 1;

	public String Title   = null;
	public String Msg    = null;
	public String Icon    = null;
	public String Buttons = null;
	
	public String[] Button = null;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;
	
	public int nTheme;
	public boolean bFontTheme;
	public int TitleColor;
	
	public Drawable dDraw = null;
	
	public int style;
	public int nTimer;
	public int min;
	public int max;
	public int value;
	
	int width;
	int height;
	
	boolean update = true;
	
	private ProgressDialog progDialog = null;
	
	/////////////////////
	//
	// Constructors
	//
	/////////////////////
	public progDialogMMF(CExtension ho) {
		this.ho = ho;
		clear();
	}
	
	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

    public void DoShow() {
    	
       	UtilityDialog utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);
       	
       	if(ctw != null)
       		progDialog = new ProgressDialog(ctw);
       	else
        	progDialog = new ProgressDialog(ho.getControlsContext());
       		
    	dlg = progDialog;    	
   	    	
    	if(TitleColor != -1) {
    		String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
    		progDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
    	}
    	else
    		progDialog.setTitle(Title);	// Title Text

    	progDialog.setMessage(Msg); 				 // Message Text
    	progDialog.setIcon(dDraw); 					 // Icon
    	 
    	if(style == 0)    		
    		progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
    	else if(style == 1)    		
    		progDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
    	else
    		progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
   	
    	if(nTimer != -1 && nTimer > 300) {
    		
    		progDialog.setIndeterminate(true);
    		
    		long timer = Long.valueOf(nTimer);

    		new CountDownTimer(timer, 1000)
    		{
    			@Override
				public void onTick(long millisUntilFinished)
    			{
    			}

    			@Override
				public void onFinish()
    			{
    				//Finish dialog by Timeout
    				progDialog.dismiss();
    			}
    		}.start();
    	}
    	else {
    		progDialog.setIndeterminate(false);
    		// reference is for 0 to 100, displacement for minimum
    		progDialog.setMax(max-min);
    	}
    	
    	progDialog.setCancelable(false);

    	utilityDialog.requestDialogFeatures(progDialog);
    	
       	if(Title == null && Msg == null)
        	progDialog.setProgressStyle(android.R.attr.progressBarStyleSmall); 
    	
    	progDialog.show(); //Show the dialog   	
    	
    	utilityDialog.resizeTitle(progDialog);
    	utilityDialog.resizeMessage(progDialog);
    	
       	utilityDialog.setWorkingView(progDialog.getWindow().getDecorView());
       	
       	if(Title == null){
  			utilityDialog.Align(nAlign);
      		if( Msg == null) {
       			utilityDialog.forceSize(130, 150);
       		}
       		else {
       			utilityDialog.forceSize(Msg.length() * 8 + 130, 150);

       		}
       	}

       	else
       		utilityDialog.updateSize(nSize, nAlign);       			

    }

    public void kill() {
    	if(progDialog != null)
    		progDialog.dismiss();
    }
    
    public void setValue(int nvalue) {
    	if(progDialog != null && nTimer == -1)
    		progDialog.setProgress((nvalue-min) > max ? max : ((nvalue-min) < min ? min : (nvalue-min)));
    }
    
   
	public void clear(){
		// return Values
		Id   = null;
		bRet = null;
		Tag  = null;
		sRet = null;
		nRet = -1;

		Title   = null;
		Msg     = null;
		Icon    = null;
		Buttons = null;
		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;
		bFontTheme = false;

	}
	
	public Dialog getDialog() {
		return dlg;
	}

}
