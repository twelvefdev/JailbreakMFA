/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup.LayoutParams;
import android.widget.TextView;

public class toastDialogMMF {

	private CExtension ho = null;
	private Dialog dlg= null;
	private AlertDialog toastDialog = null;

	
	String Id = null;
	String Msg = null;
	int nSize;
	int nAlign;
	int nTimeout;

	int nTheme;
	public boolean bFontTheme;

	public Drawable dDraw = null;

	/////////////////////
	//
	// Constructors
	//
	/////////////////////
	public toastDialogMMF(CExtension ho, OnToastResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
	}

	/////////////////////
	//
	// Listeners
	//
	/////////////////////

	public OnToastResultListener mListener;

	public interface OnToastResultListener {
		public abstract void onClick(String Id);
	}

	// Allows the user to set an Listener and react to the event
	public void setOnToastResultListener(OnToastResultListener listener) {
		mListener = listener;
	}

	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

	void DoShow() {

		UtilityDialog utilityDialog = new UtilityDialog();

		ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);

       	if(ctw == null) {
       		toastDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
       	}
       	else
       		toastDialog = new AlertDialog.Builder(ctw).create();   		
		
    	dlg = toastDialog;
    	
		// Duration
		int duration;

		if(nTimeout == 0)
			duration = 3500;
		else if(nTimeout == -1)
			duration = 2000;
		else
			duration = nTimeout;

		long timer = Long.valueOf(duration);

		CountDownTimer mTimer = new CountDownTimer(timer, 1000)
		{
			@Override
			public void onTick(long millisUntilFinished)
			{
			}

			@Override
			public void onFinish()
			{
				//Finish dialog by Timeout
				toastDialog.dismiss();
				onDismiss();
			}
			
		};

		LayoutInflater inflater = toastDialog.getLayoutInflater();

		final View dialoglayout = inflater.inflate(utilityDialog.getLayoutByName("dialog_toast"), null);

		// Set a desired image
		ImageView image = (ImageView) dialoglayout.findViewById( utilityDialog.getIDsByName("imageToast") );
		if(dDraw != null)
			image.setImageDrawable(dDraw);
		else
			image.setVisibility(View.GONE);

		// set a message
		TextView text = (TextView) dialoglayout.findViewById( utilityDialog.getIDsByName("textToast") );
		text.setText(Msg);

		toastDialog.setView(dialoglayout);

		utilityDialog.requestDialogFeatures(toastDialog);

    	utilityDialog.setWorkingView(dialoglayout);
    	
		int w = UtilityDialog.getBestWidthView(dialoglayout);

		int s = utilityDialog.getScreenWidth();

		if(w < s && dDraw == null) {
			text.setGravity(Gravity.CENTER);
			text.setPadding(5, 5, 5, 5);
		}
			
		toastDialog.show(); //Show the dialog 
		
    	if(!bFontTheme) {
    		utilityDialog.resizeMessage(toastDialog);
    	}
		
		if((w + 100) > s)
			utilityDialog.updateSize(5, nAlign);
		else {
			utilityDialog.Align(nAlign);
			utilityDialog.forceSize(w + 100, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
		}
    	
		mTimer.start();
		
		ho.pause();

	}

	void clear() {
		Id   = null;
		Msg = null;
	}	

	public Dialog getDialog() {
		return dlg;
	}
	
	public void onDismiss() {
		ho.resume();
		mListener.onClick(Id);

	}
}
