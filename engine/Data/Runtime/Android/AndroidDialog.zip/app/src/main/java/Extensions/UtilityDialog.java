/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;


import java.lang.reflect.Field;

import Runtime.Log;
import Runtime.MMFRuntime;
import android.app.Dialog;
import android.graphics.Point;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class UtilityDialog {

	private Dialog dialog = null;
	private View view = null;
	private WindowManager.LayoutParams DlgWnd = null;
	private int width;
	private int height;
	private int dpi;
	private int ScreenWidth;
	private int ScreenHeight;
	
	private static Class<?> classLayout = null;
	private static Class<?> classIDs    = null;
	private static Class<?> classDrawable = null;
	private static Class<?> classStyle  = null;

	@SuppressWarnings("deprecation")
	public UtilityDialog() {
		try {
			classLayout = Class.forName(MMFRuntime.inst.getPackageName()+".R$layout");
		} catch (ClassNotFoundException e) {
			Log.Log("UtiDlg "+e.toString());
		}
		
		try {
			classIDs = Class.forName(MMFRuntime.inst.getPackageName()+".R$id");
		} catch (ClassNotFoundException e) {
			Log.Log("UtiDlg "+e.toString());
		}
		try {
			classDrawable = Class.forName(MMFRuntime.inst.getPackageName()+".R$drawable");
		} catch (ClassNotFoundException e) {
			Log.Log("UtiDlg "+ e.toString());
		}
		try {
			classStyle = Class.forName(MMFRuntime.inst.getPackageName()+".R$style");
		} catch (ClassNotFoundException e) {
			Log.Log("UtiDlg "+ e.toString());
		}
		
		Display display = MMFRuntime.inst.getWindowManager().getDefaultDisplay();

		if(Build.VERSION.SDK_INT > 13) {
			Point size = new Point();
			display.getSize(size);
			ScreenWidth = size.x;
			ScreenHeight = size.y;
		}else {
			//Below API 13
			ScreenWidth = display.getWidth();  // deprecated
			ScreenHeight = display.getHeight();  // deprecated
		}
				
	}
	
	public void requestDialogFeatures(Dialog ldialog) {
		this.dialog = ldialog;
       	dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		DlgWnd = dialog.getWindow().getAttributes();	
	}
	
	public void setWorkingView(View view) {
		this.view = view;
	}
	public void updateSize(int nSize, int nAlign) {
		
		int w = LayoutParams.MATCH_PARENT, h = LayoutParams.MATCH_PARENT;

		ScreenSize();
		/*
			0:FULL, 1:LARGE, 2:MEDIUM, 3:SMALL, 4:WIDE, 5:FIT
		*/
		switch(nSize) {
		case 0:
			w = (int)(width * 0.95f);
			h = (int)(height * 0.95f);
			break;
		case 1:
			w = LayoutParams.WRAP_CONTENT;
			h = (int)(height * 0.80f);
			break;
		case 2:
			w = (int)(width * 0.50f);
			h = LayoutParams.WRAP_CONTENT;
			break;
		case 3:
			w = LayoutParams.WRAP_CONTENT;
			h = (int)(height * 0.35f);
			break;
		case 4:
			w = (int)(width * 0.80f);
			h = LayoutParams.WRAP_CONTENT;
			break;
		case 5:
			w = LayoutParams.WRAP_CONTENT;
			h = LayoutParams.WRAP_CONTENT;
			break;
		case 6:
			{
				if(view != null)
					w = getBestWidthView(view) + (int)(width*0.15f);
				else
					w = LayoutParams.WRAP_CONTENT;
				
				h = LayoutParams.WRAP_CONTENT;
			}
			break;
		case 7:
			w = (int)(width * 0.30f);
			h = LayoutParams.WRAP_CONTENT;
			break;
		}

		switch(nAlign) {
		case 0:
			DlgWnd.gravity = Gravity.BOTTOM;
			break;
		case 1:
			DlgWnd.gravity = Gravity.CENTER;
			break;
		case 2:
			DlgWnd.gravity = Gravity.TOP;
			break;
		}

		DlgWnd.width = w;
		DlgWnd.height= h;

		dialog.getWindow().setAttributes(DlgWnd);
	}

	public void forceSize(int w, int h) {
		
		DlgWnd.width = w;
		DlgWnd.height= h;

		dialog.getWindow().setAttributes(DlgWnd);
	}

    public static int getBestWidthList(ListView listView) {

        ListAdapter mAdapter = listView.getAdapter();

        int totalWidth = 0;

        for (int i = 0; i < mAdapter.getCount(); i++) {
            View mView = mAdapter.getView(i, null, listView);

            mView.measure(
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),

                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));

            totalWidth= Math.max(mView.getMeasuredWidth(), totalWidth);
        }

        return totalWidth;
	
    }

    public static int getBestHeightList(ListView listView) {

        ListAdapter mAdapter = listView.getAdapter();

        int totalHeight = 0;

        for (int i = 0; i < mAdapter.getCount(); i++) {
            View mView = mAdapter.getView(i, null, listView);

            mView.measure(
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),

                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));

            totalHeight += Math.max(mView.getMeasuredHeight(), 0);
        }

        return totalHeight;
	
    }
    
    
    public static int getBestWidthView(View view) {

    	int width = 0;
    	view.measure(
    			MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),

    			MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));

    	width= Math.max(view.getMeasuredWidth(), width);

    	return width;

    }

    public static int getListViewHeight(ListView listView) {
    	ListAdapter adapter = listView.getAdapter();

    	int totalHeight = 0;

    	listView.measure(MeasureSpec.makeMeasureSpec(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED), 
    			MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));

    	totalHeight = listView.getMeasuredHeight() * adapter.getCount() + ((adapter.getCount()-1) * listView.getDividerHeight());

    	return totalHeight;
    }    
    
    public int getScreenWidth() {
    	return ScreenWidth;
    }
    
    public int getScreenHeight() {
    	return ScreenHeight;
    }
    
	public void Align(int nAlign) {
		
		switch(nAlign) {
		case 0:
			DlgWnd.gravity = Gravity.BOTTOM;
			break;
		case 1:
			DlgWnd.gravity = Gravity.CENTER;
			break;
		case 2:
			DlgWnd.gravity = Gravity.TOP;
			break;
		}

		dialog.getWindow().setAttributes(DlgWnd);
	}
	
	public void setMarginVertical(float m) {
		DlgWnd.verticalMargin = m;
		dialog.getWindow().setAttributes(DlgWnd);
	}
	
	public void setMarginHorizontal(float l) {
		DlgWnd.horizontalMargin = l;
		dialog.getWindow().setAttributes(DlgWnd);
	}
	
	public void setXY(int x, int y) {
		DlgWnd.x = x;
		DlgWnd.y = y;
		dialog.getWindow().setAttributes(DlgWnd);
	}
	
	@SuppressWarnings("deprecation")
	private void ScreenSize() {
		Display display = MMFRuntime.inst.getWindowManager().getDefaultDisplay();

		if(Build.VERSION.SDK_INT > 13) {
			Point size = new Point();
			display.getSize(size);
			width = size.x;
			height = size.y;
		}		else {
			//Below API 13
			width = display.getWidth();  // deprecated
			height = display.getHeight();  // deprecated
		}

		Log.Log(" width: "+width+"  height: "+height);
	}

	private void deviceDpi() {
		Display display = MMFRuntime.inst.getWindowManager().getDefaultDisplay();
		DisplayMetrics metrics = new DisplayMetrics();
		display.getMetrics(metrics);
		
		switch(metrics.densityDpi){		
			case 0:
			case DisplayMetrics.DENSITY_LOW:
				dpi = 1;
				break;
			case DisplayMetrics.DENSITY_MEDIUM:
				dpi = 2;
				break;
			case DisplayMetrics.DENSITY_HIGH:
				dpi = 3;
				break;
			case DisplayMetrics.DENSITY_XHIGH:
				dpi = 4;
				break;
			default:
				dpi = 2;
				break;
		}
		Log.Log("Dpi: " + dpi);
	}
	
	public ContextThemeWrapper themeDialog(int nTheme) {
		ContextThemeWrapper ctw = new ContextThemeWrapper(MMFRuntime.inst, android.R.style.Theme_Dialog);    	
		deviceDpi();

		if(nTheme == 0) {
			ctw = new ContextThemeWrapper(MMFRuntime.inst, android.R.style.Theme_DeviceDefault_Dialog );
		}
		if(nTheme == 1) {
			ctw = new ContextThemeWrapper(MMFRuntime.inst, android.R.style.Theme_Holo_Dialog );
		}
		if(nTheme == 2) {
			ctw = new ContextThemeWrapper(MMFRuntime.inst, android.R.style.Theme_Holo_Light_Dialog );
		}
		if(nTheme == 3) {
			ctw = new ContextThemeWrapper(MMFRuntime.inst, android.R.style.Theme_Dialog );
		}
		if(nTheme == 4) {
			ctw = new ContextThemeWrapper(MMFRuntime.inst, MMFRuntime.inst.getResourceID("style/Theme.Fusion_actionbar") );
		}
		return ctw;
	}
	
	public int getDpi() {
		return dpi;
	}
	
	public void resizeTitle(Dialog dialog) {
		final int alertTitle = dialog.getContext().getResources().getIdentifier( "alertTitle", "id", "android");
		TextView textView = (TextView) dialog.findViewById(android.R.id.title);
		if(alertTitle != 0 && textView == null)
			textView = (TextView)dialog.findViewById(alertTitle);
		if(textView != null) {
			if(dpi == 1)
				textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
			if(dpi == 2)
				textView.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
			if(dpi == 3)
				textView.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
			if(dpi == 4)
				textView.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
		}
	}
	
	public void resizeMessage(Dialog dialog) {
		TextView textView = (TextView) dialog.findViewById(android.R.id.message);
		if(textView != null) {
			if(dpi == 1)
				textView.setTextSize(TypedValue.COMPLEX_UNIT_SP,14);
			if(dpi == 2)
				textView.setTextSize(TypedValue.COMPLEX_UNIT_SP,14);
			if(dpi == 3)
				textView.setTextSize(TypedValue.COMPLEX_UNIT_SP,14);
			if(dpi == 4)
				textView.setTextSize(TypedValue.COMPLEX_UNIT_SP,14);
		}
	}
	
    public static int getResourceByName(Class<?> Rclass, String name) {
        int id = -1;
        try {
            if (Rclass != null) {
                final Field field = Rclass.getField(name);
                if (field != null)
                    id = field.getInt(null);
            }
        } catch (final Exception e) {
            Log.Log("UtilDlg "+ e.toString());
            e.printStackTrace();
        }
        return id;
    }
    
    public int getLayoutByName(String name) {
        int id = -1;
        try {
            if (classLayout != null) {
                final Field field = classLayout.getField(name);
                if (field != null)
                    id = field.getInt(null);
            }
        } catch (final Exception e) {
            Log.Log("UtilDlg "+ e.toString());
            e.printStackTrace();
        }
        return id;
    }
    
    public int getIDsByName(String name) {
        int id = -1;
        try {
            if (classIDs != null) {
                final Field field = classIDs.getField(name);
                if (field != null)
                    id = field.getInt(null);
            }
        } catch (final Exception e) {
            Log.Log("UtilDlg "+ e.toString());
            e.printStackTrace();
        }
        return id;
    }
    
    public int getDrawableByName(String name) {
        int id = -1;
        try {
            if (classDrawable != null) {
                final Field field = classDrawable.getField(name);
                if (field != null)
                    id = field.getInt(null);
            }
        } catch (final Exception e) {
            Log.Log("UtilDlg "+ e.toString());
            e.printStackTrace();
        }
        return id;
    }
        
    public int getStyleByName(String name) {
        int id = -1;
        try {
            if (classStyle != null) {
                final Field field = classStyle.getField(name);
                if (field != null)
                    id = field.getInt(null);
            }
        } catch (final Exception e) {
            Log.Log("UtilDlg "+ e.toString());
            e.printStackTrace();
        }
        return id;
    }
}
