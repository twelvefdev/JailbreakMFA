package Extensions;

import java.util.List;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


public class FileArrayAdapter extends ArrayAdapter<FileSelOption> {

	private Context context;
	private int id;
	private List<FileSelOption>items;
	private UtilityDialog utility= null;
	
	private int nRows;
	private boolean once=true;
	private Drawable dDrawFolder = null;
	private Drawable dDrawFiles = null;
	private String ParentTxt = null;
	private String FolderTxt = null;
	
	public FileArrayAdapter(Context context, int textViewResourceId,
			List<FileSelOption> objects, boolean nOnce, String parenttxt, String foldertxt, Drawable dFolder, Drawable dFiles) {
		super(context, textViewResourceId, objects);
		this.context = context;
		this.id = textViewResourceId;
		items = objects;
		once = nOnce;
		this.FolderTxt = foldertxt;
		this.ParentTxt = parenttxt;
		this.dDrawFolder = dFolder;
		this.dDrawFiles  = dFiles;
		this.utility = new UtilityDialog();
	}
	
	public boolean getFirstTime() {
		return once;
	}
	
	@Override
	public FileSelOption getItem(int i) {
		 return items.get(i);

	}
	
	
	@Override
       public View getView(int position, View convertView, ViewGroup parent) {
               View v = convertView;
               if (v == null) {
                   LayoutInflater vi = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                   v = vi.inflate(id, null);
               }
               final FileSelOption o = items.get(position);
               if (o != null) {
        	   	   ImageView i1 = (ImageView) v.findViewById( utility.getIDsByName("imageView01") );
                   TextView t1 = (TextView)  v.findViewById( utility.getIDsByName("TextView01") );
                   TextView t2 = (TextView)  v.findViewById( utility.getIDsByName("TextView02") );
                      
                       if(t1!=null)
                       	t1.setText(o.getName());
                       if(t2!=null)
                       	t2.setText(o.getData());
                       if(i1!=null && (o.getData().equalsIgnoreCase(FolderTxt)||o.getData().equalsIgnoreCase(ParentTxt))) { 
                    	   if(dDrawFolder != null) {
                    		   i1.setImageDrawable(dDrawFolder);
                    	   }
                    	   else {                 			   
                    		   i1.setImageResource( utility.getDrawableByName("folderx") );

                    	   }
                       }
                       else {
                    	   if(dDrawFiles != null) {
                    		   i1.setImageDrawable(dDrawFiles);                  		   
                    	   }
                    	   else {
                        	   i1.setImageResource( utility.getDrawableByName("filex") );
                    	   }
                    	   
                       }
               }
               return v;
       }

}


 