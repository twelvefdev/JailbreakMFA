package Extensions;

import java.io.InputStream;
import java.net.URL;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import Actions.CActExtension;
import Banks.CImage;
import Conditions.CCndExtension;
import Expressions.CValue;
import Extensions.agreementDialogMMF.OnAgreementResultListener;
import Extensions.alertDialogMMF.OnAlertResultListener;
import Extensions.colorDialogMMF.OnColorResultListener;
import Extensions.dateDialogMMF.OnDateResultListener;
import Extensions.fileDialogMMF.OnFileSelResultListener;
import Extensions.loginDialogMMF.OnLoginResultListener;
import Extensions.menuDialogMMF.OnMenuResultListener;
import Extensions.notificationDialogMMF.OnPushListener;
import Extensions.passwordDialogMMF.OnPasswordResultListener;
import Extensions.popupDialogMMF.OnPopupResultListener;
import Extensions.promptDialogMMF.OnPromptResultListener;
import Extensions.sliderDialogMMF.OnSliderResultListener;
import Extensions.timeDialogMMF.OnTimeResultListener;
import Extensions.toastDialogMMF.OnToastResultListener;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Runtime.SurfaceView;
import Services.CBinaryFile;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.StrictMode;

@SuppressLint("NewApi")
public class CRunAndroidDialog extends CRunExtension
{
	// <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
	public static final int CNDALERTDIALOG = 0;
	public static final int CNDLOGINDIALOG = 1;
	public static final int CNDPASSWORDDIALOG = 2;
	public static final int CNDPROMPTDIALOG = 3;
	public static final int CNDPOPUPDIALOG = 4;
	public static final int CNDPOPUPCHOICE = 5;
	public static final int CNDAGREEDIALOG = 6;
	public static final int CNDSLIDERDIALOG = 7;
	public static final int CNDSLIDERVALUE = 8;
	public static final int CNDFILEPICKER = 9;
	public static final int CNDCOLORPICKER = 10;
	public static final int CNDDATEPICKER = 11;
	public static final int CNDTIMEPICKER = 12;
	public static final int CNDQUICKENDED = 13;
	public static final int CNDPUSHSEND = 14;
	public static final int CNDMENUDIALOG = 15;
	public static final int CNDLASTERROR = 16;
	public static final int CND_LAST = 17;

	public static final int ACTDIALOGTITLE = 0;
	public static final int ACTDIALOGICON = 1;
	public static final int ACTDIALOGMESSAGE = 2;
	public static final int ACTDIALOGBUTTONTEXT = 3;
	public static final int ACTDIALOGSIZE = 4;
	public static final int ACTDIALOGALIGN = 5;
	public static final int ACTALERTSAVE = 6;
	public static final int ACTALERTDO = 7;
	public static final int ACTLOGINUSER = 8;
	public static final int ACTLOGINPASSWORD = 9;
	public static final int ACTLOGINREMEMBER = 10;
	public static final int ACTLOGINFLAGREMEMBER = 11;
	public static final int ACTLOGINSAVE = 12;
	public static final int ACTLOGINDO = 13;
	public static final int ACTPASSWORDOLD = 14;
	public static final int ACTPASSWORDNEW = 15;
	public static final int ACTPASSWORDCONFIRM = 16;
	public static final int ACTPASSWORDSAVE = 17;
	public static final int ACTPASSWORDDO = 18;
	public static final int ACTPROMPTLABEL = 19;
	public static final int ACTPROMPTSAVE = 20;
	public static final int ACTPROMPTDO = 21;
	public static final int ACTPOPUPHEADER = 22;
	public static final int ACTPOPUPPROMPT = 23;
	public static final int ACTPOPUPSELECT = 24;
	public static final int ACTPOPUPMULTI = 25;
	public static final int ACTPOPUPSAVE = 26;
	public static final int ACTPOPUPDO = 27;
	public static final int ACTPROGSTYLE = 28;
	public static final int ACTPROGMIN = 29;
	public static final int ACTPROGMAX = 30;
	public static final int ACTPROGSET = 31;
	public static final int ACTPROGTIME = 32;
	public static final int ACTPROGSAVE = 33;
	public static final int ACTPROGDO = 34;
	public static final int ACTPROGKILL = 35;
	public static final int ACTFILEDIR = 36;
	public static final int ACTFILESAVE = 37;
	public static final int ACTFILEDO = 38;
	public static final int ACTAGREEMSGHTML = 39;
	public static final int ACTAGREECHECKTXT = 40;
	public static final int ACTAGREESAVE = 41;
	public static final int ACTAGREEDO = 42;
	public static final int ACTSLIDERMIN = 43;
	public static final int ACTSLIDERMAX = 44;
	public static final int ACTSLIDERVALUE = 45;
	public static final int ACTSLIDERSAVE = 46;
	public static final int ACTSLIDERDO = 47;
	public static final int ACTCOLORSAVE = 48;
	public static final int ACTCOLORDO = 49;
	public static final int ACTDATEDISPLAY = 50;
	public static final int ACTDATESTARTT = 51;
	public static final int ACTDATESAVE = 52;
	public static final int ACTDATEDO = 53;
	public static final int ACTTIMEDISP = 54;
	public static final int ACTTIMESTARTT = 55;
	public static final int ACTTIMESTYLE = 56;
	public static final int ACTTIMESAVE = 57;
	public static final int ACTTIMEDO = 58;
	public static final int ACTQUICKMESSAGE = 59;
	public static final int ACTQUICKALIGN = 60;
	public static final int ACTQUICKTIME = 61;
	public static final int ACTQUICKDO = 62;
	public static final int ACTPUSHTITLE = 63;
	public static final int ACTPUSHICON = 64;
	public static final int ACTPUSHMESSAGE = 65;
	public static final int ACTPUSHACTION = 66;
	public static final int ACTPUSHSOUND = 67;
	public static final int ACTPUSHVIBRATE = 68;
	public static final int ACTPUSHDO = 69;
	public static final int ACTMENUMESSAGE = 70;
	public static final int ACTMENUALIGN = 71;
	public static final int ACTMENUTIME = 72;
	public static final int ACTMENUSAVE = 73;
	public static final int ACTMENUDO = 74;
	public static final int ACTDIALOGTHEME = 75;
	public static final int ACTIMAGEFILEP = 76;
	public static final int ACTTYPEFILEPICK = 77;
	public static final int ACTDIALOGTITLECOLOR = 78;
	public static final int ACTDIALOGDISMISS = 79;
	public static final int ACTDLGTHCONTROL = 80;
	public static final int ACTDLGFILEFILTER = 81;

	public static final int EXPALERTRET = 0;
	public static final int EXPLOGINUSER = 1;
	public static final int EXPLOGINPASSWORD = 2;
	public static final int EXPLOGINREM = 3;
	public static final int EXPLOGINRET = 4;
	public static final int EXPPASSPASS = 5;
	public static final int EXPPASSNEW = 6;
	public static final int EXPPASSCONF = 7;
	public static final int EXPPASSWORDRET = 8;
	public static final int EXPPROMPTTEXT = 9;
	public static final int EXPPROMPTRET = 10;
	public static final int EXPPOPUPTEXT = 11;
	public static final int EXPPOPUPITEM = 12;
	public static final int EXPPOPUPRET = 13;
	public static final int EXPAGREECHK = 14;
	public static final int EXPAGREERET = 15;
	public static final int EXPSLIDERVALUE = 16;
	public static final int EXPSLIDERRET = 17;
	public static final int EXPFILENAME = 18;
	public static final int EXPFILERET = 19;
	public static final int EXPCOLORVALUE = 20;
	public static final int EXPCOLORALPHA = 21;
	public static final int EXPCOLORRET = 22;
	public static final int EXPDATEYEAR = 23;
	public static final int EXPDATEMONTH = 24;
	public static final int EXPDATEDAY = 25;
	public static final int EXPDATERET = 26;
	public static final int EXPTIMEHOUR = 27;
	public static final int EXPTIMEMINS = 28;
	public static final int EXPTIMESECS = 29;
	public static final int EXPTIMERET = 30;
	public static final int EXPMENUVAL = 31;
	public static final int EXPMENUSTR = 32;

	// </editor-fold>
	public short IconImages[];

	short ImagesNumbers;

	private int nTheme = 0;
	
	private CommonDlg mDialog = null;

	//private alertDialogMMF mAlert = null;
	private loginDialogMMF mLogin = null;
	private passwordDialogMMF mPassword = null;
	private promptDialogMMF mPrompt = null;
	private popupDialogMMF mPopup = null;
	private agreementDialogMMF mAgreement = null;
	private sliderDialogMMF mSlider = null;
	private fileDialogMMF mFile = null;
	//private colorDialogMMF mColor = null;
	private progDialogMMF mProg = null;
	private timeDialogMMF mTime = null;
	private dateDialogMMF mDate = null;

	private toastDialogMMF mToast = null;
	private menuDialogMMF mMenu = null;

	private notificationDialogMMF mPush = null;

	Map <String, alertDialogMMF> alertDlgs;    
	Map <String, loginDialogMMF> loginDlgs;
	Map <String, passwordDialogMMF> passwordDlgs;
	Map <String, promptDialogMMF> promptDlgs;
	Map <String, popupDialogMMF> popupDlgs;
	Map <String, agreementDialogMMF> agreeDlgs;
	Map <String, sliderDialogMMF> sliderDlgs;
	Map <String, fileDialogMMF> fileDlgs;
	Map <String, colorDialogMMF> colorDlgs;
	Map <String, progDialogMMF> progDlgs;
	Map <String, timeDialogMMF> timeDlgs;
	Map <String, dateDialogMMF> dateDlgs;
	Map <String, menuDialogMMF> menuDlgs;


	private    int alertButton;

	private String loginUser = null;
	private String loginPass = null;
	private    int loginRem;
	private    int loginButton;

	private String passPass = null;
	private String passNewx = null;
	private String passConf = null;
	private    int passButton;

	private String promptStr = null;
	private    int promptButton;

	private String popupStr = null;
	private    int popupChoice;
	private    int popupButton;

	private int agreechk;
	private int agreeButton;

	private int sliderVal;
	private int sliderButton;

	private String fileName = null;
	private    int fileButton;

	private int colorVal;
	private int colorAlpha;
	private int colorButton;

	private int dateYear;
	private int dateMonth;
	private int dateDay;
	private int dateButton;

	private int timeHours;
	private int timeMins;
	private int timeButton;

	private String menuStr = null;
	private    int menuVal;

	private int ImgFolder=-1;
	private int ImgFiles =-1;
	private int TypeFilePicker;

	private boolean bFontTheme=false;
	private Dialog ExitDlg = null;
	
	private CValue expRet;
	
	///////////////////////////////////////////////////////////////////////////
	public Drawable loadImageFromAction(String url) {

		if(url.contains("http://") || url.contains("https://"))
			try {
				Drawable d = null;
				InputStream is = (InputStream) new URL(url).getContent();
				d = Drawable.createFromStream(is, "icon");
				return d;

			} catch (Exception e) {
				return null;
			}
		else if(url.contains("android.") && url.contains("drawable."))
		{
			try {
				Drawable d = null;
				String resource = url.substring(url.lastIndexOf(".")+1, url.length());
				int id = MMFRuntime.inst.getResources().getIdentifier(resource, "drawable", "android");
				d = MMFRuntime.inst.getResources().getDrawable(id);
				return d;

			} catch (Exception e) {
				return null;
			}
			
		}
		else if(url.contains("drawable."))
		{
			try {
				Drawable d = null;
				String resource = url.substring(url.lastIndexOf(".")+1, url.length());
				int id = MMFRuntime.inst.getResources().getIdentifier(resource, "drawable", MMFRuntime.inst.getClass().getPackage().getName());
				d = MMFRuntime.inst.getResources().getDrawable(id);
				return d;

			} catch (Exception e) {
				return null;
			}
			
		}
		else {
			int nImageNum = -1;

			try {
				nImageNum = Integer.parseInt(url) - 1;
				if(IconImages.length > 0 &&  nImageNum != -1) {
					short Image = IconImages[nImageNum];
					CImage cImage = ho.getImageBank().getImageFromHandle(Image);

					if(cImage == null)
						return null;

					int[] mImage = cImage.getRawPixels();

					if(mImage == null)
						return null;

					Bitmap image = null;

					image = Bitmap.createBitmap(cImage.getWidth(), cImage.getHeight(), cImage.getFormat());

					image.setPixels(mImage, 0, cImage.getWidth(), 0, 0, cImage.getWidth(), cImage.getHeight());

					cImage = null;

					Resources r = MMFRuntime.inst.getResources();

					Drawable d = new BitmapDrawable(r, image);

					return d;
				}
				else
					return null;
			} catch(NumberFormatException e) {
				System.out.println("Could not parse " + e);
			} 
		}
		return null;    	
	}

	class CommonDlg {
		// return Values
		String   Id = null;
		String bRet = null;
		//String  Tag = null;
		//String sRet = null;
		//int    nRet = -1;

		int Type;

		String   Title = null;
		String    Msg  = null;
		String   Icon  = null;
		String Buttons = null;

		boolean bFontTheme;
		
		int nBtCount;       	
		int nSize;
		int nAlign;

		int nTheme;
		int TitleColor;

		void clear () {
			// return Values
			Id = null;
			bRet = null;
			//Tag = null;
			//sRet = null;
			//nRet = -1;

			Type = -1;

			Title = null;
			Msg  = null;
			Icon  = null;
			Buttons = null;
			bFontTheme = false;
			nBtCount = -1;       
			nSize = -1;
			nAlign = -1;  
			TitleColor = -1;
		}
	}


	private void FillAlert(alertDialogMMF alert, String name) {

		if(alert != null) {
			alert.clear();

			alert.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				alert.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				alert.Msg = mDialog.Msg;
			alert.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				alert.Buttons = mDialog.Buttons;
			else
				alert.Buttons = null;				
			alert.nAlign = mDialog.nAlign;
			alert.nSize = mDialog.nSize;
			alert.nTheme = nTheme;
			alert.bFontTheme = bFontTheme;
			alert.TitleColor = mDialog.TitleColor;
			if(mDialog.Icon != null)
				alert.dDraw = loadImageFromAction(mDialog.Icon);
		}

	}

	private void FillLogin(loginDialogMMF login, String name) {

		if(login != null) {
			login.clear();

			login.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				login.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				login.Msg = mDialog.Msg;
			login.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				login.Buttons = mDialog.Buttons;
			else
				login.Buttons = null;				
			login.nAlign = mDialog.nAlign;
			login.nSize = mDialog.nSize;
			
			login.LogUser = mLogin.LogUser;
			login.LogPass = mLogin.LogPass;
			login.LogRemm = mLogin.LogRemm;
			login.UserInit= mLogin.UserInit;
			
			login.nTheme = nTheme;
			login.TitleColor = mDialog.TitleColor;
			
			if(mDialog.Icon != null)
				login.dDraw = loadImageFromAction(mDialog.Icon);

		}

	}

	private void FillPassword(passwordDialogMMF password, String name) {

		if(password != null) {
			password.clear();

			password.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				password.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				password.Msg = mDialog.Msg;
			password.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				password.Buttons = mDialog.Buttons;
			else
				password.Buttons = null;				
			password.nAlign = mDialog.nAlign;
			password.nSize = mDialog.nSize;
			password.nTheme = nTheme;
			password.bFontTheme = bFontTheme;
			password.TitleColor = mDialog.TitleColor;
			
			password.OldPass = mPassword.OldPass;
			password.NewPass = mPassword.NewPass;
			password.ConPass = mPassword.ConPass;

			if(mDialog.Icon != null)
				password.dDraw = loadImageFromAction(mDialog.Icon);

		}

	}


	private void FillPrompt(promptDialogMMF prompt, String name) {

		if(prompt != null) {
			prompt.clear();

			prompt.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				prompt.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				prompt.Msg = mDialog.Msg;
			prompt.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				prompt.Buttons = mDialog.Buttons;
			else
				prompt.Buttons = null;				
			prompt.nAlign = mDialog.nAlign;
			prompt.nSize = mDialog.nSize;
			prompt.nTheme = nTheme;
			prompt.bFontTheme = bFontTheme;
			prompt.TitleColor = mDialog.TitleColor;
			
			prompt.Prompt = mPrompt.Prompt;
			prompt.PromptInit = mPrompt.PromptInit;

			if(mDialog.Icon != null)
				prompt.dDraw = loadImageFromAction(mDialog.Icon);

		}

	}

	private void FillPopup(popupDialogMMF popup, String name) {

		if(popup != null) {
			popup.clear();

			popup.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				popup.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				popup.Msg = mDialog.Msg;
			popup.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				popup.Buttons = mDialog.Buttons;
			else
				popup.Buttons = null;				
			popup.nAlign = mDialog.nAlign;
			popup.nSize = mDialog.nSize;
			popup.nTheme = nTheme;
			popup.TitleColor = mDialog.TitleColor;
			
			popup.Header = mPopup.Header;
			popup.Lists = mPopup.Lists;
			popup.Choosed = mPopup.Choosed;
			popup.isMultiple = mPopup.isMultiple;

			if(mDialog.Icon != null)
				popup.dDraw = loadImageFromAction(mDialog.Icon);

			mPopup.clear();
		}

	}

	private void FillAgreement(agreementDialogMMF agree, String name) {

		if(agree != null) {
			agree.clear();

			agree.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				agree.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				agree.Msg = mDialog.Msg;
			agree.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				agree.Buttons = mDialog.Buttons;
			else
				agree.Buttons = null;				
			agree.nAlign = mDialog.nAlign;
			agree.nSize = mDialog.nSize;
			agree.nTheme = nTheme;
			agree.bFontTheme = bFontTheme;
			agree.TitleColor = mDialog.TitleColor;
			
			agree.AgreeHTML = mAgreement.AgreeHTML;
			agree.AcceptedLabel = mAgreement.AcceptedLabel;
			agree.AcceptedTerms = mAgreement.AcceptedTerms;

			if(mDialog.Icon != null)
				agree.dDraw = loadImageFromAction(mDialog.Icon);
			
			mAgreement.clear();
		}

	} 
	
	private void FillSlider(sliderDialogMMF slider, String name) {

		if(slider != null) {
			slider.clear();

			slider.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				slider.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				slider.Msg = mDialog.Msg;

			slider.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				slider.Buttons = mDialog.Buttons;
			else
				slider.Buttons = null;				
			slider.nAlign = mDialog.nAlign;
			slider.nSize = mDialog.nSize;
			slider.nTheme = nTheme;
			slider.bFontTheme = bFontTheme;
			slider.TitleColor = mDialog.TitleColor;
			
			slider.Min = mSlider.Min;
			slider.Max = mSlider.Max;
			slider.value = mSlider.value;

			if(mDialog.Icon != null)
				slider.dDraw = loadImageFromAction(mDialog.Icon);

			mSlider.clear();
		}

	}       

	private void FillFileSelector(fileDialogMMF file, String name) {

		if(file != null) {
			file.clear();

			file.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				file.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				file.Msg = mDialog.Msg;

			file.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				file.Buttons = mDialog.Buttons;
			else
				file.Buttons = null;				
			file.nAlign = mDialog.nAlign;
			file.nSize = mDialog.nSize;
			file.nTheme = nTheme;
			file.bFontTheme = bFontTheme;
			file.TitleColor = mDialog.TitleColor;
			
			file.DefaultDir = mFile.DefaultDir;
			file.ParentTxt  = mFile.ParentTxt;
			file.FolderTxt  = mFile.FolderTxt;
			file.FileTxt    = mFile.FileTxt;
			file.sExt       = mFile.sExt;

			if(TypeFilePicker == 0)
				file.TypeFilePicker = false;
			else
				file.TypeFilePicker = true;
			
			if(mDialog.Icon != null)
				file.dDraw = loadImageFromAction(mDialog.Icon);
			
			if(ImgFolder != -1) {
				file.dDrawFolder = loadImageFromAction(String.valueOf(ImgFolder));
			}
			if(ImgFiles != -1) {
				file.dDrawFiles = loadImageFromAction(String.valueOf(ImgFiles));
			}
		}

	}       

	private void FillColor(colorDialogMMF color, String name) {

		if(color != null) {
			color.clear();

			color.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				color.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				color.Msg = mDialog.Msg;
			color.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				color.Buttons = mDialog.Buttons;
			else
				color.Buttons = null;				
			color.nAlign = mDialog.nAlign;
			color.nSize = mDialog.nSize;
			color.nTheme = nTheme;
			color.bFontTheme = bFontTheme;
			color.TitleColor = mDialog.TitleColor;
			color.RetColor = 0xFFFFFFF;
			if(mDialog.Icon != null)
				color.dDraw = loadImageFromAction(mDialog.Icon);

		}

	}
	
	private void FillProg(progDialogMMF prog, String name) {

		if(prog != null) {
			prog.clear();

			prog.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				prog.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				prog.Msg = mDialog.Msg;
			prog.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				prog.Buttons = mDialog.Buttons;
			else
				prog.Buttons = null;				
			prog.nAlign = mDialog.nAlign;
			prog.nSize = mDialog.nSize;
			prog.nTheme = nTheme;
			prog.bFontTheme = bFontTheme;
			prog.TitleColor = mDialog.TitleColor;
			
			prog.style = mProg.style;
			prog.min   = mProg.min;
			prog.max   = mProg.max;
			prog.value = mProg.value;
			prog.nTimer = mProg.nTimer;
			
			if(mDialog.Icon != null)
				prog.dDraw = loadImageFromAction(mDialog.Icon);
			
			mProg.clear();
		}

	}

	private void FillTime(timeDialogMMF time, String name) {

		if(time != null) {
			time.clear();

			time.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				time.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				time.Msg = mDialog.Msg;
			time.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				time.Buttons = mDialog.Buttons;
			else
				time.Buttons = null;				
			time.nAlign = mDialog.nAlign;
			time.nSize = mDialog.nSize;
			time.nTheme = nTheme;
			time.bFontTheme = bFontTheme;
			time.TitleColor = mDialog.TitleColor;
			
			time.hours = mTime.hours;
			time.mins = mTime.mins;
			time.style = mTime.style;
			time.what = mTime.what;
			
			if(mDialog.Icon != null)
				time.dDraw = loadImageFromAction(mDialog.Icon);

		}

	}

	private void FillDate(dateDialogMMF date, String name) {

		if(date != null) {
			date.clear();

			date.Id = name;
			if(mDialog.Title != null && mDialog.Title.length() > 0)
				date.Title = mDialog.Title;
			if(mDialog.Msg != null && mDialog.Msg.length() > 0)
				date.Msg = mDialog.Msg;
			date.Icon = mDialog.Icon;
			if(mDialog.Buttons != null && mDialog.Buttons.length() > 0)
				date.Buttons = mDialog.Buttons;
			else
				date.Buttons = null;				
			date.nAlign = mDialog.nAlign;
			date.nSize = mDialog.nSize;
			
			date.nTheme = nTheme;
			date.bFontTheme = bFontTheme;
			date.TitleColor = mDialog.TitleColor;
			date.day = mDate.day;
			date.month = mDate.month;
			date.year = mDate.year;
			date.style = mDate.style;
			date.what = mDate.what;
			date.calOff = mDate.calOff;
			
			if(mDialog.Icon != null)
				date.dDraw = loadImageFromAction(mDialog.Icon);

		}

	}

	private void FillMenu(menuDialogMMF menu, String name) {

		int smax;

		if(menu != null) {
			menu.clear();

			menu.Id = name;
			menu.nTheme = nTheme;
			if(mMenu.Items.length() > 0)
				menu.Items = mMenu.Items;
			
			menu.Icon = mMenu.Icon;
			menu.nAlign = mMenu.nAlign;
			menu.timeout = mMenu.timeout;

			if(menu.Items != null) {
				String [] s = menu.Items.split(",");
				if(s.length > 0) {
					smax = s.length;
					if(menu.Icon != null) {
						String [] mIcon = menu.Icon.split(",");
						if(mIcon.length > 0) {
							menu.dDraw = new Drawable[smax];
							int i = 0;
							for(String icon : mIcon) {
								menu.dDraw[i] = loadImageFromAction(icon);
								i++;
								if(i >= smax)
									break;
							}
						}
					}
				}
			}
		}
	}

	///////////////////////////////////////////////////////////////////////
	//
	//			Dialogs Listeners
	//
	///////////////////////////////////////////////////////////////////////

	private OnAlertResultListener alertListener = new OnAlertResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			alertButton  = nRet;
			ExitDlg = null;
			ho.pushEvent(CNDALERTDIALOG, 0);
			
		}
	};

	private OnLoginResultListener loginListener = new OnLoginResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet, String RetUser,
				String RetPass, int RetRemm) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			loginButton = nRet;
			loginUser = RetUser;
			loginPass = RetPass;
			loginRem = RetRemm;		
			ExitDlg = null;
			ho.pushEvent(CNDLOGINDIALOG, 0);

		}
	};

	private OnPasswordResultListener passwordListener = new OnPasswordResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet,
				String RetOldPass, String RetNewPass, String RetConfirm) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			passButton = nRet;
			passPass = RetOldPass;
			passNewx = RetNewPass;
			passConf = RetConfirm;
			ExitDlg = null;
			ho.pushEvent(CNDPASSWORDDIALOG, 0);

		}

	};

	private OnPromptResultListener promptListener = new OnPromptResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet, String RetPrompt) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			promptButton = nRet;
			promptStr = RetPrompt;
			ExitDlg = null;
			ho.pushEvent(CNDPROMPTDIALOG, 0);

		}

	};

	private OnPopupResultListener popupListener = new OnPopupResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet, int nChoice, String Selected) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			popupButton = nRet;
			popupChoice = nChoice;
			popupStr = Selected;
			ExitDlg = null;
			ho.pushEvent(CNDPOPUPDIALOG, 0);
		}

		@Override
		public void onChange(String Id, int nChoice) {
			mDialog.Id   = Id;
			popupChoice = nChoice;
			ExitDlg = null;
			ho.pushEvent(CNDPOPUPCHOICE, 0);
		}

	};

	private OnAgreementResultListener agreementListener = new OnAgreementResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet, int Accepted) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			agreeButton = nRet;
			agreechk = Accepted;
			ExitDlg = null;
			ho.pushEvent(CNDAGREEDIALOG, 0);

		}

	};

	private OnSliderResultListener sliderListener = new OnSliderResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet, int RetValue) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			sliderButton = nRet;
			sliderVal = RetValue;
			ExitDlg = null;
			ho.pushEvent(CNDSLIDERDIALOG, 0);

		}

		@Override
		public void onValueChange(String Id, String bRet, int nRet, int RetValue) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			sliderVal = RetValue;
			ExitDlg = null;
			ho.pushEvent(CNDSLIDERVALUE, 0);

		}

	};

	private OnFileSelResultListener fileListener = new OnFileSelResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet, String RetFile) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			fileButton = nRet;
			fileName = RetFile;
			ExitDlg = null;
			ho.pushEvent(CNDFILEPICKER, 0);

		}

	};

	private OnColorResultListener colorListener = new OnColorResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet, int RetColor,
				int RetAlpha) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			colorButton = nRet;
			colorVal = RetColor;
			colorAlpha = RetAlpha;
			ExitDlg = null;
			ho.pushEvent(CNDCOLORPICKER, 0);

		}

	};

	private OnTimeResultListener timeListener = new OnTimeResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet, int RetHours,	int RetMins) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			timeButton = nRet;
			timeHours = RetHours;
			timeMins  = RetMins;
			ExitDlg = null;
			ho.pushEvent(CNDTIMEPICKER, 0);

		}

	};

	private OnDateResultListener dateListener = new OnDateResultListener() {

		@Override
		public void onClick(String Id, String bRet, int nRet, int RetDay, int RetMonth, int RetYear) {
			mDialog.Id   = Id;
			mDialog.bRet = bRet;
			dateButton = nRet;
			dateDay = RetDay;
			dateMonth = RetMonth;
			dateYear = RetYear;
			ExitDlg = null;
			ho.pushEvent(CNDDATEPICKER, 0);

		}

	};

	private OnToastResultListener quickListener = new OnToastResultListener() {

		@Override
		public void onClick(String Id) {
			mDialog.Id   = Id;
			ho.pushEvent(CNDQUICKENDED, 0);

		}

	};

	private OnMenuResultListener menuListener = new OnMenuResultListener() {

		@Override
		public void onClick(String Id, String RetMenu, int RetItem) {
			mDialog.Id   = Id;
			menuVal = RetItem;
			menuStr = RetMenu;
			ho.pushEvent(CNDMENUDIALOG, 0);

		}

	};

	private OnPushListener pushListener = new OnPushListener() {

		@Override
		public void onNotification(String Id) {
			mDialog.Id   = Id;
			ho.pushEvent(CNDPUSHSEND, 0);

		}


	};

	public CRunAndroidDialog()
	{
		if(android.os.Build.VERSION.SDK_INT > 10) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy);
        }
		expRet = new CValue(0);
	}
	
	public @Override int getNumberOfConditions()
	{
		return CND_LAST;
	}
	public @Override boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
	{
		file.bUnicode = true;
		file.skipBytes(8);
		file.readString(261);
		file.readString(261);
		file.readString(261);
		ImagesNumbers = file.readShort();
		IconImages = new short[ImagesNumbers];

		if(ImagesNumbers > 0) {
			int i;
			for (i = 0; i < ImagesNumbers; i++)
			{
				IconImages[i] = file.readShort();
			}

			ho.loadImageList(IconImages);
		}

		mDialog = new CommonDlg();
		mDialog.clear();
		
		//mAlert    = new alertDialogMMF(ho, alertListener);
		mLogin    = new loginDialogMMF(ho, loginListener);
		mPassword = new passwordDialogMMF(ho, passwordListener);
		mPrompt   = new promptDialogMMF(ho, promptListener);
		mPopup    = new popupDialogMMF(ho, popupListener);
		mAgreement= new agreementDialogMMF(ho, agreementListener);
		mSlider   = new sliderDialogMMF(ho, sliderListener);
		mFile     = new fileDialogMMF(ho, fileListener);
		//mColor    = new colorDialogMMF(ho, colorListener);

		mProg    = new progDialogMMF(ho);
		mDate    = new dateDialogMMF(ho, dateListener);
		mTime    = new timeDialogMMF(ho, timeListener);

		mToast   = new toastDialogMMF(ho, quickListener);
		mToast.clear();

		mMenu    = new menuDialogMMF(ho, menuListener);

		mPush    = new notificationDialogMMF(ho, pushListener);
		mPush.clear();

		alertDlgs    = new HashMap<String, alertDialogMMF> ();
		loginDlgs    = new HashMap<String, loginDialogMMF> ();
		passwordDlgs = new HashMap<String, passwordDialogMMF> ();
		promptDlgs   = new HashMap<String, promptDialogMMF> ();
		popupDlgs    = new HashMap<String, popupDialogMMF> ();
		agreeDlgs    = new HashMap<String, agreementDialogMMF> ();
		sliderDlgs   = new HashMap<String, sliderDialogMMF> ();
		fileDlgs   = new HashMap<String, fileDialogMMF> ();
		colorDlgs   = new HashMap<String, colorDialogMMF> ();
		progDlgs   = new HashMap<String, progDialogMMF> ();
		dateDlgs   = new HashMap<String, dateDialogMMF> ();
		timeDlgs   = new HashMap<String, timeDialogMMF> ();

		menuDlgs   = new HashMap<String, menuDialogMMF> ();

		return false;
	}

	public @Override void destroyRunObject(boolean bFast)
	{
		if(ExitDlg != null)
			ExitDlg.dismiss();
		
		alertDlgs.clear();
		loginDlgs.clear();
		passwordDlgs.clear();
		promptDlgs.clear();
		popupDlgs.clear();
		agreeDlgs.clear();
		sliderDlgs.clear();
		fileDlgs.clear();
		colorDlgs.clear();
		progDlgs.clear();
		dateDlgs.clear();
		timeDlgs.clear();
		menuDlgs.clear();

		mDialog = null;

		//mAlert    = null;
		mLogin    = null;
		mPassword = null;
		mPrompt   = null;
		mPopup    = null;
		mAgreement= null;
		mSlider   = null;
		mFile     = null;
		//mColor    = null;

		mProg    = null;
		mDate    = null;
		mTime    = null;

		mToast   = null;
		mMenu    = null;

		mPush    = null;
		
		pushListener = null;
		menuListener = null;
		quickListener = null;
		dateListener = null;
		timeListener = null;
		colorListener = null;
		fileListener = null;
		sliderListener = null;
		agreementListener = null;
		popupListener = null;
		promptListener = null;
		passwordListener = null;
		loginListener = null;
		alertListener = null;		
	}
	
	public @Override int handleRunObject()
	{
		return REFLAG_ONESHOT;
	}

	public @Override void pauseRunObject()
	{
		if(ExitDlg != null)
			ExitDlg.dismiss();		
	}

	public @Override void continueRunObject()
	{
	}

	// Conditions
	// -------------------------------------------------
	public @Override boolean condition(int num, CCndExtension cnd)
	{
		switch (num)
		{
		case CNDALERTDIALOG:
			return cndAlertDialog(cnd);
		case CNDLOGINDIALOG:
			return cndLoginDialog(cnd);
		case CNDPASSWORDDIALOG:
			return cndPasswordDialog(cnd);
		case CNDPROMPTDIALOG:
			return cndPromptDialog(cnd);
		case CNDPOPUPDIALOG:
			return cndPopupDialog(cnd);
		case CNDPOPUPCHOICE:
			return cndPopupChoice(cnd);
		case CNDAGREEDIALOG:
			return cndAgreeDialog(cnd);
		case CNDSLIDERDIALOG:
			return cndSliderDialog(cnd);
		case CNDSLIDERVALUE:
			return cndSliderValue(cnd);
		case CNDFILEPICKER:
			return cndFilePicker(cnd);
		case CNDCOLORPICKER:
			return cndColorPicker(cnd);
		case CNDDATEPICKER:
			return cndDatePicker(cnd);
		case CNDTIMEPICKER:
			return cndTimePicker(cnd);
		case CNDQUICKENDED:
			return cndQuickEnd(cnd);
		case CNDPUSHSEND:
			return cndPushSent(cnd);
		case CNDMENUDIALOG:
			return cndMenuDialog(cnd);
		case CNDLASTERROR:
			return cndLastError(cnd);
		}
		return false;
	}

	// Actions
	// -------------------------------------------------
	public @Override void action(int num, CActExtension act)
	{
		switch (num)
		{
		case ACTDIALOGTITLE:
			actDialogTitle(act);
			break;
		case ACTDIALOGICON:
			actDialogIcon(act);
			break;
		case ACTDIALOGMESSAGE:
			actDialogMessage(act);
			break;
		case ACTDIALOGBUTTONTEXT:
			actDialogButtonText(act);
			break;
		case ACTDIALOGSIZE:
			actDialogSize(act);
			break;
		case ACTDIALOGALIGN:
			actDialogAlign(act);
			break;
		case ACTALERTSAVE:
			actAlertSave(act);
			break;
		case ACTALERTDO:
			actAlertDo(act);
			break;
		case ACTLOGINUSER:
			actLoginUser(act);
			break;
		case ACTLOGINPASSWORD:
			actLoginPassword(act);
			break;
		case ACTLOGINREMEMBER:
			actLoginRemember(act);
			break;
		case ACTLOGINFLAGREMEMBER:
			actLoginFlagRemember(act);
			break;
		case ACTLOGINSAVE:
			actLoginSave(act);
			break;
		case ACTLOGINDO:
			actLoginDo(act);
			break;
		case ACTPASSWORDOLD:
			actPasswordOld(act);
			break;
		case ACTPASSWORDNEW:
			actPasswordNew(act);
			break;
		case ACTPASSWORDCONFIRM:
			actPasswordConfirm(act);
			break;
		case ACTPASSWORDSAVE:
			actPasswordSave(act);
			break;
		case ACTPASSWORDDO:
			actPasswordDo(act);
			break;
		case ACTPROMPTLABEL:
			actPromptLabel(act);
			break;
		case ACTPROMPTSAVE:
			actPromptSave(act);
			break;
		case ACTPROMPTDO:
			actPromptDo(act);
			break;
		case ACTPOPUPHEADER:
			actPopupHeader(act);
			break;
		case ACTPOPUPPROMPT:
			actPopupPrompt(act);
			break;
		case ACTPOPUPSELECT:
			actPopupSelect(act);
			break;
		case ACTPOPUPMULTI:
			actPopupMulti(act);
			break;
		case ACTPOPUPSAVE:
			actPopupSave(act);
			break;
		case ACTPOPUPDO:
			actPopupDo(act);
			break;
		case ACTPROGSTYLE:
			actProgStyle(act);
			break;
		case ACTPROGMIN:
			actProgMin(act);
			break;
		case ACTPROGMAX:
			actProgMax(act);
			break;
		case ACTPROGSET:
			actProgSet(act);
			break;
		case ACTPROGTIME:
			actProgTime(act);
			break;
		case ACTPROGSAVE:
			actProgSave(act);
			break;
		case ACTPROGDO:
			actProgDo(act);
			break;
		case ACTPROGKILL:
			actProgKill(act);
			break;
		case ACTFILEDIR:
			actFileDir(act);
			break;
		case ACTFILESAVE:
			actFileSave(act);
			break;
		case ACTFILEDO:
			actFileDo(act);
			break;
		case ACTAGREEMSGHTML:
			actAgreeMsgHtml(act);
			break;
		case ACTAGREECHECKTXT:
			actAgreeCheckTxt(act);
			break;
		case ACTAGREESAVE:
			actAgreeSave(act);
			break;
		case ACTAGREEDO:
			actAgreeDo(act);
			break;
		case ACTSLIDERMIN:
			actSliderMin(act);
			break;
		case ACTSLIDERMAX:
			actSliderMax(act);
			break;
		case ACTSLIDERVALUE:
			actSliderValue(act);
			break;
		case ACTSLIDERSAVE:
			actSliderSave(act);
			break;
		case ACTSLIDERDO:
			actSliderDo(act);
			break;
		case ACTCOLORSAVE:
			actColorSave(act);
			break;
		case ACTCOLORDO:
			actColorDo(act);
			break;
		case ACTDATEDISPLAY:
			actDateDisplay(act);
			break;
		case ACTDATESTARTT:
			actDateStartT(act);
			break;
		case ACTDATESAVE:
			actDateSave(act);
			break;
		case ACTDATEDO:
			actDateDo(act);
			break;
		case ACTTIMEDISP:
			actTimeDisp(act);
			break;
		case ACTTIMESTARTT:
			actTimeStartT(act);
			break;
		case ACTTIMESTYLE:
			actTimeStyle(act);
			break;
		case ACTTIMESAVE:
			actTimeSave(act);
			break;
		case ACTTIMEDO:
			actTimeDo(act);
			break;
		case ACTQUICKMESSAGE:
			actQuickMessage(act);
			break;
		case ACTQUICKALIGN:
			actQuickAlign(act);
			break;
		case ACTQUICKTIME:
			actQuickTime(act);
			break;
		case ACTQUICKDO:
			actQuickDo(act);
			break;
		case ACTPUSHTITLE:
			actPushTitle(act);
			break;
		case ACTPUSHICON:
			actPushIcon(act);
			break;
		case ACTPUSHMESSAGE:
			actPushMessage(act);
			break;
		case ACTPUSHACTION:
			actPushAction(act);
			break;
		case ACTPUSHSOUND:
			actPushSound(act);
			break;
		case ACTPUSHVIBRATE:
			actPushVibrate(act);
			break;
		case ACTPUSHDO:
			actPushDo(act);
			break;
		case ACTMENUMESSAGE:
			actMenuMessage(act);
			break;
		case ACTMENUALIGN:
			actMenuAlign(act);
			break;
		case ACTMENUTIME:
			actMenuTime(act);
			break;
		case ACTMENUSAVE:
			actMenuSave(act);
			break;
		case ACTMENUDO:
			actMenuDo(act);
			break;
		case ACTDIALOGTHEME:
			actDialogtheme(act);
			break;
		case ACTIMAGEFILEP:
			actImageFilePicker(act);
			break;
		case ACTTYPEFILEPICK:
			actTypeFilePicker(act);
			break;
		case ACTDIALOGTITLECOLOR:
			actDialogTitleColor(act);
			break;
		case ACTDIALOGDISMISS:
			actDialogDismiss(act);
			break;
		case ACTDLGTHCONTROL:
			actFontThemeControl(act);
			break;
		case ACTDLGFILEFILTER:
			actFileFilter(act);
			break;
		}				
	}
	
	// Expressions
	// -------------------------------------------------
	public @Override CValue expression(int num)
	{
		switch (num)
		{
		case EXPALERTRET:
			return expAlertRet();
		case EXPLOGINUSER:
			return expLoginUser();
		case EXPLOGINPASSWORD:
			return expLoginPassword();
		case EXPLOGINREM:
			return expLoginRem();
		case EXPLOGINRET:
			return expLoginRet();
		case EXPPASSPASS:
			return expPassPass();
		case EXPPASSNEW:
			return expPassNew();
		case EXPPASSCONF:
			return expPassConf();
		case EXPPASSWORDRET:
			return expPasswordRet();
		case EXPPROMPTTEXT:
			return expPromptText();
		case EXPPROMPTRET:
			return expPromptRet();
		case EXPPOPUPTEXT:
			return expPopupText();
		case EXPPOPUPITEM:
			return expPopupChoice();
		case EXPPOPUPRET:
			return expPopupRet();
		case EXPAGREECHK:
			return expAgreeChk();
		case EXPAGREERET:
			return expAgreeRet();
		case EXPSLIDERVALUE:
			return expSliderValue();
		case EXPSLIDERRET:
			return expSliderRet();
		case EXPFILENAME:
			return expFileName();
		case EXPFILERET:
			return expFileRet();
		case EXPCOLORVALUE:
			return expColorValue();
		case EXPCOLORALPHA:
			return expColorAlpha();
		case EXPCOLORRET:
			return expColorRet();
		case EXPDATEYEAR:
			return expDateyear();
		case EXPDATEMONTH:
			return expDatemonth();
		case EXPDATEDAY:
			return expDateday();
		case EXPDATERET:
			return expDateRet();
		case EXPTIMEHOUR:
			return expTimeHour();
		case EXPTIMEMINS:
			return expTimeMins();
		case EXPTIMESECS:
			return expTimeSecs();
		case EXPTIMERET:
			return expTimeRet();
		case EXPMENUVAL:
			return expMenuVal();
		case EXPMENUSTR:
			return expMenuStr();
		}
		return null;
	}

	private int IntFromButton(String button) {
		int result = -1;
		try {
			result = Integer.parseInt(button);
		}catch (Exception e) {
			result = -1;
		}
		return result;
	}
	//////////////////////////////////////////////////////////////////
	//
	//                    Conditions
	//
	//////////////////////////////////////////////////////////////////

	private boolean cndAlertDialog(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(alertButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndLoginDialog(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(loginButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndPasswordDialog(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(passButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndPromptDialog(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(promptButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndPopupDialog(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(popupButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndPopupChoice(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		int param1 = cnd.getParamExpression(rh,1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			//if(param1 == popupChoice || param1 == -1) {
			//	return true;
			//}
			//else
			//	return false;
			return (param1 == popupChoice || param1 == -1);
		}
		return false;
	}

	private boolean cndAgreeDialog(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(agreeButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndSliderDialog(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(sliderButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndSliderValue(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			return true;
		}
		return false;        
	}

	private boolean cndFilePicker(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(fileButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndColorPicker(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(colorButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndDatePicker(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(dateButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndTimePicker(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		String param1 = cnd.getParamExpString(rh,1);
		int nButton = IntFromButton(param1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			if(nButton != -1) {
				if(timeButton == nButton)
					return true;
			}
			else if(mDialog.bRet.contentEquals(param1))
				return true;
			else
				return false;
		}
		return false;
	}

	private boolean cndQuickEnd(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndPushSent(CCndExtension cnd)
	{
		return true;
	}

	private boolean cndMenuDialog(CCndExtension cnd)
	{
		String param0 = cnd.getParamExpString(rh,0);
		int param1 = cnd.getParamExpression(rh,1);
		if(mDialog != null && mDialog.Id.contentEquals(param0)){
			//if(param1 == menuVal || param1 == -1) {
			//	return true;
			//}
			//else
			//	return false;
			return (param1 == menuVal || param1 == -1);
		}
		return false;    }

	private boolean cndLastError(CCndExtension cnd)
	{
		return true;
	}


	//////////////////////////////////////////////////////////////////
	//
	//                    Actions
	//
	//////////////////////////////////////////////////////////////////

	private void actDialogTitle(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(mDialog != null)
			mDialog.Title = param0;
	}

	private void actDialogIcon(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(mDialog != null)
			mDialog.Icon = param0;
	}

	private void actDialogMessage(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(mDialog != null)
			mDialog.Msg = param0;
	}

	private void actDialogButtonText(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(mDialog != null)
			mDialog.Buttons = param0;
	}

	private void actDialogSize(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 < 7 && param0 > -1 && mDialog != null)
			mDialog.nSize = param0;
	}

	private void actDialogAlign(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 < 3 && param0 > -1 && mDialog != null)
			mDialog.nAlign = param0;
	}

	private void actAlertSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(alertDlgs != null ) {
				if(alertDlgs.containsKey(param0)) {
					alertDlgs.remove(param0);
				}

			}
			alertDlgs.put(param0, new alertDialogMMF(ho, alertListener));
			FillAlert(alertDlgs.get(param0), param0);
		}
	}

	private void actAlertDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		String m = act.getParamExpString(rh,1);
		if(param0.length() > 0) {
			if(alertDlgs != null && alertDlgs.containsKey(param0)) {
				
				if(alertDlgs.get(param0) != null)
					alertDlgs.get(param0).DoShow(m);
				ExitDlg = alertDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actLoginUser(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		String param1 = act.getParamExpString(rh,1);
		if(mLogin != null) {
			mLogin.LogUser = param0;
			mLogin.UserInit = param1;
			
		}
	}

	private void actLoginPassword(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(mLogin != null)
			mLogin.LogPass = param0;
	}

	private void actLoginRemember(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(mLogin != null)
			mLogin.LogRemm = param0;
	}

	private void actLoginFlagRemember(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 >= 0 && param0 < 2)
			mLogin.PassRemember = param0;
	}

	private void actLoginSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(loginDlgs != null ) {
				if(loginDlgs.containsKey(param0)) {
					loginDlgs.remove(param0);
				}

			}
			loginDlgs.put(param0, new loginDialogMMF(ho, loginListener));
			FillLogin(loginDlgs.get(param0), param0);

		}
	}

	private void actLoginDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		String param1 = act.getParamExpString(rh,1);
		if(param0.length() > 0) {
			if(loginDlgs != null && loginDlgs.containsKey(param0)) {
				
				if(loginDlgs.get(param0) != null)
					loginDlgs.get(param0).DoShow(param1);
				ExitDlg = loginDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actPasswordOld(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(mPassword != null)
			mPassword.OldPass = param0;

	}

	private void actPasswordNew(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(mPassword != null)
			mPassword.NewPass = param0;
	}

	private void actPasswordConfirm(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(mPassword != null)
			mPassword.ConPass = param0;
	}

	private void actPasswordSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(passwordDlgs != null ) {
				if(passwordDlgs.containsKey(param0)) {
					passwordDlgs.remove(param0);
				}

			}
			passwordDlgs.put(param0, new passwordDialogMMF(ho, passwordListener));
			FillPassword(passwordDlgs.get(param0), param0);

		}

	}

	private void actPasswordDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(passwordDlgs != null && passwordDlgs.containsKey(param0)) {
				
				if(passwordDlgs.get(param0) != null)
					passwordDlgs.get(param0).DoShow();
				ExitDlg = passwordDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actPromptLabel(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		String param1 = act.getParamExpString(rh,1);
		if(mPrompt != null) {
			mPrompt.Prompt = param0;
			mPrompt.PromptInit = param1;
			
		}
	}

	private void actPromptSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(promptDlgs != null ) {
				if(promptDlgs.containsKey(param0)) {
					promptDlgs.remove(param0);
				}

			}
			promptDlgs.put(param0, new promptDialogMMF(ho, promptListener));
			FillPrompt(promptDlgs.get(param0), param0);

		}
	}

	private void actPromptDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		String param1 = act.getParamExpString(rh,1);
		if(param0.length() > 0) {
			if(promptDlgs != null && promptDlgs.containsKey(param0)) {
				
				if(promptDlgs.get(param0) != null)
					promptDlgs.get(param0).DoShow(param1);
				ExitDlg = promptDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actPopupHeader(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0 && mPopup != null)
			mPopup.Header = param0;
		else
			mPopup.Header = null;
	}

	private void actPopupPrompt(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		mPopup.Lists = param0;
	}

	private void actPopupSelect(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(mPopup != null)
			mPopup.Choosed = param0;

	}

	private void actPopupMulti(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 == 1 && mPopup != null) {
			mPopup.isMultiple = true;
		}
		else
			mPopup.isMultiple = false;
	}

	private void actPopupSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(popupDlgs != null ) {
				if(popupDlgs.containsKey(param0)) {
					popupDlgs.remove(param0);
				}

			}
			popupDlgs.put(param0, new popupDialogMMF(ho, popupListener));
			FillPopup(popupDlgs.get(param0), param0);

		}
	}

	private void actPopupDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		String select = act.getParamExpString(rh,1);
		if(param0.length() > 0) {
			if(popupDlgs != null && popupDlgs.containsKey(param0)) {
				
				if(popupDlgs.get(param0) != null)
					popupDlgs.get(param0).DoShow(select);
				ExitDlg = popupDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actProgStyle(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(mProg != null)
			mProg.style = param0;
	}

	private void actProgMin(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(mProg != null)
			mProg.min = param0;
	}

	private void actProgMax(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(mProg != null)
			mProg.max = param0;
	}

	private void actProgSet(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		String param1 = act.getParamExpString(rh,1);
		if(progDlgs != null && progDlgs.containsKey(param1)) {
			if(progDlgs.get(param1) != null)
				progDlgs.get(param1).setValue(param0);
			mProg.value = param0;
		}        
	}

	private void actProgTime(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		mProg.nTimer = param0;
	}

	private void actProgSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(progDlgs != null ) {
				if(progDlgs.containsKey(param0)) {
					progDlgs.remove(param0);
				}

			}
			progDlgs.put(param0, new progDialogMMF(ho));
			FillProg(progDlgs.get(param0), param0);

		}

	}

	private void actProgDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(progDlgs != null && progDlgs.containsKey(param0)) {
				
				if(progDlgs.get(param0) != null)
					progDlgs.get(param0).DoShow();
				ExitDlg = progDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actProgKill(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(progDlgs != null && progDlgs.containsKey(param0)) {
				if(progDlgs.get(param0) != null)
					progDlgs.get(param0).kill();
			}
		}
	}

	private void actFileDir(CActExtension act)
	{
		if(mFile != null) { 	
			mFile.DefaultDir = act.getParamExpString(rh,0);
			mFile.ParentTxt  = act.getParamExpString(rh,1);
			mFile.FolderTxt  = act.getParamExpString(rh,2);
			mFile.FileTxt    = act.getParamExpString(rh,3);
		}
	}

	private void actFileSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(fileDlgs != null ) {
				if(fileDlgs.containsKey(param0)) {
					fileDlgs.remove(param0);
				}

			}
			fileDlgs.put(param0, new fileDialogMMF(ho, fileListener));
			FillFileSelector(fileDlgs.get(param0), param0);

		}
	}

	private void actFileDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		String def_dir = act.getParamExpString(rh,1);

		if(param0.length() > 0) {
			if(fileDlgs != null && fileDlgs.containsKey(param0)) {
				
				if(fileDlgs.get(param0) != null)
					fileDlgs.get(param0).DoShow(def_dir);
				ExitDlg = fileDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actAgreeMsgHtml(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			mAgreement.AgreeHTML = param0;
		}
	}

	private void actAgreeCheckTxt(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);        
		int param1 = act.getParamExpression(rh,1);

		if(param0.length() > 0)
			mAgreement.AcceptedLabel = param0;
		else
			mAgreement.AcceptedLabel = null;

		if(param1 >= 0 && param1 < 2)
			mAgreement.AcceptedTerms = param1;
	}

	private void actAgreeSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(agreeDlgs != null ) {
				if(agreeDlgs.containsKey(param0)) {
					agreeDlgs.remove(param0);
				}

			}
			agreeDlgs.put(param0, new agreementDialogMMF(ho, agreementListener));
			FillAgreement(agreeDlgs.get(param0), param0);

		}
	}

	private void actAgreeDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(agreeDlgs != null && agreeDlgs.containsKey(param0)) {
				
				if(agreeDlgs.get(param0) != null)
					agreeDlgs.get(param0).DoShow();
				ExitDlg = agreeDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actSliderMin(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 >= 0 && mSlider != null) {
			mSlider.Min = param0;
		}
	}

	private void actSliderMax(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 >= 0 && mSlider != null) {
			mSlider.Max = param0;
		}
	}

	private void actSliderValue(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 >= 0 && mSlider != null) {
			mSlider.value = param0;
		}
	}

	private void actSliderSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(sliderDlgs != null ) {
				if(sliderDlgs.containsKey(param0)) {
					sliderDlgs.remove(param0);
				}
			}
			sliderDlgs.put(param0, new sliderDialogMMF(ho, sliderListener));
			FillSlider(sliderDlgs.get(param0), param0);
		}

	}

	private void actSliderDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(sliderDlgs != null && sliderDlgs.containsKey(param0)) {
				
				if(sliderDlgs.get(param0) != null)
					sliderDlgs.get(param0).DoShow();
				ExitDlg = sliderDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actColorSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(colorDlgs != null ) {
				if(colorDlgs.containsKey(param0)) {
					colorDlgs.remove(param0);
				}

			}
			colorDlgs.put(param0, new colorDialogMMF(ho, colorListener));
			FillColor(colorDlgs.get(param0), param0);

		}

	}

	private void actColorDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		int lColor = act.getParamExpression(rh,1);
		if(param0.length() > 0) {
			if(colorDlgs != null && colorDlgs.containsKey(param0)) {
				
				if(colorDlgs.get(param0) != null)
					colorDlgs.get(param0).DoShow(lColor);
				ExitDlg = colorDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actDateDisplay(CActExtension act)
	{
		if(mDate != null) {
			mDate.what = act.getParamExpression(rh,0);
			mDate.calOff = act.getParamExpression(rh,1);
		}
	}

	private void actDateStartT(CActExtension act)
	{
		if(mDate != null) {
			mDate.year   = act.getParamExpression(rh,0);
			mDate.month = act.getParamExpression(rh,1);
			mDate.day  = act.getParamExpression(rh,2);
		}
	}

	private void actDateSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(dateDlgs != null ) {
				if(dateDlgs.containsKey(param0)) {
					dateDlgs.remove(param0);
				}

			}
			dateDlgs.put(param0, new dateDialogMMF(ho, dateListener));
			FillDate(dateDlgs.get(param0), param0);

		}

	}

	private void actDateDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		int d = act.getParamExpression(rh,1);
		int m = act.getParamExpression(rh,2);
		int y = act.getParamExpression(rh,3);
		if(param0.length() > 0) {
			if(dateDlgs != null && dateDlgs.containsKey(param0)) {
				
				if(dateDlgs.get(param0) != null)
					dateDlgs.get(param0).DoShow(d,m,y);
				ExitDlg = dateDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actTimeDisp(CActExtension act)
	{
		if(mTime != null)
			mTime.what = act.getParamExpression(rh,0);
	}

	private void actTimeStartT(CActExtension act)
	{
		if(mTime != null) {
			mTime.hours = act.getParamExpression(rh,0);
			mTime.mins  = act.getParamExpression(rh,1);
		}
	}

	private void actTimeStyle(CActExtension act)
	{
		if(mTime != null)
			mTime.style = act.getParamExpression(rh,0);
	}

	private void actTimeSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(timeDlgs != null ) {
				if(timeDlgs.containsKey(param0)) {
					timeDlgs.remove(param0);
				}
			}
			timeDlgs.put(param0, new timeDialogMMF(ho, timeListener));
			FillTime(timeDlgs.get(param0), param0);
		}  	
	}

	private void actTimeDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		int h = act.getParamExpression(rh,1);
		int m = act.getParamExpression(rh,2);
		if(param0.length() > 0) {
			if(timeDlgs != null && timeDlgs.containsKey(param0)) {
				
				if(timeDlgs.get(param0) != null)
					timeDlgs.get(param0).DoShow(h,m);
				ExitDlg = timeDlgs.get(param0).getDialog();
				
			}
		}
	}

	private void actQuickMessage(CActExtension act)
	{
		String param1 = act.getParamExpString(rh,1);
		if(mToast != null) {
			mToast.Msg = act.getParamExpString(rh,0);
			mToast.dDraw = loadImageFromAction(param1);
		}
	}

	private void actQuickAlign(CActExtension act)
	{
		if(mToast != null) {
			mToast.nAlign = act.getParamExpression(rh,0);
			mToast.nTheme = act.getParamExpression(rh,1);	
		}
	}

	private void actQuickTime(CActExtension act)
	{
		if(mToast != null)
			mToast.nTimeout = act.getParamExpression(rh,0);
	}

	private void actQuickDo(CActExtension act)
	{
		if(mToast != null) {
			mToast.DoShow();
		}
		mToast.clear();
	}

	private void actPushTitle(CActExtension act)
	{
		if(mPush != null) {
			mPush.title = act.getParamExpString(rh,0);
			mPush.number = act.getParamExpression(rh,1);
		}
	}

	private void actPushIcon(CActExtension act)
	{
		if(mPush != null) {
			mPush.icon = act.getParamExpString(rh,0);
			mPush.dDraw = loadImageFromAction(mPush.icon);
			String szIcon = act.getParamExpString(rh,1);
			if(szIcon.length() > 0)
				mPush.smallIcon = szIcon;
			else
				mPush.smallIcon = "launcher";
		}
	}

	private void actPushMessage(CActExtension act)
	{
		if(mPush != null) {
			mPush.message = act.getParamExpString(rh,0);
			mPush.ticker  = act.getParamExpString(rh,1);
		}
	}

	private void actPushAction(CActExtension act)
	{
		if(mPush != null) {
			mPush.intent = act.getParamExpString(rh,0);
			mPush.nAction = act.getParamExpression(rh,1);
		}
	}

	private void actPushSound(CActExtension act)
	{
		if(mPush != null)
			mPush.nSound = act.getParamExpression(rh,0);
	}

	private void actPushVibrate(CActExtension act)
	{
		if(mPush != null)
			mPush.nVibrate = act.getParamExpression(rh,0);
	}

	private void actPushDo(CActExtension act)
	{
		//mPush.nSeconds = act.getParamExpression(rh,0);
		mPush.nSeconds = 0;
		if(mPush != null) {
			mPush.DoPush();
			mPush.clear();	
		}
	}

	private void actMenuMessage(CActExtension act)
	{
		if(mMenu != null) {
			mMenu.Items = act.getParamExpString(rh,0);
			mMenu.Icon = act.getParamExpString(rh,1);
		}
	}

	private void actMenuAlign(CActExtension act)
	{
		if(mMenu != null)
			mMenu.nAlign = act.getParamExpression(rh,0);
	}

	private void actMenuTime(CActExtension act)
	{
		if(mMenu != null)
			mMenu.timeout = act.getParamExpression(rh,0);
	}

	private void actMenuSave(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(menuDlgs != null ) {
				if(menuDlgs.containsKey(param0)) {
					menuDlgs.remove(param0);
				}

			}
			menuDlgs.put(param0, new menuDialogMMF(ho, menuListener));
			FillMenu(menuDlgs.get(param0), param0);
		}
	}

	private void actMenuDo(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			if(menuDlgs != null && menuDlgs.containsKey(param0)) {
				
				if(menuDlgs.get(param0) != null) {
					menuDlgs.get(param0).DoShow();
					ExitDlg = menuDlgs.get(param0).getDialog();
				}
				
			}
		}
	}

	private void actDialogtheme(CActExtension act)
	{
		int param0 = act.getParamExpression(rh,0);
		if(param0 >= 0 && param0 < 5)
			nTheme = param0;
		else
			nTheme = 0;
	}

	private void actImageFilePicker(CActExtension act)
	{
		ImgFolder=act.getParamExpression(rh,0);
		ImgFiles =act.getParamExpression(rh,1);
	}

	private void actTypeFilePicker(CActExtension act)
	{
		TypeFilePicker = act.getParamExpression(rh,0);
	}
	
	private void actDialogTitleColor(CActExtension act)
	{
		mDialog.TitleColor = act.getParamColour(rh,0);
	}
	
	private void actFontThemeControl(CActExtension act)
	{
		if(act.getParamExpression(rh,0) != 0)
			bFontTheme = true;
		else
			bFontTheme = false;
	}

	private void actDialogDismiss(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(alertDlgs != null ) {
			if(alertDlgs.containsKey(param0)) {
				alertDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(loginDlgs != null ) {
			if(loginDlgs.containsKey(param0)) {
				loginDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(passwordDlgs != null ) {
			if(passwordDlgs.containsKey(param0)) {
				passwordDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(promptDlgs != null ) {
			if(promptDlgs.containsKey(param0)) {
				promptDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(popupDlgs != null ) {
			if(popupDlgs.containsKey(param0)) {
				popupDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(fileDlgs != null ) {
			if(fileDlgs.containsKey(param0)) {
				fileDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(colorDlgs != null ) {
			if(colorDlgs.containsKey(param0)) {
				colorDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(progDlgs != null ) {
			if(progDlgs.containsKey(param0)) {
				progDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(timeDlgs != null ) {
			if(timeDlgs.containsKey(param0)) {
				timeDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(dateDlgs != null ) {
			if(dateDlgs.containsKey(param0)) {
				dateDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(menuDlgs != null ) {
			if(menuDlgs.containsKey(param0)) {
				menuDlgs.get(param0).getDialog().dismiss();
			}
			
		}
		if(SurfaceView.inst != null)
			SurfaceView.inst.makeCurrentIfNecessary();
	}
	
	private void actFileFilter(CActExtension act)
	{
		String param0 = act.getParamExpString(rh,0);
		if(param0.length() > 0) {
			mFile.sExt = param0;
		}
	}

	//////////////////////////////////////////////////////////////////
	//
	//                    Expressions
	//
	//////////////////////////////////////////////////////////////////
	private CValue expAlertRet()
	{
		expRet.forceInt(alertButton);
		return expRet;
	}

	private CValue expLoginUser()
	{
		expRet.forceString("");
		if(loginUser != null)
			expRet.forceString(loginUser);

		return expRet;
	}

	private CValue expLoginPassword()
	{
		expRet.forceString("");
		if(loginPass != null)
			expRet.forceString(loginPass);

		return expRet;
	}

	private CValue expLoginRem()
	{
		expRet.forceInt(loginRem);
		return expRet;
	}

	private CValue expLoginRet()
	{
		expRet.forceInt(loginButton);
		return expRet;
	}

	private CValue expPassPass()
	{
		if(passPass != null)
			expRet.forceString(passPass);

		return expRet;
	}

	private CValue expPassNew()
	{
		expRet.forceString("");
		if(passNewx != null)
			expRet.forceString(passNewx);

		return expRet;
	}

	private CValue expPassConf()
	{
		expRet.forceString("");
		if(passConf != null)
			expRet.forceString(passConf);

		return expRet;
	}

	private CValue expPasswordRet()
	{
		expRet.forceInt(passButton);
		return expRet;
	}

	private CValue expPromptText()
	{
		expRet.forceString("");
		if(promptStr != null)
			expRet.forceString(promptStr);

		return expRet;
	}

	private CValue expPromptRet()
	{
		expRet.forceInt(promptButton);
		return expRet;
	}

	private CValue expPopupText()
	{
		expRet.forceString("");
		if(popupStr != null)
			expRet.forceString(popupStr);

		return expRet;
	}
	
	private CValue expPopupChoice()
	{
		expRet.forceInt(popupChoice);
		return expRet;
	}

	private CValue expPopupRet()
	{
		expRet.forceInt(popupButton);
		return expRet;
	}

	private CValue expAgreeChk()
	{
		expRet.forceInt(agreechk);
		return expRet;
	}

	private CValue expAgreeRet()
	{
		expRet.forceInt(agreeButton);
		return expRet;
	}

	private CValue expSliderValue()
	{
		expRet.forceInt(sliderVal);
		return expRet;
	}

	private CValue expSliderRet()
	{
		expRet.forceInt(sliderButton);
		return expRet;
	}

	private CValue expFileName()
	{
		expRet.forceString("");
		if(fileName != null)
			expRet.forceString(fileName);

		return expRet;
	}

	private CValue expFileRet()
	{
		expRet.forceInt(fileButton);
		return expRet;
	}

	private CValue expColorValue()
	{
		expRet.forceInt(colorVal);
		return expRet;
	}

	private CValue expColorAlpha()
	{
		expRet.forceInt(colorAlpha);
		return expRet;
	}

	private CValue expColorRet()
	{
		expRet.forceInt(colorButton);
		return expRet;
	}

	private CValue expDateyear()
	{
		expRet.forceInt(dateYear);
		return expRet;
	}

	private CValue expDatemonth()
	{
		expRet.forceInt(dateMonth);
		return expRet;
	}

	private CValue expDateday()
	{
		expRet.forceInt(dateDay);
		return expRet;
	}

	private CValue expDateRet()
	{
		expRet.forceInt(dateButton);
		return expRet;
	}

	private CValue expTimeHour()
	{
		expRet.forceInt(timeHours);
		return expRet;
	}

	private CValue expTimeMins()
	{
		expRet.forceInt(timeMins);
		return expRet;
	}

	private CValue expTimeSecs()
	{
		Calendar c = Calendar.getInstance(); 
		int seconds = c.get(Calendar.SECOND);
		expRet.forceInt(seconds);
		return expRet;
	}

	private CValue expTimeRet()
	{
		expRet.forceInt(timeButton);
		return expRet;
	}

	private CValue expMenuVal()
	{
		expRet.forceInt(menuVal);
		return expRet;
	}

	private CValue expMenuStr()
	{
		expRet.forceString("");
		if(menuStr != null)
			expRet.forceString(menuStr);

		return expRet;
	}

}
