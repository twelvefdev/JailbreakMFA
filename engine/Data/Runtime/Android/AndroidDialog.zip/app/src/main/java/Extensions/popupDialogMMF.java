/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;


import Objects.CExtension;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.widget.TextView;

@SuppressLint("ResourceAsColor")
public class popupDialogMMF {

	private CExtension ho = null;
	private Dialog dlg= null;


	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public int Type = 1;

	public String Title   = null;
	public String Msg    = null;
	public String Icon    = null;
	public String Buttons = null;

	public String[] Button = null;

	public CharSequence[] List = null;
	public boolean[] ListChecked = null;

	public String Lists = null;
	public String Choosed = null;
	public String Header = null;

	public boolean isMultiple = false;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;

	public int nTheme;
	public boolean bFontTheme;
	public int TitleColor;

	public Drawable dDraw = null;

	public String Selected = null;
	public int nChoice;

	int width;
	int height;

	int lstidx = 0;

	/////////////////////
	//
	// Constructors
	//
	/////////////////////
	public popupDialogMMF(CExtension ho, OnPopupResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
	}

	/////////////////////
	//
	// Listeners
	//
	/////////////////////

	public OnPopupResultListener mListener;

	public interface OnPopupResultListener {
		public abstract void onClick(String Id, String bRet, int nRet, int nChoice, String Selected);
		public abstract void onChange(String Id, int nChoice);
	}

	// Allows the user to set an Listener and react to the event
	public void setOnPopupResultListener(OnPopupResultListener listener) {
		mListener = listener;
	}

	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

	public void DoShow(String c) {

		UtilityDialog utilityDialog = new UtilityDialog();

		ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);

		Builder builder = null;

		if(ctw == null) {
			builder = new AlertDialog.Builder(ho.getControlsContext());
		}
		else
			builder = new AlertDialog.Builder(ctw); 	

		DialogInterface.OnClickListener popupSinglelistener = new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				if(which == 0)
					return;
				nChoice = which - lstidx;
				for(int i = 0; i < ListChecked.length ; i++) {
					ListChecked[i] = false;
				}
				ListChecked[nChoice] = true;
				mListener.onChange(Id, nChoice+1);
				if(Buttons == null) {
					Selected = areSelected();
					dialog.dismiss();
				}
			}

		};

		DialogInterface.OnMultiChoiceClickListener popupMultilistener = new DialogInterface.OnMultiChoiceClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which, boolean Checked) {
				nChoice = which;
				ListChecked[nChoice] = Checked;
				mListener.onChange(Id, nChoice+1);

			}

		};

		if(Lists != null) {
			if(Lists.lastIndexOf(",") != (Lists.length()-1))
				Lists += ",";

			List = Lists.split(",");
			ListChecked = new boolean[List.length];   		

		}

		if(!isMultiple) {
			int nChk = -1;
			try {
				if(c.length() > 0) {
					nChk = Integer.parseInt(c);  				
				}
				else if(Choosed.length() > 0) {
					nChk = Integer.parseInt(Choosed);
				}
			}
			catch (Exception e) {
			}
			if(Header == null && nChk > 0)
				nChk = nChk - 1;

			builder.setSingleChoiceItems(List, nChk, popupSinglelistener);
		}
		else {
			String lChoosed = null;

			if(c.length() > 0)
				lChoosed = c;

			if(Choosed != null) {
				if(Choosed.lastIndexOf(",") != (Choosed.length()-1))
					Choosed += ",";
				lChoosed = Choosed;
			}

			if(lChoosed != null) {
				String[] CheckedList = lChoosed.split(",");
				int nIdx=0;

				for(String Chk: CheckedList){
					if(nIdx < List.length)
						ListChecked[nIdx] = Chk.contentEquals("1");
					nIdx++;
				}

			}

			Header = null;
			builder.setMultiChoiceItems(List, ListChecked, popupMultilistener);
		}

		final AlertDialog popupDialog = builder.create();

		dlg = popupDialog;

		if(TitleColor != -1) {
			String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
			popupDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
		}
		else
			popupDialog.setTitle(Title);	// Title Text

		popupDialog.setIcon(dDraw); 					 // Icon	

		int flag[] = {0,1,2};

		if(Buttons != null) {
			int nCount = 0;
			if(Buttons.lastIndexOf(",") != (Buttons.length()-1))
				Buttons += ",";

			String[] items = Buttons.split(",");
			Button = items.clone();
			for (String item : items)
			{
				if(item.length() > 0) {
					if(nCount == flag[0])
						popupDialog.setButton( DialogInterface.BUTTON_POSITIVE, item, new DialogInterface.OnClickListener() { //Button 1 Text
							@Override
							public void onClick(DialogInterface dialog, int which) {

								//Button 1 was clicked?
								nRet = 1;
								bRet = Button[nRet-1];
								Selected = areSelected();
								mListener.onClick(Id, bRet, nRet, (!isMultiple ? nChoice+1: -1), Selected);

							} });
					if(nCount == flag[1])
						popupDialog.setButton( DialogInterface.BUTTON_NEUTRAL, item, new DialogInterface.OnClickListener() { //Button 2 Text
							@Override
							public void onClick(DialogInterface dialog, int which) {

								//Button 2 was clicked?	  
								nRet = 2;
								bRet = Button[nRet-1];
								Selected = areSelected();
								mListener.onClick(Id, bRet, nRet, (!isMultiple ? nChoice+1: -1), Selected);

							} });

					if(nCount == flag[2])
						popupDialog.setButton( DialogInterface.BUTTON_NEGATIVE, item, new DialogInterface.OnClickListener() { //Button 3 Text
							@Override
							public void onClick(DialogInterface dialog, int which) {

								//Button 3 was clicked?
								nRet = 3;
								bRet = Button[nRet-1];
								Selected = areSelected();
								mListener.onClick(Id, bRet, nRet, (!isMultiple ? nChoice+1: -1), Selected);

							} });

					nCount++;
				}
			}
		} else {
			popupDialog.setOnKeyListener(new Dialog.OnKeyListener() {

				@Override
				public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
					if (keyCode == KeyEvent.KEYCODE_BACK) {
						dialog.dismiss();
						mListener.onChange(Id, -1);
						return true;
					}
					return false;
				}				
			});
		}

		popupDialog.setCancelable(false);

		utilityDialog.requestDialogFeatures(popupDialog);

		if(Header != null) {
			lstidx = 1;
			final TextView vt = new TextView(ctw);
			vt.setTextAppearance(ctw, android.R.style.TextAppearance_Medium);
			vt.setGravity(Gravity.CENTER);
			vt.setPadding(0, 12, 0, 12);
			vt.setTextColor(vt.getResources().getColor(android.R.color.tab_indicator_text));
			vt.setText(Header);
			popupDialog.getListView().addHeaderView(vt);
		}

		utilityDialog.setWorkingView(popupDialog.getListView());


		popupDialog.show();

		utilityDialog.resizeTitle(popupDialog);

		utilityDialog.updateSize(nSize, nAlign);
	}

	public void clear(){
		// return Values
		Id   = null;
		bRet = null;
		Tag  = null;
		sRet = null;
		nRet = -1;

		Title   = null;
		Msg     = null;
		Icon    = null;
		Buttons = null;
		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;
		bFontTheme = false;

	}

	private String areSelected() {
		String selectedvalues = "";
		int i = 0, qty = 0;
		for(boolean chck : ListChecked) {
			if(chck) {
				if(qty>0)
					selectedvalues +=",";

				selectedvalues += List[i];
				qty++;
			}
			i++;
		}
		return selectedvalues;
	}

	public Dialog getDialog() {
		return dlg;
	}

}
