/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package Extensions;

import java.lang.reflect.Field;
import java.util.Calendar;

import Objects.CExtension;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.text.InputType;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;

public class timeDialogMMF {

	private CExtension ho = null;
	private Dialog dlg= null;
	private TimePicker timepicker = null;
	// return Values
	public String   Id = null;
	public String bRet = null;
	public String  Tag = null;
	public String sRet = null;
	public int    nRet = -1;

	public int Type = 1;

	public String Title   = null;
	public String Msg    = null;
	public String Icon    = null;
	public String Buttons = null;
	
	public String[] Button = null;

	public int nBtCount;       	
	public int nSize;
	public int nAlign;
	
	public int nTheme;
	public boolean bFontTheme;
	public int TitleColor;
	
	public Drawable dDraw = null;
	
	public int what;
	public int style;
	public int hours;
	public int mins;
	public int secs;
	
	private boolean flagType;
	private int Time;
	
	int width;
	int height;
	
	private int RetHours;
	private int RetMins;
	
	private EditText vHours = null;
	private EditText vMins  = null;	
	
	private InputMethodManager imm = null;
	
	/////////////////////
	//
	// Constructors
	//
	/////////////////////
	public timeDialogMMF(CExtension ho, OnTimeResultListener mListener) {
		this.ho = ho;
		this.mListener = mListener;
		clear();
	}
	
	/////////////////////
	//
	// Listeners
	//
	/////////////////////
	
	public OnTimeResultListener mListener;
	
	public interface OnTimeResultListener {
		public abstract void onClick(String Id, String bRet, int nRet, int RetHours, int RetMins);
	}
	
	// Allows the user to set an Listener and react to the event
	public void setOnTimeResultListener(OnTimeResultListener listener) {
		mListener = listener;
	}
	
	////////////////////////////////////////
	//
	//        Execute the Dialog
	//
	////////////////////////////////////////

    public void DoShow(int h, int m) {
    	
       	UtilityDialog utilityDialog = new UtilityDialog();
       	
       	ContextThemeWrapper ctw = utilityDialog.themeDialog(nTheme);

       	AlertDialog timeDialog = null;
       	
       	if(ctw == null) {
       		timeDialog = new AlertDialog.Builder(ho.getControlsContext()).create();
       	}
       	else
       		timeDialog = new AlertDialog.Builder(ctw).create();
    		
    	
    	dlg = timeDialog;
    	
    	if(TitleColor != -1) {
    		String szTColor = String.format("#%06X", 0xFFFFFF & TitleColor);
    		timeDialog.setTitle(Html.fromHtml("<font color='"+szTColor+"'>"+Title+"</font>"));
    	}
    	else
    		timeDialog.setTitle(Title);	// Title Text
    	
    	timeDialog.setMessage(Msg); 				 // Message Text
    	timeDialog.setIcon(dDraw); 					 // Icon
    	
        LayoutInflater inflater = timeDialog.getLayoutInflater();
        ////////////////////////////////////////////////////////////////
        //
        //                   GetResources IDs
        //
        ////////////////////////////////////////////////////////////////
        
        final View dialoglayout = inflater.inflate(utilityDialog.getLayoutByName("dialog_time"), null);
        
        timeDialog.setView(dialoglayout);
        
        final Calendar c = Calendar.getInstance();//To initialize with the current date 
        
        if(h < 0) {
        	if(hours == -1 || h == -1)
        		hours = c.get(Calendar.HOUR_OF_DAY);
        }
        else
        	hours = h;
        
        RetHours = hours;
        
        if(m < 0) {
	        if(mins == -1 || m == -1)
		       	mins = c.get(Calendar.MINUTE);
        }
        else
        	mins = m;
        
        RetMins = mins;
        
        timepicker = (TimePicker) dialoglayout.findViewById(utilityDialog.getIDsByName("timePicker1"));

        if(style == 1)
        	timepicker.setIs24HourView(false);
        else
        	timepicker.setIs24HourView(true);
        
        timepicker.setCurrentHour(hours);
        timepicker.setCurrentMinute(mins);
        
        imm = (InputMethodManager) ho.getControlsContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        
        timepicker.setOnTimeChangedListener(new OnTimeChangedListener() {

			@Override
			public void onTimeChanged(TimePicker picker, int hours, int mins) {
				// TODO Auto-generated method stub
				/*
				if(what == 1 ) {
					if(imm != null) {
						imm.hideSoftInputFromWindow(vMins.getWindowToken(), 0); 
					}
				}
				if(what == 2) {
					if(imm != null) {
						imm.hideSoftInputFromWindow(vHours.getWindowToken(), 0);							
					}
				}
				*/
                RetHours  = hours;
	        	RetMins   = mins;

			}
        	
        });

        if(what != 3) {
            setDisabledTextViews(timepicker);
        }
        
        try {
        	Field f[] = timepicker.getClass().getDeclaredFields();
        	for (Field field : f) {
        		if(what == 2) {
        			if (field.getName().equals("mHourPicker") || field.getName().equals("mHourSpinner") || field.getName().equals("mHourSpinnerInput")) {
        				field.setAccessible(true);
        				Object hoursPicker = new Object();
        				hoursPicker = field.get(timepicker);
    					((View) hoursPicker).setEnabled(false);
        				((View) hoursPicker).setVisibility(View.GONE);
        				if(field.getName().equals("mHourSpinnerInput")) {
             				vHours = ((EditText) hoursPicker);
           					((EditText) hoursPicker).setEnabled(false);
        					((EditText) hoursPicker).setFocusable(false);
       				}
        			}
        		}
        		if(what == 1) {
        			if (field.getName().equals("mMinutePicker") || field.getName().equals("mMinuteSpinner") || field.getName().equals("mMinuteSpinnerInput")) {
        				field.setAccessible(true);
        				Object minsPicker = new Object();
        				minsPicker = field.get(timepicker);
    					((View) minsPicker).setEnabled(false);
    					((View) minsPicker).setVisibility(View.GONE);
        				if(field.getName().equals("mMinuteSpinnerInput")) {
             				vMins = ((EditText) minsPicker);
        					((EditText) minsPicker).setEnabled(false);
        					((EditText) minsPicker).setFocusable(false);
        				}
        			}
        		}
        	}
        } catch (SecurityException e) {
        	Log.d("ERROR", e.getMessage());
        } catch (IllegalArgumentException e) {
        	Log.d("ERROR", e.getMessage());
        } catch (IllegalAccessException e) {
        	Log.d("ERROR", e.getMessage());
        }
        
        
 		int flag[] = {0,1,2};
 		
    	if(Buttons != null) {
    		int nCount = 0;
    		if(Buttons.lastIndexOf(",") != (Buttons.length()-1))
    			Buttons += ",";
    		
    		String[] items = Buttons.split(",");
    		Button = items.clone();
    		for (String item : items)
    		{
    			if(item.length() > 0) {
    				if(nCount == flag[0])
    					timeDialog.setButton( DialogInterface.BUTTON_POSITIVE, item, new DialogInterface.OnClickListener() { //Button 1 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 1 was clicked?
    							nRet = 1;
    							bRet = Button[nRet-1];
    							getTime();
    							dialog.dismiss();
    							mListener.onClick(Id, bRet, nRet, RetHours, RetMins);
   						} });
    				if(nCount == flag[1])
    					timeDialog.setButton( DialogInterface.BUTTON_NEUTRAL, item, new DialogInterface.OnClickListener() { //Button 2 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 2 was clicked?	  
    							nRet = 2;
    							bRet = Button[nRet-1];
    							getTime();
    							dialog.dismiss();
    							mListener.onClick(Id, bRet, nRet, RetHours, RetMins);
    						} });

    				if(nCount == flag[2])
    					timeDialog.setButton( DialogInterface.BUTTON_NEGATIVE, item, new DialogInterface.OnClickListener() { //Button 3 Text
    						@Override
							public void onClick(DialogInterface dialog, int which) {

    							//Button 3 was clicked?
    							nRet = 3;
    							bRet = Button[nRet-1];
    							getTime();
    							dialog.dismiss();
    							mListener.onClick(Id, bRet, nRet, RetHours, RetMins);
    						} });

    				nCount++;
    			}
    		}
    	}
    	
    	timeDialog.setCancelable(false);
    	
    	utilityDialog.requestDialogFeatures(timeDialog);
    	
    	utilityDialog.setWorkingView(timepicker);
 
     	timeDialog.show(); //Show the dialog 
     	
    	if(!bFontTheme) {
    		utilityDialog.resizeTitle(timeDialog);
    		utilityDialog.resizeMessage(timeDialog);
    	}

    	utilityDialog.updateSize(nSize, nAlign);

    }

	public void clear(){
		// return Values
		Id   = null;
		bRet = null;
		Tag  = null;
		sRet = null;
		nRet = -1;

		Title   = null;
		Msg     = null;
		Icon    = null;
		Buttons = null;
		nBtCount = -1;       
		nSize = -1;
		nAlign = -1;
		bFontTheme = false;

	}

    private void setDisabledTextViews(ViewGroup dp) {
        for (int i = 0, count = dp.getChildCount(); i < count; i++) {
                View v = dp.getChildAt(i);

                if (v instanceof TextView) {
                        //v.setEnabled(false);
                        ((TextView) v).setInputType(InputType.TYPE_NULL);
                        v.setFocusableInTouchMode(false);
                } 
                else if (v instanceof ViewGroup) {
                        setDisabledTextViews((ViewGroup)v);
                }
        }
        
    }
	
	public Dialog getDialog() {
		return dlg;
	}

	public void getTime() {
		if(timepicker != null) {
			timepicker.clearFocus();
			RetHours = timepicker.getCurrentHour();
			RetMins = timepicker.getCurrentMinute();
		}
	}
	
}
