package com.clickteam.special;

import android.net.Uri;
import com.android.vending.expansion.zipfile.APEZProvider;

public class CTZipUriProvider extends APEZProvider
{
  private static final String CONTENT_PREFIX = "content://";

  private final String AUTHORITY =  "XXXXXXX";  //New Authority
  public final Uri ASSET_URI = Uri.parse(CONTENT_PREFIX + AUTHORITY);


  public String getAuthority()
  {
      return AUTHORITY;
  }

}
