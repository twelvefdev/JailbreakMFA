package Extensions;

import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.zip.CRC32;

import com.android.vending.expansion.zipfile.ZipResourceFile;
import com.android.vending.expansion.zipfile.ZipResourceFile.ZipEntryRO;

import com.google.android.vending.expansion.downloader.Constants;
import com.google.android.vending.expansion.downloader.DownloadProgressInfo;
import com.google.android.vending.expansion.downloader.DownloaderClientMarshaller;
import com.google.android.vending.expansion.downloader.DownloaderServiceMarshaller;
import com.google.android.vending.expansion.downloader.Helpers;
import com.google.android.vending.expansion.downloader.IDownloaderClient;
import com.google.android.vending.expansion.downloader.IDownloaderService;
import com.google.android.vending.expansion.downloader.IStub;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import RunLoop.CRun;
import Runtime.MMFRuntime;
import Services.CBinaryFile;
import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.os.Messenger;
import android.os.SystemClock;
import android.util.Log;

public class CRunAndroidObb extends CRunExtension
{
    // <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
    public static final int CNDONNEWEXP = 0;
    public static final int CNDISEXPAVAILABLE = 1;
    public static final int CNDONDOWNEXPPROG = 2;
    public static final int CNDONDOWNEXPCOMPL = 3;
    public static final int CNDONDOWNEXPCELL = 4;
    public static final int CNDONEXPVALIDATED = 5;
    public static final int CNDONDOWNEXPERROR = 6;
    public static final int CND_LAST = 7;

    public static final int ACTSTARTVERIFY = 0;
    public static final int ACTSTARTDOWNLOAD = 1;
    public static final int ACTPAUSEDOWNLOAD = 2;
    public static final int ACTRESUMEDOWNLOAD = 3;
    public static final int ACTABORTDOWNLOAD = 4;
    public static final int ACTALLOWCELLULAR = 5;
    public static final int ACTSTARTINSTALL = 6;
    public static final int ACTDORESTART = 7;
    public static final int ACTDELETEOLD = 8;
    public static final int ACTDELETEACT = 9;

    public static final int EXPMAINVERSION = 0;
    public static final int EXPMAINFILESIZE = 1;
    public static final int EXPPATCHVERSION = 2;
    public static final int EXPPATCHFILESIZE = 3;
    public static final int EXPPROGRESS = 4;
    public static final int EXPSPEED = 5;
    public static final int EXPTIMEREM = 6;
    public static final int EXPOVERPROG = 7;
    public static final int EXPOVERTOTAL = 8;
    public static final int EXPOVERSTR = 9;
    public static final int EXPSTATUS = 10;
    public static final int EXPERROR = 11;

    // </editor-fold>
	private static int PERMISSIONS_OBB_REQUEST = 15577897;
	private HashMap<String, String> permissionsApi23;
	boolean enabled_perms;

	private IDownloaderService mRemoteService;
    private IDownloaderClient  mLocalClient = new IDownloaderClient() {

		@Override
	    public void onDownloadProgress(DownloadProgressInfo progress) {
			mProgress.mCurrentSpeed = progress.mCurrentSpeed;
			mProgress.mOverallProgress = progress.mOverallProgress;
			mProgress.mOverallTotal = progress.mOverallTotal;
			mProgress.mTimeRemaining = progress.mTimeRemaining;
			overString = Helpers.getDownloadProgressString
	                (progress.mOverallProgress,
	                        progress.mOverallTotal);
			ho.pushEvent(CNDONDOWNEXPPROG, 0);
	    }

		@Override
		public void onDownloadStateChanged(int newState) {
			status = "changing";
	        switch (newState) {
	            case IDownloaderClient.STATE_IDLE:
	                // STATE_IDLE means the service is listening, so it's
	                // safe to start making calls via mRemoteService.
					status = "idle";
    				error = 1000;
	                break;
	            case IDownloaderClient.STATE_CONNECTING:
	            case IDownloaderClient.STATE_FETCHING_URL:
					status = "connecting";
    				error = 2000;
	                break;
	            case IDownloaderClient.STATE_DOWNLOADING:
					status = "downloading";
    				error = 3000;
	                break;
	            case IDownloaderClient.STATE_FAILED_CANCELED:
	            case IDownloaderClient.STATE_FAILED:
	            case IDownloaderClient.STATE_FAILED_FETCHING_URL:
	            case IDownloaderClient.STATE_FAILED_UNLICENSED:
					status = "failed";
    				error = 1003;
    				ho.pushEvent(CNDONDOWNEXPERROR, 0);
	                break;
	            case IDownloaderClient.STATE_PAUSED_NEED_CELLULAR_PERMISSION:
	            case IDownloaderClient.STATE_PAUSED_WIFI_DISABLED_NEED_CELLULAR_PERMISSION:
					status = "cellular";
    				error = 2000;
	                break;

	            case IDownloaderClient.STATE_PAUSED_BY_REQUEST:
					status = "paused by user";
	                break;
	            case IDownloaderClient.STATE_PAUSED_ROAMING:
	            case IDownloaderClient.STATE_PAUSED_SDCARD_UNAVAILABLE:
					status = "paused by device";
	                break;
	            case IDownloaderClient.STATE_COMPLETED:
    				error = 0;
    				status = "completed";
    				ho.pushEvent(CNDONDOWNEXPCOMPL, 0);
	                return;
	            default:
	        }
		}

		@Override
		public void onServiceConnected(Messenger m) {
	        mRemoteService = DownloaderServiceMarshaller.CreateProxy(m);
	        mRemoteService.onClientUpdated(mDownloaderClientStub.getMessenger());
		}
		
	};

    private IStub mDownloaderClientStub;
    
    private boolean mCancelValidation;
    private boolean mResultValidation;

    private DownloadProgressInfo mProgress;
    
    static private final float SMOOTHING_FACTOR = 0.005f;
    
    //private int obbVersion;
    //private long obbSize;
    private int obbMainVersion;
    private long obbMainSize;
    private int obbPatchVersion;
    private long obbPatchSize;
    private String secretKey;
    private String LVL_Key;
    private String status = "";
    private String overString = "";
    private int error;
   
    private XAPKFile[] xAPKS = {null, null};
    
    private CValue expRet;
    
    public CRunAndroidObb()
    {
    	MMFRuntime.inst.obbExpansion = true;
    	expRet = new CValue(0);
    }
    
	private static String encryptDecrypt(String key, String input) {
		
		StringBuilder output = new StringBuilder();
		
		for(int i = 0; i < input.length(); i++) {
			output.append((char) (input.charAt(i) ^ key.charAt(i % key.length())));
		}
 		
		return output.toString();
	}
   
    public @Override int getNumberOfConditions()
    {
	    return CND_LAST;
    }
    
    public @Override boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
    	
		file.bUnicode = true;
		file.skipBytes(8);
		obbMainVersion = file.readInt();
		obbMainSize = file.readInt();
		obbPatchVersion = file.readInt();
		obbPatchSize = file.readInt();

        if(obbMainVersion != MMFRuntime.inst.obbMainVersion) {
            obbMainVersion = MMFRuntime.inst.obbMainVersion;
            obbMainSize = MMFRuntime.inst.obbMainSize;
        }
        if(obbPatchVersion != MMFRuntime.inst.obbPatchVersion) {
            obbPatchVersion = MMFRuntime.inst.obbPatchVersion;
            obbPatchSize = MMFRuntime.inst.obbPatchSize;
        }

 		if(obbMainVersion > 0)
			xAPKS[0] = new XAPKFile(true, obbMainVersion, obbMainSize);
		
		if(obbPatchVersion > 0)
		    xAPKS[1] = new XAPKFile(false, obbPatchVersion, obbPatchSize);

		secretKey = file.readString(33);
		
		LVL_Key = file.readString(450).replaceAll("\\r\\n|\\r|\\n", "");
		LVL_Key = LVL_Key.trim();
		
    	mProgress = new DownloadProgressInfo(0,0,0,0);
    	
    	status="idle";
    	
        enabled_perms = false;
        
		if(MMFRuntime.deviceApi > 22)
		{
			permissionsApi23 = new HashMap<String, String>();
			permissionsApi23.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, "Write Storage");
			permissionsApi23.put(Manifest.permission.READ_EXTERNAL_STORAGE, "Read Storage");
			if(!MMFRuntime.inst.verifyOkPermissionsApi23(permissionsApi23))
				MMFRuntime.inst.pushForPermissions(permissionsApi23, PERMISSIONS_OBB_REQUEST);
			else
				enabled_perms = true;
		}
		else
			enabled_perms = true;
		
        return false;
    }
    public @Override void destroyRunObject(boolean bFast)
    {
        mCancelValidation = true;
        mProgress = null;
    }
    public @Override int handleRunObject()
    {
		if(MMFRuntime.inst != null && !enabled_perms)
		{
			MMFRuntime.inst.askForPermissionsApi23();		
		}
        return REFLAG_ONESHOT;
    }


    @Override
    public void onStop() {
		Log.v("Obb", "Stopping ...");
        if (null != mDownloaderClientStub) {
            mDownloaderClientStub.disconnect(MMFRuntime.inst);
        }
    }
    
    @Override
    public void onDestroy() {
        mCancelValidation = true;
    }

	public @Override void pauseRunObject()
	{
		Log.v("Obb", "Pausing ...");
	}
	public @Override void continueRunObject()
	{
		Log.v("Obb", "Continuing ...");
        if (null != mDownloaderClientStub) {
            mDownloaderClientStub.connect(MMFRuntime.inst);
            if(null != mRemoteService) {
                mRemoteService.requestDownloadStatus();
            }
        }
	}
    
	@Override
	public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults, List<Integer> permissionsReturned) {
		if(permissionsReturned.contains(PERMISSIONS_OBB_REQUEST))
			enabled_perms = verifyResponseApi23(permissions, permissionsApi23);
		else
			enabled_perms = false;
		
	} 

    // Conditions
    // -------------------------------------------------
    public @Override boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
        {
            case CNDONNEWEXP:
                return cndOnNewExp(cnd);
            case CNDISEXPAVAILABLE:
                return cndIsExpAvailable(cnd);
            case CNDONDOWNEXPPROG:
                return cndOnDownExpProg(cnd);
            case CNDONDOWNEXPCOMPL:
                return cndOnDownExpCompl(cnd);
            case CNDONDOWNEXPCELL:
                return cndOnDownExpCell(cnd);
            case CNDONEXPVALIDATED:
                return cndOnExpValidated(cnd);
            case CNDONDOWNEXPERROR:
                return cndOnDownExpError(cnd);
        }
        return false;
    }

    // Actions
    // -------------------------------------------------
    public @Override void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACTSTARTVERIFY:
                actStartVerify(act);
                break;
            case ACTSTARTDOWNLOAD:
                actStartDownload(act);
                break;
            case ACTPAUSEDOWNLOAD:
                actPauseDownload(act);
                break;
            case ACTRESUMEDOWNLOAD:
                actResumeDownload(act);
                break;
            case ACTABORTDOWNLOAD:
                actAbortDownload(act);
                break;
            case ACTALLOWCELLULAR:
                actAllowCellular(act);
                break;
            case ACTSTARTINSTALL:
                actStartInstall(act);
                break;
            case ACTDORESTART:
                actDoRestart(act);
                break;
            case ACTDELETEOLD:
                actdeleteOldExp(act);
                break;
            case ACTDELETEACT:
                actdeleteActualExp(act);
                break;
       }
    }

    // Expressions
    // -------------------------------------------------
    public @Override CValue expression(int num)
    {
        switch (num)
        {
            case EXPMAINVERSION:
                return expMainVersion();
            case EXPMAINFILESIZE:
                return expMainFileSize();
            case EXPPATCHVERSION:
                return expPatchVersion();
            case EXPPATCHFILESIZE:
                return expPatchFileSize();
            case EXPPROGRESS:
                return expProgress();
            case EXPSPEED:
                return expSpeed();
            case EXPTIMEREM:
                return expTimeRem();
            case EXPOVERPROG:
                return expOverProg();
            case EXPOVERTOTAL:
                return expOverTotal();
            case EXPOVERSTR:
                return expOverStr();
            case EXPSTATUS:
                return expStatus();
            case EXPERROR:
                return expError();
        }
        return null;
    }

    ///////////////////////////////////////////////////
    //
    //		Conditions
    //
    ///////////////////////////////////////////////////

    private boolean cndOnNewExp(CCndExtension cnd)
    {
        return true;
    }

    private boolean cndIsExpAvailable(CCndExtension cnd)
    {
        return MMFRuntime.inst.obbAvailable;
    }

    private boolean cndOnDownExpProg(CCndExtension cnd)
    {
        return true;
    }

    private boolean cndOnDownExpCompl(CCndExtension cnd)
    {
        return true;
    }
    
    private boolean cndOnDownExpCell(CCndExtension cnd)
    {
        return true;
    }

    private boolean cndOnExpValidated(CCndExtension cnd)
    {
        return true;
    }

    private boolean cndOnDownExpError(CCndExtension cnd)
    {
        return true;
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////
    
    ///////////////////////////////////////////////////
    //
    //		Actions
    //
    ///////////////////////////////////////////////////
    
    private void actStartVerify(CActExtension act)
    {
    	if (!MMFRuntime.inst.expansionFileDelivered(true, obbMainVersion, obbMainSize)
    			&& !MMFRuntime.inst.expansionFileDelivered(false, obbPatchVersion, obbPatchSize)) {
    		status = "NotExist";
    		error  = 1001;
    		return;
    	}
    	ho.pushEvent(CNDONNEWEXP, 0);
    		
    }

    private void actStartDownload(CActExtension act)
    {
    	if(enabled_perms)
    	{
	        try {
	            Intent launchIntent = MMFRuntime.inst
	                    .getIntent();
	            Intent intentToLaunchThisActivityFromNotification = new Intent(
	            		MMFRuntime.inst, MMFRuntime.inst.getClass());
	            intentToLaunchThisActivityFromNotification.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
	                    Intent.FLAG_ACTIVITY_CLEAR_TOP);
	            intentToLaunchThisActivityFromNotification.setAction(launchIntent.getAction());
	
	            if (launchIntent.getCategories() != null) {
	                for (String category : launchIntent.getCategories()) {
	                    intentToLaunchThisActivityFromNotification.addCategory(category);
	                }
	            }
	            com.clickteam.special.ExpansionDownloaderService.setPublicKey(LVL_Key);

	            // Build PendingIntent used to open this activity from
	            // Notification
	            PendingIntent pendingIntent = PendingIntent.getActivity(
	                    MMFRuntime.inst,
	                    0, intentToLaunchThisActivityFromNotification,
	                    PendingIntent.FLAG_UPDATE_CURRENT);
	            // Request to start the download
	            int startResult = DownloaderClientMarshaller.startDownloadServiceIfRequired(MMFRuntime.inst,
	                    pendingIntent, com.clickteam.special.ExpansionDownloaderService.class);
	                        
	            if (startResult != DownloaderClientMarshaller.NO_DOWNLOAD_REQUIRED) {
	                // The DownloaderService has started downloading the files,
	                // show progress
	                mDownloaderClientStub = DownloaderClientMarshaller.CreateStub
	                        (mLocalClient, com.clickteam.special.ExpansionDownloaderService.class);
	
	                if (null != mDownloaderClientStub)
	                     mDownloaderClientStub.connect(MMFRuntime.inst);
	
	                return;
	            } // otherwise, download not needed so we fall through to
	              // starting the movie
	        } catch (NameNotFoundException e) {
	            Log.e("Obb", "Cannot find own package! MAYDAY!");
	            e.printStackTrace();
	            return;
	        }
	        ho.pushEvent(CNDONDOWNEXPCOMPL, 0);
    	}
    }

    private void actPauseDownload(CActExtension act)
    {
    	if(mRemoteService != null) {
            mRemoteService.requestPauseDownload();
    	}
   }

    private void actResumeDownload(CActExtension act)
    {
    	if(mRemoteService != null) {
            mRemoteService.requestContinueDownload();
    	}
    }

    private void actAbortDownload(CActExtension act)
    {
    	if(mRemoteService != null) {
            mRemoteService.requestAbortDownload();
            mRemoteService.requestDownloadStatus();
    	}
    }

    private void actAllowCellular(CActExtension act)
    {
    	if(mRemoteService != null) {
            mRemoteService.setDownloadFlags(IDownloaderService.FLAGS_DOWNLOAD_OVER_CELLULAR);
    	}
    }

    private void actStartInstall(CActExtension act)
    {
        validateXAPKZipFiles();
    }

    private void actDoRestart(CActExtension act)
    {
    	MMFRuntime.inst.runOnRuntimeThread(new Runnable() {

			@Override
			public void run() {
		   		MMFRuntime.inst.doFinish();
		   		MMFRuntime.inst.die ();
            }
    		
    	});
    }

    private void actdeleteOldExp(CActExtension act)
    {
    	deleteExpansion(false);
    }
    
    private void actdeleteActualExp(CActExtension act)
    {
    	deleteExpansion(true);
    }
    
    ///////////////////////////////////////////////////
    //
    //		Expressions
    //
    ///////////////////////////////////////////////////
    private CValue expMainVersion()
    {
    	expRet.forceInt(obbMainVersion);
    	return expRet;
     }

    private CValue expMainFileSize()
    {
    	expRet.forceInt((int)obbMainSize);
    	return expRet;
   }

    private CValue expPatchVersion()
    {
    	expRet.forceInt(obbPatchVersion);
    	return expRet;
   }

    private CValue expPatchFileSize()
    {
    	expRet.forceInt((int)obbPatchSize);
    	return expRet;
    }

    private CValue expProgress()
    {
    	expRet.forceDouble( (mProgress.mOverallProgress * 100.0f / mProgress.mOverallTotal));
    	return expRet;
    }
    
    private CValue expSpeed()
    {
    	expRet.forceDouble(mProgress.mCurrentSpeed);
    	return expRet;
    }

    private CValue expTimeRem()
    {
    	expRet.forceInt((int)mProgress.mTimeRemaining);
    	return expRet;
    }

    private CValue expOverProg()
    {
    	expRet.forceInt((int)mProgress.mOverallProgress);
    	return expRet;
    }

    private CValue expOverTotal()
    {
    	expRet.forceInt((int)mProgress.mOverallTotal);
    	return expRet;
    }

    private CValue expOverStr()
    {
    	expRet.forceString(overString);
    	return expRet;
    }

    private CValue expStatus()
    {
    	expRet.forceString(status);
    	return expRet;
    }
    
    private CValue expError()
    {
    	expRet.forceInt(error);
    	return expRet;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //
    //
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private static class XAPKFile {
        public final boolean mIsMain;
        public final int mFileVersion;
        public final long mFileSize;

        XAPKFile(boolean isMain, int fileVersion, long fileSize) {
            mIsMain = isMain;
            mFileVersion = fileVersion;
            mFileSize = fileSize;
        }
    }
    
    private void deleteExpansion(boolean flag) {
    	String fileName = Helpers.getExpansionAPKFileName(MMFRuntime.inst, true, MMFRuntime.inst.obbMainVersion);
    	final File newFile = new File(Helpers.generateSaveFileName(MMFRuntime.inst, fileName));
    	final File[] listFiles = newFile.getParentFile().listFiles();
    	for (final File file:listFiles)
    	{
    		final String name = file.getName();
    		if (name.startsWith(fileName)) {
    			if(!flag)		//false is old expansion, true actual expansion
    				continue;
    			else
    				file.delete();
    		}
    	}
    }
    
    void validateXAPKZipFiles() {
    	AsyncTask<Object, DownloadProgressInfo, Boolean> validationTask = new AsyncTask<Object, DownloadProgressInfo, Boolean>() {

    		@Override
    		protected void onPreExecute() {
    			super.onPreExecute();
    		}

            @Override
			protected Boolean doInBackground(Object... params) {
                for (XAPKFile xf : xAPKS) {
                	if(xf == null)
                		continue;
                    String fileName = Helpers.getExpansionAPKFileName(
                            MMFRuntime.inst,
                            xf.mIsMain, xf.mFileVersion);
                    if (!Helpers.doesFileExist(MMFRuntime.inst, fileName,
                            xf.mFileSize, false))
                        return false;
                    fileName = Helpers
                            .generateSaveFileName(MMFRuntime.inst, fileName);
                    ZipResourceFile zrf;
                    byte[] buf = new byte[1024 * 256];
                    try {
                        zrf = new ZipResourceFile(fileName);
                        ZipEntryRO[] entries = zrf.getAllEntries();
                        /**
                         * First calculate the total compressed length
                         */
                        long totalCompressedLength = 0;
                        for (ZipEntryRO entry : entries) {
                            totalCompressedLength += entry.mCompressedLength;
                        }
                        float averageVerifySpeed = 0;
                        long totalBytesRemaining = totalCompressedLength;
                        long timeRemaining;
                        /**
                         * Then calculate a CRC for every file in the Zip file,
                         * comparing it to what is stored in the Zip directory.
                         * Note that for compressed Zip files we must extract
                         * the contents to do this comparison.
                         */
                        for (ZipEntryRO entry : entries) {
                            if (-1 != entry.mCRC32) {
                                long length = entry.mUncompressedLength;
                                CRC32 crc = new CRC32();
                                DataInputStream dis = null;
                                try {
                                    dis = new DataInputStream(
                                            zrf.getInputStream(entry.mFileName));

                                    long startTime = SystemClock.uptimeMillis();
                                    while (length > 0) {
                                        int seek = (int) (length > buf.length ? buf.length
                                                : length);
                                        dis.readFully(buf, 0, seek);
                                        crc.update(buf, 0, seek);
                                        length -= seek;
                                        long currentTime = SystemClock.uptimeMillis();
                                        long timePassed = currentTime - startTime;
                                        if (timePassed > 0) {
                                            float currentSpeedSample = (float) seek
                                                    / (float) timePassed;
                                            if (0 != averageVerifySpeed) {
                                                averageVerifySpeed = SMOOTHING_FACTOR
                                                        * currentSpeedSample
                                                        + (1 - SMOOTHING_FACTOR)
                                                        * averageVerifySpeed;
                                            } else {
                                                averageVerifySpeed = currentSpeedSample;
                                            }
                                            totalBytesRemaining -= seek;
                                            timeRemaining = (long) (totalBytesRemaining / averageVerifySpeed);
                                            this.publishProgress(
                                                    new DownloadProgressInfo(
                                                            totalCompressedLength,
                                                            totalCompressedLength
                                                                    - totalBytesRemaining,
                                                            timeRemaining,
                                                            averageVerifySpeed)
                                                    );
                                        }
                                        startTime = currentTime;
                                        if (mCancelValidation)
                                            return true;
                                    }
                                    if (crc.getValue() != entry.mCRC32) {
                                        Log.e(Constants.TAG,
                                                "CRC does not match for entry: "
                                                        + entry.mFileName);
                                        Log.e(Constants.TAG,
                                                "In file: " + entry.getZipFileName());
                                        return false;
                                    }
                                } finally {
                                    if (null != dis) {
                                        dis.close();
                                    }
                                }
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        return false;
                    }
                }
                return true;
            }

    		@Override
    		protected void onProgressUpdate(DownloadProgressInfo... values) {
    			mLocalClient.onDownloadProgress(values[0]);
    			super.onProgressUpdate(values);
    		}

    		@Override
    		protected void onPostExecute(Boolean result) {
    			mResultValidation = result;
    			if(mResultValidation) {
    				error = 0;
    				status = "validated";
    				ho.pushEvent(CNDONEXPVALIDATED, 0);
    			} else {
    				error = 1002;
    				status = "crc_failed";
    				ho.pushEvent(CNDONDOWNEXPERROR, 0);  				
    			}
    			super.onPostExecute(result);
    		}

    	};
    	status = "validating";
    	validationTask.execute(new Object());
    }    
    
}
