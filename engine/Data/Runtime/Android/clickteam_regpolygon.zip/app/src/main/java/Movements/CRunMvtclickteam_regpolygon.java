/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// CRUNMVTREGPOLYGON : Movement polyone!
//
//----------------------------------------------------------------------------------
package Movements;

import Animations.CAnim;
import Application.CRunFrame;
import Services.CBinaryFile;

public class CRunMvtclickteam_regpolygon extends CRunMvtExtension
{
    static final int MFLAG1_MOVEATSTART = 1;
    int m_dwCX;
    int m_dwCY;
    int m_dwNumSides;
    int m_dwRadius;
    int m_dwFlags;
    int m_dwRotAng;
    int m_dwVel;
    boolean r_Stopped;
    int r_OnEnd;
    int r_CX;
    int r_CY;
    int r_Sides;
    double r_Vel;
    double r_CurrentAngle;
    double r_SideRemainder;
    double r_Radius;
    double r_CurrentX;
    double r_CurrentY;
    double r_SideSize;
    double r_TurnAngle;

    public CRunMvtclickteam_regpolygon()
    {
    }

    @Override
	public void initialize(CBinaryFile file)
    {
        // Version number
        file.skipBytes(1);
        m_dwCX = file.readInt();
        m_dwCY = file.readInt();
        m_dwNumSides = file.readInt();
        m_dwRadius = file.readInt();
        m_dwFlags = file.readInt();
        m_dwRotAng = file.readInt();
        m_dwVel = file.readInt();

        //*** General variables
        double r_StartAngle = m_dwRotAng * (Math.PI / 180.0);

        r_Stopped = ((m_dwFlags & MFLAG1_MOVEATSTART) == 0);
        r_CX = m_dwCX;
        r_CY = m_dwCY;
        r_Sides = m_dwNumSides;
        r_Vel = m_dwVel / 50.0;
        r_Radius = m_dwRadius;

        r_CurrentX = r_CX + r_Radius * Math.cos(r_StartAngle);
        r_CurrentY = r_CY - r_Radius * Math.sin(r_StartAngle);
        r_SideSize = 2 * r_Radius * Math.sin(Math.PI / r_Sides);
        r_TurnAngle = (2.0 / r_Sides) * Math.PI;
        r_CurrentAngle = Math.PI * (0.5 + (1.0 / r_Sides)) + r_StartAngle;
        r_SideRemainder = r_SideSize;

        ho.roc.rcSpeed = Math.abs(m_dwVel);

        if (r_Vel < 0.0)
        {
            r_CurrentAngle = r_CurrentAngle + Math.PI * (1.0 - (2.0 / r_Sides));
            r_TurnAngle += 2 * Math.PI * (1.0 - (2.0 / r_Sides));
            r_Vel *= -1;
        }
    }

    void reset()
    {
        //*** General variables
        double r_StartAngle = m_dwRotAng * (Math.PI / 180.0);

        r_CX = m_dwCX;
        r_CY = m_dwCY;
        r_Sides = m_dwNumSides;
        r_Vel = m_dwVel / 50.0;
        r_Radius = m_dwRadius;

        r_CurrentX = r_CX + r_Radius * Math.cos(r_StartAngle);
        r_CurrentY = r_CY - r_Radius * Math.sin(r_StartAngle);
        r_SideSize = 2 * r_Radius * Math.sin(Math.PI / r_Sides);
        r_TurnAngle = (2.0 / r_Sides) * Math.PI;
        r_CurrentAngle = Math.PI * (0.5 + (1.0 / r_Sides)) + r_StartAngle;
        r_SideRemainder = r_SideSize;

        if (r_Vel < 0.0)
        {
            r_CurrentAngle = r_CurrentAngle + Math.PI * (1.0 - (2.0 / r_Sides));
            r_TurnAngle += 2 * Math.PI * (1.0 - (2.0 / r_Sides));
            r_Vel *= -1;
        }
    }

    @Override
	public void kill()
    {
    }

    @Override
	public boolean move()
    {
        //*** Object needs to be moved?
        if (!r_Stopped)
        {
            double toMove = r_Vel;
            if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
            {
                toMove = toMove * ho.hoAdRunHeader.rh4MvtTimerCoef;
            }

            boolean complete = false;

            while (complete == false)
            {
                if (toMove >= r_SideRemainder)
                {
                    //*** move to the next vertex and turn the angle ready to move along next section
                    r_CurrentX += r_SideRemainder * Math.cos(r_CurrentAngle);
                    r_CurrentY -= r_SideRemainder * Math.sin(r_CurrentAngle);
                    toMove -= r_SideRemainder;
                    r_SideRemainder = r_SideSize;
                    r_CurrentAngle += r_TurnAngle;
                }
                else
                {
                    //*** move along the side
                    r_CurrentX += toMove * Math.cos(r_CurrentAngle);
                    r_CurrentY -= toMove * Math.sin(r_CurrentAngle);
                    r_SideRemainder -= toMove;
                    complete = true;
                }
            }
            //*** Move object, run animation and collision detection
            animations(CAnim.ANIMID_WALK);
            ho.hoX = (int) r_CurrentX;
            ho.hoY = (int) r_CurrentY;
            collisions();

            //*** Indicate the object has been moved
            return true;
        }
        animations(CAnim.ANIMID_STOP);
        collisions();
        return false;
    }

    @Override
	public void setPosition(int x, int y)
    {
        r_CurrentX -= ho.hoX - x;
        r_CurrentY -= ho.hoY - y;

        r_CX -= ho.hoX - x;
        r_CY -= ho.hoY - y;

        ho.hoX = x;
        ho.hoY = y;
    }

    @Override
	public void setXPosition(int x)
    {
        r_CurrentX -= ho.hoX - x;
        r_CX -= ho.hoX - x;

        ho.hoX = x;
    }

    @Override
	public void setYPosition(int y)
    {
        r_CurrentY -= ho.hoY - y;
        r_CY -= ho.hoY - y;

        ho.hoY = y;
    }

    @Override
	public void stop(boolean bCurrent)
    {
        r_Stopped = true;
    }

    @Override
	public void bounce(boolean bCurrent)
    {
    }

    @Override
	public void reverse()
    {
        r_CurrentAngle += Math.PI;
        r_TurnAngle = 2 * Math.PI - r_TurnAngle;
        r_SideRemainder = r_SideSize - r_SideRemainder;
    }

    @Override
	public void start()
    {
        r_Stopped = false;
    }

    @Override
	public void setSpeed(int speed)
    {
        r_Vel = Math.abs(speed) / 50.0;
    }

    @Override
	public void setMaxSpeed(int speed)
    {
    }

    @Override
	public void setDir(int dir)
    {
    }

    @Override
	public void setAcc(int acc)
    {
    }

    @Override
	public void setDec(int dec)
    {
    }

    @Override
	public void setRotSpeed(int speed)
    {
    }

    @Override
	public void set8Dirs(int dirs)
    {
    }

    @Override
	public void setGravity(int gravity)
    {
    }

    @Override
	public int extension(int function, int param)
    {
        return 0;
    }

    @Override
	public double actionEntry(int action)
    {
        int param;
        switch (action)
        {
            case 3445:	    // SET_CENTRE_X = 3445,
                param = (int) getParamDouble();
                r_CurrentX += param - r_CX;
                r_CX = param;
                break;
            case 3446:	    // SET_CENTRE_Y,
                param = (int) getParamDouble();
                r_CurrentY += param - r_CY;
                r_CY = param;
                break;
            case 3447:	    // SET_NUMSIDES,
                param = (int) getParamDouble();
                m_dwNumSides = Math.max(param, 0);
                reset();
                break;
            case 3448:	    // SET_RADIUS,
                param = (int) getParamDouble();
                m_dwRadius = Math.max(param, 0);
                reset();
                break;
            case 3449:	    // SET_ROTATION_ANGLE,
                param = (int) getParamDouble();
                m_dwRotAng = Math.max(param, 0);
                reset();
                break;
            case 3450:	    // SET_VELOCITY,
                param = (int) getParamDouble();
                r_Vel = Math.abs(param) / 50.0;
                break;
            case 3451:	    // GET_CENTRE_X,
                return r_CX;
            case 3452:	    // GET_CENTRE_Y,
                return r_CY;
            case 3453:	    // GET_NUMSIDES,
                return r_Sides;
            case 3454:	    // GET_RADIUS,
                return r_Radius;
            case 3455:	    // GET_ROTATION_ANGLE,
                return m_dwRotAng;
            case 3456:	    // GET_VELOCITY
                return r_Vel * 50;
        }
        return 0;
    }

    @Override
	public int getSpeed()
    {
        return (int) (r_Vel * 50);
    }

    @Override
	public int getAcceleration()
    {
        return 0;
    }

    @Override
	public int getDeceleration()
    {
        return 0;
    }

    @Override
	public int getGravity()
    {
        return 0;
    }
}
