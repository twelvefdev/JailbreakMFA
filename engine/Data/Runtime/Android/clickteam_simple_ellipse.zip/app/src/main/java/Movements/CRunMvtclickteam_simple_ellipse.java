/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// CRUNMVTSIMPLEELLIPSE
//
//----------------------------------------------------------------------------------

package Movements;

import Animations.CAnim;
import Application.CRunFrame;
import Services.CBinaryFile;

public class CRunMvtclickteam_simple_ellipse extends CRunMvtExtension
{
    static final int MFLAG1_MOVEATSTART = 1;
    int m_dwCX;
    int m_dwCY;
    int m_dwRadiusX;
    int m_dwRadiusY;
    int m_dwStartAngle;
    int m_dwFlags;
    int m_dwAngVel;
    int m_dwOffset;
    boolean r_Stopped;
    int r_CX;
    int r_CY;
    int r_radiusX;
    int r_radiusY;
    double r_AngVel;
    double r_Offset;
    double r_CurrentAngle;

    public CRunMvtclickteam_simple_ellipse()
    {
    }

    @Override
	public void initialize(CBinaryFile file)
    {
        file.skipBytes(1);
        m_dwCX = file.readInt();
        m_dwCY = file.readInt();
        m_dwRadiusX = file.readInt();
        m_dwRadiusY = file.readInt();
        m_dwStartAngle = file.readInt();
        m_dwFlags = file.readInt();
        m_dwAngVel = file.readInt();
        m_dwOffset = file.readInt();

        r_Stopped = ((m_dwFlags & MFLAG1_MOVEATSTART) == 0);

        r_CX = m_dwCX;
        r_CY = m_dwCY;
        r_AngVel = m_dwAngVel / 50.0 * (Math.PI / 180.0);
        r_Offset = m_dwOffset * (Math.PI / 180.0);
        r_CurrentAngle = m_dwStartAngle * (Math.PI / 180.0);
        r_radiusX = m_dwRadiusX;
        r_radiusY = m_dwRadiusY;

        ho.roc.rcSpeed = m_dwAngVel;
    }

    @Override
	public void kill()
    {
    }

    @Override
	public boolean move()
    {
        //*** Object needs to be moved?
        if (!r_Stopped)
        {
            double x = r_radiusX * Math.cos(r_CurrentAngle);
            double y = r_radiusY * Math.sin(r_CurrentAngle);

            //*** Carry out 2D transform if needed
            if (Math.abs(r_Offset) > 0.0001)
            {
                double xprime = Math.cos(r_Offset) * x - y * Math.sin(r_Offset);
                double yprime = Math.sin(r_Offset) * x + y * Math.cos(r_Offset);

                x = xprime;
                y = yprime;
            }

            double calculs = r_AngVel;
            if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
            {
                calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
            }

            r_CurrentAngle += calculs;

            if (r_CurrentAngle < 0)
            {
                r_CurrentAngle += 2 * Math.PI;
            }
            else if (r_CurrentAngle > 2 * Math.PI)
            {
                r_CurrentAngle -= 2 * Math.PI;
            }

            animations(CAnim.ANIMID_WALK);
            ho.hoX = (int) (r_CX + x);
            ho.hoY = (int) (r_CY - y);
            collisions();

            //*** Indicate the object has been moved
            return true;
        }
        animations(CAnim.ANIMID_STOP);
        collisions();

        //*** The object has not been moved
        return false;
    }

    void reset()
    {
        r_CX = m_dwCX;
        r_CY = m_dwCY;
        r_AngVel = m_dwAngVel / 50.0 * (Math.PI / 180.0);
        r_Offset = m_dwOffset * (Math.PI / 180.0);
        r_CurrentAngle = m_dwStartAngle * (Math.PI / 180.0);
        r_radiusX = m_dwRadiusX;
        r_radiusY = m_dwRadiusY;
    }

    @Override
	public void setPosition(int x, int y)
    {
        r_CX -= ho.hoX - x;
        r_CY -= ho.hoY - y;

        ho.hoX = x;
        ho.hoY = y;
    }

    @Override
	public void setXPosition(int x)
    {
        r_CX -= ho.hoX - x;
        ho.hoX = x;
    }

    @Override
	public void setYPosition(int y)
    {
        r_CY -= ho.hoY - y;
        ho.hoY = y;
    }

    @Override
	public void stop(boolean bCurrent)
    {
        r_Stopped = true;
    }

    @Override
	public void bounce(boolean bCurrent)
    {
    }

    @Override
	public void reverse()
    {
        r_AngVel *= -1;
    }

    @Override
	public void start()
    {
        r_Stopped = false;
    }

    @Override
	public void setSpeed(int speed)
    {
        //*** Linear motion components;
        r_AngVel = (speed) / 50.0 * (Math.PI / 180.0);
        ho.roc.rcSpeed = speed;
    }

    @Override
	public void setMaxSpeed(int speed)
    {
    }

    @Override
	public void setDir(int dir)
    {
    }

    @Override
	public void setAcc(int acc)
    {
    }

    @Override
	public void setDec(int dec)
    {
    }

    @Override
	public void setRotSpeed(int speed)
    {
    }

    @Override
	public void set8Dirs(int dirs)
    {
    }

    @Override
	public void setGravity(int gravity)
    {
    }

    @Override
	public int extension(int function, int param)
    {
        return 0;
    }

    @Override
	public double actionEntry(int action)
    {
        int param;
        switch (action)
        {
            case 3645:	    // SET_CENTRE_X = 3645,
                param = (int) getParamDouble();
                r_CX = param;
                break;
            case 3646:	    // SET_CENTRE_Y,
                param = (int) getParamDouble();
                r_CY = param;
                break;
            case 3647:	    // SET_RADIUS_X,
                param = (int) getParamDouble();
                r_radiusX = param;
                break;
            case 3648:	    // SET_RADIUS_Y,
                param = (int) getParamDouble();
                r_radiusY = param;
                break;
            case 3649:	    // SET_ANGSPEED,
                param = (int) getParamDouble();
                r_AngVel = param / 50.0 * (Math.PI / 180.0);
                ho.roc.rcSpeed = param;
                break;
            case 3650:	    // SET_CURRENTANGLE,
                param = (int) getParamDouble();
                r_CurrentAngle = param * (Math.PI / 180.0);
            case 3651:	    // SET_OFFSETANGLE,
                param = (int) getParamDouble();
                r_Offset = param * (Math.PI / 180.0);
            case 3652:	    // GET_CENTRE_X,
                return r_CX;
            case 3653:	    // GET_CENTRE_Y,
                return r_CY;
            case 3654:	    // GET_RADIUS_X,
                return r_radiusX;
            case 3655:	    // GET_RADIUS_Y,
                return r_radiusY;
            case 3656:	    // GET_ANGSPEED,
                return r_AngVel * 50.0 * (180.0 / Math.PI);
            case 3657:	    // GET_CURRENTANGLE,
                return r_CurrentAngle * (180 / Math.PI);
            case 3658:	    // GET_OFFSETANGLE
                return r_Offset * (180 / Math.PI);
        }
        return 0;
    }

    @Override
	public int getSpeed()
    {
        return ho.roc.rcSpeed;
    }

    @Override
	public int getAcceleration()
    {
        return 0;
    }

    @Override
	public int getDeceleration()
    {
        return 0;
    }

    @Override
	public int getGravity()
    {
        return 0;
    }
}
