/* Copyright (c) 1996-2013 Clickteam
 *
 * This source code is part of the Android exporter for Clickteam Multimedia Fusion 2.
 * 
 * Permission is hereby granted to any person obtaining a legal copy 
 * of Clickteam Multimedia Fusion 2 to use or modify this source code for 
 * debugging, optimizing, or customizing applications created with 
 * Clickteam Multimedia Fusion 2.  Any other use of this source code is prohibited.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
//----------------------------------------------------------------------------------
//
// CRUNMVTPINBALL : movement pinball
//
//----------------------------------------------------------------------------------
package Movements;

import Animations.CAnim;
import Application.CRunFrame;
import Services.CBinaryFile;
import Services.CPoint;
import Sprites.CColMask;

public class CRunMvtpinball extends CRunMvtExtension
{
    public static final int EFLAG_MOVEATSTART = 1;
    public static final int MFLAG_STOPPED = 1;
    int m_dwInitialSpeed;
    int m_dwDeceleration;
    int m_dwGravity;
    int m_dwInitialDir;
    int m_dwFlags;
    double m_gravity;
    double m_xVector;
    double m_yVector;
    double m_angle;
    double m_X;
    double m_Y;
    double m_deceleration;
    int m_flags;

    public CRunMvtpinball()
    {
    }

    @Override
	public void initialize(CBinaryFile file)
    {
        file.skipBytes(1);
        m_dwInitialSpeed = file.readInt();
        m_dwDeceleration = file.readInt();
        m_dwGravity = file.readInt();
        m_dwInitialDir = file.readInt();
        m_dwFlags = file.readInt();

        // Initialisations
        m_X = ho.hoX;
        m_Y = ho.hoY;
        ho.roc.rcSpeed = m_dwInitialSpeed;

        // Finds the initial direction
        ho.roc.rcDir = dirAtStart(m_dwInitialDir);
        double angle = (ho.roc.rcDir * 2 * Math.PI) / 32.0;

        // Calculates the vectors
        m_gravity = m_dwGravity;
        m_deceleration = m_dwDeceleration;
        m_xVector = ho.roc.rcSpeed * Math.cos(angle);
        m_yVector = -ho.roc.rcSpeed * Math.sin(angle);

        // Move at start
        m_flags = 0;
        if ((m_dwFlags & EFLAG_MOVEATSTART) == 0)
        {
            m_flags |= MFLAG_STOPPED;
        }
    }

    double getAngle(double vX, double vY)
    {
        double vector = Math.sqrt(vX * vX + vY * vY);
        if (vector == 0.0)
        {
            return 0.0;
        }
        double angle = Math.acos(vX / vector);
        if (vY > 0.0)
        {
            angle = 2.0 * Math.PI - angle;
        }
        return angle;
    }

    public double getVector(double vX, double vY)
    {
        return Math.sqrt(vX * vX + vY * vY);
    }

    @Override
	public void kill()
    {
    }

    @Override
	public boolean move()
    {
        // Stopped?
        if ((m_flags & MFLAG_STOPPED) != 0)
        {
            animations(CAnim.ANIMID_STOP);
            collisions();
            return false;
        }

        // Increase Y speed
        m_yVector += m_gravity / 10.0;

        // Get the current vector of the ball
        double angle = getAngle(m_xVector, m_yVector);	// Get the angle and vector
        double vector = getVector(m_xVector, m_yVector);
        double calculs = m_deceleration;
        if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
        {
            calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
        }
        vector -= calculs / 50.0;
        if (vector < 0.0)
        {
            vector = 0.0;
        }
        m_xVector = vector * Math.cos(angle);					// Restores X and Y speeds
        m_yVector = -vector * Math.sin(angle);

        // Calculate the new position
        calculs = m_xVector;
        if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
        {
            calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
        }
        m_X = m_X + (calculs / 10.0);
        calculs = m_yVector;
        if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
        {
            calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
        }
        m_Y = m_Y + (calculs / 10.0);

        // Performs the animation
        ho.roc.rcSpeed = (int) vector;
        if (ho.roc.rcSpeed > 250)
        {
            ho.roc.rcSpeed = 250;
        }
        ho.roc.rcDir = (int) ((angle * 32) / (2.0 * Math.PI));
        animations(CAnim.ANIMID_WALK);

        // detects the collisions
        ho.hoX = (int) m_X;
        ho.hoY = (int) m_Y;
        collisions();

        // The object has been moved
        return true;
    }

    @Override
	public void setPosition(int x, int y)
    {
        ho.hoX = x;
        ho.hoY = y;
        m_X = x;
        m_Y = y;
    }

    @Override
	public void setXPosition(int x)
    {
        ho.hoX = x;
        m_X = x;
    }

    @Override
	public void setYPosition(int y)
    {
        ho.hoY = y;
        m_Y = y;
    }

    @Override
	public void stop(boolean bCurrent)
    {
        m_flags |= MFLAG_STOPPED;
    }

    @Override
	public void bounce(boolean bCurrent)
    {
        if (!bCurrent)
        {
            m_xVector = -m_xVector;
            m_yVector = -m_yVector;
            return;
        }

        // Takes the object against the obstacle
        CPoint pt = new CPoint();
        approachObject(ho.hoX, ho.hoY, ho.roc.rcOldX, ho.roc.rcOldY, 0, CColMask.CM_TEST_PLATFORM, pt);
        ho.hoX = pt.x;
        ho.hoY = pt.y;
        m_X = pt.x;
        m_Y = pt.y;

        // Get the current vector of the ball
        double angle = getAngle(m_xVector, m_yVector);
        double vector = getVector(m_xVector, m_yVector);

        // Finds the shape of the obstacle
        double a;
        double aFound = -1000;
        for (a = 0.0; a < 2.0 * Math.PI; a += Math.PI / 32.0)
        {
            double xVector = 16 * Math.cos(angle + a);
            double yVector = -16 * Math.sin(angle + a);
            double x = m_X + xVector;
            double y = m_Y + yVector;

            if (testPosition((int) x, (int) y, 0, CColMask.CM_TEST_PLATFORM, false))
            {
                aFound = a;
                break;
            }
        }

        // If nothing is found, simply go backward
        if (aFound == -1000)
        {
            m_xVector = -m_xVector;
            m_yVector = -m_yVector;
        }
        else
        {
            // The angle is found, proceed with the bounce
            angle += aFound * 2;
            if (angle > 2.0 * Math.PI)
            {
                angle -= 2.0 * Math.PI;
            }
            
    		ho.roc.rcDir = (int) ((angle * 32) / (2.0 * Math.PI));

            // Restores the speed vectors
            m_xVector = vector * Math.cos(angle);
            m_yVector = -vector * Math.sin(angle);
        }
    }

    @Override
	public void reverse()
    {
        m_xVector = -m_xVector;
        m_yVector = -m_yVector;
    }

    @Override
	public void start()
    {
        m_flags &= ~MFLAG_STOPPED;
    }

    @Override
	public void setSpeed(int speed)
    {
        //if (speed < 0)
        //{
        //	speed = 0;
        //}
        if (speed > 250)
        {
        	speed = 250;
        }
        
        ho.roc.rcSpeed = speed;

        // Gets the current speed vector
        double angle = getAngle(m_xVector, m_yVector);

        // Changes the current x and y vectors
        m_xVector = speed * Math.cos(angle);
        m_yVector = -speed * Math.sin(angle);
    }

    @Override
	public void setMaxSpeed(int speed)
    {
    }

    @Override
	public void setDir(int dir)
    {
        ho.roc.rcDir = dir;

        // Get the current speed vector
        double angle = getAngle(m_xVector, m_yVector);
        double vector = getVector(m_xVector, m_yVector);

        // Converts the angle in 32 directions to a angle in radian
        angle = dir * 2.0 * Math.PI / 32.0;

        // Changes the speeds
        m_xVector = vector * Math.cos(angle);
        m_yVector = -vector * Math.sin(angle);
    }

    @Override
	public void setAcc(int acc)
    {
    }

    @Override
	public void setDec(int dec)
    {
    	/*
        if (dec < 0)
        {
            dec = 0;
        }
        if (dec > 250)
        {
            dec = 250;
        }
        */
    	m_deceleration = dec;
    }

    @Override
	public void setRotSpeed(int speed)
    {
    }

    @Override
	public void set8Dirs(int dirs)
    {
    }

    @Override
	public void setGravity(int gravity)
    {
        if (gravity < 0)
        {
        	gravity = 0;
        }
        if (gravity > 250)
        {
        	gravity = 250;
        }
        m_gravity = gravity;
    }

    @Override
	public int extension(int function, int param)
    {
        return 0;
    }

    @Override
	public double actionEntry(int action)
    {
        switch (action)
        {
            default:		// SET_INVADERS_SPEED = 3745,
                m_gravity = getParamDouble();
                break;
        }
        return 0;
    }

    @Override
	public int getSpeed()
    {
        return ho.roc.rcSpeed;
    }

    @Override
	public int getAcceleration()
    {
        return 0;
    }

    @Override
	public int getDeceleration()
    {
        return (int) m_deceleration;
    }

    @Override
	public int getGravity()
    {
        return (int) m_gravity;
    }
}
