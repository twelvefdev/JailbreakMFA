package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import Objects.CActive;
import Objects.CExtension;
import Objects.CObject;
import RunLoop.CCreateObjectInfo;
import Runtime.Log;
import Runtime.MMFRuntime;
import Services.CBinaryFile;
import Services.CRect;
import android.text.InputType;
import android.view.inputmethod.EditorInfo;

public class CRunInputType extends CRunExtension
{
    // <editor-fold defaultstate="collapsed" desc=" A/C/E Constants ">
    public static final int CND_ISKEYBVISIBLE = 0;
    public static final int CND_LAST = 1;

    public static final int ACTKBTEXT = 0;
    public static final int ACTKBNUMERIC = 1;
    public static final int ACTKBPHONE = 2;
    public static final int ACTKBURI = 3;
    public static final int ACTKBEMAIL = 4;
    public static final int ACTKBPOSTAL = 5;
    public static final int ACTKBDDATE = 6;
    public static final int ACTKBUNDEF = 7;
    public static final int ACTEDITFITS = 8;
    public static final int ACTEDITFITO = 9;
    public static final int ACTHINTCOLOR = 10;
    public static final int ACTHINTTEXT = 11;
    public static final int ACTKBNUMERICTYPES = 12;
    public static final int ACTKBNUMERICIME = 13;
    public static final int ACTKBBYNUMERIC = 14;
    public static final int ACTKBSTRINGTYPES = 15;
    public static final int ACTKBSTRINGIME = 16;
    public static final int ACTKBBYSTRINGS = 17;


    public static final int EXPLASTKBTYPE = 0;
    public static final int EXPLASTKBSUBTYPE = 1;
    public static final int EXPFITFONTSIZE = 2;

    // </editor-fold>
    
    private int keyBoardType = 0;
    private int IMEType = 0;
    private int type;
    private int subtype;
    private int fitfontsize = 0;

    private int nType;
    private int nSubtype;
    private int nIME_opt;
    private String sType;
    private String sSubtype;
    private String sIME_opt;

    public CRunInputType()
    {
    }
    
    public @Override int getNumberOfConditions()
    {
	    return CND_LAST;
    }
    
    public @Override boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
    	// Set Empty string keyboard configuration.
           sType = "";
        sSubtype = "";
        sIME_opt = "";
        
    	return false;
    }
    
    public @Override void destroyRunObject(boolean bFast)
    {
    }
    
    public @Override int handleRunObject()
    {
        return REFLAG_ONESHOT;
    }
    
    public @Override void pauseRunObject()
    {
    }
    
    public @Override void continueRunObject()
    {
    }

    // Conditions
    // -------------------------------------------------
    public @Override boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
        {
        	case CND_ISKEYBVISIBLE:
        		return MMFRuntime.inst.keyBoardOn;
        }
        return false;
    }

    // Actions
    // -------------------------------------------------
    public @Override void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACTKBTEXT:
                actKBText(act);
                break;
            case ACTKBNUMERIC:
                actKBNumeric(act);
                break;
            case ACTKBPHONE:
                actKBPhone(act);
                break;
            case ACTKBURI:
                actKBUri(act);
                break;
            case ACTKBEMAIL:
                actKBEmail(act);
                break;
            case ACTKBPOSTAL:
                actKBPostal(act);
                break;
            case ACTKBDDATE:
                actKBDDate(act);
                break;
            case ACTKBUNDEF:
                actKBUndef(act);
                break;
            case ACTEDITFITS:
                actEditFitSize(act);
                break;
            case ACTEDITFITO:
                actEditFitObject(act);
                break;
            case ACTHINTCOLOR:
                actEditHintColor(act);
                break;
            case ACTHINTTEXT:
                actEditHintText(act);
                break;
            case ACTKBNUMERICTYPES:
                actKBNumericTypes(act);
                break;
            case ACTKBNUMERICIME:
                actKBNumericIME(act);
                break;
            case ACTKBBYNUMERIC:
                actKBbyNumeric(act);
                break;
            case ACTKBSTRINGTYPES:
                actKBStringTypes(act);
                break;
            case ACTKBSTRINGIME:
                actKBStringIME(act);
                break;
            case ACTKBBYSTRINGS:
                actKBbyStrings(act);
                break;
        }
    }

    // Expressions
    // -------------------------------------------------
    public @Override CValue expression(int num)
    {
        switch (num)
        {
            case EXPLASTKBTYPE:
                return expLastKBType();
            case EXPLASTKBSUBTYPE:
                return expLastKBSubType();
            case EXPFITFONTSIZE:
                return expFitFontSize();
        }
        return null;
    }

    private void actKBText(CActExtension act)
    {
    	int param0 = act.getParamExpression(rh,0);
    	int param1 = act.getParamExpression(rh,1);
    	CObject obj = act.getParamObject(rh,2);

    	if(obj != null) {
        	keyBoardType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        	type = keyBoardType;
        	switch(param0) {
    	    	case 0:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_VARIATION_NORMAL;
    	    		break;
    	    	case 1:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS;
    	    		break;
    	    	case 2:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    	    		break;
    	    	case 3:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    	    		break;
    	    	case 4:
    	    		subtype = param0;
    	    		keyBoardType &= ~InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_CORRECT;
    	    		break;
    	    	case 5:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_CORRECT;
    	    		break;
    	    	case 6:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_CORRECT;
    	    		break;
    	    	case 7:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_CORRECT;
    	    		break;
    	    	case 8:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE;
    	    		break;
    	    	case 9:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE;
    	    		break;
    	    	case 10:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE;
    	    		break;
    	    	case 11:
    	    		subtype = param0;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE;
    	    		break;
    	    	case 12:
    	    		subtype = param0;
    	    		keyBoardType &= ~InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_CORRECT;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE;
    	    		break;
    	    	case 13:
    	    		subtype = param0;
    	    		keyBoardType &= ~InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_CORRECT;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE;
    	    		break;
    	    	case 14:
    	    		subtype = param0;
    	    		keyBoardType &= ~InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_CORRECT;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE;
    	    		break;
    	    	case 15:
    	    		subtype = param0;
    	    		keyBoardType &= ~InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_CORRECT;
    	    		keyBoardType |= InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE;
    	    		break;
    	    	default:
    	    		subtype = -1;
    	    		keyBoardType |= InputType.TYPE_TEXT_VARIATION_NORMAL;
    	    		break;
        	}

        	SetIMEOptions(param1);
        	SetKeyboardIME(obj);
    	}
    	
    }

    private void actKBNumeric(CActExtension act)
    {
    	int param0 = act.getParamExpression(rh,0);
    	int param1 = act.getParamExpression(rh,1);
    	CObject obj = act.getParamObject(rh,2);

    	if(obj != null) {
    		keyBoardType = InputType.TYPE_CLASS_NUMBER;
    		type = keyBoardType;
    		switch(param0) {
	    		case 0:
	    			subtype = param0;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_VARIATION_NORMAL;
	    			break;
	    		case 1:
	    			subtype = param0;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_FLAG_SIGNED;
	    			break;
	    		case 2:
	    			subtype = param0;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_FLAG_DECIMAL;
	    			break;
	    		case 3:
	    			subtype = param0;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_FLAG_SIGNED;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_FLAG_DECIMAL;
	    			break;
	    		case 4:
	    			subtype = param0;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_VARIATION_PASSWORD;
	    			break;
	    		case 5:
	    			subtype = param0;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_FLAG_SIGNED;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_VARIATION_PASSWORD;
	    			break;
	    		case 6:
	    			subtype = param0;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_FLAG_DECIMAL;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_VARIATION_PASSWORD;
	    			break;
	    		case 7:
	    			subtype = param0;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_FLAG_SIGNED;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_FLAG_DECIMAL;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_VARIATION_PASSWORD;
	    			break;
	    		default:
	    			subtype = -1;
	    			keyBoardType = keyBoardType | InputType.TYPE_NUMBER_VARIATION_NORMAL;
	    			break;
    		}
    		
        	SetIMEOptions(param1);
    		SetKeyboardIME(obj);
    	}
    }

    private void actKBPhone(CActExtension act)
    {
    	int param0 = act.getParamExpression(rh,0);
    	CObject obj = act.getParamObject(rh,1);

    	if(obj != null) {
        	keyBoardType = InputType.TYPE_CLASS_PHONE;
        	type = keyBoardType;
        	subtype = 0;
        	SetIMEOptions(param0);
    		SetKeyboardIME(obj);
    	}
   }

    private void actKBUri(CActExtension act)
    {
    	int param0 = act.getParamExpression(rh,0);
    	CObject obj = act.getParamObject(rh,1);

    	if(obj != null) {
        	keyBoardType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL;
        	keyBoardType |= InputType.TYPE_TEXT_VARIATION_URI;    	
        	subtype = 0;
        	type = keyBoardType;
        	SetIMEOptions(param0);
    		SetKeyboardIME(obj);
    	}
    }

    private void actKBEmail(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
    	CObject obj = act.getParamObject(rh,1);

    	if(obj != null) {
        	keyBoardType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
			keyBoardType |= InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ;
        	type = keyBoardType;
        	subtype = 0;

        	SetIMEOptions(param0);

    		SetKeyboardIME(obj);
    	}
    }

    private void actKBPostal(CActExtension act)
    {
    	keyBoardType = InputType.TYPE_CLASS_TEXT;
    	type = keyBoardType;
    	subtype = 0;
    	keyBoardType = keyBoardType | InputType.TYPE_TEXT_VARIATION_POSTAL_ADDRESS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;    	
    	int param0 = act.getParamExpression(rh,0);
    	CObject obj = act.getParamObject(rh,1);

    	if(obj != null) {
        	keyBoardType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        	type = keyBoardType;
        	subtype = 0;
        	keyBoardType = keyBoardType | InputType.TYPE_TEXT_VARIATION_URI;    	
        	SetIMEOptions(param0);
    		SetKeyboardIME(obj);
    	}
   }

    private void actKBDDate(CActExtension act)
    {
        int param0 = act.getParamExpression(rh,0);
    	int param1 = act.getParamExpression(rh,1);
    	CObject obj = act.getParamObject(rh,2);

    	if(obj != null) {
        	keyBoardType = InputType.TYPE_CLASS_DATETIME;
        	type = keyBoardType;
        	switch(param0) {
        		case 0:
        			subtype = param0;
        			keyBoardType = keyBoardType | InputType.TYPE_DATETIME_VARIATION_NORMAL;
        			break;
        		case 1:
        			subtype = param0;
        			keyBoardType = keyBoardType | InputType.TYPE_DATETIME_VARIATION_DATE;
        			break;
        		case 2:
        			subtype = param0;
        			keyBoardType = keyBoardType | InputType.TYPE_DATETIME_VARIATION_TIME;
        			break;
        	}
        	
        	SetIMEOptions(param1);
    		SetKeyboardIME(obj);
    	}
    }
    
    private void actKBUndef(CActExtension act)
    {
    	int param0 = act.getParamExpression(rh,0);
    	CObject obj = act.getParamObject(rh,1);

    	if(obj != null) {
        	keyBoardType = InputType.TYPE_NULL;
        	type = keyBoardType;
        	subtype = 0;
        	SetIMEOptions(param0);
    		SetKeyboardIME(obj);
    	}
   }

    private void actEditFitSize(CActExtension act)
    {
    	CObject obj = act.getParamObject(rh,0);
    	int x = act.getParamExpression(rh,1);
    	int y = act.getParamExpression(rh,2);
    	int w = act.getParamExpression(rh,3);
    	int h = act.getParamExpression(rh,4);

    	if(obj != null) {
    		CRect rect = new CRect();
    		rect.left = x;
    		rect.right= x+w;
    		rect.top  = y;
    		rect.bottom= y+h;
        	FitEditSizeAndPosition(obj, rect);
    	}
    	
    }

    private void actEditFitObject(CActExtension act)
    {
    	CObject obj1 = act.getParamObject(rh,0);
    	CObject obj2 = act.getParamObject(rh,1);
    	int padHorizontal = act.getParamExpression(rh,2);
    	int padVertical = act.getParamExpression(rh,3);
    	
    	if(obj1 != null && obj2 != null) {
    		CRect rect = new CRect();
    		getActiveRect(obj2, rect); 
    		rect.left  += padHorizontal;
    		rect.top   += padVertical;
    		rect.right -= padHorizontal;
    		rect.bottom-= padVertical;
        	FitEditSizeAndPosition(obj1, rect);
    	}
    	
    }
    
    private void actEditHintColor(CActExtension act)
    {
    	CObject obj = act.getParamObject(rh,0);
    	int color = act.getParamColour(rh,1);
    	int alpha = (int) (255*act.getParamExpDouble(rh,2));

    	if(obj != null) {
        	SetEditHintColor(obj, alpha << 24 | color);
    	}
    	
    }
    
    private void actEditHintText(CActExtension act)
    {
    	CObject obj = act.getParamObject(rh,0);
    	String txt = act.getParamExpString(rh,1);
 
    	if(obj != null) {
        	SetEditHintText(obj, txt);
    	}
    	
    }
    
    private void actKBNumericTypes(CActExtension act)
    {
        nType = act.getParamExpression(rh,0);
    }

    private void actKBNumericIME(CActExtension act)
    {
        nIME_opt = act.getParamExpression(rh,0);
    }

    private void actKBbyNumeric(CActExtension act)
    {
    	CObject obj = act.getParamObject(rh,0);
    	if(obj != null) {
    		Log.Log("Object Type: "+obj.hoType +" ");
    		if(obj.hoType >= 32) {
    			if (obj instanceof CExtension) {
    				CRunExtension cExt = ((CExtension) obj).ext;
    				if(cExt instanceof CRunExtension) {
    					CRunViewExtension ViewExt = ((CRunViewExtension)cExt);
    					if(ViewExt instanceof CRunkcedit) {
    						CRunkcedit edit = ((CRunkcedit)ViewExt);
    						edit.SetIMEOptions(nIME_opt);
    						edit.SetKeyboard(nType);

    					}
    				}
    			}
    		}          	
    	}
    }

    private void actKBStringTypes(CActExtension act)
    {
        sType = act.getParamExpString(rh,0);
    }

    private void actKBStringIME(CActExtension act)
    {
        sIME_opt = act.getParamExpString(rh,0);
    }

    private void actKBbyStrings(CActExtension act)
    {
    	
    	CObject obj = act.getParamObject(rh,0);
    	if(obj != null && sType.length() > 8 && sIME_opt.length() > 7) {
    		Log.Log("Object Type: "+obj.hoType +" ");
    		if(obj.hoType >= 32) {
    			if (obj instanceof CExtension) {
    				CRunExtension cExt = ((CExtension) obj).ext;
    				if(cExt instanceof CRunExtension) {
    					CRunViewExtension ViewExt = ((CRunViewExtension)cExt);
    					if(ViewExt instanceof CRunkcedit) {
    						CRunkcedit edit = ((CRunkcedit)ViewExt);
    						edit.SetIMEOptions(IMESet(sIME_opt));
    						edit.SetKeyboard(NumericType(sType));

    					}
    				}
    			}
    		}          	
    	}
    }
    
    public enum IMEEnum {
    	IME_ACTION_DONE,
    	IME_ACTION_GO,
    	IME_ACTION_NEXT,
    	IME_ACTION_NONE,
    	IME_ACTION_PREVIOUS,
    	IME_ACTION_SEARCH,
    	IME_ACTION_SEND,
    	IME_ACTION_UNSPECIFIED,
    	IME_FLAG_FORCE_ASCII,
    	IME_FLAG_NAVIGATE_NEXT,
    	IME_FLAG_NAVIGATE_PREVIOUS,
    	IME_FLAG_NO_ACCESSORY_ACTION,
    	IME_FLAG_NO_ENTER_ACTION,
    	IME_FLAG_NO_EXTRACT_UI,
    	IME_FLAG_NO_FULLSCREEN,
    	IME_FLAG_NO_PERSONALIZED_LEARNING,
    	IME_MASK_ACTION,
    	IME_NULL 
    }

    private int IMESet(String s) {
    	int nRet=0;
    	String IMEs[] = s.replace(" ",  "").toUpperCase().split(",");
    	if(IMEs != null && IMEs.length > 0)
    	{
	    	for(String ime : IMEs)
	    	{
	    		IMEEnum Cmd = IMEEnum.valueOf(ime);
	    		switch(Cmd) {
	    			case IME_ACTION_DONE:
	    				nRet += 6;
	    				break;
	    			case IME_ACTION_GO:
	    				nRet += 2;
	    				break;
	    			case IME_ACTION_NEXT:
	    				nRet += 5;
	    				break;
	    			case IME_ACTION_NONE:
	    				nRet += 1;
	    				break;
	    			case IME_ACTION_PREVIOUS:
	    				nRet += 7;
	    				break;
	    			case IME_ACTION_SEARCH:
	    				nRet += 3;
	    				break;
	    			case IME_ACTION_SEND:
	    				nRet += 4;
	    				break;
	    			case IME_ACTION_UNSPECIFIED:
	    				nRet += 0;
	    				break;
	    			case IME_FLAG_FORCE_ASCII:
	    				nRet += -2147483648;
	    				break;
	    			case IME_FLAG_NAVIGATE_NEXT:
	    				nRet += 134217728;
	    				break;
	    			case IME_FLAG_NAVIGATE_PREVIOUS:
	    				nRet += 67108864;
	    				break;
	    			case IME_FLAG_NO_ACCESSORY_ACTION:
	    				nRet += 536870912;
	    				break;
	    			case IME_FLAG_NO_ENTER_ACTION:
	    				nRet += 1073741824;
	    				break;
	    			case IME_FLAG_NO_EXTRACT_UI:
	    				nRet += 268435456;
	    				break;
	    			case IME_FLAG_NO_FULLSCREEN:
	    				nRet += 33554432;
	    				break;
	    			case IME_FLAG_NO_PERSONALIZED_LEARNING:
	    				nRet += 16777216;
	    				break;
	    			case IME_MASK_ACTION:
	    				nRet += 255;
	    				break;
	    			case IME_NULL:
	    				nRet += 0;
	    				break;
	    		}
	    	}
    	}
    	return nRet;
    }
    
    public enum TypeEnum {
    	TYPE_CLASS_DATETIME,
    	TYPE_CLASS_NUMBER,
    	TYPE_CLASS_PHONE,
    	TYPE_CLASS_TEXT,
    	TYPE_DATETIME_VARIATION_DATE,
    	TYPE_DATETIME_VARIATION_NORMAL,
    	TYPE_DATETIME_VARIATION_TIME,
    	TYPE_MASK_CLASS,
    	TYPE_MASK_FLAGS,
    	TYPE_MASK_VARIATION,
    	TYPE_NULL,
    	TYPE_NUMBER_FLAG_DECIMAL,
    	TYPE_NUMBER_FLAG_SIGNED,
    	TYPE_NUMBER_VARIATION_NORMAL,
    	TYPE_NUMBER_VARIATION_PASSWORD,
    	TYPE_TEXT_FLAG_AUTO_COMPLETE,
    	TYPE_TEXT_FLAG_AUTO_CORRECT,
    	TYPE_TEXT_FLAG_CAP_CHARACTERS,
    	TYPE_TEXT_FLAG_CAP_SENTENCES,
    	TYPE_TEXT_FLAG_CAP_WORDS,
    	TYPE_TEXT_FLAG_IME_MULTI_LINE,
    	TYPE_TEXT_FLAG_MULTI_LINE,
    	TYPE_TEXT_FLAG_NO_SUGGESTIONS,
    	TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
    	TYPE_TEXT_VARIATION_EMAIL_SUBJECT,
    	TYPE_TEXT_VARIATION_FILTER,
    	TYPE_TEXT_VARIATION_LONG_MESSAGE,
    	TYPE_TEXT_VARIATION_NORMAL,
    	TYPE_TEXT_VARIATION_PASSWORD,
    	TYPE_TEXT_VARIATION_PERSON_NAME,
    	TYPE_TEXT_VARIATION_PHONETIC,
    	TYPE_TEXT_VARIATION_POSTAL_ADDRESS,
    	TYPE_TEXT_VARIATION_SHORT_MESSAGE,
    	TYPE_TEXT_VARIATION_URI,
    	TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
    	TYPE_TEXT_VARIATION_WEB_EDIT_TEXT,
    	TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
    	TYPE_TEXT_VARIATION_WEB_PASSWORD
    }
    
    private int NumericType(String s) {
    	int nRet=0;
    	String Types[] = s.replace(" ",  "").toUpperCase().split(",");
    	if(Types != null && Types.length > 0)
    	{
    		for(String type : Types)
    		{
    			TypeEnum Cmd = TypeEnum.valueOf(type);
    			switch(Cmd) {
    			case TYPE_CLASS_DATETIME:
    				nRet += 4;
    				break;
    			case TYPE_CLASS_NUMBER:
    				nRet += 2;
    				break;
    			case TYPE_CLASS_PHONE:
    				nRet += 3;
    				break;
    			case TYPE_CLASS_TEXT:
    				nRet += 1;
    				break;
    			case TYPE_DATETIME_VARIATION_DATE:
    				nRet += 16;
    				break;
    			case TYPE_DATETIME_VARIATION_NORMAL:
    				nRet += 0;
    				break;
    			case TYPE_DATETIME_VARIATION_TIME:
    				nRet += 32;
    				break;
    			case TYPE_MASK_CLASS:
    				nRet += 15;
    				break;
    			case TYPE_MASK_FLAGS:
    				nRet += 16773120;
    				break;
    			case TYPE_MASK_VARIATION:
    				nRet += 4080;
    				break;
    			case TYPE_NULL:
    				nRet += 0;
    				break;
    			case TYPE_NUMBER_FLAG_DECIMAL:
    				nRet += 8192;
    				break;
    			case TYPE_NUMBER_FLAG_SIGNED:
    				nRet += 4096;
    				break;
    			case TYPE_NUMBER_VARIATION_NORMAL:
    				nRet += 0;
    				break;
    			case TYPE_NUMBER_VARIATION_PASSWORD:
    				nRet += 16;
    				break;
    			case TYPE_TEXT_FLAG_AUTO_COMPLETE:
    				nRet += 65536;
    				break;
    			case TYPE_TEXT_FLAG_AUTO_CORRECT:
    				nRet += 32768;
    				break;
    			case TYPE_TEXT_FLAG_CAP_CHARACTERS:
    				nRet += 4096;
    				break;
    			case TYPE_TEXT_FLAG_CAP_SENTENCES:
    				nRet += 16384;
    				break;
    			case TYPE_TEXT_FLAG_CAP_WORDS:
    				nRet += 8192;
    				break;
    			case TYPE_TEXT_FLAG_IME_MULTI_LINE:
    				nRet += 262144;
    				break;
    			case TYPE_TEXT_FLAG_MULTI_LINE:
    				nRet += 131072;
    				break;
    			case TYPE_TEXT_FLAG_NO_SUGGESTIONS:
    				nRet += 524288;
    				break;
    			case TYPE_TEXT_VARIATION_EMAIL_ADDRESS:
    				nRet += 32;
    				break;
    			case TYPE_TEXT_VARIATION_EMAIL_SUBJECT:
    				nRet += 48;
    				break;
    			case TYPE_TEXT_VARIATION_FILTER:
    				nRet += 176;
    				break;
    			case TYPE_TEXT_VARIATION_LONG_MESSAGE:
    				nRet += 80;
    				break;
    			case TYPE_TEXT_VARIATION_NORMAL:
    				nRet += 0;
    				break;
    			case TYPE_TEXT_VARIATION_PASSWORD:
    				nRet += 128;
    				break;
    			case TYPE_TEXT_VARIATION_PERSON_NAME:
    				nRet += 96;
    				break;
    			case TYPE_TEXT_VARIATION_PHONETIC:
    				nRet += 192;
    				break;
    			case TYPE_TEXT_VARIATION_POSTAL_ADDRESS:
    				nRet += 112;
    				break;
    			case TYPE_TEXT_VARIATION_SHORT_MESSAGE:
    				nRet += 64;
    				break;
    			case TYPE_TEXT_VARIATION_URI:
    				nRet += 16;
    				break;
    			case TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:
    				nRet += 114;
    				break;
    			case TYPE_TEXT_VARIATION_WEB_EDIT_TEXT:
    				nRet += 160;
    				break;
    			case TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS:
    				nRet += 208;
    				break;
    			case TYPE_TEXT_VARIATION_WEB_PASSWORD:
    				nRet += 224;
    				break;
    			}
    		}
    	}
    	return nRet;

    }
    
    private void SetIMEOptions(int value) {
    	switch(value) {
	    	case 0:
	    		IMEType = EditorInfo.IME_ACTION_UNSPECIFIED;
	    		break;
	    	case 1:
	    		IMEType = EditorInfo.IME_ACTION_GO;
	    		break;
	    	case 2:
	    		IMEType = EditorInfo.IME_ACTION_SEND;
	    		break;
	    	case 3:
	    		IMEType = EditorInfo.IME_ACTION_SEARCH;
	    		break;
	    	case 4:
	    		IMEType = EditorInfo.IME_ACTION_PREVIOUS;
	    		break;
	    	case 5:
	    		IMEType = EditorInfo.IME_ACTION_NONE;
	    		break;
    	}    	
    }
    
    private void SetKeyboardIME(CObject obj) {
        if(obj != null) {
        	Log.Log("Object Type: "+obj.hoType +" ");
        	if(obj.hoType >= 32) {
        		if (obj instanceof CExtension) {
					CRunExtension cExt = ((CExtension) obj).ext;
					if(cExt instanceof CRunExtension) {
						CRunViewExtension ViewExt = ((CRunViewExtension)cExt);
						if(ViewExt instanceof CRunkcedit) {
							CRunkcedit edit = ((CRunkcedit)ViewExt);
							edit.SetIMEOptions(IMEType);
							edit.SetKeyboard(keyBoardType);

						}
					}
        		}
        	}
        	
        }
    }
    
    private void FitEditSizeAndPosition(CObject obj, CRect rect) {
        if(obj != null) {
        	Log.Log("Object Type: "+obj.hoType +" ");
        	if(obj.hoType >= 32) {
        		if (obj instanceof CExtension) {
					CRunExtension cExt = ((CExtension) obj).ext;
					if(cExt instanceof CRunExtension) {
						CRunViewExtension ViewExt = ((CRunViewExtension)cExt);
						if(ViewExt instanceof CRunkcedit) {
							CRunkcedit edit = ((CRunkcedit)ViewExt);
							edit.ResizeToFit(rect, true);
							fitfontsize = edit.getFitFontSize();
						}
					}
        		}
        	}
        	
        }
    }
    
    private void SetEditHintColor(CObject obj, int color) {
        if(obj != null) {
        	Log.Log("Object Type: "+obj.hoType +" ");
        	if(obj.hoType >= 32) {
        		if (obj instanceof CExtension) {
					CRunExtension cExt = ((CExtension) obj).ext;
					if(cExt instanceof CRunExtension) {
						CRunViewExtension ViewExt = ((CRunViewExtension)cExt);
						if(ViewExt instanceof CRunkcedit) {
							CRunkcedit edit = ((CRunkcedit)ViewExt);
							edit.SetHintColor(color);
						}
					}
        		}
        	}
        	
        }
    }
    
    private void SetEditHintText(CObject obj, String s) {
        if(obj != null) {
        	Log.Log("Object Type: "+obj.hoType +" ");
        	if(obj.hoType >= 32) {
        		if (obj instanceof CExtension) {
					CRunExtension cExt = ((CExtension) obj).ext;
					if(cExt instanceof CRunExtension) {
						CRunViewExtension ViewExt = ((CRunViewExtension)cExt);
						if(ViewExt instanceof CRunkcedit) {
							CRunkcedit edit = ((CRunkcedit)ViewExt);
							edit.SetHintText(s);
						}
					}
        		}
        	}
        	
        }
    }

    private void getActiveRect(CObject obj, CRect rect) {
        if(obj != null) {
        	Log.Log("Object Type: "+obj.hoType +" ");
        	if(obj.hoType == 2) {
        		if (obj instanceof CObject) {
					CActive cObj = ((CActive) obj);
					if(cObj instanceof CActive) {
						rect.left  = cObj.hoX-cObj.hoImgXSpot;
						rect.top   = cObj.hoY-cObj.hoImgYSpot;
						rect.right = rect.left + cObj.hoImgWidth;
						rect.bottom= rect.top + cObj.hoImgHeight;
					}
        		}
        	}
        	
        }
    }

    
    /**
     * 
     * Expressions
     * 
     */
    
    
    private CValue expLastKBType()
    {
        return new CValue(type);
    }

    private CValue expLastKBSubType()
    {
        return new CValue(subtype);
    }
    
    private CValue expFitFontSize()
    {
         return new CValue(fitfontsize);
    }

}
