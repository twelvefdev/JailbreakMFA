﻿//----------------------------------------------------------------------------------
//
// CRUNMVTSPACESHIP : Movement spaceship!
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Movements;
using RuntimeXNA.Services;
using RuntimeXNA.Objects;
using RuntimeXNA.Animations;
using RuntimeXNA.Sprites;
using RuntimeXNA.Application;

namespace RuntimeXNA.Movements
{
    public class CRunMvtspaceship : CRunMvtExtension
    {
        int m_dwPower;
        int m_dwRotationSpeed;
        int m_dwInitialSpeed;
        int m_dwInitialDir;
        int m_dwDeceleration;
        int m_dwGravity;
        int m_dwGravityDir;
        int m_dwPlayer;
        int m_dwButton;
        int m_dwFlags;
        double m_X;
        double m_Y;
        double m_xVector;
        double m_yVector;
        double m_xGravity;
        double m_yGravity;
        double m_deceleration;
        double m_power;
        int m_button;
        int m_rotationSpeed;
        int m_rotCounter;
        int m_gravity;
        int m_gravityAngle;
        bool m_bStop;
        bool m_autoReactor;
        bool m_autoRotateRight;
        bool m_autoRotateLeft;

        public override void initialize(CFile file)
        {
            // Charge les données
            byte version = (byte)file.readAByte();
            m_dwPower = file.readAInt();
            m_dwRotationSpeed = file.readAInt();
            m_dwInitialSpeed = file.readAInt();
            m_dwInitialDir = file.readAInt();
            m_dwDeceleration = file.readAInt();
            m_dwGravity = file.readAInt();
            m_dwGravityDir = file.readAInt();
            m_dwPlayer = file.readAInt();
            m_dwButton = file.readAInt();
            m_dwFlags = file.readAInt();

            // Initialisations
            m_X = ho.hoX;
            m_Y = ho.hoY;

            // Finds the initial speed vectors
            ho.roc.rcSpeed = m_dwInitialSpeed;
            ho.roc.rcDir = dirAtStart(m_dwInitialDir);
            double ang = (ho.roc.rcDir * 2 * Math.PI) / 32.0;
            m_xVector = ho.roc.rcSpeed * Math.Cos(ang);
            m_yVector = -ho.roc.rcSpeed * Math.Sin(ang);

            // Calculates the vectors
            m_gravity = m_dwGravity;
            m_gravityAngle = dirAtStart(m_dwGravityDir);
            ang = (m_gravityAngle * 2 * Math.PI) / 32.0;
            m_xGravity = m_gravity * Math.Cos(ang);
            m_yGravity = -m_gravity * Math.Sin(ang);

            // Other values
            m_deceleration = m_dwDeceleration;
            m_rotationSpeed = m_dwRotationSpeed;
            m_power = m_dwPower;
            m_button = m_dwButton;
            m_bStop = false;
            ho.roc.rcPlayer = m_dwPlayer;
            m_rotCounter = 0;

            m_autoReactor = false;
            m_autoRotateRight = false;
            m_autoRotateLeft = false;
        }

        double getAngle(double vX, double vY)
        {
            double vector = Math.Sqrt(vX * vX + vY * vY);
            if (vector == 0.0)
            {
                return 0.0;
            }
            double angle = Math.Acos(vX / vector);
            if (vY > 0.0)
            {
                angle = 2.0 * Math.PI - angle;
            }
            return angle;
        }

        double getVector(double vX, double vY)
        {
            return Math.Sqrt(vX * vX + vY * vY);
        }

        public override bool move()
        {
            int anim = CAnim.ANIMID_WALK;

            if (m_bStop == false)
            {
                // Get the joystick
                byte j = rh.rhPlayer[ho.roc.rcPlayer];

                // Rotation of the ship
                if ((j & 15) != 0 || (m_autoRotateRight || m_autoRotateLeft))
                {
                    int rotSpeed = m_rotationSpeed;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        rotSpeed = (int)(((double)rotSpeed) * ho.hoAdRunHeader.rh4MvtTimerCoef);
                    }
                    m_rotCounter += rotSpeed;
                    if (m_rotCounter >= 100)
                    {
                        m_rotCounter -= 100;
                        if ((j & 0x04) != 0 || m_autoRotateLeft)
                        {
                            m_autoRotateLeft = false;
                            ho.roc.rcDir += 1;
                            if (ho.roc.rcDir >= 32)
                            {
                                ho.roc.rcDir -= 32;
                            }
                        }
                        if ((j & 0x08) != 0 || m_autoRotateRight)
                        {
                            m_autoRotateRight = false;
                            ho.roc.rcDir -= 1;
                            if (ho.roc.rcDir < 0)
                            {
                                ho.roc.rcDir += 32;
                            }
                        }
                    }
                }

                // Movement of the ship
                byte mask = 0x01;
                switch (m_button)
                {
                    case 0:
                        mask = 0x01;
                        break;
                    case 1:
                        mask = 0x10;
                        break;
                    case 2:
                        mask = 0x20;
                        break;
                }

                double calculs;
                if ((j & mask) != 0 || (m_autoReactor))
                {
                    double angle = (ho.roc.rcDir * 2 * Math.PI) / 32.0;

                    calculs = m_power;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }

                    double m_xPower = calculs * Math.Cos(angle);
                    double m_yPower = -calculs * Math.Sin(angle);

                    m_xVector += m_xPower / 150.0;
                    m_yVector += m_yPower / 150.0;

                    anim = CAnim.ANIMID_JUMP;

                    // switch off automatic reactor (as have applied it)
                    m_autoReactor = false;
                }

                // Gravity
                calculs = m_xGravity;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                m_xVector += calculs / 150.0;
                calculs = m_yGravity;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                m_yVector += m_yGravity / 150.0;

                // Deceleration
                double ang = getAngle(m_xVector, m_yVector);	// Get the angle and vector
                double vector = getVector(m_xVector, m_yVector);	// Get the angle and vector
                calculs = m_deceleration;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                vector -= calculs / 250.0;
                if (vector < 0.0)
                {
                    vector = 0.0;
                }
                m_xVector = vector * Math.Cos(ang);					// Restores X and Y speeds
                m_yVector = -vector * Math.Sin(ang);

                // Calculate the new position
                calculs = m_xVector;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                m_X = m_X + (calculs / 10.0);
                calculs = m_yVector;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                m_Y = m_Y + (calculs / 10.0);

                ho.roc.rcSpeed = (int)vector;
            }

            // Performs the animation
            if (ho.roc.rcSpeed > 100)
            {
                ho.roc.rcSpeed = 100;
            }
            animations(anim);

            // detects the collisions
            ho.hoX = (int)m_X;
            ho.hoY = (int)m_Y;
            collisions();

            return true;
        }

        double modf(double value)
        {
            int i = (int)value;
            return value - i;
        }

        public override void setPosition(int x, int y)
        {
            ho.hoX = x;
            ho.hoY = y;

            double frac;
            frac = modf(m_X);
            m_X = x + frac;
            frac = modf(m_Y);
            m_Y = y + frac;
        }

        public override void setXPosition(int x)
        {
            ho.hoX = (short)x;
            double frac;
            frac = modf(m_X);
            m_X = x + frac;
        }

        public override void setYPosition(int y)
        {
            ho.hoY = (short)y;
            double frac;
            frac = modf(m_Y);
            m_Y = y + frac;
        }

        public override void stop(bool bCurrent)
        {
            m_bStop = true;
        }

        public override void bounce(bool bCurrent)
        {
            if (bCurrent)
            {
                CPoint pt = new CPoint();
                approachObject(ho.hoX, ho.hoY, ho.roc.rcOldX, ho.roc.rcOldY, 0, CColMask.CM_TEST_PLATFORM, pt);
                ho.hoX = pt.x;
                ho.hoY = pt.y;
                m_X = pt.x;
                m_Y = pt.y;
            }
            m_xVector = -m_xVector;
            m_yVector = -m_yVector;
        }

        public override void reverse()
        {
            m_xVector = -m_xVector;
            m_yVector = -m_yVector;
        }

        public override void start()
        {
            m_bStop = false;
        }

        public override void setSpeed(int speed)
        {
            if (speed < 0)
            {
                speed = 0;
            }
            if (speed > 100)
            {
                speed = 100;
            }

            double ang = (ho.roc.rcDir * 2 * Math.PI) / 32.0;
            ho.roc.rcSpeed = speed;
            m_xVector = speed * Math.Cos(ang);
            m_yVector = -speed * Math.Sin(ang);
        }

        public override void setDir(int dir)
        {
            double ang = getAngle(m_xVector, m_yVector);	// Get the angle and vector
            double vector = getVector(m_xVector, m_yVector);
            ang = (dir * 2 * Math.PI) / 32.0;
            ho.roc.rcDir = dir;
            m_xVector = vector * Math.Cos(ang);					// Restores X and Y speeds
            m_yVector = -vector * Math.Sin(ang);
        }

        public override void setDec(int dec)
        {
            if (dec < 0)
            {
                dec = 0;
            }
            if (dec > 100)
            {
                dec = 100;
            }
            m_deceleration = dec;
        }

        public override void setRotSpeed(int speed)
        {
            if (speed < 0)
            {
                speed = 0;
            }
            if (speed > 100)
            {
                speed = 100;
            }
            m_rotationSpeed = speed;
        }

        public override void setGravity(int gravity)
        {
            if (gravity < 0)
            {
                gravity = 0;
            }
            if (gravity > 100)
            {
                gravity = 100;
            }

            m_gravity = gravity;
            double ang = (m_gravityAngle * 2 * Math.PI) / 32.0;
            m_xGravity = m_gravity * Math.Cos(ang);
            m_yGravity = -m_gravity * Math.Sin(ang);
        }

        public override double actionEntry(int action)
        {
            int param;
            switch (action)
            {
                case 0:		// SPACE_SETPOWER:
                    param = (int)getParamDouble();
                    if (param < 0)
                    {
                        param = 10;
                    }
                    if (param > 100)
                    {
                        param = 100;
                    }
                    m_power = param;
                    break;
                case 1:		// SPACE_SETSPEED:
                    param = (int)getParamDouble();
                    setSpeed(param);
                    break;
                case 2:		// SPACE_SETDIR:
                    param = (int)getParamDouble();
                    setDir(param);
                    break;
                case 3:		// SPACE_SETDEC:
                    param = (int)getParamDouble();
                    setDec(param);
                    break;
                case 4:		// SPACE_SETROTSPEED:
                    param = (int)getParamDouble();
                    setRotSpeed(param);
                    break;
                case 5:		// SPACE_SETGRAVITY:
                    param = (int)getParamDouble();
                    setGravity(param);
                    break;
                case 6:		// SPACE_SETGRAVITYDIR:
                    param = (int)getParamDouble();
                    double angle2 = (param * 2 * Math.PI) / 32.0;
                    m_xGravity = m_gravity * Math.Cos(angle2);
                    m_yGravity = -m_gravity * Math.Sin(angle2);
                    break;
                case 7:		// SPACE_APPLYREACTOR:
                    m_autoReactor = true;
                    break;
                case 10:		// SPACE_APPLYROTATERIGHT:
                    m_autoRotateRight = true;
                    break;
                case 11:		// SPACE_APPLYROTATELEFT:
                    m_autoRotateLeft = true;
                    break;
                case 12:		// SPACE_GETGRAVITY:
                    return (int)m_gravity;
                case 13:		// SPACE_GETGRAVITYDIR:
                    return (int)m_gravityAngle;
                case 14:		// SPACE_GETDECELERATION:
                    return (int)m_deceleration;
                case 15:		// PACE_GETROTATIONSPEED:
                    return (int)m_rotationSpeed;
                case 16:		// SPACE_GETTHRUSTPOWER:
                    return (int)m_power;
            }
            return 0;
        }

        public override int getSpeed()
        {
            return ho.roc.rcSpeed;
        }

        public override int getAcceleration()
        {
            return (int)m_power;
        }

        public override int getDeceleration()
        {
            return (int)m_deceleration;
        }

        public override int getGravity()
        {
            return (int)m_gravity;
        }



    }
}
