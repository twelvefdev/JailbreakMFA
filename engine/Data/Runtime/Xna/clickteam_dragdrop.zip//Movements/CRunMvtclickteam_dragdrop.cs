﻿//----------------------------------------------------------------------------------
//
// CRUNMVTCLICKTEAM-DRAGDROP
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;
using RuntimeXNA.Movements;
using RuntimeXNA.Services;
using RuntimeXNA.Objects;
using RuntimeXNA.Animations;
using RuntimeXNA.Sprites;
using RuntimeXNA.Application;
using RuntimeXNA.OI;

namespace RuntimeXNA.Movements
{
    class CRunMvtclickteam_dragdrop : CRunMvtExtension
    {
	    const int FLAG_LIMITAREA = 1;
	    const int FLAG_SNAPTO = 2;
	    const int FLAG_DROPWHENLEAVE = 4;
	    const int FLAG_FORCELIMITS = 8;

        const int SET_DragDrop_Method = 4145;
        const int SET_DragDrop_IsLimited=4146;
        const int SET_DragDrop_DropOutsideArea=4147;
        const int SET_DragDrop_ForceWithinLimits=4148;
        const int SET_DragDrop_AreaX=4149;
        const int SET_DragDrop_AreaY=4150;
        const int SET_DragDrop_AreaW=4151;
        const int SET_DragDrop_AreaH=4152;
        const int SET_DragDrop_SnapToGrid=4153;
        const int SET_DragDrop_GridX=4154;
        const int SET_DragDrop_GridY=4155;
        const int SET_DragDrop_GridW=4156;
        const int SET_DragDrop_GridH=4157;
        const int GET_DragDrop_AreaX=4158;
        const int GET_DragDrop_AreaY=4159;
        const int GET_DragDrop_AreaW=4160;
        const int GET_DragDrop_AreaH=4161;
        const int GET_DragDrop_GridX=4162;
        const int GET_DragDrop_GridY=4163;
        const int GET_DragDrop_GridW=4164;
        const int GET_DragDrop_GridH=4165;

        // Données edittime
	    public int ed_dragWithSelected;
	    public int ed_limitX;
	    public int ed_limitY;
	    public int ed_limitWidth;
	    public int ed_limitHeight;
	    public int ed_gridOriginX;
	    public int ed_gridOriginY;
	    public int ed_gridDx;
	    public int ed_gridDy;
	    public int ed_flags;

        // Donnéez runtime
	    public int dragWith;

	    public int lastMouseX;
	    public int lastMouseY;
	    public bool keyDown=false;
	    public bool drag=false;

	    // Variables for limited area dragging
	    public bool snapToGrid=false;
	    public bool limitedArea=false;
	    public bool dropWhenLeaveArea=false;
	    public bool forceWithinLimits=false;
	    public int minX;
	    public int minY;
	    public int maxX;
	    public int maxY;

	    public int gridOriginX;
	    public int gridOriginY;
	    public int gridSizeX;
	    public int gridSizeY;
	    public int x;
	    public int y;

	    public int lastX;
	    public int lastY;

        public bool bLeftLast=false;
        public bool bRightLast=false;
        public int clickLoop = 0;
        public bool clickLeft=false;
        public bool clickRight=false;

        public override void initialize(CFile file)
        {
            file.skipBytes(1);

            //Flags
            ed_flags = file.readAInt();
            ed_dragWithSelected = file.readAInt();
            ed_limitX = file.readAInt();
            ed_limitY = file.readAInt();
            ed_limitWidth = file.readAInt();
            ed_limitHeight = file.readAInt();
            ed_gridOriginX = file.readAInt();
            ed_gridOriginY = file.readAInt();
            ed_gridDx = file.readAInt();
            ed_gridDy = file.readAInt();

            //*** General variables
            dragWith = ed_dragWithSelected;
            drag = false;
            keyDown = false;
            snapToGrid = ((ed_flags & FLAG_SNAPTO) != 0);
            limitedArea = ((ed_flags & FLAG_LIMITAREA) != 0);
            dropWhenLeaveArea = ((ed_flags & FLAG_DROPWHENLEAVE) != 0);
            forceWithinLimits = ((ed_flags & FLAG_FORCELIMITS) != 0);

            // Limit area settings
            minX = ed_limitX;
            minY = ed_limitY;
            maxX = minX + ed_limitWidth;
            maxY = minY + ed_limitHeight;

            // Grid settings
            gridOriginX = ed_gridOriginX;
            gridOriginY = ed_gridOriginY;
            gridSizeX = ed_gridDx;
            gridSizeY = ed_gridDy;

            lastX = ho.hoX;
            lastY = ho.hoY;
        }

        public void handleMouseKeys()
        {
            bool bLeft = (ho.hoAdRunHeader.rh2MouseKeys&0x01)!=0;
            bool bRight = (ho.hoAdRunHeader.rh2MouseKeys&0x02)!=0;
            if (bLeft != bLeftLast)
            {
                bLeftLast = bLeft;
                if (bLeft)
                {
                    if (clickLoop != ho.hoAdRunHeader.rhLoopCount + 1)
                        clickRight = false;
                    clickLoop = ho.hoAdRunHeader.rhLoopCount + 1;
                    clickLeft = true;
                }
            }
            if (bRight != bRightLast)
            {
                bRightLast = bRight;
                if (bRight)
                {
                    if (clickLoop != ho.hoAdRunHeader.rhLoopCount + 1)
                        clickLeft = false;
                    clickLoop = ho.hoAdRunHeader.rhLoopCount + 1;
                    clickRight = true;
                }
            }
        }

        public bool isTopMostAOAtXY_Transparent(int x, int y)
        {
            CObject pRo = null;
            CSprite pSpr = null;

            do
            {
                // Get the next sprite at x,y
                pSpr = ho.hoAdRunHeader.rhApp.spriteGen.spriteCol_TestPoint(pSpr, (short)-1, x-ho.hoAdRunHeader.rhWindowX, y-ho.hoAdRunHeader.rhWindowY, CSpriteGen.SCF_EVENNOCOL);

                if (pSpr == null)
                    break;

                // Object not being destroyed?
                if ((pSpr.sprFlags & CSprite.SF_TOKILL) == 0)
                {
                    // Get object pointer
                    CObject pHo = pSpr.sprExtraInfo;

                    // Active object ?
                    if (pHo != null && pHo.hoType == COI.OBJ_SPR)
                        pRo = pHo;

                }
            } while (pSpr != null);
            if (pRo == ho)
            {
                return true;
            }
            // Explore les autres objets
            // ~~~~~~~~~~~~~~~~~~~~~~~~~
            int count = 0;
            int i;
            CObject pHox;
            int x1, y1, x2, y2;

            for (i = 0; i < ho.hoAdRunHeader.rhNObjects; i++)
            {
                while (ho.hoAdRunHeader.rhObjectList[count] == null)
                    count++;
                pHox = ho.hoAdRunHeader.rhObjectList[count];
                count++;

                x1 = pHox.hoX - pHox.hoImgXSpot;
                y1 = pHox.hoY - pHox.hoImgYSpot;
                x2 = x1 + pHox.hoImgWidth;
                y2 = y1 + pHox.hoImgHeight;
                if (x >= x1 && x < x2 && y >= y1 && y < y2)
                {
                    if ((pHox.hoFlags & CObject.HOF_DESTROYED) == 0)
                    {
                        if (pHox.hoType != COI.OBJ_SPR)
                        {
                            pRo = pHox;
                        }
                    }
                }
            }

            if (pRo == ho)
            {
                return true;
            }
            return false;
        }
        public override bool move()
        {
            handleMouseKeys();
            handleDragAndDrop();

            // Handle the objects movement, if it needs to be moved.
            if (drag)
            {
                int dX = ho.hoAdRunHeader.rh2MouseX - lastMouseX;
                int dY = ho.hoAdRunHeader.rh2MouseY - lastMouseY;

                lastMouseX = ho.hoAdRunHeader.rh2MouseX;
                lastMouseY = ho.hoAdRunHeader.rh2MouseY;

                animations(CAnim.ANIMID_WALK);
                x += dX;
                y += dY;
                ho.hoX = x;
                ho.hoY = y;

                if (snapToGrid)
                {
                    int topX = ((ho.hoX - ho.hoImgXSpot) - gridOriginX) % gridSizeX;
                    int topY = ((ho.hoY - ho.hoImgYSpot) - gridOriginY) % gridSizeY;

                    ho.hoX -= topX;
                    ho.hoY -= topY;
                }

                checkLimitedArea();
                collisions();

                return true;
            }
            else
            {
                bool hasChanged = false;
                if (forceWithinLimits)
                {
                    int oldX = ho.hoX;
                    int oldY = ho.hoY;
                    checkLimitedArea();
                    if ((oldX != ho.hoX) || (oldY != ho.hoY))
                        hasChanged = true;
                }
                animations(CAnim.ANIMID_STOP);
                collisions();
                return hasChanged;
            }
        }

        public void handleDragAndDrop()
        {
            if (!drag)
            {
                // Check if dragging of object has started
                if (dragWith == 0)
                {
                    // Left mouse button is down
                    if ((ho.hoAdRunHeader.rh2MouseKeys&0x01)!=0)
                    {
                        if (keyDown == false)
                        {
                            keyDown = true;

                            if (isTopMostAOAtXY_Transparent(ho.hoAdRunHeader.rh2MouseX - ho.hoAdRunHeader.rhWindowX, ho.hoAdRunHeader.rh2MouseY - ho.hoAdRunHeader.rhWindowY))
                            {
                                startDragging();
                            }
                        }
                    }
                    else
                    {
                        keyDown = false;
                    }
                }
                else if (dragWith == 1)
                {
                    // Right mouse button is down
                    if ((ho.hoAdRunHeader.rh2MouseKeys&0x01)!=0)
                    {
                        if (keyDown == false)
                        {
                            keyDown = true;

                            if (isTopMostAOAtXY_Transparent(ho.hoAdRunHeader.rh2MouseX - ho.hoAdRunHeader.rhWindowX, ho.hoAdRunHeader.rh2MouseY - ho.hoAdRunHeader.rhWindowY))
                            {
                                startDragging();
                            }
                        }
                    }
                    else
                    {
                        keyDown = false;
                    }
                }
                else if (dragWith == 2)
                {
                    // Left mouse button clicked or currently down
                    if ((ho.hoAdRunHeader.rh2MouseKeys&0x01)!=0)
                    {
                        if (keyDown == false)
                        {
                            keyDown = true;
                        }
                    }
                    else
                    {
                        if (keyDown == true)
                        {
                            if (isTopMostAOAtXY_Transparent(ho.hoAdRunHeader.rh2MouseX - ho.hoAdRunHeader.rhWindowX, ho.hoAdRunHeader.rh2MouseY - ho.hoAdRunHeader.rhWindowY))
                            {
                                startDragging();
                            }
                        }

                        keyDown = false;
                    }
                }

                else if (dragWith == 3)
                {
                    // Right mouse button clicked or currently down
                    if (((clickLoop == ho.hoAdRunHeader.rhLoopCount) && clickRight) || (ho.hoAdRunHeader.rh2MouseKeys&0x02)!=0)
                    {
                        if (keyDown == false)
                        {
                            keyDown = true;
                        }
                    }
                    else
                    {
                        if (keyDown == true)
                        {
                            if (isTopMostAOAtXY_Transparent(ho.hoAdRunHeader.rh2MouseX - ho.hoAdRunHeader.rhWindowX, ho.hoAdRunHeader.rh2MouseY - ho.hoAdRunHeader.rhWindowY))
                            {
                                startDragging();
                            }
                        }

                        keyDown = false;
                    }
                }
            }
            else
            {
                // Check if dragging of object has ended.
                if (dragWith == 0)
                {
                    // Left mouse button released
                    if ((ho.hoAdRunHeader.rh2MouseKeys&0x01)==0)
                    {
                        stop(true);
                    }
                }
                else if (dragWith == 1)
                {
                    // Right mouse button released
                    if ((ho.hoAdRunHeader.rh2MouseKeys&0x02)==0)
                    {
                        stop(true);
                    }
                }
                else if (dragWith == 2)
                {
                    // Left mouse button clicked or currently down
                    if (((clickLoop == ho.hoAdRunHeader.rhLoopCount) && clickLeft) || (ho.hoAdRunHeader.rh2MouseKeys&0x01)!=0)
                    {
                        keyDown = true;
                    }
                    else
                    {
                        if (keyDown)
                        {
                            stop(true);
                        }
                    }
                }
                else if (dragWith == 3)
                {
                    // Right mouse button clicked or currently down
                    if (((clickLoop == ho.hoAdRunHeader.rhLoopCount) && clickRight) || (ho.hoAdRunHeader.rh2MouseKeys&0x02)!=0)
                    {
                        keyDown = true;
                    }
                    else
                    {
                        if (keyDown)
                        {
                            stop(true);
                        }
                    }
                }
            }
        }

        public void startDragging()
        {
            lastMouseX = ho.hoAdRunHeader.rh2MouseX;
            lastMouseY = ho.hoAdRunHeader.rh2MouseY;

            lastX = ho.hoX;
            lastY = ho.hoY;

            x = ho.hoX;
            y = ho.hoY;

            drag = true;

            ho.roc.rcSpeed = 50;
        }

        public void checkLimitedArea()
        {
            if (limitedArea)
            {
                // Check x-coordinates
                if (ho.hoX < minX)
                {
                    ho.hoX = minX;
                    if (dropWhenLeaveArea) drag = false;
                }
                else if (ho.hoX > maxX)
                {
                    ho.hoX = maxX;
                    if (dropWhenLeaveArea) drag = false;
                }

                // Check y-coordinates
                if (ho.hoY < minY)
                {
                    ho.hoY = minY;
                    if (dropWhenLeaveArea) drag = false;
                }
                else if (ho.hoY > maxY)
                {
                    ho.hoY = maxY;
                    if (dropWhenLeaveArea) drag = false;
                }
            }
        }

        public override void setPosition(int x, int y)
        {
            ho.hoX = x;
            ho.hoY = y;
        }

        public override void setXPosition(int x)
        {
            ho.hoX = x;
        }

        public override void setYPosition(int y)
        {
            ho.hoY = y;
        }

        public override void stop(bool bCurrent)
        {
            drag = false;
            keyDown = false;

            ho.roc.rcSpeed = 0;
        }

        public override void start()
        {
            startDragging();
        }

        public override void bounce(bool bCurrent)
        {
            if (drag)
            {
                setPosition(lastX, lastY);
                stop(true);
            }
        }


        //****************************************
        //*** Extension Actions entry ************
        //****************************************
        public override double actionEntry(int action)
        {
            int param;
            switch (action)
            {
                case SET_DragDrop_Method:
                    {
                        param = (int)getParamDouble();
                        // Methods 0-4 supported
                        if ((param >= 0) && (param < 5))
                        {
                            dragWith = param;
                        }
                    }
                    break;

                case SET_DragDrop_IsLimited:
                    {
                        param = (int)getParamDouble();
                        limitedArea = param != 0;
                    }
                    break;

                case SET_DragDrop_DropOutsideArea:
                    {
                        param = (int)getParamDouble();
                        dropWhenLeaveArea = param != 0;
                    }
                    break;

                case SET_DragDrop_ForceWithinLimits:
                    {
                        param = (int)getParamDouble();
                        forceWithinLimits = param != 0;
                    }
                    break;

                case SET_DragDrop_AreaX:
                    {
                        param = (int)getParamDouble();
                        minX = param;
                    }
                    break;

                case SET_DragDrop_AreaY:
                    {
                        param = (int)getParamDouble();
                        minY = param;
                    }
                    break;

                case SET_DragDrop_AreaW:
                    {
                        param = (int)getParamDouble();
                        maxX = minX + param;
                    }
                    break;

                case SET_DragDrop_AreaH:
                    {
                        param = (int)getParamDouble();
                        maxY = minY + param;
                    }
                    break;

                case SET_DragDrop_SnapToGrid:
                    {
                        param = (int)getParamDouble();
                        snapToGrid = param != 0;
                    }
                    break;

                case SET_DragDrop_GridX:
                    {
                        param = (int)getParamDouble();
                        gridOriginX = param;
                    }
                    break;

                case SET_DragDrop_GridY:
                    {
                        param = (int)getParamDouble();
                        gridOriginY = param;
                    }
                    break;

                case SET_DragDrop_GridW:
                    {
                        param = (int)getParamDouble();
                        gridSizeX = param;
                    }
                    break;

                case SET_DragDrop_GridH:
                    {
                        param = (int)getParamDouble();
                        gridSizeY = param;
                    }
                    break;

                case GET_DragDrop_AreaX:
                    {
                        return minX;
                    }

                case GET_DragDrop_AreaY:
                    {
                        return minY;
                    }

                case GET_DragDrop_AreaW:
                    {
                        return maxX - minX;
                    }

                case GET_DragDrop_AreaH:
                    {
                        return maxY - minY;
                    }

                case GET_DragDrop_GridX:
                    {
                        return gridOriginX;
                    }

                case GET_DragDrop_GridY:
                    {
                        return gridOriginY;
                    }

                case GET_DragDrop_GridW:
                    {
                        return gridSizeX;
                    }

                case GET_DragDrop_GridH:
                    {
                        return gridSizeY;
                    }
            }
            return 0;
        }

        public override int getSpeed()
        {
            return ho.roc.rcSpeed;
        }

        public override int getAcceleration()
        {
            return 100;
        }

        public override int getDeceleration()
        {
            return 100;
        }

    }
}
