﻿//----------------------------------------------------------------------------------
//
// CRUNMVTCIRCULAR : Movement circular!
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Movements;
using RuntimeXNA.Services;
using RuntimeXNA.Objects;
using RuntimeXNA.Animations;
using RuntimeXNA.Sprites;
using RuntimeXNA.Application;

namespace RuntimeXNA.Movements
{
    class CRunMvtclickteam_circular : CRunMvtExtension
    {
        const int MFLAG1_MOVEATSTART = 1;
        const int ONEND_STOP = 0;
        const int ONEND_RESET = 1;
        const int ONEND_REVERSE_VEL = 2;
        const int ONEND_REVERSE_DIR = 3;
        int m_dwCX;
        int m_dwCY;
        int m_dwStartAngle;
        int m_dwRadius;
        int m_dwRmin;
        int m_dwRmax;
        int m_dwFlags;
        int m_dwOnEnd;
        int m_dwSpiVel;
        int m_dwAngVel;
        bool r_Stopped;
        int r_OnEnd;
        int r_CX;
        int r_CY;
        int r_Rmin;
        int r_Rmax;
        double r_AngVel;
        double r_SpiVel;
        double r_CurrentRadius;
        double r_CurrentAngle;

        public override void initialize(CFile file)
        {
            file.skipBytes(1);
            m_dwCX = file.readAInt();
            m_dwCY = file.readAInt();
            m_dwRadius = file.readAInt();
            m_dwStartAngle = file.readAInt();
            m_dwRmin = file.readAInt();
            m_dwRmax = file.readAInt();
            m_dwFlags = file.readAInt();
            m_dwOnEnd = file.readAInt();
            m_dwAngVel = file.readAInt();
            m_dwSpiVel = file.readAInt();

            //*** General variables
            //	r_Stopped = (bool)( 1 - m_pMvt->m_dwFlags);
            r_Stopped = ((m_dwFlags & MFLAG1_MOVEATSTART) == 0);
            r_OnEnd = m_dwOnEnd;

            r_CX = m_dwCX;
            r_CY = m_dwCY;
            r_Rmin = m_dwRmin;
            r_Rmax = m_dwRmax;
            r_AngVel = m_dwAngVel / 50.0 * (Math.PI / 180.0);
            r_SpiVel = m_dwSpiVel / 50.0;
            r_CurrentAngle = m_dwStartAngle * (Math.PI / 180.0);
            r_CurrentRadius = m_dwRadius;
            ho.roc.rcSpeed = (int)m_dwAngVel;
        }

        public override bool move()
        {
            double calculs;

            //*** Object needs to be moved?
            if (!r_Stopped)
            {
                animations(CAnim.ANIMID_WALK);
                ho.hoX = (int)(r_CX + r_CurrentRadius * Math.Cos(r_CurrentAngle));
                ho.hoY = (int)(r_CY - r_CurrentRadius * Math.Sin(r_CurrentAngle));
                collisions();

                calculs = r_AngVel;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                r_CurrentAngle += calculs;

                if (r_CurrentAngle < 0)
                {
                    r_CurrentAngle += 2 * Math.PI;
                }
                else if (r_CurrentAngle > 2 * Math.PI)
                {
                    r_CurrentAngle -= 2 * Math.PI;
                }

                if (Math.Abs(r_SpiVel) > 0.00001)
                {
                    calculs = r_SpiVel;
                    if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                    {
                        calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                    }
                    r_CurrentRadius += calculs;

                    if (r_CurrentRadius < r_Rmin || r_CurrentRadius > r_Rmax)
                    {
                        if (r_OnEnd == ONEND_STOP)
                        {
                            r_Stopped = true;
                        }
                        else if (r_OnEnd == ONEND_REVERSE_VEL)
                        {
                            r_SpiVel *= -1;
                        }
                        else if (r_OnEnd == ONEND_REVERSE_DIR)
                        {
                            r_AngVel *= -1;
                            r_SpiVel *= -1;
                        }
                        else if (r_OnEnd == ONEND_RESET)
                        {
                            reset();
                        }
                    }
                }
                //*** Indicate the object has been moved
                return true;
            }
            animations(CAnim.ANIMID_STOP);
            collisions();

            return ho.roc.rcChanged;
        }

        void reset()
        {
            r_CX = m_dwCX;
            r_CY = m_dwCY;
            r_Rmin = m_dwRmin;
            r_Rmax = m_dwRmax;
            r_AngVel = m_dwAngVel / 50.0 * (Math.PI / 180.0);
            r_SpiVel = m_dwSpiVel / 50.0;
            r_CurrentAngle = m_dwStartAngle * (Math.PI / 180.0);
            r_CurrentRadius = m_dwRadius;
        }

        public override void setPosition(int x, int y)
        {
            r_CX -= ho.hoX - x;
            r_CY -= ho.hoY - y;

            ho.hoX = x;
            ho.hoY = y;
        }

        public override void setXPosition(int x)
        {
            r_CX -= ho.hoX - x;
            ho.hoX = x;
        }

        public override void setYPosition(int y)
        {
            r_CY -= ho.hoY - y;
            ho.hoY = y;
        }

        public override void stop(bool bCurrent)
        {
            r_Stopped = true;
        }

        public override void reverse()
        {
            r_AngVel *= -1;
        }

        public override void start()
        {
            r_Stopped = false;
        }

        public override void setSpeed(int speed)
        {
            //*** Linear motion components;
            r_AngVel = (speed) / 50.0 * (Math.PI / 180.0);
            ho.roc.rcSpeed = speed;
        }

        public override double actionEntry(int action)
        {
            int param;
            switch (action)
            {
                case 3345:		// SET_CENTRE_X = 3345,
                    param = (int)getParamDouble();
                    r_CX = param;
                    return 0;
                case 3346:		// SET_CENTRE_Y,
                    param = (int)getParamDouble();
                    r_CY = param;
                    return 0;
                case 3347:		// SET_ANGSPEED,
                    param = (int)getParamDouble();
                    r_AngVel = param / 50.0 * (Math.PI / 180.0);
                    ho.roc.rcSpeed = param;
                    return 0;
                case 3348:		// SET_CURRENTANGLE,
                    param = (int)getParamDouble();
                    r_CurrentAngle = param * (Math.PI / 180.0);
                    return 0;
                case 3349:		// SET_RADIUS,
                    param = (int)getParamDouble();
                    r_CurrentRadius = Math.Max(param, 0);
                    return 0;
                case 3350:		// SET_SPIRALVEL,
                    param = (int)getParamDouble();
                    r_SpiVel = param / 50.0;
                    return 0;
                case 3351:		// SET_MINRADIUS,
                    param = (int)getParamDouble();
                    r_Rmin = Math.Max(param, 0);
                    return 0;
                case 3352:		// SET_MAXRADIUS,
                    param = (int)getParamDouble();
                    r_Rmax = Math.Max(param, 0);
                    return 0;
                case 3353:		// SET_ONCOMPLETION,
                    param = (int)getParamDouble();
                    int onEnd = param;
                    if (onEnd >= ONEND_STOP && onEnd <= ONEND_REVERSE_DIR)
                    {
                        r_OnEnd = onEnd;
                    }
                    return 0;
                case 3354:		// GET_CENTRE_X,
                    return r_CX;
                case 3355:		// GET_CENTRE_Y,
                    return r_CY;
                case 3356:		// GET_ANGSPEED,
                    return r_AngVel * 50.0 * (180.0 / Math.PI);
                case 3357:		// GET_CURRENTANGLE,
                    return r_CurrentAngle * (180 / Math.PI);
                case 3358:		// GET_RADIUS,
                    return r_CurrentRadius;
                case 3359:		// GET_SPIRALVEL,
                    return r_SpiVel * 50;
                case 3360:		// GET_MINRADIUS,
                    return r_Rmin;
                case 3361:		// GET_MAXRADIUS
                    return r_Rmax;
            }
            return 0;
        }

        public override int getSpeed()
        {
            return ho.roc.rcSpeed;
        }
    }
}
