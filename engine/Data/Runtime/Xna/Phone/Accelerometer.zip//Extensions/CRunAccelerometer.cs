//----------------------------------------------------------------------------------
//
// CRUNACCELEROMETER iPhone accelerometers
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunAccelerometer : CRunExtension
    {
        const int EXP_XDIRECT=0;
        const int EXP_YDIRECT=1;
        const int EXP_ZDIRECT=2;
        const int EXP_XGRAVITY=3;
        const int EXP_YGRAVITY=4;
        const int EXP_ZGRAVITY=5;
        const int EXP_XINSTANT=6;
        const int EXP_YINSTANT=7;
        const int EXP_ZINSTANT=8;
        const int EXP_ORIENTATION=9;
        const int CND_ORIENTATIONCHANGED = 0;

        int orientationCount;
        DisplayOrientation orientation;
        DisplayOrientation oldOrientation;

        public override int getNumberOfConditions()
        {
            return 1;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            orientationCount = -1;
            orientation=CRunApp.orientation;
            oldOrientation = orientation;
            ho.hoAdRunHeader.rhApp.startAccelerometer();
            return true;
        }
        public override void destroyRunObject(bool bFast)
        {
            ho.hoAdRunHeader.rhApp.stopAccelerometer();
        }

        public override int handleRunObject()
        {
            orientation = CRunApp.orientation;
            if (orientation!=oldOrientation)
            {
                oldOrientation=orientation;
                orientationCount=ho.getEventCount();
                ho.pushEvent(CND_ORIENTATIONCHANGED, 0);
            }
            return 0;
        }

        public override bool condition(int num, CCndExtension cnd)
        {
	        if (num==CND_ORIENTATIONCHANGED)
	        {
		        return orientationChanged();
	        }
	        return false;
        }

        bool orientationChanged()
        {
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
		        return true;
	        }
	        if (ho.getEventCount() == orientationCount)
	        {
		        return true;
	        }
	        return false;
        }

        public override CValue expression(int num)
        {
	        double ret=0.0;

            switch (num)
            {
                case EXP_XDIRECT:
                    ret = CRunApp.accX;
                    break;
                case EXP_YDIRECT:
                    ret = CRunApp.accY;
                    break;
                case EXP_ZDIRECT:
                    ret = CRunApp.accZ;
                    break;
                case EXP_XGRAVITY:
                    ret = CRunApp.filteredAccX;
                    break;
                case EXP_YGRAVITY:
                    ret = CRunApp.filteredAccY;
                    break;
                case EXP_ZGRAVITY:
                    ret = CRunApp.filteredAccZ;
                    break;
                case EXP_XINSTANT:
                    ret = CRunApp.instantAccX;
                    break;
                case EXP_YINSTANT:
                    ret = CRunApp.instantAccY;
                    break;
                case EXP_ZINSTANT:
                    ret = CRunApp.instantAccZ;
                    break;
                case EXP_ORIENTATION:
                    {
                        return new CValue((int)orientation);
                    }
            }
            return new CValue((double)ret);
        }
    }
}
