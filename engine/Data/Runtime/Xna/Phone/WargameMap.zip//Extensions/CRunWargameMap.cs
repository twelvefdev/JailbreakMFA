﻿//----------------------------------------------------------------------------------
//
// CRunWargameMap: Wargame Map object
// fin 29/01/09
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunWargameMap : CRunExtension
    {
        const byte SETS_OPEN_SET = 1;
        const byte SETS_CLOSED_SET = 2;
        const byte INF_TILE_COST = 99;

        const int CND_COMPARETILECOST = 0;
        const int CND_TILEIMPASSABLE = 1;
        const int CND_PATHEXISTS = 2;
        const int CND_COMPAREPATHCOST = 3;
        const int CND_COMPAREPATHLENGTH = 4;
        const int CND_COMPARECOSTTOPOINT = 5;
        const int CND_COMPAREPOINTDIRECTION = 6;
        const int CND_COMPARECOSTTOCURRENT = 7;
        const int CND_COMPARECURRENTDIRECTION = 8;
        const int CND_ENDOFPATH = 9;
        const int ACT_SETWIDTH = 0;
        const int ACT_SETHEIGHT = 1;
        const int ACT_SETCOST = 2;
        const int ACT_CALCULATEPATH = 3;
        const int ACT_NEXTPOINT = 4;
        const int ACT_PREVPOINT = 5;
        const int ACT_RESETPOINT = 6;
        const int ACT_CALCULATELOS = 7;
        const int EXP_GETWIDTH = 0;
        const int EXP_GETHEIGHT = 1;
        const int EXP_GETTILECOST = 2;
        const int EXP_GETPATHCOST = 3;
        const int EXP_GETPATHLENGTH = 4;
        const int EXP_GETCOSTTOPOINT = 5;
        const int EXP_GETPOINTDIRECTION = 6;
        const int EXP_GETPOINTX = 7;
        const int EXP_GETPOINTY = 8;
        const int EXP_GETSTARTX = 9;
        const int EXP_GETSTARTY = 10;
        const int EXP_GETDESTX = 11;
        const int EXP_GETDESTY = 12;
        const int EXP_GETCURRENTINDEX = 13;
        const int EXP_GETCOSTTOCURRENT = 14;
        const int EXP_GETCURRENTDIRECTION = 15;
        const int EXP_GETCURRENTX = 16;
        const int EXP_GETCURRENTY = 17;
        const int EXP_GETCOSTATPOINT = 18;
        const int EXP_GETCOSTATCURRENT = 19;

        int mapWidth, mapHeight;
        bool oddColumnsHigh;
        byte[] map;
        CArrayList path; //WargameMapPathPoint
        int iterator;
        int startX=0, startY=0, destX=0, destY=0;

        public override int getNumberOfConditions()
        {
            return 10;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            file.setUnicode(false);
            ho.hoX = cob.cobX;
            ho.hoY = cob.cobY;
            ho.hoImgWidth = 32;
            ho.hoImgHeight = 32;
            this.mapWidth = file.readAInt();
            this.mapHeight = file.readAInt();
            this.oddColumnsHigh = (file.readAByte() == 0) ? false : true;
            this.map = new byte[this.mapWidth * this.mapHeight];
            fillMap((byte) 1);
            return true;
        }

        public void fillMap(byte v)
        {
            for (int i = 0; i < this.map.Length; i++)
            {
                this.map[i] = v;
            }
        }

        private int heuristic(int x1, int y1, int x2, int y2, int oddColumnConstant)
        {
            int xdist = Math.Abs((int) x1 - (int) x2);
            int ydist = Math.Abs((int) y1 - (int) y2);
            int additional;	// This is the number of steps we must move vertically.
            // The principle of the heuristic is that for every two columns we move across,
            // we can move one row down simultaneously. This means we can remove the number of rows
            // calculated from the absolute difference between rows.
            // The result is that we have an efficient and correct heuristic for the quickest path.

            // If we're in a low column, we move down a row on every odd column rather than even columns.
            if (((x1 % 2) ^ oddColumnConstant) == 1)
            {
                additional = ydist - ((xdist + 1) / 2);
            }
            else
            {
                additional = ydist - (xdist / 2);
            }
            if (additional > 0)
            {
                return xdist + additional;
            }
            return xdist;
        }

        private CArrayList resort(CArrayList openHeap, int[] fCost)
        {
            CArrayList r = new CArrayList();
            for (int i = 0; i < openHeap.size(); i++)
            {
                if (r.size() == 0)
                {
                    r.add(openHeap.get(i));
                }
                else
                {
                    int insertAt = r.size();
                    for (int j = r.size() - 1; j >= 0; j--)
                    {
                        if (fCost[((int)openHeap.get(i))] < fCost[((int)r.get(j))])
                        {
                            insertAt = j;
                        }
                    }
                    r.add(insertAt, openHeap.get(i));
                }
            }
            return r;
        }

        private CArrayList ConstructPath(int[] gCost, int[] parent, int x1, int y1, int x2, int y2)
        {
            CArrayList rPath = new CArrayList();
            int pos = x2 + y2 * this.mapWidth;
            int finishPos = x1 + y1 * this.mapWidth;
            // Add the current (destination) point
            WargameMapPathPoint point = new WargameMapPathPoint(x2, y2, gCost[pos]);
            rPath.add(point);
            // Go backwards through the path
            while (pos != finishPos)
            {
                pos = parent[pos];
                point = new WargameMapPathPoint(pos % this.mapWidth, pos / this.mapWidth, gCost[pos]);
                rPath.add(0, point);
            }
            return rPath;
        }

        public CArrayList Pathfinder(int x1, int y1, int x2, int y2)
        {
            int oddColumnConstant = this.oddColumnsHigh ? 1 : 0;
            byte[] sets = new byte[this.mapWidth * this.mapHeight];
            int[] fCost = new int[this.mapWidth * this.mapHeight];
            int[] gCost = new int[this.mapWidth * this.mapHeight];
            int[] hCost = new int[this.mapWidth * this.mapHeight];
            int[] parent = new int[this.mapWidth * this.mapHeight];
            CArrayList openHeap = new CArrayList(); //Integer
            sets[x1 + y1 * this.mapWidth] = SETS_OPEN_SET;
            openHeap.add((int)(x1 + y1 * this.mapWidth));
            while (!openHeap.isEmpty())
            {
                // Grab the cheapest 
                int current = ((int) openHeap.get(0)); //0 is the top
                int currentX = current % this.mapWidth;
                int currentY = (int) Math.Floor((double)(current / this.mapWidth));
                if ((currentX == x2) && (currentY == y2))
                {
                    // We're done!
                    return ConstructPath(gCost, parent, x1, y1, x2, y2);
                }
                // Remove from open set and add to closed set
                openHeap.remove(0);
                sets[current] = SETS_CLOSED_SET;
                // Is this column high? 1 if high, -1 if not.
                int sideColumnConstant = ((currentX % 2) ^ oddColumnConstant) * 2 - 1;
                // Get the neighbouring coordinates
                pair[] neighbours =
                {
                    new pair(currentX - 1, currentY), new pair(currentX - 1, currentY + sideColumnConstant),
                    new pair(currentX, currentY - 1), new pair(currentX, currentY + 1),
                    new pair(currentX + 1, currentY), new pair(currentX + 1, currentY + sideColumnConstant),
                };
                // and walk through them
                for (int i = 0; i < 6; i++)
                {
                    // Out of bounds?
                    if ((neighbours[i].first >= this.mapWidth) || (neighbours[i].first < 0) ||
                            (neighbours[i].second >= this.mapHeight) || (neighbours[i].second < 0))
                    {
                        continue;
                    }
                    int next = neighbours[i].first + neighbours[i].second * this.mapWidth;
                    // In closed set?
                    if (sets[next] == SETS_CLOSED_SET)
                    {
                        continue;
                    }
                    // Impassable?
                    if (this.map[next] >= INF_TILE_COST)
                    {
                        continue;
                    }
                    // Calculate the cost to travel to this tile
                    int g = gCost[current] + this.map[next];
                    // Is this not in the open set?
                    if (sets[next] != SETS_OPEN_SET)
                    {
                        // Add to open set
                        sets[next] = SETS_OPEN_SET;
                        hCost[next] = heuristic(neighbours[i].first, neighbours[i].second, x2, y2, oddColumnConstant);
                        parent[next] = current;
                        gCost[next] = g;
                        fCost[next] = g + hCost[next];
                        // Add to heap
                        openHeap.add(0, (int)(next));
                        openHeap = resort(openHeap, fCost);
                    }
                    // Did we find a quicker path to this tile?
                    else if (g < gCost[current])
                    {
                        parent[next] = current;
                        gCost[next] = g;
                        fCost[next] = g + hCost[next];
                        // We need to resort the queue now it's been updated
                        openHeap = resort(openHeap, fCost);
                    }
                }
            }
            return null;
        }

        private int my_max(int x, int y)
        {
            return (x < y) ? y : x;
        }

        public bool WithinBounds(int x, int y)
        { //1-based
            if ((x > 0) && (x <= this.mapWidth) && (y > 0) && (y <= this.mapHeight))
            {
                return true;
            }
            return false;
        }

        public bool PointWithinBounds(int x)
        { //1-based
            if (this.path == null)
            {
                return false;
            }
            return (x <= this.path.size() - 1);
        }

        public byte GetTileFromArray(int x, int y)
        {
            return this.map[x + (y * this.mapWidth)];
        }

        public void SetTileInArray(int x, int y, byte value)
        {
            this.map[x + (y * this.mapWidth)] = value;
        }

        public CArrayList GetStraightLinePath(int x1, int y1, int x2, int y2)
        {
            int cost = 0, cumulativeCost = 0;
            int xstep = (x1 < x2) ? 1 : -1;
            int ystep = (y1 < y2) ? 1 : -1;
            CArrayList rPath = new CArrayList();
            // If the X coordinates are the same, our path is simple.
            if (x1 == x2)
            {
                while (true)
                {
                    WargameMapPathPoint point;
                    cost = GetTileFromArray(x1, y1);
                    if (cost >= INF_TILE_COST)
                    {
                        // Fail...
                        return null;
                    }
                    cumulativeCost += cost;
                    point = new WargameMapPathPoint(x1, y1, cumulativeCost);
                    rPath.add(rPath.size(), point);
                    if (y1 == y2)
                    {
                        // Finished!
                        return rPath;
                    }
                    y1 += ystep;
                }
            }
            int verticalMovement = 0, adjustedWidth = 0;
            int incrementColumn = this.oddColumnsHigh ? 1 : 0;

            // Calculate the vertical distance we should be travelling.
            // Are we going in the / direction?
            if (((x1 < x2) && (y1 > y2)) || ((x1 > x2) && (y1 < y2)))
            {
                // Reverse the columns that we increment on.
                incrementColumn = 1 - incrementColumn;
            }
            // When the Y position is equal, the rightmost column must be high.
            else if ((y1 == y2) && ((my_max(x1, x2) & 1) == incrementColumn))
            {
                incrementColumn = 1 - incrementColumn;
            }

            // Move the X coordinates left so that they lie on low columns.
            adjustedWidth = x2 - (((x2 & 1) != incrementColumn) ? 1 : 0);
            adjustedWidth -= x1 - (((x1 & 1) != incrementColumn) ? 1 : 0);
            verticalMovement = Math.Abs(adjustedWidth) / 2;
            if (Math.Abs(y2 - y1) != verticalMovement)
            {
                // Not a straight line. For shame.
                return null;
            }
            // If we're going backwards, reverse the columns we increment on. (Maybe for the second time!)
            if (x1 > x2)
            {
                incrementColumn = 1 - incrementColumn;
            }
            // Move in the X dimension.
            while (true)
            {
                WargameMapPathPoint point;
                cost = GetTileFromArray(x1, y1);
                if (cost >= INF_TILE_COST)
                {
                    // Fail...
                    return null;
                }
                cumulativeCost += cost;
                point = new WargameMapPathPoint(x1, y1, cumulativeCost);
                rPath.add(rPath.size(), point);
                if (x1 == x2)
                {
                    // Finished!
                    return rPath;
                }
                x1 += xstep;
                // Do we need to change the Y position?
                if ((x1 & 1) == incrementColumn)
                {
                    y1 += ystep;
                }
            }
        }

        private bool IsHighColumn(int column, bool oddColumnsHigh)
        {
            return ((oddColumnsHigh && ((column % 2) == 1)) || (!oddColumnsHigh && ((column % 2) == 0)));
        }

        public int GetKeypadStyleDirection(int pointIndex)
        {
            if (pointIndex == 0)
            {
                return 0;
            }
            WargameMapPathPoint current = (WargameMapPathPoint) this.path.get(pointIndex);
            WargameMapPathPoint last = (WargameMapPathPoint) this.path.get(pointIndex - 1);

            switch (current.x - last.x)
            {
                case 0:
                    // Same column. This means either north or south - simple.
                    return (current.y < last.y) ? 8 : 2;

                case -1:
                    // We've moved a column west.
                    // In high columns, at the south-east Y positions are not equal.
                    // but in low columns, at the south-east Y positions are equal.
                    // Use XOR to negate the equality for high columns.
                    return ((current.y == last.y) ^ IsHighColumn(current.x, this.oddColumnsHigh)) ? 1 : 7;

                case 1:
                    // We've moved a column east.
                    return ((current.y == last.y) ^ IsHighColumn(current.x, this.oddColumnsHigh)) ? 3 : 9;
            }
            // If we reached here something went wrong somewhere (how helpful)
            return 0;
        }

        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_COMPARETILECOST:
                    return cCompareTileCost(cnd.getParamExpression(rh, 0), cnd.getParamExpression(rh, 1), cnd);
                case CND_TILEIMPASSABLE:
                    return cTileImpassable(cnd.getParamExpression(rh, 0), cnd.getParamExpression(rh, 1));
                case CND_PATHEXISTS:
                    return cPathExists();
                case CND_COMPAREPATHCOST:
                    return cComparePathCost(cnd);
                case CND_COMPAREPATHLENGTH:
                    return cComparePathLength(cnd);
                case CND_COMPARECOSTTOPOINT:
                    return cCompareCostToPoint(cnd.getParamExpression(rh, 0), cnd);
                case CND_COMPAREPOINTDIRECTION:
                    return cComparePointDirection(cnd.getParamExpression(rh, 0), cnd);
                case CND_COMPARECOSTTOCURRENT:
                    return cCompareCostToCurrent(cnd);
                case CND_COMPARECURRENTDIRECTION:
                    return cCompareCurrentDirection(cnd);
                case CND_ENDOFPATH:
                    return cEndOfPath();
            }
            return false;
        }

        private bool cCompareTileCost(int x, int y, CCndExtension cnd)
        {
            if (WithinBounds(x, y))
            {
                return cnd.compareValues(rh, 2, new CValue(GetTileFromArray(x - 1, y - 1)));
            }
            return cnd.compareValues(rh, 2, new CValue(CRunWargameMap.INF_TILE_COST));
        }

        private bool cTileImpassable(int x, int y)
        {
            if (WithinBounds(x, y))
            {
                return (GetTileFromArray(x - 1, y - 1) >= CRunWargameMap.INF_TILE_COST) ? true : false;
            }
            return true;
        }

        private bool cPathExists()
        {
            if (path != null)
            {
                return true;
            }
            return false;
        }

        private bool cComparePathCost(CCndExtension cnd)
        {
            if (path == null)
            {
                return cnd.compareValues(rh, 0, new CValue(0));
            }
            return cnd.compareValues(rh, 0,
                    new CValue(((WargameMapPathPoint)path.get(path.size() - 1)).cumulativeCost));
        }

        private bool cComparePathLength(CCndExtension cnd)
        {
            if (path == null)
            {
                return cnd.compareValues(rh, 0, new CValue(0));
            }
            return cnd.compareValues(rh, 0,
                    new CValue(path.size() - 1));
        }

        private bool cCompareCostToPoint(int pointIndex, CCndExtension cnd)
        {
            if (path == null)
            {
                return cnd.compareValues(rh, 1, new CValue(0));
            }
            if (!PointWithinBounds(pointIndex))
            {
                return cnd.compareValues(rh, 1, new CValue(0));
            }
            return cnd.compareValues(rh, 1,
                    new CValue(((WargameMapPathPoint)path.get(pointIndex)).cumulativeCost));
        }

        private bool cComparePointDirection(int pointIndex, CCndExtension cnd)
        {
            if (path == null)
            {
                return cnd.compareValues(rh, 1, new CValue(0));
            }
            if (!PointWithinBounds(pointIndex))
            {
                return cnd.compareValues(rh, 1, new CValue(0));
            }
            return cnd.compareValues(rh, 1, new CValue(GetKeypadStyleDirection(pointIndex)));
        }

        private bool cCompareCostToCurrent(CCndExtension cnd)
        {
            if (path == null)
            {
                return cnd.compareValues(rh, 0, new CValue(0));
            }
            return cnd.compareValues(rh, 0,
                    new CValue(((WargameMapPathPoint)path.get(iterator)).cumulativeCost));
        }

        private bool cCompareCurrentDirection(CCndExtension cnd)
        {
            if (path == null)
            {
                return cnd.compareValues(rh, 0, new CValue(0));
            }
            if (!PointWithinBounds(iterator))
            {
                return cnd.compareValues(rh, 0, new CValue(0));
            }
            return cnd.compareValues(rh, 0, new CValue(GetKeypadStyleDirection(iterator)));
        }

        private bool cEndOfPath()
        {
            if (path == null)
            {
                return true;
            }
            if (iterator >= path.size() - 1)
            {
                return true;
            }
            return false;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_SETWIDTH:
                    aSetWidth(act.getParamExpression(rh, 0));
                    break;
                case ACT_SETHEIGHT:
                    aSetHeight(act.getParamExpression(rh, 0));
                    break;
                case ACT_SETCOST:
                    aSetCost(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1), act.getParamExpression(rh, 2));
                    break;
                case ACT_CALCULATEPATH:
                    aCalculatePath(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1), act.getParamExpression(rh, 2), act.getParamExpression(rh, 3));
                    break;
                case ACT_NEXTPOINT:
                    aNextPoint();
                    break;
                case ACT_PREVPOINT:
                    aPrevPoint();
                    break;
                case ACT_RESETPOINT:
                    aResetPoint();
                    break;
                case ACT_CALCULATELOS:
                    aCalculateLOS(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1), act.getParamExpression(rh, 2), act.getParamExpression(rh, 3));
                    break;
            }
        }

        private void aSetWidth(int w)
        {
            mapWidth = w;
            map = new byte[w * mapHeight];
            fillMap((byte)0);
        }

        private void aSetHeight(int h)
        {
            mapHeight = h;
            map = new byte[h * mapWidth];
            fillMap((byte)0);
        }

        private void aSetCost(int x, int y, int cost)
        {
            if (WithinBounds(x, y))
            {
                if (cost > 255)
                {
                    cost = 255;
                }
                SetTileInArray(x - 1, y - 1, (byte)cost);
            }
        }

        private void aCalculatePath(int sX, int sY, int dX, int dY)
        {
            startX = sX;
            startY = sY;
            destX = dX;
            destY = dY;
            path = Pathfinder(startX - 1, startY - 1, destX - 1, destY - 1);
            iterator = 0;
        }

        private void aNextPoint()
        {
            if ((path != null) && (iterator < path.size() - 1))
            {
                iterator++;
            }
        }

        private void aPrevPoint()
        {
            if (iterator > 0)
            {
                iterator--;
            }
        }

        private void aResetPoint()
        {
            iterator = 0;
        }

        private void aCalculateLOS(int sX, int sY, int dX, int dY)
        {
            startX = sX;
            startY = sY;
            destX = dX;
            destY = dY;
            path = GetStraightLinePath(startX - 1, startY - 1, destX - 1, destY - 1);
            iterator = 0;
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_GETWIDTH:
                    return new CValue(mapWidth);
                case EXP_GETHEIGHT:
                    return new CValue(mapHeight);
                case EXP_GETTILECOST:
                    return eGetTileCost(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_GETPATHCOST:
                    return eGetPathCost();
                case EXP_GETPATHLENGTH:
                    return eGetPathLength();
                case EXP_GETCOSTTOPOINT:
                    return eGetCostToPoint(ho.getExpParam().getInt());
                case EXP_GETPOINTDIRECTION:
                    return eGetPointDirection(ho.getExpParam().getInt());
                case EXP_GETPOINTX:
                    return eGetPointX(ho.getExpParam().getInt());
                case EXP_GETPOINTY:
                    return eGetPointY(ho.getExpParam().getInt());
                case EXP_GETSTARTX:
                    return new CValue(startX);
                case EXP_GETSTARTY:
                    return new CValue(startY);
                case EXP_GETDESTX:
                    return new CValue(destX);
                case EXP_GETDESTY:
                    return new CValue(destY);
                case EXP_GETCURRENTINDEX:
                    return new CValue(iterator);
                case EXP_GETCOSTTOCURRENT:
                    return eGetCostToCurrent();
                case EXP_GETCURRENTDIRECTION:
                    return eGetCurrentDirection();
                case EXP_GETCURRENTX:
                    return eGetCurrentX();
                case EXP_GETCURRENTY:
                    return eGetCurrentY();
                case EXP_GETCOSTATPOINT:
                    return eGetCostAtPoint(ho.getExpParam().getInt());
                case EXP_GETCOSTATCURRENT:
                    return eGetCostAtCurrent();
            }
            return new CValue(0);//won't be used
        }

        private CValue eGetTileCost(int x, int y)
        {
            if (map == null)
            {
                return new CValue(0);
            }
            if (!WithinBounds(x, y))
            {
                return new CValue(0);
            }
            return new CValue(GetTileFromArray(x - 1, y - 1));
        }

        private CValue eGetPathCost()
        {
            if (path == null)
            {
                return new CValue(0);
            }
            return new CValue(((WargameMapPathPoint)path.get(path.size() - 1)).cumulativeCost);
        }

        private CValue eGetPathLength()
        {
            if (path == null)
            {
                return new CValue(0);
            }
            return new CValue(path.size() - 1);
        }

        private CValue eGetCostToPoint(int pointIndex)
        {
            if (path == null)
            {
                return new CValue(0);
            }
            if (!PointWithinBounds(pointIndex))
            {
                return new CValue(0);
            }
            return new CValue(((WargameMapPathPoint)path.get(pointIndex)).cumulativeCost);
        }

        private CValue eGetPointDirection(int pointIndex)
        {
            if (path == null)
            {
                return new CValue(0);
            }
            if (!PointWithinBounds(pointIndex))
            {
                return new CValue(0);
            }
            return new CValue(GetKeypadStyleDirection(pointIndex));
        }

        private CValue eGetPointX(int pointIndex)
        {
            if (path == null)
            {
                return new CValue(0);
            }
            if (!PointWithinBounds(pointIndex))
            {
                return new CValue(0);
            }
            return new CValue(((WargameMapPathPoint)path.get(pointIndex)).x + 1);
        }

        private CValue eGetPointY(int pointIndex)
        {
            if (path == null)
            {
                return new CValue(0);
            }
            if (!PointWithinBounds(pointIndex))
            {
                return new CValue(0);
            }
            return new CValue(((WargameMapPathPoint)path.get(pointIndex)).y + 1);
        }

        private CValue eGetCostToCurrent()
        {
            if (path == null)
            {
                return new CValue(0);
            }
            return new CValue(((WargameMapPathPoint)path.get(iterator)).cumulativeCost);
        }

        private CValue eGetCurrentDirection()
        {
            if (path == null)
            {
                return new CValue(0);
            }
            if (iterator == 0)
            {
                return new CValue(0);
            }
            return new CValue(GetKeypadStyleDirection(iterator));
        }

        private CValue eGetCurrentX()
        {
            if (path == null)
            {
                return new CValue(0);
            }
            return new CValue(((WargameMapPathPoint)path.get(iterator)).x + 1);
        }

        private CValue eGetCurrentY()
        {
            if (path == null)
            {
                return new CValue(0);
            }
            return new CValue(((WargameMapPathPoint)path.get(iterator)).y + 1);
        }

        private CValue eGetCostAtPoint(int pointIndex)
        {
            if (path == null)
            {
                return new CValue(0);
            }
            if (!PointWithinBounds(pointIndex))
            {
                return new CValue(0);
            }
            WargameMapPathPoint p = (WargameMapPathPoint)path.get(pointIndex);
            return new CValue(GetTileFromArray(p.x, p.y));
        }

        private CValue eGetCostAtCurrent()
        {
            if (path == null)
            {
                return new CValue(0);
            }
            WargameMapPathPoint p = (WargameMapPathPoint)path.get(iterator);
            return new CValue(GetTileFromArray(p.x, p.y));
        }



    }

    public class WargameMapPathPoint
    {
        public int x, y, cumulativeCost;

        public WargameMapPathPoint(int x, int y, int cumulativeCost)
        {
            this.x = x;
            this.y = y;
            this.cumulativeCost = cumulativeCost;
        }
    }
    class pair
    {
        public int first;
        public int second;

        public pair(int first, int second)
        {
            this.first = first;
            this.second = second;
        }
    }

}
