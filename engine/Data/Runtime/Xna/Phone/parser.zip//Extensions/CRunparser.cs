﻿//----------------------------------------------------------------------------------
//
// CRunparser: String Parser object
// fin 14/04/09
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;


namespace RuntimeXNA.Extensions
{
    class CRunparser : CRunExtension
    {
        public const int CASE_INSENSITIVE = 0;
        public const int SEARCH_LITERAL = 0;
        const int CND_ISURLSAFE = 0;
        const int ACT_SETSTRING = 0;
        const int ACT_SAVETOFILE = 1;
        const int ACT_LOADFROMFILE = 2;
        const int ACT_APPENDTOFILE = 3;
        const int ACT_APPENDFROMFILE = 4;
        const int ACT_RESETDELIMS = 5;
        const int ACT_ADDDELIM = 6;
        const int ACT_SETDELIM = 7;
        const int ACT_DELETEDELIMINDEX = 8;
        const int ACT_DELETEDELIM = 9;
        const int ACT_SETDEFDELIMINDEX = 10;
        const int ACT_SETDEFDELIM = 11;
        const int ACT_SAVEASCSV = 12;
        const int ACT_LOADFROMCSV = 13;
        const int ACT_SAVEASMMFARRAY = 14;
        const int ACT_LOADFROMMMFARRAY = 15;
        const int ACT_SAVEASDYNAMICARRAY = 16;
        const int ACT_LOADFROMDYNAMICARRAY = 17;
        const int ACT_CASEINSENSITIVE = 18;
        const int ACT_CASESENSITIVE = 19;
        const int ACT_SEARCHLITERAL = 20;
        const int ACT_SEARCHWILDCARDS = 21;
        const int ACT_SAVEASINI = 22;
        const int ACT_LOADFROMINI = 23;
        const int EXP_GETSTRING = 0;
        const int EXP_GETLENGTH = 1;
        const int EXP_LEFT = 2;
        const int EXP_RIGHT = 3;
        const int EXP_MIDDLE = 4;
        const int EXP_NUMBEROFSUBS = 5;
        const int EXP_INDEXOFSUB = 6;
        const int EXP_INDEXOFFIRSTSUB = 7;
        const int EXP_INDEXOFLASTSUB = 8;
        const int EXP_REMOVE = 9;
        const int EXP_REPLACE = 10;
        const int EXP_INSERT = 11;
        const int EXP_REVERSE = 12;
        const int EXP_UPPERCASE = 13;
        const int EXP_LOWERCASE = 14;
        const int EXP_URLENCODE = 15;
        const int EXP_CHR = 16;
        const int EXP_ASC = 17;
        const int EXP_ASCLIST = 18;
        const int EXP_NUMBEROFDELIMS = 19;
        const int EXP_GETDELIM = 20;
        const int EXP_GETDELIMINDEX = 21;
        const int EXP_GETDEFDELIM = 22;
        const int EXP_GETDEFDELIMINDEX = 23;
        const int EXP_LISTCOUNT = 24;
        const int EXP_LISTSETAT = 25;
        const int EXP_LISTINSERTAT = 26;
        const int EXP_LISTAPPEND = 27;
        const int EXP_LISTPREPEND = 28;
        const int EXP_LISTGETAT = 29;
        const int EXP_LISTFIRST = 30;
        const int EXP_LISTLAST = 31;
        const int EXP_LISTFIND = 32;
        const int EXP_LISTCONTAINS = 33;
        const int EXP_LISTDELETEAT = 34;
        const int EXP_LISTSWAP = 35;
        const int EXP_LISTSORTASC = 36;
        const int EXP_LISTSORTDESC = 37;
        const int EXP_LISTCHANGEDELIMS = 38;
        const int EXP_SETSTRING = 39;
        const int EXP_SETVALUE = 40;
        const int EXP_GETMD5 = 41;

        
        String source = "";
        bool caseSensitive;
        bool wildcards;
        CArrayList delims = new CArrayList(); //Strings
        String defaultDelim;
        CArrayList tokensE = new CArrayList(); //parserElement

        public override int getNumberOfConditions()
        {
            return 1;
        }

        private String fixString(String input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] < 10)
                {
                    return input.Substring(0, i);
                }
            }
            return input;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            file.setUnicode(false);
            file.skipBytes(4);
            this.source = fixString(file.readAString(1025));
            short nComparison = file.readAShort();
            if (nComparison == CASE_INSENSITIVE)
            {
                this.caseSensitive = false;
            }
            else
            {
                this.caseSensitive = true;
            }
            short nSearchMode = file.readShort();
            if (nSearchMode == SEARCH_LITERAL)
            {
                this.wildcards = false;
            }
            else
            {
                this.wildcards = true;
            }
            return true;
        }

        public void redoTokens()
        {
            this.tokensE.clear();
            String sourceToTest = this.source;
            if (!(sourceToTest.Length==0))
            {
                int lastTokenLocation = 0;
                bool work = true;
                while (work)
                {
                    CArrayList aTokenE = new CArrayList(); //parserElement
                    CArrayList aDelim = new CArrayList(); //String
                    for (int j = 0; j < this.delims.size(); j++)
                    {
                        String delim = (String)this.delims.get(j);
                        int index = getSubstringIndex(sourceToTest, delim, 0);
                        if (index != -1)
                        {
                            aTokenE.add(new parserElement(sourceToTest.Substring(0, index), lastTokenLocation));
                            aDelim.add(delim);
                        }
                    }
                    //pick smallest token
                    int smallestC = Int32.MaxValue;
                    int smallest = -1;
                    for (int j = 0; j < aTokenE.size(); j++)
                    {
                        if (((parserElement)aTokenE.get(j)).text.Length < smallestC)
                        {
                            smallestC = ((parserElement)aTokenE.get(j)).text.Length;
                            smallest = j;
                        }
                    }
                    if (smallest != -1)
                    {
                        this.tokensE.add(aTokenE.get(smallest));
                        sourceToTest = sourceToTest.Substring(
                                ((parserElement)aTokenE.get(smallest)).text.Length +
                                ((String)aDelim.get(smallest)).Length);
                        lastTokenLocation += ((parserElement)aTokenE.get(smallest)).text.Length +
                                ((String)aDelim.get(smallest)).Length;
                    }
                    else
                    {
                        //if at end of search, add remainder
                        this.tokensE.add(new parserElement(sourceToTest, lastTokenLocation));
                        work = false;
                    }
                }
                for (int i = 0; i < this.tokensE.size(); i++)
                {
                    //remove ""
                    parserElement e = (parserElement)this.tokensE.get(i);
                    if (e.text.Length==0)
                    {
                        this.tokensE.remove(i);
                        i--;
                    }
                }
            }
        }

        public int getSubstringIndex(String source, String find, int occurance)
        { //occurance is 0-based
            String theSource = source;
            if (source.Length==0)
            {
                return -1;
            }
            if (!this.caseSensitive)
            {
                theSource = theSource.ToLower();
                find = find.ToLower();
            }
            if (this.wildcards)
            {
                StringTokenizer st = new StringTokenizer(find, "*");
                int ct = st.countTokens();
                String[] asteriskless = new String[ct];
                for (int i = 0; i < ct; i++)
                {
                    asteriskless[i] = st.nextToken();
                }
                int lastOccurance = -1;
                for (int occ = 0; occ <= occurance; occ++)
                {
                    int[] asterisklessLocation = new int[ct];
                    for (int asterisk = 0; asterisk < ct; asterisk++)
                    {
                        for (int i = 0; i < theSource.Length; i++)
                        {
                            String findThis = asteriskless[asterisk];
                            //replace "?" occurances with chars from source
                            for (int j = 0; j < findThis.Length; j++)
                            {
                                if (findThis[j]=='?')
                                {
                                    if (i + j < theSource.Length)
                                    {
                                        findThis = findThis.Substring(0, j) +
                                                theSource.Substring(i + j, 1) +
                                                findThis.Substring(j + 1);
                                    }
                                }
                            }
                            if ((asterisk == 0) || (asterisklessLocation[asterisk - 1] == -1))
                            {
                                asterisklessLocation[asterisk] = theSource.IndexOf(findThis, lastOccurance + 1);
                            }
                            else
                            {
                                asterisklessLocation[asterisk] = theSource.IndexOf(findThis, asterisklessLocation[asterisk - 1]);
                            }
                            if (asterisklessLocation[asterisk] != -1)
                            {
                                i = theSource.Length; //stop
                            }
                        }
                    }
                    //now each int in asterisklessLocation should be in an acsending order (lowest first)
                    //if they are not, then the string wasn't found in the source
                    int last = -1;
                    for (int i = 0; i < ct; i++)
                    {
                        if (asterisklessLocation[i] > last)
                        {
                            last = asterisklessLocation[i];
                        }
                        else
                        {
                            lastOccurance = -1;
                            i = ct; //stop
                        }
                    }
                    if ((occ == 0) || (lastOccurance != -1))
                    {
                        if (asterisklessLocation.Length > 0)
                        {
                            lastOccurance = asterisklessLocation[0];
                        }
                        else
                        {
                            lastOccurance = -1;
                        }
                    }
                }
                return lastOccurance;
            }
            else
            { //no wildcards
                int lastIndex = -1;
                for (int i = 0; i <= occurance; i++)
                {
                    lastIndex = theSource.IndexOf(find, lastIndex + 1);
                }
                return lastIndex;
            }
        }

        public bool substringMatches(String source, String find)
        {
            String theSource = source;
            if (!this.caseSensitive)
            {
                theSource = theSource.ToLower();
                find = find.ToLower();
            }
            if (this.wildcards)
            {
                StringTokenizer st = new StringTokenizer(find, "*");
                int ct = st.countTokens();
                String[] asteriskless = new String[ct];
                for (int i = 0; i < ct; i++)
                {
                    asteriskless[i] = st.nextToken();
                }
                int[] asterisklessLocation = new int[ct];
                for (int asterisk = 0; asterisk < ct; asterisk++)
                {
                    for (int i = 0; i < theSource.Length; i++)
                    {
                        String findThis = asteriskless[asterisk];
                        //replace "?" occurances with chars from source
                        for (int j = 0; j < findThis.Length; j++)
                        {
                            if (findThis[j]=='?')
                            {
                                if (i + j < theSource.Length)
                                {
                                    findThis = findThis.Substring(0, j) +
                                            theSource.Substring(i + j, 1) +
                                            findThis.Substring(j + 1);
                                }
                            }
                        }
                        if ((asterisk == 0) || (asterisklessLocation[asterisk - 1] == -1))
                        {
                            asterisklessLocation[asterisk] = theSource.IndexOf(findThis);
                        }
                        else
                        {
                            asterisklessLocation[asterisk] = theSource.IndexOf(findThis, asterisklessLocation[asterisk - 1]);
                        }
                        if (asterisklessLocation[asterisk] != -1)
                        {
                            i = theSource.Length; //stop
                        }
                    }
                }
                //now each int in asterisklessLocation should be in an acsending order (lowest first)
                //if they are not, then the string wasn't found in the source
                int last = -1;
                bool ok = true;
                for (int i = 0; i < ct; i++)
                {
                    if (asterisklessLocation[i] > last)
                    {
                        last = asterisklessLocation[i];
                    }
                    else
                    {
                        i = ct; //stop
                        ok = false;
                    }
                }
                if ((ok) && (find.Length > 0) && (asterisklessLocation.Length > 0))
                {
                    if (getSubstringIndex(theSource, find, 1) == -1)
                    { //no other occurances
                        if (find[0]=='*')
                        {
                            if (find[find.Length - 1]=='*')
                            {
                                //if it starts with a * and ends with a *
                                return true;
                            }
                            else
                            {
                                //if last element is at the end of the source
                                if (asterisklessLocation[ct - 1] + asteriskless[ct - 1].Length == theSource.Length)
                                {
                                    return true;
                                }
                            }
                        }
                        else
                        {
                            if (asterisklessLocation[0] == 0)
                            {
                                if (find[find.Length - 1]=='*')
                                {
                                    //if it starts with a * and ends with a *
                                    return true;
                                }
                                else
                                {
                                    //if last element is at the end of the source
                                    if (asterisklessLocation[ct - 1] + asteriskless[ct - 1].Length == theSource.Length)
                                    {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            { //no wildcards
                if ((theSource.Length == find.Length) && (theSource.IndexOf(find, 0) == 0))
                {
                    return true;
                }
            }
            return false;
        }

        bool isLetterOrDigit(char c)
        {
            if (c >= 'A' && c <= 'Z')
            {
                return true;
            }
            if (c >= 'a' && c <= 'z')
            {
                return true;
            }
            if (c >= '0' && c <= '9')
            {
                return true;
            }
            if (c == '_')
            {
                return true;
            }
            return false;
        }
        public override bool condition(int num, CCndExtension cnd)
        {
            if (num == CND_ISURLSAFE)
            {
                for (int index = 0; index < source.Length; index++)
                {
                    while (!isLetterOrDigit(source[index]))
                    {
                        if (source[index] == '+')
                        {
                            break;
                        }
                        else
                        {
                            if (source[index] == '%')
                            {
                                if (source.Length > index + 2)
                                {
                                    if (isLetterOrDigit(source[index + 1])
                                            && isLetterOrDigit(source[index + 2]))
                                    {
                                        index = index + 2;
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                    break;
                                }
                                else
                                {
                                    return false;
                                }
                            }
                            else
                            {
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
            return false;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_SETSTRING:
                    source = act.getParamExpString(rh, 0);
                    redoTokens();
                    break;
                case ACT_SAVETOFILE:
                    break;
                case ACT_LOADFROMFILE:
                    break;
                case ACT_APPENDTOFILE:
                    break;
                case ACT_APPENDFROMFILE:
                    break;
                case ACT_RESETDELIMS:
                    delims.clear();
                    break;
                case ACT_ADDDELIM:
                    SP_addDelim(act.getParamExpString(rh, 0));
                    break;
                case ACT_SETDELIM:
                    SP_setDelim(act.getParamExpString(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case ACT_DELETEDELIMINDEX:
                    SP_deleteDelimIndex(act.getParamExpression(rh, 0));
                    break;
                case ACT_DELETEDELIM:
                    SP_deleteDelim(act.getParamExpString(rh, 0));
                    break;
                case ACT_SETDEFDELIMINDEX:
                    SP_setDefDelimIndex(act.getParamExpression(rh, 0));
                    break;
                case ACT_SETDEFDELIM:
                    SP_setDefDelim(act.getParamExpString(rh, 0));
                    break;
                case ACT_SAVEASCSV:
                    break;
                case ACT_LOADFROMCSV:
                    break;
                case ACT_SAVEASMMFARRAY:
                    break;
                case ACT_LOADFROMMMFARRAY:
                    break;
                case ACT_SAVEASDYNAMICARRAY:
                    break;
                case ACT_LOADFROMDYNAMICARRAY:
                    break;
                case ACT_CASEINSENSITIVE:
                    caseSensitive = false;
                    redoTokens();
                    break;
                case ACT_CASESENSITIVE:
                    caseSensitive = true;
                    redoTokens();
                    break;
                case ACT_SEARCHLITERAL:
                    wildcards = false;
                    redoTokens();
                    break;
                case ACT_SEARCHWILDCARDS:
                    wildcards = true;
                    redoTokens();
                    break;
                case ACT_SAVEASINI:
                    break;
                case ACT_LOADFROMINI:
                    break;
            }
        }

        private void SP_addDelim(String delim)
        {
            if (delim.Length!=0)
            {
                bool exists = false;
                for (int i = 0; i < delims.size(); i++)
                {
                    String thisDelim = (String) delims.get(i);
                    if (getSubstringIndex(thisDelim, delim, 0) >= 0)
                    {
                        exists = true;
                    }
                }
                if (exists == false)
                {
                    delims.add(delim);
                    redoTokens();
                    defaultDelim = delim;
                }
            }
        }

        private void SP_setDelim(String delim, int index)
        {
            if ((index >= 0) && (index < delims.size()))
            {
                delims.set(index, delim);
                defaultDelim = delim;
                redoTokens();
            }
        }

        private void SP_deleteDelimIndex(int index)
        {
            if ((index >= 0) && (index < delims.size()))
            {
                delims.remove(index);
                if (index < delims.size())
                {
                    defaultDelim = (String) delims.get(index);
                }
                else
                {
                    defaultDelim = null;
                }
                redoTokens();
            }
        }

        private void SP_deleteDelim(String delim)
        {
            for (int i = 0; i < delims.size(); i++)
            {
                if (string.Compare(((String)delims.get(i)), delim)==0)
                {
                    delims.remove(i);
                    if (i < delims.size())
                    {
                        defaultDelim = (String) delims.get(i);
                    }
                    else
                    {
                        defaultDelim = null;
                    }
                    redoTokens();
                    return;
                }
            }
        }

        private void SP_setDefDelimIndex(int index)
        {
            if ((index >= 0) && (index < delims.size()))
            {
                defaultDelim = (String) delims.get(index);
            }
        }

        private void SP_setDefDelim(String delim)
        {
            for (int i = 0; i < delims.size(); i++)
            {
                if (string.Compare((String)delims.get(i), delim)==0)
                {
                    defaultDelim = (String) delims.get(i);
                    return;
                }
            }
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_GETSTRING:
                    return new CValue(source);
                case EXP_GETLENGTH:
                    return new CValue(source.Length);
                case EXP_LEFT:
                    return SP_left(ho.getExpParam().getInt());
                case EXP_RIGHT:
                    return SP_right(ho.getExpParam().getInt());
                case EXP_MIDDLE:
                    return SP_middle(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_NUMBEROFSUBS:
                    return SP_numberOfSubs(ho.getExpParam().getString());
                case EXP_INDEXOFSUB:
                    return SP_indexOfSub(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_INDEXOFFIRSTSUB:
                    return SP_indexOfFirstSub(ho.getExpParam().getString());
                case EXP_INDEXOFLASTSUB:
                    return SP_indexOfLastSub(ho.getExpParam().getString());
                case EXP_REMOVE:
                    return SP_remove(ho.getExpParam().getString());
                case EXP_REPLACE:
                    return SP_replace(ho.getExpParam().getString(), ho.getExpParam().getString());
                case EXP_INSERT:
                    return SP_insert(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_REVERSE:
                    return SP_reverse();
                case EXP_UPPERCASE:
                    return new CValue(source.ToUpper());
                case EXP_LOWERCASE:
                    return new CValue(source.ToLower());
                case EXP_URLENCODE:
                    return SP_urlEncode();
                case EXP_CHR:
                    return SP_chr(ho.getExpParam().getInt());
                case EXP_ASC:
                    return SP_asc(ho.getExpParam().getString());
                case EXP_ASCLIST:
                    return SP_ascList(ho.getExpParam().getString());
                case EXP_NUMBEROFDELIMS:
                    return new CValue(delims.size());
                case EXP_GETDELIM:
                    return SP_getDelim(ho.getExpParam().getInt());
                case EXP_GETDELIMINDEX:
                    return SP_getDelimIndex(ho.getExpParam().getString());
                case EXP_GETDEFDELIM:
                    return SP_getDefDelim();
                case EXP_GETDEFDELIMINDEX:
                    return SP_getDefDelimIndex();
                case EXP_LISTCOUNT:
                    return new CValue(tokensE.size());
                case EXP_LISTSETAT:
                    return SP_listSetAt(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_LISTINSERTAT:
                    return SP_listInsertAt(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_LISTAPPEND:
                    return new CValue(source + ho.getExpParam().getString());
                case EXP_LISTPREPEND:
                    return new CValue(ho.getExpParam().getString() + source);
                case EXP_LISTGETAT:
                    return SP_listGetAt(ho.getExpParam().getInt());
                case EXP_LISTFIRST:
                    return SP_listFirst();
                case EXP_LISTLAST:
                    return SP_listLast();
                case EXP_LISTFIND: //matching
                    return SP_listFind(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_LISTCONTAINS:
                    return SP_listContains(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_LISTDELETEAT:
                    return SP_listDeleteAt(ho.getExpParam().getInt());
                case EXP_LISTSWAP:
                    return SP_listSwap(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_LISTSORTASC:
                    return SP_listSortAsc();
                case EXP_LISTSORTDESC:
                    return SP_listSortDesc();
                case EXP_LISTCHANGEDELIMS:
                    return SP_listChangeDelims(ho.getExpParam().getString());
                case EXP_SETSTRING:
                    return SP_setStringEXP(ho.getExpParam().getString());
                case EXP_SETVALUE:
                    return SP_setValueEXP(ho.getExpParam().getString());
                case EXP_GETMD5:
                    return SP_getMD5();
            }
            return new CValue(0);//won't be used
        }

        private CValue SP_left(int i)
        {
            if ((i >= 0) && (i <= source.Length))
            {
                return new CValue(source.Substring(0, i));
            }
            return new CValue("");
        }

        private CValue SP_right(int i)
        {
            if ((i >= 0) && (i <= source.Length))
            {
                return new CValue(source.Substring(source.Length - i));
            }
            return new CValue("");
        }

        private CValue SP_middle(int i, int length)
        {
            length = Math.Max(0, length);
            if ((i >= 0) && (i + length <= source.Length))
            {
                return new CValue(source.Substring(i, length));
            }
            return new CValue("");
        }

        private CValue SP_numberOfSubs(String sub)
        {
            int count = 0;
            while (getSubstringIndex(source, sub, count) != -1)
            {
                count++;
            }
            return new CValue(count);
        }

        private CValue SP_indexOfSub(String sub, int occurance)
        { //1-based
            occurance = Math.Max(1, occurance);
            return new CValue(getSubstringIndex(source, sub, occurance - 1));
        }

        private CValue SP_indexOfFirstSub(String sub)
        {
            return new CValue(getSubstringIndex(source, sub, 0));
        }

        private CValue SP_indexOfLastSub(String sub)
        {
            int n = Math.Max(1, SP_numberOfSubs(sub).getInt());
            return new CValue(getSubstringIndex(source, sub, n - 1));
        }

        private CValue SP_remove(String sub)
        {
            int count = 0;
            CArrayList parts = new CArrayList(); //Integer
            int index = getSubstringIndex(source, sub, count);
            while (index != -1)
            {
                parts.add(index);
                count++;
                index = getSubstringIndex(source, sub, count);
            }
            if (parts.size() == 0)
            {
                return new CValue(source);
            }
            int last = 0;
            String r = "";
            for (int i = 0; i < parts.size(); i++)
            {
                r += source.Substring(last, ((int) parts.get(i))-last);
                last = ((int) parts.get(i)) + sub.Length;
                if (i == parts.size() - 1)
                {
                    r += source.Substring(last);
                }
            }
            return new CValue(r);
        }

        private CValue SP_replace(String old, String newString)
        {
            int count = 0;
            CArrayList parts = new CArrayList(); //Integer
            int index = getSubstringIndex(source, old, count);
            while (index != -1)
            {
                parts.add(index);
                count++;
                index = getSubstringIndex(source, old, count);
            }
            if (parts.size() == 0)
            {
                return new CValue(source);
            }
            int last = 0;
            String r = "";
            for (int i = 0; i < parts.size(); i++)
            {
                r += source.Substring(last, ((int) parts.get(i))-last) + newString;
                last = ((int) parts.get(i)) + old.Length;
                if (i == parts.size() - 1)
                {
                    r += source.Substring(last);
                }
            }
            return new CValue(r);
        }

        private CValue SP_insert(String insert, int index)
        {
            if ((index >= 1) && (index <= source.Length))
            {
                return new CValue(source.Substring(0, index - 1) + insert + source.Substring(index - 1));
            }
            return new CValue("");
        }

        private CValue SP_reverse()
        {
            String r = "";
            for (int i = source.Length - 1; i >= 0; i--)
            {
                r += source.Substring(i, i);
            }
            return new CValue(r);
        }

        private CValue SP_urlEncode()
        {
            String r = "";
            for (int i = 0; i < source.Length; i++)
            {
                if (isLetterOrDigit(source[i]))
                {
                    r += source.Substring(i, 1);
                }
                else
                {
                    if (source[i]==' ')
                    {
                        r += "+";
                    }
                    else
                    {
                        if (source[i] == 13)
                        {
                            r += "+";
                            i++;
                        }
                        else
                        {
                            r += "%";
                            r += ((int)(source[i] >> 4)).ToString("X");
                            r += ((int)(source[i] % 16)).ToString("X");;
                        }
                    }
                }
            }
            return new CValue(r);
        }

        private CValue SP_chr(int value)
        {
            String r = new String((char)value, 1);
            return new CValue(r);
        }

        private CValue SP_asc(String value)
        {
            if (value.Length> 0)
            {
                int r = (int) value[0];
                return new CValue(r);
            }
            return new CValue(0);
        }

        private CValue SP_ascList(String delim)
        {
            String r = "";
            for (int i = 0; i < source.Length; i++)
            {
                r += ((int)source[i]).ToString();
                if (i < source.Length - 1)
                {
                    r += delim;
                }
            }
            return new CValue(r);
        }

        private CValue SP_getDelim(int i)
        { //0-based, silly 3ee
            if ((i >= 0) && (i < delims.size()))
            {
                return new CValue((String) delims.get(i));
            }
            return new CValue("");
        }

        private CValue SP_getDelimIndex(String delim)
        {
            for (int i = 0; i < delims.size(); i++)
            {
                String thisDelim = (String) delims.get(i);
                if (getSubstringIndex(thisDelim, delim, 0) >= 0)
                {
                    return new CValue(i);
                }
            }
            return new CValue(-1);
        }

        private CValue SP_getDefDelim()
        {
            if (defaultDelim != null)
            {
                return new CValue(defaultDelim);
            }
            return new CValue("");
        }

        private CValue SP_getDefDelimIndex()
        {
            if (defaultDelim != null)
            {
                for (int i = 0; i < delims.size(); i++)
                {
                    String thisDelim = (String) delims.get(i);
                    if (getSubstringIndex(thisDelim, defaultDelim, 0) >= 0)
                    {
                        return new CValue(i);
                    }
                }
            }
            return new CValue(-1);
        }

        private CValue SP_listSetAt(String replace, int index)
        { //1-based
            if ((index >= 1) && (index <= tokensE.size()))
            {
                parserElement e = (parserElement) tokensE.get(index - 1);
                String r = source.Substring(0, e.index) + replace + source.Substring(e.endIndex);
                return new CValue(r);
            }
            return new CValue("");
        }

        private CValue SP_listInsertAt(String insert, int index)
        { //1-based
            if ((index >= 1) && (index <= tokensE.size()))
            {
                parserElement e = (parserElement) tokensE.get(index - 1);
                String r = source.Substring(0, e.index) + insert + source.Substring(e.index);
                return new CValue(r);
            }
            return new CValue("");
        }

        private CValue SP_listGetAt(int index)
        { //1-based
            if ((index >= 1) && (index <= tokensE.size()))
            {
                parserElement e = (parserElement) tokensE.get(index - 1);
                return new CValue(e.text);
            }
            return new CValue("");
        }

        private CValue SP_listFirst()
        {
            if (tokensE.size() > 0)
            {
                parserElement e = (parserElement) tokensE.get(0);
                return new CValue(e.text);
            }
            return new CValue("");
        }

        private CValue SP_listLast()
        {
            if (tokensE.size() > 0)
            {
                parserElement e = (parserElement) tokensE.get(tokensE.size() - 1);
                return new CValue(e.text);
            }
            return new CValue("");
        }

        private CValue SP_listFind(String find, int occurance)
        { //matching //1-based
            if ((occurance > 0) && (find.Length > 0))
            {
                int occuranceCount = 0;
                for (int i = 0; i < tokensE.size(); i++)
                {
                    parserElement e = (parserElement) tokensE.get(i);
                    if (substringMatches(e.text, find))
                    {
                        occuranceCount++;
                    }
                    if (occuranceCount == occurance)
                    {
                        return new CValue(i + 1);
                    }
                }
            }
            return new CValue(0);
        }

        private CValue SP_listContains(String find, int occurance)
        { //matching //1-based
            if ((occurance > 0) && (find.Length > 0))
            {
                int occuranceCount = 0;
                for (int i = 0; i < tokensE.size(); i++)
                {
                    parserElement e = (parserElement) tokensE.get(i);
                    if (getSubstringIndex(e.text, find, 0) != -1)
                    {
                        occuranceCount++;
                    }
                    if (occuranceCount == occurance)
                    {
                        return new CValue(i + 1);
                    }
                }
            }
            return new CValue(0);
        }

        private CValue SP_listDeleteAt(int index)
        { //1-based
            if ((index >= 1) && (index <= tokensE.size()))
            {
                parserElement e = (parserElement) tokensE.get(index - 1);
                String r = source.Substring(0, e.index) + source.Substring(e.endIndex);
                return new CValue(r);
            }
            return new CValue("");
        }

        private CValue SP_listSwap(int i1, int i2)
        { //1-based
            if ((i1 >= 1) && (i2 >= 1) && (i1 <= tokensE.size()) && (i2 <= tokensE.size()))
            {
                if (i1 == i2)
                {
                    return new CValue(source);
                }
                parserElement e1 = (parserElement) tokensE.get(i1 - 1);
                parserElement e2 = (parserElement) tokensE.get(i2 - 1);
                String r = "";
                if (i1 > i2)
                {
                    //e2 comes sooner
                    r += source.Substring(0, e2.index); //string leading up to e2
                    r += source.Substring(e1.index, e1.endIndex - e1.index); //e1
                    r += source.Substring(e2.endIndex, e1.index - e2.endIndex); //string between e2 and e1
                    r += source.Substring(e2.index, e2.endIndex - e2.index); //e2
                    r += source.Substring(e1.endIndex); //string from end of e1 to end
                }
                else
                { //i1 < i2
                    //e1 comes sooner
                    r += source.Substring(0, e1.index); //string leading up to e1
                    r += source.Substring(e2.index, e2.endIndex - e2.index); //e2
                    r += source.Substring(e1.endIndex, e2.index - e1.endIndex); //string between e1 and e2
                    r += source.Substring(e1.index, e1.endIndex - e1.index); //e1
                    r += source.Substring(e2.endIndex); //string from end of e2 to end
                }
                return new CValue(r);
            }
            return new CValue("");
        }

        private CValue SP_listSortAsc()
        {
            CArrayList sorted = new CArrayList(); //parserElement
            for (int i = 0; i < tokensE.size(); i++)
            {
                parserElement e = (parserElement) tokensE.get(i);
                if (sorted.size() == 0)
                {
                    sorted.add(e);
                }
                else
                {
                    int index = 0;
                    for (int j = 0; j < sorted.size(); j++)
                    {
                        parserElement element = (parserElement) sorted.get(j);
                        if (caseSensitive)
                        {
                            if (string.Compare(e.text, element.text) >= 0)
                            {
                                index = j;
                            }
                        }
                        else
                        {
                            if (string.Compare(e.text, element.text, StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                index = j;
                            }
                        }
                    }
                    sorted.add(index, e);
                }
            }
            String r = "";
            for (int i = 0; i < sorted.size(); i++)
            {
                parserElement e = (parserElement) sorted.get(i);
                parserElement oe = (parserElement) tokensE.get(i);
                if (i == 0)
                {
                    r += source.Substring(0, oe.index);
                }
                else
                {
                    parserElement lastOrigE = (parserElement) tokensE.get(i - 1);
                    r += source.Substring(lastOrigE.endIndex, oe.index - lastOrigE.endIndex);
                }
                r += source.Substring(e.index, e.endIndex - e.index);
                if (i == sorted.size() - 1)
                {
                    r += source.Substring(oe.endIndex);
                }
            }
            return new CValue(r);
        }

        private CValue SP_listSortDesc()
        {
            CArrayList sorted = new CArrayList(); //parserElement
            for (int i = 0; i < tokensE.size(); i++)
            {
                parserElement e = (parserElement) tokensE.get(i);
                if (sorted.size() == 0)
                {
                    sorted.add(e);
                }
                else
                {
                    int index = sorted.size();
                    for (int j = sorted.size() - 1; j >= 0; j--)
                    {
                        parserElement element = (parserElement) sorted.get(j);
                        if (caseSensitive)
                        {
                            if (string.Compare(e.text, element.text) >= 0)
                            {
                                index = j;
                            }
                        }
                        else
                        {
                            if (string.Compare(e.text, element.text, StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                index = j;
                            }
                        }
                    }
                    sorted.add(index, e);
                }
            }
            String r = "";
            for (int i = 0; i < sorted.size(); i++)
            {
                parserElement e = (parserElement) sorted.get(i);
                parserElement oe = (parserElement) tokensE.get(i);
                if (i == 0)
                {
                    r += source.Substring(0, oe.index);
                }
                else
                {
                    parserElement lastOrigE = (parserElement) tokensE.get(i - 1);
                    r += source.Substring(lastOrigE.endIndex, oe.index - lastOrigE.endIndex);
                }
                r += source.Substring(e.index, e.endIndex - e.index);
                if (i == sorted.size() - 1)
                {
                    r += source.Substring(oe.endIndex);
                }
            }
            return new CValue(r);
        }

        private CValue SP_listChangeDelims(String changeDelim)
        {
            if (defaultDelim != null)
            {
                String r = "";
                for (int i = 0; i < tokensE.size(); i++)
                {
                    parserElement e = (parserElement) tokensE.get(i);
                    int here = e.index - defaultDelim.Length;
                    if ((here >= 0) && (string.Compare(source.Substring(here, e.index-here), defaultDelim)==0))
                    {
                        r += changeDelim;
                    }
                    else
                    {
                        if (i == 0)
                        {
                            r += source.Substring(0, e.index);
                        }
                        else
                        {
                            parserElement lastOrigE = (parserElement) tokensE.get(i - 1);
                            r += source.Substring(lastOrigE.endIndex, e.index - lastOrigE.endIndex);
                        }
                    }
                    r += source.Substring(e.index, e.endIndex - e.index);
                    if (i == tokensE.size() - 1)
                    {
                        if (string.Compare(source.Substring(e.endIndex), defaultDelim)==0)
                        {
                            r += changeDelim;
                        }
                        else
                        {
                            r += source.Substring(e.endIndex);
                        }
                    }
                }
                return new CValue(r);
            }
            return new CValue("");
        }

        private CValue SP_setStringEXP(String newSource)
        {
            source = newSource;
            redoTokens();
            return new CValue("");
        }

        private CValue SP_setValueEXP(String newSource)
        {
            source = newSource;
            redoTokens();
            return new CValue(0);
        }

        private CValue SP_getMD5()
        {
            byte[] bytes = MD5Core.GetHash(source);
            int n;
            String s = "";
            String temp;
            for (n = 0; n < bytes.Length; n++)
            {
                temp = bytes[n].ToString("X");
                if (temp.Length < 2)
                    temp = "0" + temp;
                s += temp;
            }
            return new CValue(s.ToLower());
        }
    }
    // **************************************************************
    // * Raw implementation of the MD5 hash algorithm
    // * from RFC 1321.
    // *
    // * Written By: Reid Borsuk and Jenny Zheng
    // * Copyright (c) Microsoft Corporation.  All rights reserved.
    // **************************************************************

    // Simple struct for the (a,b,c,d) which is used to compute the mesage digest.  
    struct ABCDStruct
    {
        public uint A;
        public uint B;
        public uint C;
        public uint D;
    }

    public sealed class MD5Core
    {
        //Prevent CSC from adding a default public constructor
        public MD5Core() { }

        public static byte[] GetHash(string input, Encoding encoding)
        {
            if (null == input)
                throw new System.ArgumentNullException("input", "Unable to calculate hash over null input data");
            if (null == encoding)
                throw new System.ArgumentNullException("encoding", "Unable to calculate hash over a string without a default encoding. Consider using the GetHash(string) overload to use UTF8 Encoding");

            byte[] target = encoding.GetBytes(input);

            return GetHash(target);
        }

        public static byte[] GetHash(string input)
        {
            return GetHash(input, new UTF8Encoding());
        }

        public static string GetHashString(byte[] input)
        {
            if (null == input)
                throw new System.ArgumentNullException("input", "Unable to calculate hash over null input data");

            string retval = BitConverter.ToString(GetHash(input));
            retval = retval.Replace("-", "");

            return retval;
        }

        public static string GetHashString(string input, Encoding encoding)
        {
            if (null == input)
                throw new System.ArgumentNullException("input", "Unable to calculate hash over null input data");
            if (null == encoding)
                throw new System.ArgumentNullException("encoding", "Unable to calculate hash over a string without a default encoding. Consider using the GetHashString(string) overload to use UTF8 Encoding");

            byte[] target = encoding.GetBytes(input);

            return GetHashString(target);
        }

        public static string GetHashString(string input)
        {
            return GetHashString(input, new UTF8Encoding());
        }

        public static byte[] GetHash(byte[] input)
        {
            if (null == input)
                throw new System.ArgumentNullException("input", "Unable to calculate hash over null input data");

            //Intitial values defined in RFC 1321
            ABCDStruct abcd = new ABCDStruct();
            abcd.A = 0x67452301;
            abcd.B = 0xefcdab89;
            abcd.C = 0x98badcfe;
            abcd.D = 0x10325476;

            //We pass in the input array by block, the final block of data must be handled specialy for padding & length embeding
            int startIndex = 0;
            while (startIndex <= input.Length - 64)
            {
                MD5Core.GetHashBlock(input, ref abcd, startIndex);
                startIndex += 64;
            }
            // The final data block. 
            return MD5Core.GetHashFinalBlock(input, startIndex, input.Length - startIndex, abcd, (Int64)input.Length * 8);
        }

        internal static byte[] GetHashFinalBlock(byte[] input, int ibStart, int cbSize, ABCDStruct ABCD, Int64 len)
        {
            byte[] working = new byte[64];
            byte[] length = BitConverter.GetBytes(len);

            //Padding is a single bit 1, followed by the number of 0s required to make size congruent to 448 modulo 512. Step 1 of RFC 1321  
            //The CLR ensures that our buffer is 0-assigned, we don't need to explicitly set it. This is why it ends up being quicker to just
            //use a temporary array rather then doing in-place assignment (5% for small inputs)
            Array.Copy(input, ibStart, working, 0, cbSize);
            working[cbSize] = 0x80;

            //We have enough room to store the length in this chunk
            if (cbSize <= 56)
            {
                Array.Copy(length, 0, working, 56, 8);
                GetHashBlock(working, ref ABCD, 0);
            }
            else  //We need an aditional chunk to store the length
            {
                GetHashBlock(working, ref ABCD, 0);
                //Create an entirely new chunk due to the 0-assigned trick mentioned above, to avoid an extra function call clearing the array
                working = new byte[64];
                Array.Copy(length, 0, working, 56, 8);
                GetHashBlock(working, ref ABCD, 0);
            }
            byte[] output = new byte[16];
            Array.Copy(BitConverter.GetBytes(ABCD.A), 0, output, 0, 4);
            Array.Copy(BitConverter.GetBytes(ABCD.B), 0, output, 4, 4);
            Array.Copy(BitConverter.GetBytes(ABCD.C), 0, output, 8, 4);
            Array.Copy(BitConverter.GetBytes(ABCD.D), 0, output, 12, 4);
            return output;
        }

        // Performs a single block transform of MD5 for a given set of ABCD inputs
        /* If implementing your own hashing framework, be sure to set the initial ABCD correctly according to RFC 1321:
        //      A = 0x67452301;
        //      B = 0xefcdab89;
        //      C = 0x98badcfe;
        //      D = 0x10325476;
        */
        internal static void GetHashBlock(byte[] input, ref ABCDStruct ABCDValue, int ibStart)
        {
            uint[] temp = Converter(input, ibStart);
            uint a = ABCDValue.A;
            uint b = ABCDValue.B;
            uint c = ABCDValue.C;
            uint d = ABCDValue.D;

            a = r1(a, b, c, d, temp[0], 7, 0xd76aa478);
            d = r1(d, a, b, c, temp[1], 12, 0xe8c7b756);
            c = r1(c, d, a, b, temp[2], 17, 0x242070db);
            b = r1(b, c, d, a, temp[3], 22, 0xc1bdceee);
            a = r1(a, b, c, d, temp[4], 7, 0xf57c0faf);
            d = r1(d, a, b, c, temp[5], 12, 0x4787c62a);
            c = r1(c, d, a, b, temp[6], 17, 0xa8304613);
            b = r1(b, c, d, a, temp[7], 22, 0xfd469501);
            a = r1(a, b, c, d, temp[8], 7, 0x698098d8);
            d = r1(d, a, b, c, temp[9], 12, 0x8b44f7af);
            c = r1(c, d, a, b, temp[10], 17, 0xffff5bb1);
            b = r1(b, c, d, a, temp[11], 22, 0x895cd7be);
            a = r1(a, b, c, d, temp[12], 7, 0x6b901122);
            d = r1(d, a, b, c, temp[13], 12, 0xfd987193);
            c = r1(c, d, a, b, temp[14], 17, 0xa679438e);
            b = r1(b, c, d, a, temp[15], 22, 0x49b40821);

            a = r2(a, b, c, d, temp[1], 5, 0xf61e2562);
            d = r2(d, a, b, c, temp[6], 9, 0xc040b340);
            c = r2(c, d, a, b, temp[11], 14, 0x265e5a51);
            b = r2(b, c, d, a, temp[0], 20, 0xe9b6c7aa);
            a = r2(a, b, c, d, temp[5], 5, 0xd62f105d);
            d = r2(d, a, b, c, temp[10], 9, 0x02441453);
            c = r2(c, d, a, b, temp[15], 14, 0xd8a1e681);
            b = r2(b, c, d, a, temp[4], 20, 0xe7d3fbc8);
            a = r2(a, b, c, d, temp[9], 5, 0x21e1cde6);
            d = r2(d, a, b, c, temp[14], 9, 0xc33707d6);
            c = r2(c, d, a, b, temp[3], 14, 0xf4d50d87);
            b = r2(b, c, d, a, temp[8], 20, 0x455a14ed);
            a = r2(a, b, c, d, temp[13], 5, 0xa9e3e905);
            d = r2(d, a, b, c, temp[2], 9, 0xfcefa3f8);
            c = r2(c, d, a, b, temp[7], 14, 0x676f02d9);
            b = r2(b, c, d, a, temp[12], 20, 0x8d2a4c8a);

            a = r3(a, b, c, d, temp[5], 4, 0xfffa3942);
            d = r3(d, a, b, c, temp[8], 11, 0x8771f681);
            c = r3(c, d, a, b, temp[11], 16, 0x6d9d6122);
            b = r3(b, c, d, a, temp[14], 23, 0xfde5380c);
            a = r3(a, b, c, d, temp[1], 4, 0xa4beea44);
            d = r3(d, a, b, c, temp[4], 11, 0x4bdecfa9);
            c = r3(c, d, a, b, temp[7], 16, 0xf6bb4b60);
            b = r3(b, c, d, a, temp[10], 23, 0xbebfbc70);
            a = r3(a, b, c, d, temp[13], 4, 0x289b7ec6);
            d = r3(d, a, b, c, temp[0], 11, 0xeaa127fa);
            c = r3(c, d, a, b, temp[3], 16, 0xd4ef3085);
            b = r3(b, c, d, a, temp[6], 23, 0x04881d05);
            a = r3(a, b, c, d, temp[9], 4, 0xd9d4d039);
            d = r3(d, a, b, c, temp[12], 11, 0xe6db99e5);
            c = r3(c, d, a, b, temp[15], 16, 0x1fa27cf8);
            b = r3(b, c, d, a, temp[2], 23, 0xc4ac5665);

            a = r4(a, b, c, d, temp[0], 6, 0xf4292244);
            d = r4(d, a, b, c, temp[7], 10, 0x432aff97);
            c = r4(c, d, a, b, temp[14], 15, 0xab9423a7);
            b = r4(b, c, d, a, temp[5], 21, 0xfc93a039);
            a = r4(a, b, c, d, temp[12], 6, 0x655b59c3);
            d = r4(d, a, b, c, temp[3], 10, 0x8f0ccc92);
            c = r4(c, d, a, b, temp[10], 15, 0xffeff47d);
            b = r4(b, c, d, a, temp[1], 21, 0x85845dd1);
            a = r4(a, b, c, d, temp[8], 6, 0x6fa87e4f);
            d = r4(d, a, b, c, temp[15], 10, 0xfe2ce6e0);
            c = r4(c, d, a, b, temp[6], 15, 0xa3014314);
            b = r4(b, c, d, a, temp[13], 21, 0x4e0811a1);
            a = r4(a, b, c, d, temp[4], 6, 0xf7537e82);
            d = r4(d, a, b, c, temp[11], 10, 0xbd3af235);
            c = r4(c, d, a, b, temp[2], 15, 0x2ad7d2bb);
            b = r4(b, c, d, a, temp[9], 21, 0xeb86d391);

            ABCDValue.A = unchecked(a + ABCDValue.A);
            ABCDValue.B = unchecked(b + ABCDValue.B);
            ABCDValue.C = unchecked(c + ABCDValue.C);
            ABCDValue.D = unchecked(d + ABCDValue.D);
            return;
        }

        //Manually unrolling these equations nets us a 20% performance improvement
        private static uint r1(uint a, uint b, uint c, uint d, uint x, int s, uint t)
        {
            //                                (b + LSR((a + F(b, c, d) + x + t), s))
            //F(x, y, z)            ((x & y) | ((x ^ 0xFFFFFFFF) & z))
            return unchecked(b + LSR((a + ((b & c) | ((b ^ 0xFFFFFFFF) & d)) + x + t), s));
        }

        private static uint r2(uint a, uint b, uint c, uint d, uint x, int s, uint t)
        {
            //                                (b + LSR((a + G(b, c, d) + x + t), s))
            //G(x, y, z)            ((x & z) | (y & (z ^ 0xFFFFFFFF)))
            return unchecked(b + LSR((a + ((b & d) | (c & (d ^ 0xFFFFFFFF))) + x + t), s));
        }

        private static uint r3(uint a, uint b, uint c, uint d, uint x, int s, uint t)
        {
            //                                (b + LSR((a + H(b, c, d) + k + i), s))
            //H(x, y, z)            (x ^ y ^ z)
            return unchecked(b + LSR((a + (b ^ c ^ d) + x + t), s));
        }

        private static uint r4(uint a, uint b, uint c, uint d, uint x, int s, uint t)
        {
            //                                (b + LSR((a + I(b, c, d) + k + i), s))
            //I(x, y, z)            (y ^ (x | (z ^ 0xFFFFFFFF)))
            return unchecked(b + LSR((a + (c ^ (b | (d ^ 0xFFFFFFFF))) + x + t), s));
        }

        // Implementation of left rotate
        // s is an int instead of a uint becuase the CLR requires the argument passed to >>/<< is of 
        // type int. Doing the demoting inside this function would add overhead.
        private static uint LSR(uint i, int s)
        {
            return ((i << s) | (i >> (32 - s)));
        }

        //Convert input array into array of UInts
        private static uint[] Converter(byte[] input, int ibStart)
        {
            if (null == input)
                throw new System.ArgumentNullException("input", "Unable convert null array to array of uInts");

            uint[] result = new uint[16];

            for (int i = 0; i < 16; i++)
            {
                result[i] = (uint)input[ibStart + i * 4];
                result[i] += (uint)input[ibStart + i * 4 + 1] << 8;
                result[i] += (uint)input[ibStart + i * 4 + 2] << 16;
                result[i] += (uint)input[ibStart + i * 4 + 3] << 24;
            }

            return result;
        }
    }
    class parserElement
    {
        public String text;
        public int index;
        public int endIndex;

        public parserElement(String text, int index)
        {
            this.text = text;
            this.index = index;
            this.endIndex = index + this.text.Length;
        }
    }

    class StringTokenizer
    {
        string[] array=null;
        int count=0;

        public StringTokenizer(string source, string delim)
        {
            int total=0;
            int pos = source.IndexOf(delim);
            while (pos >= 0)
            {
                total++;
                pos++;
                if (pos>=source.Length)
                {
                    break;
                }
                pos = source.IndexOf(delim, pos);
            }
            if (total > 0)
            {
                array = new string[total];
                total = 0;
                pos = source.IndexOf(delim);
                int oldPos = 0;
                while (pos >= 0)
                {
                    array[total]=source.Substring(oldPos, pos - oldPos);
                    oldPos = pos + 1;
                    total++;
                    if (oldPos >= source.Length)
                    {
                        break;
                    }
                    pos = source.IndexOf(delim, oldPos);
                }
            }
        }
        public int countTokens()
        {
            if (array != null)
            {
                return array.Length;
            }
            return 0;
        }
        public string nextToken()
        {
            if (array!=null)
            {
                return array[count++];
            }
            return "";
        }
    }
}
