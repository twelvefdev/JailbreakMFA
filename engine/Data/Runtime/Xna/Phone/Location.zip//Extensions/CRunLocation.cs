//----------------------------------------------------------------------------------
//
// CRUNLOCATION : GPS
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Application;
using System.Device.Location;

namespace RuntimeXNA.Extensions
{
    class CRunLocation : CRunExtension
    {
        const int CND_LOCENABLED=0;
        const int CND_NEWLOCATION=1;
        const int ACT_GETLOCATION=0;
        const int ACT_SETDISTANCEFILTER=1;
        const int ACT_SETACCURACY=2;
        const int EXP_LATITUDE=0;
        const int EXP_LONGITUDE=1;
        const int EXP_ALTITUDE=2;
        const int EXP_COURSE=3;
        const int EXP_SPEED=4;
        const int EXP_TIMELAST=5;
        const int EXP_DISTANCEFILTER=6;
        const int EXP_ACCURACY = 7;

        int newLocationCount;
        int distance;
        int accuracy;
        double altitude;
        double latitude;
        double longitude;
        double course;
        double speed;
        bool bEnabled;
        int deltaTime;
        GeoCoordinateWatcher watcher;

        public override int getNumberOfConditions()
        {
            return 2;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
        	distance=file.readAInt();
	        bEnabled=false;    

	        accuracy=file.readAInt();
            GeoPositionAccuracy a = GeoPositionAccuracy.Default;
            if (accuracy == 0)
            {
                a = GeoPositionAccuracy.High;
            }
            watcher = new GeoCoordinateWatcher(a);
            watcher.MovementThreshold = 20;
            watcher.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(StatusChanged);
            watcher.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(PositionChanged);

            return true;
        }
        public override void destroyRunObject(bool bFast)
        {
            watcher.Stop();
        }

        void StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            switch (e.Status)
            {
                case GeoPositionStatus.Disabled:
                    bEnabled = false;
                    break;
                case GeoPositionStatus.Initializing:
                    bEnabled = false;
                    break;
                case GeoPositionStatus.NoData:
                    bEnabled = false;
                    break;
                case GeoPositionStatus.Ready:
                    bEnabled = true;
                    break;

            }
        }

        void PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            latitude = e.Position.Location.Latitude;
            longitude = e.Position.Location.Longitude;
            altitude = e.Position.Location.Altitude;
            course = e.Position.Location.Course;
            speed = e.Position.Location.Speed;
            deltaTime = (int)ho.hoAdRunHeader.rhTimer;

	        newLocationCount=ho.getEventCount();
	        ho.pushEvent(CND_NEWLOCATION, 0);
        }

        public override bool condition(int num, CCndExtension cnd)
        {
	        switch (num)
	        {
		        case CND_NEWLOCATION:
			        return cndNewLocation();
		        case CND_LOCENABLED:
			        return bEnabled;
	        }
            return false;
        }

        bool cndNewLocation()
        {
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
		        return true;
	        }
	        if (ho.getEventCount() == newLocationCount)
	        {
		        return true;
	        }
	        return false;
        }
/*
        public override void action(int num, CActExtension act)
        {
		    case ACT_GETLOCATION:
			    break;
		    case ACT_SETDISTANCEFILTER:
                break;
		    case ACT_SETACCURACY:
			    break;
        }
*/
        // Expressions
        // --------------------------------------------
        public override CValue expression(int num)
        {
	        switch (num)
	        {
		        case EXP_LATITUDE:
			        return new CValue(latitude);
		        case EXP_LONGITUDE:
			        return new CValue(longitude);
		        case EXP_ALTITUDE:
			        return new CValue(altitude);
		        case EXP_COURSE:
			        return new CValue(course);
		        case EXP_SPEED:
			        return new CValue(speed);
		        case EXP_TIMELAST:
			        return new CValue(deltaTime);
		        case EXP_DISTANCEFILTER:
			        return new CValue(distance);
		        case EXP_ACCURACY:
			        return new CValue(accuracy);
	        }
	        return null;
        }

    }
}
