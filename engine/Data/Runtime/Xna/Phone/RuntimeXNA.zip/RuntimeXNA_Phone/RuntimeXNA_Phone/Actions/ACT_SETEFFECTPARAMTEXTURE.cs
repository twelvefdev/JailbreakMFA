﻿// -----------------------------------------------------------------------------
//
// SET EFFECT PARAM TEXTURE
//
// -----------------------------------------------------------------------------
using System;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Params;
using RuntimeXNA.Objects;
using RuntimeXNA.Sprites;
namespace RuntimeXNA.Actions
{
    class ACT_EXTSETEFFECTPARAMTEXTURE : CAct
    {
        public override void execute(CRun rhPtr)
        {
        }
    }
}
