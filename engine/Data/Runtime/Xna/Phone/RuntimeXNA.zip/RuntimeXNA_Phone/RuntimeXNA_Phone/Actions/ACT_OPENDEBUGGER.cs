// -----------------------------------------------------------------------------
//
// OPEN DEBUGGER
//
// -----------------------------------------------------------------------------
using System;
using RuntimeXNA.RunLoop;
namespace RuntimeXNA.Actions
{
	
	public class ACT_OPENDEBUGGER:CAct
	{
		public override void  execute(CRun rhPtr)
		{
			
		}
	}
}