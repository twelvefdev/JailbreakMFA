//----------------------------------------------------------------------------------
//
// CRUNMultipleTouch
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input.Touch;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Events;
using System.IO.IsolatedStorage;
using RuntimeXNA.Application;
using RuntimeXNA.Sprites;
namespace RuntimeXNA.Extensions 
{
    class CRunMultipleTouch : CRunExtension, ITouches
    {
        const int CND_NEWTOUCH=0;
        const int CND_ENDTOUCH=1;
        const int CND_NEWTOUCHANY=2;
        const int CND_ENDTOUCHANY=3;
        const int CND_TOUCHMOVED=4;
        const int CND_TOUCHACTIVE=5;
        const int CND_NEWTOUCHOBJECT=6;
        const int CND_TOUCHACTIVEOBJECT=7;
        const int CND_NEWPITCH=8;
        const int CND_PITCHACTIVE=9;
        const int CND_NEWGESTURE=10;
        const int CND_LAST = 11;

        const int ACT_SETORIGINX=0;
        const int ACT_SETORIGINY=1;
        const int ACT_RECOGNIZE=2;
        const int ACT_SETRECOGNITION=3;
        const int ACT_SETZONE=4;
        const int ACT_SETZONECOORD=5;
        const int ACT_LOADINI=6;
        const int ACT_RECOGNIZEG=7;
        const int ACT_CLEARGESTURES=8;
        const int EXP_GETNUMBER=0;
        const int EXP_GETLAST=1;
        const int EXP_MTGETX=2;
        const int EXP_MTGETY=3;
        const int EXP_GETLASTNEWTOUCH=4;
        const int EXP_GETLASTENDTOUCH=5;
        const int EXP_GETORIGINX=6;
        const int EXP_GETORIGINY=7;
        const int EXP_GETDELTAX=8;
        const int EXP_GETDELTAY=9;
        const int EXP_GETTOUCHANGLE=10;
        const int EXP_GETDISTANCE = 11;
        const int EXP_PITCHDISTANCE = 12;
        const int EXP_PITCHANGLE = 13;
        const int EXP_PITCHPERCENTAGE = 14;
        const int EXP_RECOGNIZEDNAME = 15;
        const int EXP_RECOGNIZEDPERCENT = 16;
        const int EMPTYTOUCH = 0x7AEDC0F5;
        const int MTFLAG_RECOGNITION = 0x0001;
        const int MTFLAG_AUTO=0x0002;      

	    int newTouchCount;
	    int endTouchCount;
	    int movedTouchCount;
	    int[] touchesID;
	    int[] touchesX;
	    int[] touchesY;
	    int[] startX;
	    int[] startY;
	    int[] dragX;
	    int[] dragY;
	    int[] touchesNew;
	    int[] touchesEnd;
	    int lastTouch;
	    int lastNewTouch;
	    int lastEndTouch;
        int maxTouches;
        CArrayList touchArray;
        string gestureName;
        int gestureNumber;
        double gesturePercent;
        int width;
        int height;
        int flags;
        int depth;
        int pitch1;
        int pitch2;
        int newPitchCount;
        int pitchDistance;
        int touchXPrevious, touchYPrevious;
        PDollarRecognizer recognizer;
        short OiUnder;
        int newGestureCount;

        public override int getNumberOfConditions()
        {
            return CND_LAST;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            width = file.readAShort();
            height = file.readAShort();
            flags = file.readAInt();
            depth = file.readAShort();
            string text = file.readAString();
            if ((flags & MTFLAG_RECOGNITION)!=0)
            {
                createRecognizer();
                addGestures(getStrings(text));
                touchArray = new CArrayList();
            }

            maxTouches = ho.hoAdRunHeader.rhApp.numberOfTouches;
            touchesID=new int[maxTouches];
            touchesX = new int[maxTouches];
            touchesY = new int[maxTouches];
            startX = new int[maxTouches];
            startY = new int[maxTouches];
            dragX = new int[maxTouches];
            dragY = new int[maxTouches];
            touchesNew = new int[maxTouches];
            touchesEnd = new int[maxTouches];

            newPitchCount=-1;
            newTouchCount = -1;
            endTouchCount = -1;
            movedTouchCount = -1;
            lastNewTouch = -1;
            lastEndTouch = -1;
            lastTouch = -1;
            pitch1=pitch2=-1;
            newGestureCount=1;

            int n;
            for (n = 0; n < maxTouches; n++)
            {
                touchesID[n] = EMPTYTOUCH;
                touchesX[n] = -1;
                touchesY[n] = -1;
                touchesNew[n] = 0;
                touchesEnd[n] = 0;
                startX[n] = 0;
                startY[n] = 0;
                dragX[n] = 0;
                dragY[n] = 0;
            }
            ho.hoAdRunHeader.touches = this;
            return true;
        }

        public override void destroyRunObject(bool bFast)
        {
            ho.hoAdRunHeader.touches = null;
        }

        public override int handleRunObject()
        {
            int n;
            for (n = 0; n < maxTouches; n++)
            {
                if (touchesNew[n] > 0)
                {
                    touchesNew[n]--;
                }
                if (touchesEnd[n] > 0)
                {
                    touchesEnd[n]--;
                }
            }
            return 0;
        }

        public bool touchBegan(TouchLocation touch)
        {
	        int n;
	        for (n=0; n<maxTouches; n++)
	        {
		        if (touchesID[n]==touch.Id)
		        {
			        break;
		        }
		        if (touchesID[n]==EMPTYTOUCH)
		        {
			        break;
		        }
	        }
	        if (n<maxTouches && touchesID[n]==EMPTYTOUCH)
	        {
		        touchesID[n]=touch.Id;
		        touchesX[n]=(int)touch.Position.X;
                touchesY[n] = (int)touch.Position.Y;
                startX[n] = (int)touch.Position.X;
                dragX[n] = (int)touch.Position.X;
                startY[n] = (int)touch.Position.Y;
                dragY[n] = (int)touch.Position.Y;
		        touchesNew[n]=2;
		        lastTouch=n;
		        lastNewTouch=n;
		        newTouchCount=ho.getEventCount();
		        ho.generateEvent(CND_NEWTOUCH, 0);
		        ho.generateEvent(CND_NEWTOUCHANY, 0);
	        
     	        this.callObjectConditions(this.touchesX[n], this.touchesY[n]);

                if (this.pitch1<0)
	            {
	        	    this.pitch1=n;
	            }
	            else if (this.pitch2<0)
	            {
	        	    this.pitch2=n;
		            this.ho.generateEvent(CRunMultipleTouch.CND_NEWPITCH, 0);
		            this.newPitchCount=this.ho.getEventCount();
		            this.pitchDistance=this.getDistance();
		        }
	            else
	            {
	        	    this.pitch1=-1;
	        	    this.pitch2=-1;
	            }	                	
	        
	            if ((this.flags&CRunMultipleTouch.MTFLAG_RECOGNITION)!=0)
	            {
	        	    if (this.touchesX[n]>=this.ho.hoX && this.touchesX[n]<this.ho.hoX+this.width && this.touchesY[n]>=this.ho.hoY && this.touchesY[n]<this.ho.hoY+this.height)
	        	    {	        	
		        	    if (this.touchArray.size()>=this.depth)
		        	    {
		        		    this.touchArray.remove(0);
		        	    }
                        int l = this.touchArray.size();
                        this.touchArray.add(new CArrayList());
					    ((CArrayList)this.touchArray.get(l)).add(this.touchesX[n]);
					    ((CArrayList)this.touchArray.get(l)).add(this.touchesY[n]);
                        touchXPrevious=touchYPrevious=0x7FFFFFFF;
				    }
	            }        	
            
            }
	        return true;
        }

        public void touchMoved(TouchLocation touch)
        {
	        int n;
	        for (n=0; n<maxTouches; n++)
	        {
		        if (touchesID[n]==touch.Id)
		        {
			        touchesX[n]=(int)touch.Position.X;
			        touchesY[n]=(int)touch.Position.Y;
			        dragX[n]=(int)touch.Position.X;
			        dragY[n]=(int)touch.Position.Y;
			        lastTouch=n;
			        ho.generateEvent(CND_TOUCHMOVED, 0);

		            if ((this.flags&MTFLAG_RECOGNITION)!=0)
		            {
		        	    if (this.touchesX[n]!=this.touchXPrevious || this.touchesY[n]!=this.touchYPrevious)
		        	    {
		        		    this.touchXPrevious=this.touchesX[n];
		        		    this.touchYPrevious=this.touchesY[n];
						    ((CArrayList)this.touchArray.get(this.touchArray.size()-1)).add(this.touchesX[n]);
						    ((CArrayList)this.touchArray.get(this.touchArray.size()-1)).add(this.touchesY[n]);
		        	    }
		            }
                    break;
		        }
	        }
        }

        public void touchEnded(TouchLocation touch)
        {
	        int n;
	        for (n=0; n<maxTouches; n++)
	        {
		        if (touchesID[n]==touch.Id)
		        {
			        touchesX[n]=(int)touch.Position.X;
			        touchesY[n]=(int)touch.Position.Y;
			        dragX[n]=(int)touch.Position.X;
			        dragY[n]=(int)touch.Position.Y;
			        touchesID[n]=EMPTYTOUCH;
			        touchesEnd[n]=2;
			        lastTouch=n;
			        lastEndTouch=n;
			        endTouchCount=ho.getEventCount();

		            if (n==this.pitch1)
		        	    this.pitch1=-1;
		            else if (n==this.pitch2)
		        	    this.pitch2=-1;
		        	
		            if ((this.flags&MTFLAG_RECOGNITION)!=0)
		            {
		        	    if (this.touchesX[n]!=this.touchXPrevious || this.touchesY[n]!=this.touchYPrevious)
		        	    {
						    ((CArrayList)this.touchArray.get(this.touchArray.size()-1)).add(this.touchesX[n]);
						    ((CArrayList)this.touchArray.get(this.touchArray.size()-1)).add(this.touchesY[n]);
		        	    }
		            }

                    ho.generateEvent(CND_ENDTOUCH, 0);
                    ho.generateEvent(CND_ENDTOUCHANY, 0);

                    break;
		        }
	        }
        }

	    private void createRecognizer()
	    {
		    if ((this.flags&MTFLAG_RECOGNITION)!=0)
		    {
			    if (this.recognizer==null)
			    {
				    this.recognizer=new PDollarRecognizer();
			    }
		    }
	    }

	    void addGestures(string[] strings)
	    {
		    int number, end;
            string name;
		    int line=0;
            int start=0;
            int count = 0;
		    while(true)
		    {
			    for (; line<strings.Length; line++)
			    {
                    start=strings[line].IndexOf("[");
				    if (start>=0)
				    {
                        start++;
					    break;
				    }
			    }
			    if (line>=strings.Length)
				    break;
			    end=strings[line].IndexOf("]", start);
			    if (end<0)
				    continue;
			    name=strings[line].Substring(1, end-1);

                Point[] points = new Point[1];
                count = 0;
			    for (line++, number=0; line<strings.Length; number++, line++)
			    {
				    int equal=strings[line].IndexOf("=");
				    if (equal<0)
					    break;
					
				    string str=strings[line].Substring(equal+1);
				    int bracket=0;
				    int comma, x, y;

                    int size=0, pos=0;
                    while((pos=str.IndexOf("(", pos+1))>=0)
                        size++;
                    Array.Resize(ref points, points.Length+size);
				    while(true)
				    {
					    bracket=str.IndexOf("(", bracket);
					    if (bracket<0)
						    break;
					    comma=str.IndexOf(",", bracket);
					    if (comma<0)
						    break;
                        try
                        {
					        x=System.Convert.ToInt32(str.Substring(bracket+1, comma-(bracket+1)), 10);
					        bracket=str.IndexOf(")", comma);
					        if (bracket<0)
						        break;	
					        y=System.Convert.ToInt32(str.Substring(comma+1, bracket-(comma+1)), 10);
                        }
                        catch(FormatException e)
                        {
                            e.GetType();
                            break;
                        }
                        catch (ArgumentOutOfRangeException e)
                        {
                            e.GetType();
                            break;
                        }
					    points[count++]=new Point(x, y, number);
				    }
			    }
			    this.recognizer.AddGesture(name, points);
		    }
	    }

	    void recognize(int depth, string name)
	    {
		    this.createRecognizer();
		
		    int position;
		    Point[] points=new Point[0];
		
		    for (position=0; position<depth; position++)
		    {
			    if (position>=this.touchArray.size())
				    break;

			    CArrayList t=(CArrayList)this.touchArray.get(this.touchArray.size()-position-1);
                int l = points.Length;
				Array.Resize(ref points, l+t.size()/2);
			    int n;
                int count = 0;
			    for (n=0; n<t.size()/2; n++)
			    {
				    points[l+n]=new Point((int)t.get(n*2), (int)t.get(n*2+1), position);
                    count++;
			    }
                if (count <= 1)
                {
                    this.gestureNumber = -1;
                    this.gesturePercent = 0;
                    this.gestureName = "";
                }
		    }
		    this.recognizer.Recognize(points, name);
		    this.gestureNumber=this.recognizer.gestureNumber;
		    this.gesturePercent=this.recognizer.gesturePercent;
		    this.gestureName=this.recognizer.gestureName;
		    if (this.gestureNumber>=0)
		    {
                this.newGestureCount = ho.getEventCount();
	            this.ho.generateEvent(CRunMultipleTouch.CND_NEWGESTURE, 0);
		    }
	    }

        public void touchCancelled(TouchLocation touch)
        {
            touchEnded(touch);
        }

        public override bool condition(int num, CCndExtension cnd)
        {
	        switch (num)
	        {
		        case CND_NEWTOUCH:
			        return cndNewTouch(cnd);
		        case CND_ENDTOUCH:
			        return cndEndTouch(cnd);
		        case CND_NEWTOUCHANY:
			        return cndNewTouchAny(cnd);
		        case CND_ENDTOUCHANY:
			        return cndEndTouchAny(cnd);
		        case CND_TOUCHMOVED:
			        return cndTouchMoved(cnd);
		        case CND_TOUCHACTIVE:
			        return cndTouchActive(cnd);
	            case CND_NEWTOUCHOBJECT:
		            return this.cndNewTouchObject(cnd);
	            case CND_TOUCHACTIVEOBJECT:
		            return this.isActiveRoutine(cnd.getParamExpression(this.rh, 0), cnd.getParamObject(this.rh, 1).oiList);
    	        case CND_NEWPITCH:
	        	    return this.cndNewPitch(cnd);
	            case CND_PITCHACTIVE:
	        	    return this.cndPitchActive(cnd);	
	            case CND_NEWGESTURE:
	        	    return this.cndNewGesture(cnd);        		        
	        }
	        return false;
        }

	    private void callObjectConditions(int x, int y)
	    {
		    CRun rhPtr=this.ho.hoAdRunHeader;
		
		    CArrayList list=new CArrayList();
		    CObject pHox;
            int count=0, i;
		    for (i=0; i<rhPtr.rhNObjects; i++)
		    {
		        while(rhPtr.rhObjectList[count]==null)
				    count++;
		        pHox=rhPtr.rhObjectList[count];
		        count++;

			    if (this.isObjectUnder(pHox, x, y))
			    {
				    list.add(pHox);
			    }
		    }
            for (count = 0; count < list.size(); count++)
            {
                pHox = (CObject)list.get(count);
                this.OiUnder = pHox.hoOi;
	            this.ho.generateEvent(CRunMultipleTouch.CND_NEWTOUCHOBJECT, 0);
            }
	    }

	    private bool isObjectUnder(CObject pHox, int x, int y)
	    {
		    int x1, y1, x2, y2;
		    CRun rhPtr=this.ho.hoAdRunHeader;

		    x1=pHox.hoX-pHox.hoImgXSpot;
		    y1=pHox.hoY-pHox.hoImgYSpot;
		    x2=x1+pHox.hoImgWidth;
		    y2=y1+pHox.hoImgHeight;
			int mx = x - rhPtr.rhWindowX;
			int my = y - rhPtr.rhWindowY;
		    if (x>=x1 && x<x2 && y>=y1 && y<y2)
		    {
                if ((pHox.hoFlags & CObject.HOF_DESTROYED) == 0)
                {
				    if (pHox.hoType==COI.OBJ_SPR)
				    {
                        return (rhPtr.rhApp.spriteGen.spriteCol_TestPointOne(pHox.roc.rcSprite, CSpriteGen.LAYER_ALL, mx, my, 0) != null);
                    }
				    else
				    {
					    return true;
				    }
                }
		    }
		    return false;		
	    }

	    private bool isActiveRoutine(int touch, short oiList)
	    {
            if (touch>=0 && touch<this.maxTouches)
            {
	            if (this.touchesID[touch]!=0)
	            {
				    CRun rhPtr=this.ho.hoAdRunHeader;
				    CEventProgram rhEvtProg=rhPtr.rhEvtProg;
				
		            CObject rh2EventPrev=rhEvtProg.rh2EventPrev;
		            CObjInfo rh2EventPrevOiList = rhEvtProg.rh2EventPrevOiList;
		            CObject rh2EventPos = rhEvtProg.rh2EventPos;
		            int rh2EventPosOiList = rhEvtProg.rh2EventPosOiList;
		            int evtNSelectedObjects = rhEvtProg.evtNSelectedObjects;
				
				    bool result=false;
				    do
				    {
					    CObject pHo=rhPtr.rhEvtProg.evt_FirstObject(oiList);
					    if (pHo==null)
						    break;
                        int count = rhPtr.rhEvtProg.evtNSelectedObjects;    
					
					    do
					    {		
					        if (!this.isObjectUnder(pHo, this.touchesX[touch], this.touchesY[touch]))
					        {
							    count--;
							    rhPtr.rhEvtProg.evt_DeleteCurrentObject();
					        }		    
					        pHo=rhPtr.rhEvtProg.evt_NextObject();
					    } while(pHo!=null);
					
					    result=(count!=0);
				    }while(false);
		
		            rhEvtProg.rh2EventPrev=rh2EventPrev;
		            rhEvtProg.rh2EventPrevOiList=rh2EventPrevOiList;
		            rhEvtProg.rh2EventPos=rh2EventPos;
		            rhEvtProg.rh2EventPosOiList=rh2EventPosOiList;
		            rhEvtProg.evtNSelectedObjects=evtNSelectedObjects;
		        
		            return result;
	            }
            }
            return false;
	    }

        private bool cndNewTouchObject(CCndExtension cnd)
        {
            if ((this.ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
            {
                return this.OiUnder == cnd.getParamObject(this.rh, 0).oi;
            }
            if (this.ho.getEventCount() == this.newTouchCount)
            {
                return this.isActiveRoutine(this.lastNewTouch, cnd.getParamObject(this.rh, 0).oiList);
            }
            return false;
        }

        bool cndNewTouch(CCndExtension cnd)
        {
	        int touch=cnd.getParamExpression(rh, 0);
	        bool bTest=false;
	        if (touch<0)
	        {
		        bTest=true;
	        }
	        if (touch>=0 && touch<maxTouches)
	        {
		        if (touchesNew[touch]!=0)
		        {
			        bTest=true;
		        }
	        }
	        if (bTest)
	        {
		        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		        {
			        return true;
		        }
		        if (ho.getEventCount()==newTouchCount)
		        {
			        return true;
		        }
	        }
	        return false;
        }

        bool cndNewTouchAny(CCndExtension cnd)
        {
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
		        return true;
	        }
	        if (ho.getEventCount() == newTouchCount)
	        {
		        return true;
	        }
	        return false;
        }

        bool cndEndTouchAny(CCndExtension cnd)
        {
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
		        return true;
	        }
	        if (ho.getEventCount() == endTouchCount)
	        {
		        return true;
	        }
	        return false;
        }

        bool cndEndTouch(CCndExtension cnd)
        {
	        int touch=cnd.getParamExpression(rh, 0);
	        bool bTest=false;
	        if (touch<0)
	        {
		        bTest=true;
	        }
	        if (touch>=0 && touch<maxTouches)
	        {
		        if (touchesEnd[touch]!=0)
		        {
			        bTest=true;
		        }
	        }
	        if (bTest)
	        {
		        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		        {
			        return true;
		        }
		        if (ho.getEventCount() == endTouchCount)
		        {
			        return true; 
		        }
	        }
	        return false;
        }

        bool cndTouchMoved(CCndExtension cnd)
        {
	        int touch=cnd.getParamExpression(rh, 0);
	        bool bTest=false;
	        if (touch<0)
	        {
		        bTest=true;
	        }
	        if (touch==lastTouch)
	        {
		        bTest=true;
	        }
	        if (bTest)
	        {
		        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		        {
			        return true;
		        }
		        if (ho.getEventCount() == movedTouchCount)
		        {
			        return true;
		        }
	        }
	        return false;
        }

        bool cndTouchActive(CCndExtension cnd)
        {
	        int touch=cnd.getParamExpression(rh, 0);
	        if (touch>=0 && touch<maxTouches)
	        {
		        if (touchesID[touch]!=EMPTYTOUCH)
		        {
			        return true;
		        }
	        }
	        return false;
        }

        private bool cndNewPitch(CCndExtension cnd)
        {
            if ((this.ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
            {
	            return true;
            }         
            if (this.ho.getEventCount() == this.newPitchCount)
            {
	            return true;
            }                     
            return false;
        }

        private bool cndNewGesture(CCndExtension cnd)
        {
            if ((this.ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
            {
	            return true;
            }         
            if (this.ho.getEventCount() == this.newGestureCount)
            {
	            return true;
            }                     
            return false;
        }

	    private bool cndPitchActive(CCndExtension cnd)
	    {
		    return (this.pitch1>=0 && this.pitch2>=0);
	    }

        public override void action(int num, CActExtension act)
        {
	        switch (num)
	        {
		        case ACT_SETORIGINX:
			        setOriginX(act);
			        break;
		        case ACT_SETORIGINY:
			        setOriginY(act);
			        break;
			    case ACT_RECOGNIZE:
				    this.actRecognize(act);
				    break;
			    case ACT_SETRECOGNITION:
				    this.actSetRecognition(act);
				    break;
			    case ACT_SETZONE:
				    this.actSetZone(act);
                    break;
			    case ACT_SETZONECOORD:
				    this.actSetZoneCoords(act);
				    break;
			    case ACT_LOADINI:
				    this.actLoadIni(act);
				    break;
			    case ACT_RECOGNIZEG:
				    this.actRecognizeG(act);
				    break;
			    case ACT_CLEARGESTURES:
				    this.actClearGestures();
				    break;
	        }
        }

        private void actSetZone(CActExtension act)
        {
    	    PARAM_ZONE zone=act.getParamZone(this.rh, 0);
    	    this.ho.hoX=zone.x1;
    	    this.ho.hoY=zone.y1;
    	    this.width=zone.x2-zone.x1;
    	    this.height=zone.y2-zone.y1;
        }
        private void actSetZoneCoords(CActExtension act)
        {
    	    this.ho.hoX=act.getParamExpression(this.rh, 0);
    	    this.ho.hoY=act.getParamExpression(this.rh, 1);
    	    this.width=act.getParamExpression(this.rh, 2);
    	    this.height=act.getParamExpression(this.rh, 3);    	
        }
        private string[] getStrings(string text)
        {
            int end, end1, end2, begin=0;
            string[] strings=new string[0];
    	    while(begin<text.Length)
    	    {
      		    end1=text.IndexOf((Char)10, begin);
      		    end2=text.IndexOf((Char)13, begin);
                if (end1 < 0)
                    end1 = text.Length;
                if (end2 < 0)
                    end2 = text.Length;
      		    end=Math.Min(end1, end2);
                int p=strings.Length;
                Array.Resize(ref strings, strings.Length+1);
      		    strings[p]=text.Substring(begin, end-begin);
      		    begin=Math.Max(end1+1, end2+1);
		    }	    	    	    
		    return strings;	
        }
        string cleanName(string name)
        {
            int pos = name.LastIndexOf('\\');
            if (pos < 0)
            {
                pos = name.LastIndexOf('/');
            }
            if (pos >= 0 && pos + 1 < name.Length)
            {
                name = name.Substring(pos + 1);
            }
            return name;
        }
        public CFile loadFromProject(string name)
        {
            CFile cfile = null;
            CEmbeddedFile efile = rh.rhApp.getEmbeddedFile(name);
            if (efile!=null)
            {
                cfile = efile.open();
            }
            if (cfile==null)
            {
                int pos = name.LastIndexOf('.');
                if (pos >= 0)
                {
                    name = name.Substring(0, pos);
                }
                BinaryRead.Data iniFile = null;
                try
                {
                    iniFile = rh.rhApp.content.Load<BinaryRead.Data>(name);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
                if (iniFile != null)
                {
                    cfile = new CFile(iniFile.data);
                }
            }
            return cfile;
        }
        private CFile GetCFile(string path)
        {
            CFile cFile=null;
            using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (isf.FileExists(path))
                {
                    using (IsolatedStorageFileStream isfs = new IsolatedStorageFileStream(path, FileMode.Open, isf))
                    {
                        using (BinaryReader reader = new BinaryReader(isfs))
                        {
                            int length=(int)reader.BaseStream.Length;
                            byte[] data=new byte[length];
                            try
                            {
                                reader.Read(data, 0, length);
                            }
                            catch (IOException e)
                            {
                                e.GetType();
                            }
                            reader.Close();
                            reader.Dispose();
                            cFile=new CFile(data);
                        }
                    }
                }
                else
                {
                    loadFromProject(path);
                }
                isf.Dispose();
            } 
            return cFile;
        }
        private void actLoadIni(CActExtension act)
        {
    	    if ((this.flags&CRunMultipleTouch.MTFLAG_RECOGNITION)!=0)
    	    {
    		    this.createRecognizer();
	    
                string path = cleanName(act.getParamFilename(rh, 0));
                CFile file = GetCFile(path);
    	    	string[] strings=new string[0];	    	
                if (file != null)
                {
				    while(!file.isEOF())
                    {
                        int l=strings.Length;
                        Array.Resize(ref strings, l+1);
					    strings[l]=file.readAStringEOL();
		            }
			    }
			    if (strings.Length>0)
			    {
				    this.addGestures(strings);
			    }
		    }
        }
        private void actClearGestures()
        {
    	    if ((this.flags&MTFLAG_RECOGNITION)==0)
    	    {
    		    this.createRecognizer();
    		    this.recognizer.ClearGestures();
    	    }
        }
	    private void actRecognize(CActExtension act)
	    {
		    if ((this.flags&CRunMultipleTouch.MTFLAG_RECOGNITION)!=0)
		    {
			    int depth=act.getParamExpression(this.rh, 0);
			    if (depth<0)
				    depth=1;
			    if (depth>this.depth)
				    depth=this.depth;
			    this.recognize(depth, null);
		    }
	    }
	    private void actRecognizeG(CActExtension act)
	    {
		    if ((this.flags&CRunMultipleTouch.MTFLAG_RECOGNITION)!=0)
		    {
			    string name=act.getParamExpString(this.rh, 0);
			    int depth=act.getParamExpression(this.rh, 1);
			    if (depth<0)
				    depth=1;
			    if (depth>this.depth)
				    depth=this.depth;
			    this.recognize(depth, name);
		    }
	    }
	    private void actSetRecognition(CActExtension act)
	    {
		    int onOff=act.getParamExpression(this.rh, 0);
		    int d=act.getParamExpression(this.rh, 1);
            if (d < 1)
                d = 1;
            if (d > 10)
                d = 10;
            depth = d;

		    if (onOff!=0)
		    {
			    this.flags=this.flags|CRunMultipleTouch.MTFLAG_RECOGNITION;
			    this.touchArray=new CArrayList();
		    }
		    else
		    {
			    this.flags&=~CRunMultipleTouch.MTFLAG_RECOGNITION;
			    this.touchArray=null;
		    }
	    }

        void setOriginX(CActExtension act)
        {
	        int touch=act.getParamExpression(rh, 0);
	        int coord=act.getParamExpression(rh, 1);
	
	        if (touch>=0 && touch<maxTouches)						   
	        {
		        startX[touch]=coord-rh.rhWindowX;
	        }							   
        }
        void setOriginY(CActExtension act)
        {
	        int touch=act.getParamExpression(rh, 0);
	        int coord=act.getParamExpression(rh, 1);
	
	        if (touch>=0 && touch<maxTouches)						   
	        {
		        startY[touch]=coord-rh.rhWindowY;
	        }							   
        }

        public override CValue expression(int num)
        {
	        switch (num)
	        {
		        case EXP_GETNUMBER:
			        return expGetNumber();
		        case EXP_GETLAST:
			        return new CValue(lastTouch);
		        case EXP_MTGETX:
			        return expGetX();
		        case EXP_MTGETY:
			        return expGetY();
		        case EXP_GETLASTNEWTOUCH:
			        return new CValue(lastNewTouch);
		        case EXP_GETLASTENDTOUCH:
			        return new CValue(lastEndTouch);
		        case EXP_GETORIGINX:
			        return expGetOriginX();
		        case EXP_GETORIGINY:
			        return expGetOriginY();
		        case EXP_GETDELTAX:
			        return expGetDeltaX();
		        case EXP_GETDELTAY:
			        return expGetDeltaY();
		        case EXP_GETTOUCHANGLE:
			        return expGetAngle();
		        case EXP_GETDISTANCE:
			        return expGetDistance();
	            case EXP_PITCHDISTANCE:
		            return this.expPitchDistance();
	            case EXP_PITCHANGLE:
		            return this.expPitchAngle();
                case EXP_PITCHPERCENTAGE:
                    return this.expPitchPercentage();
	            case EXP_RECOGNIZEDNAME:
		            return new CValue(this.gestureName);
	            case EXP_RECOGNIZEDPERCENT:
		            return new CValue((int)(this.gesturePercent*100));
	        }
	        return null;
        }

	    private CValue expPitchAngle()
	    {
            CValue ret=new CValue(-1);
		    if (this.pitch1>=0 && this.pitch2>=0)
		    {
	            int deltaX=this.touchesX[this.pitch2]-this.touchesX[this.pitch1];
	            int deltaY=this.touchesY[this.pitch2]-this.touchesY[this.pitch1];
	            double angle=Math.Atan2(-deltaY,deltaX)*57.295779513082320876798154814105;
	            if (angle<0)
	            {
		            angle=360.0+angle;
	            }
	            ret.forceInt((int)angle);  
	        }
	        return ret;	
	    }
        private int getDistance()
        {
		    if (this.pitch1>=0 && this.pitch2>=0)
		    {
	            int deltaX=this.touchesX[this.pitch2]-this.touchesX[this.pitch1];
	            int deltaY=this.touchesY[this.pitch2]-this.touchesY[this.pitch1];
	            return (int)Math.Sqrt(deltaX*deltaX+deltaY*deltaY);
	        }
            return -1;
        }
	    private CValue expPitchDistance()
	    {
	        return new CValue(getDistance());	    
	    }
	    private CValue expPitchPercentage()
	    {
            CValue ret=new CValue(-1);
		    int distance=getDistance();
		    if (distance>=0 && this.pitchDistance>0)
		    {
			    double percent=(distance/this.pitchDistance)*100;
			    ret.forceInt((int)percent);
		    }
		    return ret;
	    }

        CValue expGetNumber()
        {
	        int count=0;
	        int n;
	        for (n=0; n<maxTouches; n++)
	        {
		        if (touchesID[n]!=EMPTYTOUCH)
		        {
			        count++;
		        }
	        }
	        return new CValue(count);
        }
        CValue expGetX()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(touchesX[touch]+rh.rhWindowX);
	        }
	        return new CValue(-1);
        }
        CValue expGetY()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(touchesY[touch]+rh.rhWindowY);
	        }
	        return new CValue(-1);
        }
        CValue expGetOriginX()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(startX[touch]+rh.rhWindowX);
	        }
	        return new CValue(-1);
        }
        CValue expGetOriginY()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(startY[touch]+rh.rhWindowY);
	        }
	        return new CValue(-1);
        }
        CValue expGetDeltaX()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(dragX[touch]-startX[touch]);
	        }
	        return new CValue(-1);
        }
        CValue expGetDeltaY()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(dragY[touch]-startY[touch]);
	        }
	        return new CValue(-1);
        }
        CValue expGetAngle()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        int deltaX=dragX[touch]-startX[touch];
		        int deltaY=dragY[touch]-startY[touch];
		        double angle=Math.Atan2(-deltaY,deltaX)*57.295779513082320876798154814105;
		        if (angle<0)
		        {
			        angle=360.0+angle;
		        }
		        return new CValue((int)angle);
	        }
	        return new CValue(-1);
        }
        CValue expGetDistance()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        int deltaX=dragX[touch]-startX[touch];
		        int deltaY=dragY[touch]-startY[touch];
		        double distance=Math.Sqrt(deltaX*deltaX+deltaY*deltaY);
		        return new CValue((int)distance);
	        }
            return new CValue(-1);
        }



        /**
         * The $P Point-Cloud Recognizer (JavaScript version)
         *
         * 	Radu-Daniel Vatavu, Ph.D.
         *	University Stefan cel Mare of Suceava
         *	Suceava 720229, Romania
         *	vatavu@eed.usv.ro
         *
         *	Lisa Anthony, Ph.D.
         *      UMBC
         *      Information Systems Department
         *      1000 Hilltop Circle
         *      Baltimore, MD 21250
         *      lanthony@umbc.edu
         *
         *	Jacob O. Wobbrock, Ph.D.
         * 	The Information School
         *	University of Washington
         *	Seattle, WA 98195-2840
         *	wobbrock@uw.edu
         *
         * The academic publication for the $P recognizer, and what should be 
         * used to cite it, is:
         *
         *	Vatavu, R.-D., Anthony, L. and Wobbrock, J.O. (2012).  
         *	  Gestures as point clouds: A $P recognizer for user interface 
         *	  prototypes. Proceedings of the ACM Int'l Conference on  
         *	  Multimodal Interfaces (ICMI '12). Santa Monica, California  
         *	  (October 22-26, 2012). New York: ACM Press, pp. 273-280.
         *
         * This software is distributed under the "New BSD License" agreement:
         *
         * Copyright (c) 2012, Radu-Daniel Vatavu, Lisa Anthony, and 
         * Jacob O. Wobbrock. All rights reserved.
         *
         * Redistribution and use in source and binary forms, with or without
         * modification, are permitted provided that the following conditions are met:
         *    * Redistributions of source code must retain the above copyright
         *      notice, this list of conditions and the following disclaimer.
         *    * Redistributions in binary form must reproduce the above copyright
         *      notice, this list of conditions and the following disclaimer in the
         *      documentation and/or other materials provided with the distribution.
         *    * Neither the names of the University Stefan cel Mare of Suceava, 
         *	University of Washington, nor UMBC, nor the names of its contributors 
         *	may be used to endorse or promote products derived from this software 
         *	without specific prior written permission.
         *
         * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
         * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
         * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
         * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Radu-Daniel Vatavu OR Lisa Anthony
         * OR Jacob O. Wobbrock BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
         * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
         * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
         * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
         * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
         * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
         * SUCH DAMAGE.
        **/
        class Point
        {
            public double X, Y;
            public int ID;
            public Point(double x, double y, int id)
            {
                this.X = x;
                this.Y = y;
                this.ID = id; // stroke ID to which this point belongs (1,2,...)
            }
        }
        class PointCloud
        {
            public string Name;
            public Point[] Points;
            public PointCloud(PDollarRecognizer pRec, string name, Point[] points)
            {
                this.Name = name;
                this.Points = pRec.Resample(points, pRec.NumPoints);
                this.Points = pRec.Scale(this.Points);
                this.Points = pRec.TranslateTo(this.Points, pRec.Origin);
            }
        }
        class PDollarRecognizer
        {
            public int NumPoints = 32;
            public Point Origin = new Point(0, 0, 0);
	        public double gesturePercent=0;
	        public int gestureNumber=-1;
	        public string gestureName="";
	        public PointCloud[] PointClouds=new PointCloud[0];

            public PDollarRecognizer()
            {
            }
            public void Recognize(Point[] points, string name)
	        {
		        points = Resample(points, NumPoints);
		        points = Scale(points);
		        points = TranslateTo(points, Origin);
		
		        double b = 1000000;
		        int u = -1;
		        if (name==null)
		        {
			        for (int i = 0; i < this.PointClouds.Length; i++) // for each point-cloud template
			        {
				        double d = GreedyCloudMatch(points, this.PointClouds[i]);
				        if (d < b) {
					        b = d; // best (least) distance
					        u = i; // point-cloud
				        }
			        }
		        }
		        else
		        {
			        int num;
			        for (num = 0; num < this.PointClouds.Length; num++) 
			        {
				        if (String.Compare(this.PointClouds[num].Name, name)==0)
					        break;
			        }
			        if (num<this.PointClouds.Length)
			        {
				        b=GreedyCloudMatch(points, this.PointClouds[num]);
				        u=num;
			        }			
		        }
		        this.gesturePercent=Math.Max((b - 2.0) / -2.0, 0.0);
		        if (this.gesturePercent>0)
		        {
			        this.gestureNumber=u;
			        this.gestureName=(u == -1) ? "" : this.PointClouds[u].Name;
		        }
	        }
	        public int AddGesture(string name, Point[] points)
	        {
		        int num;
		        for (num = 0; num < this.PointClouds.Length; num++) 
		        {
			        if (String.Compare(this.PointClouds[num].Name, name)==0)
				        break;
		        }
		        if (num<this.PointClouds.Length)
			        this.PointClouds[num]=new PointCloud(this, name, points);
		        else			
		        {
                    Array.Resize(ref this.PointClouds, this.PointClouds.Length+1);
			        this.PointClouds[this.PointClouds.Length-1]=new PointCloud(this, name, points);
		        }			
		        return num;
	        }
	        public void ClearGestures()
	        {
                this.PointClouds = new PointCloud[0];
	        }

            public double GreedyCloudMatch(Point[] points, PointCloud P)
            {
	            double e = 0.50;
	            int step = (int)Math.Pow(points.Length, 1 - e);
	            double min = 1000000000;
	            for (int i = 0; i < points.Length; i += step) 
                {
		            double d1 = CloudDistance(points, P.Points, i);
		            double d2 = CloudDistance(P.Points, points, i);
		            min = Math.Min(min, Math.Min(d1, d2)); // min3
	            }
	            return min;
            }
            public double CloudDistance(Point[] pts1, Point[] pts2, int start)
            {
	            bool[] matched = new bool[pts1.Length]; // pts1.length == pts2.length
	            for (int k = 0; k < pts1.Length; k++)
		            matched[k] = false;
	            double sum = 0;
	            int i = start;
	            do
	            {
		            int index = -1;
		            double min = 1000000000;
		            for (int j = 0; j < matched.Length; j++)
		            {
			            if (!matched[j]) 
                        {
				            double d = Distance(pts1[i], pts2[j]);
				            if (d < min) 
                            {
					            min = d;
					            index = j;
				            }
			            }
		            }
		            matched[index] = true;
		            double weight = 1 - ((double)((i - start + pts1.Length) % pts1.Length)) / pts1.Length;
		            sum += weight * min;
		            i = (i + 1) % pts1.Length;
	            } while (i != start);
	            return sum;
            }
            public Point[] Resample(Point[] points, int n)
            {
	            double I = PathLength(points) / (n - 1); // interval length
	            double D = 0.0;
                Point[] newpoints = new Point[1];
                newpoints[0]=points[0];
	            for (int i = 1; i < points.Length; i++)
	            {
		            if (points[i].ID == points[i-1].ID)
		            {
			            double d = Distance(points[i - 1], points[i]);
			            if ((D + d) >= I)
			            {
				            double qx = points[i - 1].X + ((I - D) / d) * (points[i].X - points[i - 1].X);
				            double qy = points[i - 1].Y + ((I - D) / d) * (points[i].Y - points[i - 1].Y);
				            Point q = new Point(qx, qy, points[i].ID);
                            this.insertPoint(ref newpoints, newpoints.Length, q);
                            this.insertPoint(ref points, i, q); // insert 'q' at position i in points s.t. 'q' will be the next i
				            D = 0.0;
			            }
			            else D += d;
		            }
	            }
	            if (newpoints.Length == n - 1) // sometimes we fall a rounding-error short of adding the last point, so add it if so
		            this.insertPoint(ref newpoints, newpoints.Length, new Point(points[points.Length - 1].X, points[points.Length - 1].Y, points[points.Length - 1].ID));
	            return newpoints;
            }
            public void insertPoint(ref Point[] points, int position, Point point)
            {
                int l=points.Length+1;
                Array.Resize(ref points, l);
                int c;
                for (c=l; c>position; c--)
                    points[c]=points[c-1];
                points[c]=point;
            }
            public Point[] Scale(Point[] points)
            {
	            double minX = 1000000000, maxX = -1000000000, minY = +1000000000, maxY = -1000000000;
	            for (int i = 0; i < points.Length; i++) 
                {
		            minX = Math.Min(minX, points[i].X);
		            minY = Math.Min(minY, points[i].Y);
		            maxX = Math.Max(maxX, points[i].X);
		            maxY = Math.Max(maxY, points[i].Y);
	            }
	            double size = Math.Max(maxX - minX, maxY - minY);
	            Point[] newpoints = new Point[points.Length];
	            for (int i = 0; i < points.Length; i++) 
                {
		            double qx = (points[i].X - minX) / size;
		            double qy = (points[i].Y - minY) / size;
		            newpoints[i] = new Point(qx, qy, points[i].ID);
	            }
	            return newpoints;
            }
            public Point[] TranslateTo(Point[] points, Point pt) // translates points' centroid
            {
	            Point c = Centroid(points);
	            Point[] newpoints = new Point[points.Length];
	            for (int i = 0; i < points.Length; i++) 
                {
		            double qx = points[i].X + pt.X - c.X;
		            double qy = points[i].Y + pt.Y - c.Y;
		            newpoints[i] = new Point(qx, qy, points[i].ID);
	            }
	            return newpoints;
            }
            public Point Centroid(Point[] points)
            {
	            double x = 0.0, y = 0.0;
	            for (int i = 0; i < points.Length; i++) 
                {
		            x += points[i].X;
		            y += points[i].Y;
	            }
	            x /= points.Length;
	            y /= points.Length;
	            return new Point(x, y, 0);
            }
            public double PathDistance(Point[] pts1, Point[] pts2) // average distance between corresponding points in two paths
            {
	            double d = 0.0;
	            for (int i = 0; i < pts1.Length; i++) // assumes pts1.length == pts2.length
		            d += Distance(pts1[i], pts2[i]);
	            return d / pts1.Length;
            }
            public double PathLength(Point[] points) // length traversed by a point path
            {
	            double d = 0.0;
	            for (int i = 1; i < points.Length; i++)
	            {
		            if (points[i].ID == points[i-1].ID)
			            d += Distance(points[i - 1], points[i]);
	            }
	            return d;
            }
            public double Distance(Point p1, Point p2) // Euclidean distance between two points
            {
	            double dx = p2.X - p1.X;
	            double dy = p2.Y - p1.Y;
	            return Math.Sqrt(dx * dx + dy * dy);
            }
        }
    }
}
