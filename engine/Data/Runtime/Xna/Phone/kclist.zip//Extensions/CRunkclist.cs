﻿//----------------------------------------------------------------------------------
//
// CRUNKCLIST: extension object
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework;
#if !WINDOWS_PHONE
using Microsoft.Xna.Framework.Storage;
#else
using System.IO.IsolatedStorage;
#endif
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunkclist : CRunExtension, IControl
    {
	    // Flags
	    const int LIST_FREEFLAG = 0x0001;
	    const int LIST_VSCROLLBAR = 0x0002;
	    const int LIST_SORT = 0x0004;
	    const int LIST_BORDER = 0x0008;
	    const int LIST_HIDEONSTART = 0x0010;
	    const int LIST_SYSCOLOR = 0x0020;
	    const int LIST_3DLOOK = 0x0040;
	    const int LIST_SCROLLTONEWLINE = 0x0080;
	    const int LIST_JUSTCREATED = 0x8000;
	
	    // Condition identifiers
	    const int CND_VISIBLE = 0;
	    const int CND_ENABLE = 1;
	    const int CND_DOUBLECLICKED = 2;
	    const int CND_SELECTIONCHANGED = 3;
	    const int CND_HAVEFOCUS = 4;
	    const int CND_LAST = 5;
	    // Action identifiers
	    const int ACT_LOADLIST = 0;
	    const int ACT_LOADDRIVESLIST = 1;
	    const int ACT_LOADDIRECTORYLIST = 2;
	    const int ACT_LOADFILESLIST = 3;
	    const int ACT_SAVELIST = 4;
	    const int ACT_RESET = 5;
	    const int ACT_ADDLINE = 6;
	    const int ACT_INSERTLINE = 7;
	    const int ACT_DELLINE = 8;
	    const int ACT_SETCURRENTLINE = 9;
	    const int ACT_SHOW = 10;
	    const int ACT_HIDE = 11;
	    const int ACT_ACTIVATE = 12;
	    const int ACT_ENABLE = 13;
	    const int ACT_DISABLE = 14;
	    const int ACT_SETPOSITION = 15;
	    const int ACT_SETXPOSITION = 16;
	    const int ACT_SETYPOSITION = 17;
	    const int ACT_SETSIZE = 18;
	    const int ACT_SETXSIZE = 19;
	    const int ACT_SETYSIZE = 20;
	    const int ACT_DESACTIVATE = 21;
	    const int ACT_SCROLLTOTOP = 22;
	    const int ACT_SCROLLTOLINE = 23;
	    const int ACT_SCROLLTOEND = 24;
	    const int ACT_SETCOLOR = 25;
	    const int ACT_SETBKDCOLOR = 26;
	    const int ACT_LOADFONTSLIST = 27;
	    const int ACT_LOADFONTSIZESLIST = 28;
	    const int ACT_SETLINEDATA = 29;
	    const int ACT_CHANGELINE = 30;
	    const int ACT_LAST = 31;
	    // Expression identifiers
	    const int EXP_GETSELECTINDEX = 0;
	    const int EXP_GETSELECTTEXT = 1;
	    const int EXP_GETSELECTDIRECTORY = 2;
	    const int EXP_GETSELECTDRIVE = 3;
	    const int EXP_GETLINETEXT = 4;
	    const int EXP_GETLINEDIRECTORY = 5;
	    const int EXP_GETLINEDRIVE = 6;
	    const int EXP_GETNBLINE = 7;
	    const int EXP_GETXPOSITION = 8;
	    const int EXP_GETYPOSITION = 9;
	    const int EXP_GETXSIZE = 10;
	    const int EXP_GETYSIZE = 11;
	    const int EXP_GETCOLOR = 12;
	    const int EXP_GETBKDCOLOR = 13;
	    const int EXP_FINDSTRING = 14;
	    const int EXP_FINDSTRINGEXACT = 15;
	    const int EXP_GETLASTINDEX = 16;
	    const int EXP_GETLINEDATA = 17;
	    const int EXP_LAST = 18;

    	public CRunList list;
	    public CFontInfo listFontInfo;
	    public int listFontFore;
    	public int listFontBack;
    	public int flags;
    	public int indexOffset;
	    public bool selectionChangedIgnore= false;
    	public int oldWidth;
    	public int oldHeight;
    	public int doubleClickedEvent;
    	public int selectionChangedEvent;
    	public int lastIndex;
#if !WINDOWS_PHONE
        Object stateobj;
#endif

	    public override int getNumberOfConditions()
	    {
	        return CND_LAST;
	    }

	    public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
	    {
	        // Read from edPtr
	        ho.hoImgWidth = file.readAShort();
	        ho.hoImgHeight = file.readAShort();
			oldWidth=ho.hoImgWidth;
			oldHeight=ho.hoImgHeight;
				        
	        // This is a 16-bit logfont structure
	        if (ho.hoAdRunHeader.rhApp.bUnicode==false)
	        {
	            listFontInfo = file.readLogFont16();
	        }
	        else
	        {
	            listFontInfo = file.readLogFont();
	        }
	        listFontFore = file.readAColor();
	        file.readAString(40);
	        file.skipBytes(16 * 4);
	        listFontBack = file.readAColor();
	        flags = file.readAInt();

	        int lineNumbers= file.readAShort();

	        // If TRUE, indexes are 1-based. So the index offset is -1 when true
	        // (subtract one from value provided) and 0 when false (no modification)
	        indexOffset = file.readAInt() == 1 ? -1 : 0;
	        
	        // Skip three longs (lSecu)
	        file.skipBytes(4 * 3);
	        
			// Creates the list
			int newFlags=0;
			if ((flags&LIST_VSCROLLBAR)!=0)
			{
				newFlags|=CRunList.LISTFLAG_SCROLLBAR;
			}
			if ((flags&LIST_HIDEONSTART)!=0)
			{
				newFlags|=CRunList.LISTFLAG_HIDDEN;
			}
			if ((flags&LIST_SORT)!=0)
			{
				newFlags|=CRunList.LISTFLAG_SORT;
			}
			if ((flags&LIST_BORDER)!=0)
			{
				newFlags|=CRunList.LISTFLAG_BORDER;
			}
			if ((flags&LIST_3DLOOK)!=0)
			{
				newFlags|=CRunList.LISTFLAG_3DLOOK;
			}
			if ((flags&LIST_SCROLLTONEWLINE)!=0)
			{
				newFlags|=CRunList.LISTFLAG_SCROLLTONEWLINE;
			}
			list=new CRunList(ho.hoAdRunHeader, ho.hoX-ho.hoAdRunHeader.rhWindowX+ho.hoAdRunHeader.rhApp.xOffset, ho.hoY-ho.hoAdRunHeader.rhWindowY+ho.hoAdRunHeader.rhApp.yOffset, 
							  ho.hoImgWidth, ho.hoImgHeight,
							  listFontInfo, listFontFore, listFontBack, newFlags);

			// Insert the strings			
	        while (lineNumbers > 0)
	        {
	            string line = file.readAString();
	            list.addString(line, lineNumbers==1);
	            lineNumbers--;
	        }
//            list.sortStrings();
//            list.createStrings();

    		doubleClickedEvent=-1;
    		selectionChangedEvent=-1;
			lastIndex=0;

            ho.hoAdRunHeader.addControl(this);

	        return false;
	    }
        public override void destroyRunObject(bool bFast)
        {
            ho.hoAdRunHeader.delControl(this);
        }
		public override int handleRunObject()
		{
			list.handle(ho.hoAdRunHeader.rh2MouseX-ho.hoX, ho.hoAdRunHeader.rh2MouseY-ho.hoY);
			
			if (list.bSelChanged)
			{
				list.bSelChanged=false;
                selectionChangedEvent = ho.getEventCount();
            	ho.pushEvent(CND_SELECTIONCHANGED, 0);
			}
			if (list.bDoubleClick)
			{
				list.bDoubleClick=false;
	            doubleClickedEvent = ho.getEventCount();
	            ho.pushEvent(CND_DOUBLECLICKED, 0);
	  		}
			return 0;	
		}
        public void setMouseControlled(bool bFlag)
        {
            list.setMouseControlled(bFlag);
        }
        public void setFocus(bool bFlag)
		{
			list.setFocus(bFlag);
		}
		public void click(int nClicks)
		{
#if WINDOWS_PHONE
            handleRunObject();
#endif
			list.click(nClicks);
		}
        public int getX()
        {
            return ho.hoX;
        }
        public int getY()
        {
            return ho.hoY;
        }

		public override void displayRunObject(SpriteBatchEffect batch)
		{
			list.setPosition(ho.hoX-ho.hoAdRunHeader.rhWindowX+ho.hoAdRunHeader.rhApp.xOffset, ho.hoY-ho.hoAdRunHeader.rhWindowY+ho.hoAdRunHeader.rhApp.yOffset);
			if (ho.hoImgWidth!=oldWidth)
			{
				list.width=ho.hoImgWidth;
				oldWidth=ho.hoImgWidth;
			}
			if (ho.hoImgHeight!=oldHeight)
			{
				list.height=ho.hoImgHeight;
				oldHeight=ho.hoImgHeight;
			}
		}

        public void drawControl(SpriteBatchEffect batch)
        {
            list.drawControl(batch);
        }

	    public override CFontInfo getRunObjectFont()
	    {
	        return listFontInfo;
	    }
	
	    public override void setRunObjectFont(CFontInfo fi, CRect rc)
	    {
	        listFontInfo = fi;
	        list.setFont(listFontInfo);
	        if (rc!=null)
	        {
	        	list.setSize(rc.right, rc.bottom);
	        }
	    }
	
	    public override int getRunObjectTextColor()
	    {
	        return listFontFore;
	    }
	
	    public override void setRunObjectTextColor(int rgb)
	    {
	        listFontFore = rgb;
	        list.setForeground(listFontFore);
	    }

	    // Conditions
	    // --------------------------------------------------
	    public override bool condition(int num, CCndExtension cnd)
	    {
	        switch (num)
	        {
	            case CND_VISIBLE:
	                return cndIsVisible(cnd);
	            case CND_ENABLE:
	                return cndIsEnable(cnd);
	            case CND_DOUBLECLICKED:
	                return cndDoubleClicked(cnd);
	            case CND_SELECTIONCHANGED:
	                return cndSelectionChanged(cnd);
	            case CND_HAVEFOCUS:
	                return cndHaveFocus(cnd);
	        }
	        return false;
	    }

	    public bool cndIsVisible(CCndExtension cnd)
	    {
	        return list.bVisible;
	    }
	
	    public bool cndIsEnable(CCndExtension cnd)
	    {
	        return list.bEnabled;
	    }
	
	    public bool cndDoubleClicked(CCndExtension cnd)
	    {
	        // This is a true event, so was pushed
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
	            return true;
	        }
	        // Event occured this event loop
	        if (doubleClickedEvent == ho.getEventCount())
	        {
	            return true;
	        }
	        return false;
	    }
	
	    public bool cndSelectionChanged(CCndExtension cnd)
	    {
	        // This is a true event, so was pushed
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
	            return true;
	        }
	        // Event occured this event loop
	        if (selectionChangedEvent == ho.getEventCount())
	        {
	            return true;
	        }
	        return false;
	    }
	
	    public bool cndHaveFocus(CCndExtension cnd)
	    {
	        return list.bFocus;
	    }

	    // Actions
	    // -------------------------------------------------
	    public override void  action(int num, CActExtension act)
	    {
	        switch (num)
	        {
	            case ACT_LOADLIST:
                    ActLoad(act);
	                break;
	            case ACT_LOADDRIVESLIST:
	                break;
	            case ACT_LOADDIRECTORYLIST:
	                break;
	            case ACT_LOADFILESLIST:
	                break;
	            case ACT_SAVELIST:
                    ActSave(act);
	                break;
	            case ACT_RESET:
	                actReset(act);
	                break;
	            case ACT_ADDLINE:
	                actAddLine(act);
	                break;
	            case ACT_INSERTLINE:
	                actInsertLine(act);
	                break;
	            case ACT_DELLINE:
	                actDelLine(act);
	                break;
	            case ACT_SETCURRENTLINE:
	                actSetCurrentLine(act);
	                break;
	            case ACT_SHOW:
	                actShow(act);
	                break;
	            case ACT_HIDE:
	                actHide(act);
	                break;
	            case ACT_ACTIVATE:
	                actActivate(act);
	                break;
	            case ACT_ENABLE:
	                actEnable(act);
	                break;
	            case ACT_DISABLE:
	                actDisable(act);
	                break;
	            case ACT_SETPOSITION:
	                actSetPosition(act);
	                break;
	            case ACT_SETXPOSITION:
	                actSetXPosition(act);
	                break;
	            case ACT_SETYPOSITION:
	                actSetYPosition(act);
	                break;
	            case ACT_SETSIZE:
	                actSetSize(act);
	                break;
	            case ACT_SETXSIZE:
	                actSetXSize(act);
	                break;
	            case ACT_SETYSIZE:
	                actSetYSize(act);
	                break;
	            case ACT_DESACTIVATE:
	                actDesactivate(act);
	                break;
	            case ACT_SCROLLTOTOP:
	                actScrollToTop(act);
	                break;
	            case ACT_SCROLLTOLINE:
	                actScrollToLine(act);
	                break;
	            case ACT_SCROLLTOEND:
	                actScrollToEnd(act);
	                break;
	            case ACT_SETCOLOR:
	                actSetColor(act);
	                break;
	            case ACT_SETBKDCOLOR:
	                actSetBkdColor(act);
	                break;
	            case ACT_LOADFONTSLIST:
	                break;
	            case ACT_LOADFONTSIZESLIST:
	                break;
	            case ACT_SETLINEDATA:
	                actSetLineData(act);
	                break;
	            case ACT_CHANGELINE:
	            	actChangeLine(act);
	            	break;
	        }
	    }
        string cleanName(string name)
        {
            int pos = name.LastIndexOf('\\');
            if (pos < 0)
            {
                pos = name.LastIndexOf('/');
            }
            if (pos >= 0 && pos + 1 < name.Length)
            {
                name = name.Substring(pos + 1);
            }
            return name;
        }
        public CFile loadFromProject(string name)
        {
            CFile cfile = null;
            CEmbeddedFile efile = rh.rhApp.getEmbeddedFile(name);
            if (efile!=null)
            {
                cfile = efile.open();
            }
            if (cfile==null)
            {
                int pos = name.LastIndexOf('.');
                if (pos >= 0)
                {
                    name = name.Substring(0, pos);
                }
                BinaryRead.Data iniFile = null;
                try
                {
                    iniFile = rh.rhApp.content.Load<BinaryRead.Data>(name);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
                if (iniFile != null)
                {
                    cfile = new CFile(iniFile.data);
                }
            }
            return cfile;
        }
#if !WINDOWS_PHONE
        void GetDevice(IAsyncResult result)
        {
            ho.hoAdRunHeader.rhApp.storageDevice = StorageDevice.EndShowSelector(result);
        }
#endif
        private CFile GetCFile(string path)
        {
            CFile cFile=null;

#if !WINDOWS_PHONE
            // Opens a StorageDevice
            if (ho.hoAdRunHeader.rhApp.storageDevice == null)
            {
                stateobj = (Object)"Please choose a device";
                try
                {
                    StorageDevice.BeginShowSelector(rh.deviceSelectorPlayer, this.GetDevice, stateobj);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
            }
            if (ho.hoAdRunHeader.rhApp.storageDevice != null && ho.hoAdRunHeader.rhApp.storageDevice.IsConnected==true)
            {
                // Open a storage container.
                IAsyncResult result = ho.hoAdRunHeader.rhApp.storageDevice.BeginOpenContainer(ho.hoAdRunHeader.rhApp.appName, null, null);

                // Wait for the WaitHandle to become signaled.
                result.AsyncWaitHandle.WaitOne();

                StorageContainer container = ho.hoAdRunHeader.rhApp.storageDevice.EndOpenContainer(result);

                // Close the wait handle.
                result.AsyncWaitHandle.Close();

                // Check to see whether the save exists.
                if (!container.FileExists(path))
                {
                    // If not, dispose of the container and return.
                    container.Dispose();
                    return loadFromProject(path);
                }

                // Open the file.
                Stream stream = container.OpenFile(path, FileMode.Open);
                int length=(int)stream.Length;
                byte[] data=new byte[length];
                try
                {
                    stream.Read(data, 0, length);
                }
                catch (IOException e)
                {
                    e.GetType();
                }
                stream.Close();
                stream.Dispose();
                container.Dispose();
                cFile=new CFile(data);
            }
#else
            using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (isf.FileExists(path))
                {
                    using (IsolatedStorageFileStream isfs = new IsolatedStorageFileStream(path, FileMode.Open, isf))
                    {
                        using (BinaryReader reader = new BinaryReader(isfs))
                        {
                            int length=(int)reader.BaseStream.Length;
                            byte[] data=new byte[length];
                            try
                            {
                                reader.Read(data, 0, length);
                            }
                            catch (IOException e)
                            {
                                e.GetType();
                            }
                            reader.Close();
                            reader.Dispose();
                            cFile=new CFile(data);
                        }
                    }
                }
                else
                {
                    loadFromProject(path);
                }
                isf.Dispose();
            } 
#endif
            return cFile;
        }
        private void ActLoad(CActExtension act)
        {
            string path = cleanName(act.getParamFilename(rh, 0));
            CFile file = GetCFile(path);
            if (file != null)
            {
                list.reset();
                while (file.isEOF() == false)
                {
                    string s = file.readAStringEOL();
                    list.addString(s, false);
                }
                list.sortStrings();
            }
        }
        private void WriteAString(StreamWriter stream, string text)
        {
            try
            {
                stream.Write(text);
                stream.WriteLine();
            }
            catch (IOException e)
            {
                e.GetType();
            }
        }
        private void WriteList(StreamWriter writer)
        {
            int n;
            for (n = 0; n < list.strings.size(); n++)
            {
                string s = (string)list.strings.get(n);
                WriteAString(writer, s);
            }
        }
        private void ActSave(CActExtension act)
        {
            string path = cleanName(act.getParamFilename(rh, 0));
#if !WINDOWS_PHONE
            if (ho.hoAdRunHeader.rhApp.storageDevice == null)
            {
                stateobj = (Object)"Please choose a device";
                try
                {
                    StorageDevice.BeginShowSelector(rh.deviceSelectorPlayer, this.GetDevice, stateobj);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
            }
            if (ho.hoAdRunHeader.rhApp.storageDevice != null && ho.hoAdRunHeader.rhApp.storageDevice.IsConnected == true)
            {
                // Open a storage container.
                IAsyncResult result = ho.hoAdRunHeader.rhApp.storageDevice.BeginOpenContainer(ho.hoAdRunHeader.rhApp.appName, null, null);

                // Wait for the WaitHandle to become signaled.
                result.AsyncWaitHandle.WaitOne();

                StorageContainer container = ho.hoAdRunHeader.rhApp.storageDevice.EndOpenContainer(result);

                // Close the wait handle.
                result.AsyncWaitHandle.Close();

                // Create a new file.
                if (!container.FileExists(path))
                {
                    container.DeleteFile(path);
                }
                Stream stream = container.CreateFile(path);
                StreamWriter writer=new StreamWriter(stream);
                WriteList(writer);
                writer.Flush();
                writer.Close();
                writer.Dispose();
                container.Dispose();
            }
#else
            if (path != null)
            {
                using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    using (IsolatedStorageFileStream isfs = new IsolatedStorageFileStream(path, FileMode.Create, isf))
                    {
                        using (StreamWriter writer = new StreamWriter(isfs))
                        {
                            WriteList(writer);
                            writer.Flush();
                            writer.Close();
                            writer.Dispose();
                        }
                    }
                    isf.Dispose();
                }
            }
#endif


        }
        public void actReset(CActExtension act)
	    {
	        list.reset();
	    }
	
	    public void actAddLine(CActExtension act)
	    {
	        list.addString(act.getParamExpString(rh, 0), true);
	        lastIndex=list.strings.size()-1;
	    }
	
	    public void actInsertLine(CActExtension act)
	    {
	        int index= act.getParamExpression(rh, 0) + indexOffset;
	        if (index < 0)
	        {
	            index = 0;
	        }
	        if (index > list.strings.size())
	        {
	            index = list.strings.size();
	        }
	        list.insertString(index, act.getParamExpString(rh, 1));
	        lastIndex=index;
	    }

	    public void actChangeLine(CActExtension act)
	    {
	        int index= act.getParamExpression(rh, 0) + indexOffset;
	        if (index >= 0)
	        {
		        list.setString(index, act.getParamExpString(rh, 1));
	        }
	    }
	
	    public void actDelLine(CActExtension act)
	    {
	        int index= act.getParamExpression(rh, 0) + indexOffset;
	        if (index < 0)
	        {
	            return;
	        }
	        if (index >= list.strings.size())
	        {
	            return;
	        }
	        list.delString(index);
	    }
	
	    public void actSetCurrentLine(CActExtension act)
	    {
            int index = act.getParamExpression(rh, 0) + indexOffset;
            if (index == -1)
	        {
	            // No selection
	            list.setSelected(-1);
	        }
	        else if ((index >= 0) && (index < list.strings.size()))
	        {
	            list.setSelected(index);
	        }
            list.bSelChanged = false;
	    }
	
	    public void actShow(CActExtension act)
	    {
	    	list.setVisible(true);
	    }
	
	    public void actHide(CActExtension act)
	    {
	        list.setVisible(false);
	    }
	
	    public void actActivate(CActExtension act)
	    {
	        list.setFocus(true);
	    }
	
	    public void actEnable(CActExtension act)
	    {
	        list.setEnabled(true);
	    }
	
	    public void actDisable(CActExtension act)
	    {
	        list.setEnabled(false);
	    }
	
	    public void actSetPosition(CActExtension act)
	    {
	        ho.setPosition(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
	        ho.redraw();
	    }
	
	    public void actSetXPosition(CActExtension act)
	    {
	        ho.setPosition(act.getParamExpression(rh, 0), ho.getY());
	        ho.redraw();
	    }
	
	    public void actSetYPosition(CActExtension act)
	    {
	        ho.setPosition(ho.getX(), act.getParamExpression(rh, 0));
	        ho.redraw();
	    }
	
	    public void actSetSize(CActExtension act)
	    {
	        ho.setWidth(act.getParamExpression(rh, 0));
	        ho.setHeight(act.getParamExpression(rh, 1));
	        ho.redraw();
	    }
	
	    public void actSetXSize(CActExtension act)
	    {
	        ho.setWidth(act.getParamExpression(rh, 0));
	        ho.redraw();
	    }
	
	    public void actSetYSize(CActExtension act)
	    {
	        ho.setHeight(act.getParamExpression(rh, 0));
	        ho.redraw();
	    }
	
	    public void actDesactivate(CActExtension act)
	    {
	    	list.setFocus(false);
	    }
	
	    public void actScrollToTop(CActExtension act)
	    {
	        list.ensureIndexIsVisible(0);
	    }
	
	    public void actScrollToLine(CActExtension act)
	    {
	        list.ensureIndexIsVisible(act.getParamExpression(rh, 0));
	    }
	
	    public void actScrollToEnd(CActExtension act)
	    {
	        list.ensureIndexIsVisible(list.strings.size() - 1);
	    }
	
	    public void actSetColor(CActExtension act)
	    {
	        listFontFore = act.getParamColour(rh, 0);
	        list.setForeground(listFontFore);
	    }
	
	    public void actSetBkdColor(CActExtension act)
	    {
	        listFontBack = act.getParamColour(rh, 0);
	        list.setBackground(listFontBack);
	    }
	
	    public void actSetLineData(CActExtension act)
	    {
	        int index= act.getParamExpression(rh, 0) + indexOffset;
	        // Must be an existing element
	        if (index < 0)
	        {
	            return;
	        }
	        if (index >= list.strings.size())
	        {
	            return;
	        }
	        list.setData(index, act.getParamExpression(rh, 1));
	    }

	    // Expressions
	    // --------------------------------------------
	    public override CValue expression(int num)
	    {
	        switch (num)
	        {
	            case EXP_GETSELECTINDEX:
	                return expGetSelectIndex();
	            case EXP_GETSELECTTEXT:
	                return expGetSelectText();
	            case EXP_GETSELECTDIRECTORY:
	                return new CValue("");
	            case EXP_GETSELECTDRIVE:
	                return new CValue("");
	            case EXP_GETLINETEXT:
	                return expGetLineText();
	            case EXP_GETLINEDIRECTORY:
	                return new CValue("");
	            case EXP_GETLINEDRIVE:
	                return new CValue("");
	            case EXP_GETNBLINE:
	                return expGetNbLine();
	            case EXP_GETXPOSITION:
	                return expGetXPosition();
	            case EXP_GETYPOSITION:
	                return expGetYPosition();
	            case EXP_GETXSIZE:
	                return expGetXSize();
	            case EXP_GETYSIZE:
	                return expGetYSize();
	            case EXP_GETCOLOR:
	                return expGetColor();
	            case EXP_GETBKDCOLOR:
	                return expGetBkdColor();
	            case EXP_FINDSTRING:
	                return expFindString();
	            case EXP_FINDSTRINGEXACT:
	                return expFindStringExact();
	            case EXP_GETLASTINDEX:
	                return expGetLastIndex();
	            case EXP_GETLINEDATA:
	                return expGetLineData();
	        }
	        return null;
	    }

	    public CValue expGetSelectIndex()
	    {
	    	int y=list.ySelected;
	    	if (y>=0)							// Bug dans la version C++
	    	{
	    		y-=indexOffset;
	    	}
	        return new CValue(y);
	    }
	
	    public CValue getText(int index)
	    {
	    	CValue ret=new CValue(0);
	        if ((index < 0) || (index >= list.strings.size()))
	        {
	        	ret.forceString("");
	        }
	        else
	        {
	        	ret.forceString((String)(list.strings.get(index)));
	        }
	        return ret;
	    }
	
	    public CValue expGetSelectText()
	    {
	        return getText(list.ySelected);
	    }
		
	    public CValue expGetLineText()
	    {
	        return getText(ho.getExpParam().getInt() + indexOffset);
	    }
	
	    public CValue expGetNbLine()
	    {
	        return new CValue(list.strings.size());
	    }
	
	    public CValue expGetXPosition()
	    {
	        return new CValue(ho.getX());
	    }
	
	    public CValue expGetYPosition()
	    {
	        return new CValue(ho.getY());
	    }
	
	    public CValue expGetXSize()
	    {
	        return new CValue(ho.getWidth());
	    }
	
	    public CValue expGetYSize()
	    {
	        return new CValue(ho.getHeight());
	    }
	
	    public CValue expGetColor()
	    {
	        return new CValue(listFontFore);
	    }
	
	    public CValue expGetBkdColor()
	    {
	        return new CValue(listFontBack);
	    }
	    
	    public CValue expFindString()
	    {
	        string search= ho.getExpParam().getString();
	        int startIndex= ho.getExpParam().getInt();
	        if (startIndex != -1)
	        {
	            startIndex += indexOffset;
	        }
	        if ((startIndex < 0) || (startIndex >= list.strings.size()))
	        {
	            startIndex = -1;
	        }
	        int ret=list.findString(search, startIndex);
	        if (ret>=0)
	        {
	        	ret-=indexOffset;
	        }
	        return new CValue(ret);	    
	    }
	
	    public CValue expFindStringExact()
	    {
	        string search= ho.getExpParam().getString();
	        int startIndex= ho.getExpParam().getInt();
	        if (startIndex != -1)
	        {
	            startIndex += indexOffset;
	        }
	        if ((startIndex < 0) || (startIndex >= list.strings.size()))
	        {
	            startIndex = -1;
	        }
	        int ret=list.findStringExact(search, startIndex);
	        if (ret>=0)
	        {
	        	ret-=indexOffset;
	        }
	        return new CValue(ret);	    
	    }
	
	    public CValue expGetLastIndex()
	    {
	        return new CValue(lastIndex);
	    }
	
	    public CValue expGetLineData()
	    {
	        int index= ho.getExpParam().getInt() + indexOffset;
	        if ((index < 0) || (index >= list.datas.size()))
	        {
	            return new CValue(0);
	        }
	        return new CValue((int)(list.getData(index)));
	    }	    





    }

    class CRunList : IControl
    {
		public const int LISTFLAG_SCROLLBAR=0x0001;
        public const int LISTFLAG_SORT = 0x0002;
        public const int LISTFLAG_BORDER = 0x0004;
        public const int LISTFLAG_3DLOOK = 0x0008;
        public const int LISTFLAG_HIDDEN = 0x0010;
        public const int LISTFLAG_SCROLLTONEWLINE = 0x0020;
		int SY_TEXTBORDERS=4;
		int SELECTED_COLOR=0x7FCEFF;
		int HILIGHT_COLOR=0xB2E1FF;
		
		public int width;
		public int height;
		int trueHeight;
		int xObject;
		int yObject;
		int backColor;
		int fontColor;
		int flags;
		CFontInfo font;
		int nLines;
		public bool bVisible;
		int yPos;
		int syLine;
		public int yHilight;
		public int ySelected;
		int sBorder;
		public bool bFocus;
		int oldKey;
		public CArrayList strings;
        public CArrayList stringsShort;
        public CArrayList datas;
		CListVScrollBar slider=null;
		public bool bClick;
		public bool bDoubleClick;
		public bool bEnabled;
		public bool bSelChanged;
        CRun rhPtr;
        bool bMouseControlled;
        int syText;
        CRect tempRc=new CRect();
        Vector2 vector=new Vector2();
        SpriteFont spriteFont;
        int xSlider;
        int ySlider;

		public CRunList(CRun rh, int xx, int yy, int w, int h, CFontInfo ft, int ftColor, int bkColor, int fl)
		{
            rhPtr=rh;
			xObject=xx;
			yObject=yy;
			width=w;
			height=h;
			backColor=bkColor;
			fontColor=ftColor;
			font=ft;
			flags=fl;
			strings=new CArrayList();
            stringsShort = new CArrayList();
            datas = new CArrayList();

			yPos=0;
			yHilight=-1;
			ySelected=-1;
			oldKey=0;
			bFocus=false;
			bEnabled=true;

			sBorder=0;
			if ((flags&LISTFLAG_BORDER)!=0)
			{
				sBorder=1;
				if ((flags&LISTFLAG_3DLOOK)!=0)
				{
                    sBorder=3;
				}
			}

            CFont f = CFont.createFromFontInfo(font, rhPtr.rhApp);
            spriteFont = f.getFont();
            syText = spriteFont.LineSpacing;
			syLine=syText+SY_TEXTBORDERS;						
			nLines=(height-sBorder*2)/syLine;
			trueHeight=sBorder*2+syLine*nLines;
            if ((flags & LISTFLAG_SCROLLBAR) != 0)
            {
                xSlider=width - sBorder - CListVScrollBar.SX_BUTTON;
                ySlider = sBorder;
                slider = new CListVScrollBar(rhPtr, xObject + xSlider, yObject +ySlider, CListVScrollBar.SX_BUTTON, trueHeight - sBorder * 2);
            }
			
			bVisible=true;
			if ((flags&LISTFLAG_HIDDEN)!=0)
			{
				bVisible=false;
			}
		}
        public void setMouseControlled(bool bFlag)
        {
            bMouseControlled = bFlag;
            bFocus = bFlag;
        }
		public void destroy()
		{
		}
		public void handle(int xMouse, int yMouse)
		{
			if (bVisible==false || bEnabled==false)
			{
				return;
			}

            if (bMouseControlled)
            {
                yHilight = getLine(xMouse, yMouse);
            }

			if (bFocus)
			{
				int key=0;
                if (bMouseControlled == false)
                {
                    if ((rhPtr.rhPlayer[0] & 0x01) != 0)		// UP
                    {
                        key = 1;
                    }
                    if ((rhPtr.rhPlayer[0] & 0x02) != 0)		// DOWN
                    {
                        key = 2;
                    }
                    if ((rhPtr.rhPlayer[0] & 0x10) != 0)		// RETURN
                    {
                        key = 3;
                    }
                }
/*				if (keyBuffer[33]!=0)		// PAGEUP
				{
					key=4;
				}
				if (keyBuffer[34]!=0)		// PAGEDOWN
				{
					key=5;
				}
*/				if (key!=oldKey)
				{
					oldKey=key;
					int y=ySelected;
					switch(key)
					{
						case 1:		// Up
							if (ySelected>0)
							{
								ySelected--;
								if (ySelected<yPos)
								{
									yPos--;									
								}
								ensureIndexIsVisible(ySelected);
								bSelChanged=true;
							}
							break;
						case 2:
							if (ySelected<strings.size()-1)
							{
								ySelected++;
								if (ySelected-yPos>=nLines)
								{
									yPos++;
								}
								ensureIndexIsVisible(ySelected);
								bSelChanged=true;
							}
							break;
						case 3:
                            click(2);
							break;
						case 4:
							if (y>=0)
							{
								y-=nLines;
								if (y<0)
								{
									y=0;
								}
								if (y!=ySelected)
								{
									ySelected=y;
									if (ySelected-yPos<0)
									{
										yPos=ySelected;
									}
									ensureIndexIsVisible(ySelected);
									bSelChanged=true;
								}
							}
							break;
						case 5:
							if (y<strings.size())
							{
								y+=nLines;
								if (y>=strings.size())
								{
									y=strings.size()-1;
								}
								if (y!=ySelected)
								{
									ySelected=y;
									if (ySelected-yPos>=nLines)
									{
										yPos=ySelected-nLines+1;
										if (yPos+nLines>strings.size())
										{
											yPos=strings.size()-nLines;
										}
									}
									ensureIndexIsVisible(ySelected);
									bSelChanged=true;
								}
							}
							break;
					}			
				}
			}
			
			if (slider!=null)
			{
				slider.setRange(strings.size(), yPos, nLines);
				slider.handle(xMouse-xSlider, yMouse-ySlider);
				if (slider.yPos!=yPos)
				{
					yPos=slider.yPos;
				}
			}
		}
        public int getX()
        {
            return xObject;
        }
        public int getY()
        {
            return yObject;
        }
		public void setPosition(int xx, int yy)
		{
            xObject=xx;
            yObject=yy;
		}
        public void createStrings()
        {
            int n;

            stringsShort.clear();
            for (n = 0; n < strings.size(); n++)
            {
                string pString = (string)strings.get(n);
                Vector2 size = spriteFont.MeasureString(pString);
                int pos=pString.Length;
                while(size.X >= width - sBorder * 2)
                {
                    if (pos == 0)
                    {
                        pString = "";
                        break;
                    }
                    pos = Math.Max(0, pos - 10);
                    string testString = pString.Substring(0, pos);
                    size = spriteFont.MeasureString(testString);
                    if (size.X < width - sBorder * 2)
                    {
                        int nn;
                        int oldNN = 0;
                        for (nn = 0; nn < 10; nn++)
                        {
                            testString = pString.Substring(0, pos + nn);
                            size = spriteFont.MeasureString(testString);
                            if (size.X >= width - sBorder * 2)
                            {
                                break;
                            }
                            oldNN = nn;
                        }
                        pString = pString.Substring(0, pos + oldNN);
                        break;
                    }
                };
                stringsShort.add(pString);
            }
        }
        public void drawControl(SpriteBatchEffect batch)
		{
            if (bVisible == false)
            {
                return;
            }

            // Draw background
            tempRc.left=xObject;
            tempRc.top=yObject;
            tempRc.right = xObject + width;
            tempRc.bottom = yObject + trueHeight;
            rhPtr.rhApp.services.fillRect(batch, tempRc, backColor, CSpriteGen.BOP_COPY, 0); 
			if ((flags&LISTFLAG_BORDER)!=0)
			{
				if ((flags&LISTFLAG_3DLOOK)==0)
				{
                    rhPtr.rhApp.services.drawRect(batch, xObject, yObject, width, height, 0, CSpriteGen.BOP_COPY, 0);
				}
				else
				{
                    rhPtr.rhApp.services.drawRect(batch, xObject, yObject, width - 1, trueHeight - 1, 0x698790, CSpriteGen.BOP_COPY, 0);
                    rhPtr.rhApp.services.drawRect(batch, xObject + 1, yObject + 1, width - 3, trueHeight - 3, 0xFFFFFF, CSpriteGen.BOP_COPY, 0);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + 2, yObject + trueHeight - 3, xObject + 2, yObject + 2, 0x696969, 1, CSpriteGen.BOP_COPY, 0);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + 2, yObject + 2, xObject + width - 3, yObject + 2, 0x696969, 1, CSpriteGen.BOP_COPY, 0);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + width - 3, yObject + 2, xObject + width - 3, yObject + trueHeight - 3, 0xE3E3E3, 1, CSpriteGen.BOP_COPY, 0);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + width - 3, yObject + trueHeight - 3, xObject + 2, yObject + trueHeight - 3, 0xE3E3E3, 1, CSpriteGen.BOP_COPY, 0);
				}
			}

            int n, color;
			for (n=0; n<Math.Min(nLines, stringsShort.size()); n++)
			{
                color=-1;
                if (bFocus)
                {
                    if (n+yPos==ySelected)
                    {
                        color=SELECTED_COLOR;
                    }
                    else if (n+yPos==yHilight)
                    {
                        color=HILIGHT_COLOR;
                    }
                }
                if (color!=-1)
                {
                    tempRc.left = xObject + sBorder;
                    tempRc.top = yObject + n * syLine+sBorder;
                    tempRc.right = xObject + width - sBorder * 2;
                    tempRc.bottom=tempRc.top+syLine;
                    rhPtr.rhApp.services.fillRect(batch, tempRc, HILIGHT_COLOR, CSpriteGen.BOP_COPY, 0);
                }
                vector.X = xObject + sBorder;
                vector.Y = yObject + n * syLine+sBorder;
				Color cc=CServices.getColor(fontColor);
                batch.DrawString(spriteFont, (string)stringsShort.get(n+yPos), vector, cc);
			}
            if (slider != null)
            {
                slider.drawControl(batch);
            }
		}
		public void click(int nClicks)
		{
			if (bVisible==false || bEnabled==false)
			{
				return;
			}			
			if (yHilight>=0)
			{
				if (ySelected!=yHilight)
				{
					ySelected=yHilight;						
					bSelChanged=true;
				}
                if (nClicks==1)
                {
                    bClick=true;
                    bDoubleClick=false;
                    if (slider != null)
                    {
                        slider.click(nClicks);
                    }
                }
                else
                {
                    bClick=false;
                    bDoubleClick=true;
                    if (slider != null)
                    {
                        slider.click(nClicks);
                    }
                }
			}			
		}
		public void setFocus(Boolean bFlag)
		{
            if (bFlag != bFocus)
            {
                bFocus = bFlag;
                if (bFlag)
                {
                    if (ySelected < 0)
                    {
                        ySelected = 0;
                    }
                }
            }
		}
		public int getLine(int x, int y)
		{
			if (x>sBorder && y>sBorder)
			{
				int sx=width-sBorder;
				if (slider!=null)
				{
					sx-=CListVScrollBar.SX_BUTTON;
				}
				if (x<sx && y<trueHeight-sBorder)
				{
                    int yy = yPos + (y - sBorder) / syLine;
					if (yy<strings.size())
					{
						return yy;
					}					
				}
			}
			return -1;
		}
		public void sortStrings()
		{
			if ((flags&LISTFLAG_SORT)!=0)
			{
				if (strings.size()>1)
				{
					int bCount=0;
                    do
                    {
                        int n;
                        for (n = 0; n < strings.size() - 1; n++)
                        {
                            string s1 = (String)(strings.get(n));
                            string s2 = (String)(strings.get(n + 1));
                            if (string.Compare(s1, s2) > 0)
                            {
                                strings.set(n, s2);
                                strings.set(n + 1, s1);
                                int tmp = (int)(datas.get(n));
                                datas.set(n, datas.get(n + 1));
                                datas.set(n + 1, tmp);
                                bCount++;
                            }
                        }
                    } while (bCount != 0);
				}
			}
            createStrings();
        }		
		public void addString(string s, bool bSort)
		{
			strings.add(s);
            if (bSort)
            {
                datas.add(0);
                sortStrings();
                if ((flags & LISTFLAG_SCROLLTONEWLINE) != 0)
                {
                    int index = strings.size() - 1;
                    if ((flags & LISTFLAG_SORT) != 0)
                    {
                        int n;
                        for (n = 0; n < strings.size(); n++)
                        {
                            string ss = (String)(strings.get(n));
                            if (s == ss)
                            {
                                index = n;
                                break;
                            }
                        }
                    }
                    ensureIndexIsVisible(index);
                }
            }
		} 
		public void insertString(int index, string s)
		{
			strings.insert(index, s);
			datas.insert(index, 0);
			if (ySelected>=index)
			{
				ySelected++;
			} 
			sortStrings();
			if ((flags&LISTFLAG_SCROLLTONEWLINE)!=0)
			{
				if ((flags&LISTFLAG_SORT)!=0)
				{
					int n;
					for (n=0; n<strings.size(); n++)
					{
						string ss=(String)(strings.get(n));
						if (s==ss)
						{
							index=n;
							break;
						}
					}
				}
                ensureIndexIsVisible(index);
			}
		}
		public void setString(int index, string s)
		{
			strings.set(index, s);
			sortStrings();
		}
		public void setData(int index, int data)
		{
			if (index>=0 && index<datas.size())
			{
				datas.set(index, data);
			}
		}
		public int getData(int index)
		{
			if (index>=0 && index<datas.size())
			{
				return (int)(datas.get(index));
			}
			return 0;
		}
		public void delString(int index)
		{
			strings.remove(index);
			datas.remove(index);
            createStrings();
            if (ySelected == index)
			{
				ySelected=-1;
			}
			if (ySelected>index)
			{
				ySelected--;
			}
			if (yPos>0)
			{
				if (yPos+nLines>strings.size())
				{
					yPos=strings.size()-nLines;
					if (yPos<0)
					{
						yPos=0;
					}
				}
			}
		}
		public void setFont(CFontInfo fi)
		{
			font=fi;
            CFont f = CFont.createFromFontInfo(font, rhPtr.rhApp);
            spriteFont = f.getFont();
            syText = spriteFont.LineSpacing;
			syLine=syText+SY_TEXTBORDERS;						
			nLines=(height-sBorder*2)/syLine;
			trueHeight=sBorder*2+syLine*nLines;
		}  
		public void setForeground(int rgb)
		{
			fontColor=rgb;
		}
	    public void setBackground(int rgb)
	    {
			backColor=rgb;
	    }
		public void setSize(int sx, int sy)
		{
			width=sx;
			height=sy;
			nLines=(height-sBorder*2)/syLine;
			trueHeight=sBorder*2+syLine*nLines;
            createStrings();
        }
		public void reset()
		{
			strings.clear();
			yPos=0;
			yHilight=-1;
			ySelected=-1;
		}
		public void setSelected(int index)
		{
			if (index<0 || index>=strings.size())
			{
				index=-1;
			}
			if (index!=ySelected)
			{
				ySelected=index;
				bSelChanged=true;
			}			
		}
		public void setVisible(bool b)
		{
			bVisible=b;
            if (slider!=null)
            {
                slider.setVisible(b);
            }
		}
		public void setEnabled(Boolean b)
		{
			if (bEnabled!=b)
			{
				bEnabled=b;
				if (slider!=null)
				{
					slider.setEnabled(b);
				}
			}
		}
		public void ensureIndexIsVisible(int index)
		{
			if (index>=0 && index<strings.size())
			{
				if (index<yPos)
				{
					yPos=index;
					ySelected=index;
					bSelChanged=true;
				}
				else if (index>=yPos+nLines)				
				{
					yPos=index-nLines+1;
					ySelected=index;
					bSelChanged=true;	
				}
			}			
		}
		public int findString(string search, int startIndex)
		{
			if (search.Length>0)
			{
		        int tries= strings.size();
		        int i = startIndex;
		        int subStringLength= search.Length;
		        while (tries > 0)
		        {
		            tries--;
		            i++;
		            // Wrap around
		            if (i >= strings.size())
		            {
		                i = 0;
		            }
		            string cmp= (String)(strings.get(i));
		            if (cmp.IndexOf(search)==0)
		            {
		                // Found a line
		                return i;
		            }
		        }
		 	}
	        return -1;
		}
		public int findStringExact(string search, int startIndex)
		{
			if (search.Length>0)
			{
		        int tries= strings.size();
		        int i= startIndex;
		        while (tries > 0)
		        {
		            tries--;
		            i++;
		            // Wrap around
		            if (i >= strings.size())
		            {
		                i = 0;
		            }
		            string cmp= (String)(strings.get(i));
		            if (string.Compare(cmp, search)==0)
		            {
		                // Found a line
		                return i;
		            }
		        }
			}
	        return -1;			
		}

    }

    class CListVScrollBar 
    {
		public const int SX_BUTTON=19;
		public const int SY_BUTTON=18;
		public const int SX_LINES=6;
		public const int SX_ARROW=8;
		public const int SY_ARROW=4;

        public int xObject;
        public int yObject;
        public int width;
        public int height;
        public int yPos;
        public int yMax;
        public int syCenter;
        public int sySlider;
        public int ySlider;
        public int hilight;
        public int selected;
        public bool bActivated;
        public int oldZone;
        public int yDrag;
        public int yDragPos;
        public bool bDrag;
        public int oldKey;
        public bool bEnabled;
        public bool bVisible;
        CRun rhPtr;
        Texture2D upArrow=null;
        Texture2D downArrow=null;
        Texture2D background = null;
        Rectangle tempRect = new Rectangle();
		
		public CListVScrollBar(CRun rh, int xx, int yy, int w, int h)
		{
            rhPtr=rh;
			xObject=xx;
			yObject=yy;
			width=w;
			height=h;
			yPos=0;
			yMax=10;
			syCenter=1;
			hilight=-1;
			selected=-1;
			oldZone=-1;
			oldKey=0;
			bEnabled=true;
            bVisible = true;

            background = CServices.createGradientRectangle(rhPtr.rhApp, width - 1, height - 1, 0x94999B, 0xE7E7E7, true, 1, 0x6A6B6E);
            createDisplay();			
		}
        public int getX()
        {
            return xObject;
        }
        public int getY()
        {
            return yObject;
        }
        public void click(int nClicks)
        {
        }
        public void setFocus(bool bFocus)
        {
            if (bFocus != bEnabled)
            {
                bEnabled = bFocus;
                createDisplay();
            }
        }
        void createDisplay()
        {
			int color=0x808080;
			if (hilight==0)
			{
				color=0x404040;
			}
			if (bActivated==false || bEnabled==false)
			{
				color=0xC0C0C0;
			}		
	        upArrow=CServices.createUpArrow(rhPtr.rhApp, SX_ARROW, SY_ARROW, color);

            color=0x808080;
			if (hilight==2)
			{
				color=0x404040;
			}
			if (bActivated==false || bEnabled==false)
			{
				color=0xC0C0C0;
			}		
	        downArrow=CServices.createDownArrow(rhPtr.rhApp, SX_ARROW, SY_ARROW, color);
        }

        public void handle(int xMouse, int yMouse)
		{
			if (bActivated && bEnabled)
			{
				bool bDisplay=false;
				int zone=getZone(xMouse, yMouse);
				if (zone!=hilight)
				{
					hilight=zone;
					if (zone<0)
					{
						selected=-1;
					}	
					bDisplay=true;
				}
				
				int key=0;
				if ((rhPtr.rh2MouseKeys&0x01)!=0)
				{
					key=1;
				}
				if (key!=oldKey)
				{
					oldKey=key;				
					bDisplay=true;
					if (key==1)
					{
						selected=zone;
						switch(zone)
						{						
							case 0:
								if (yPos>0)
								{
									yPos--;
								}
								break;
							case 1:
								bDrag=true;
								yDrag=yMouse;
								yDragPos=yPos;
								break;
							case 2:
								if (yPos+syCenter<yMax)
								{
									yPos++;
								}
								break;
							case 3:
								yPos-=syCenter;
								if (yPos<0)
								{
									yPos=0;
								}
								break;
							case 4:
								yPos+=syCenter;
								if (yPos>yMax-syCenter)
								{
									yPos=yMax-syCenter;
								}
								break;
						}					
					}
					else
					{
						bDrag=false;
						selected=-1;
					}
				}
				if (key==1 && bDrag==true)
				{
                    int y = yDragPos + ((yMouse - yDrag) * yMax )/ (height - SY_BUTTON * 2);
					if (y<0)
					{
						y=0;
					}			
					if (y>yMax-syCenter)
					{		
						y=yMax-syCenter;
					}
					if (y!=yPos)
					{
						yPos=y;
					}
				} 
				if (bDisplay)
				{
					createDisplay();
				}
			}
		}

		public int getZone(int xMouse, int yMouse)
		{
			if (xMouse>=0 && xMouse<SX_BUTTON)
			{
				if (yMouse>=0 && yMouse<height)
				{
					if (yMouse<SY_BUTTON)
					{
						return 0;	
					}	
					if (yMouse>=ySlider && yMouse<ySlider+sySlider)
					{
						return 1;
					}
					if (yMouse>=height-SY_BUTTON)
					{
						return 2;
					}
					if (yMouse<ySlider)
					{
						return 3;
					}
					return 4;
				}
			}
			return -1; 
		}

        public void drawControl(SpriteBatchEffect batch)
        {
            if (bVisible == false)
            {
                return;
            }

            tempRect.X = xObject;
            tempRect.Y = yObject;
            tempRect.Width = background.Width;
            tempRect.Height = background.Height;
            batch.Draw(background, tempRect, null, Color.White);
			
			int color=0x6A6B6E;
			if (hilight==0)
			{
				color=0x64CFFF;
			}
            rhPtr.rhApp.services.drawRect(batch, xObject, yObject, width - 1, SY_BUTTON - 1, color, CSpriteGen.BOP_COPY, 0);
			color=0x6A6B6E;
			if (hilight==2)
			{
				color=0x64CFFF;
			}
            rhPtr.rhApp.services.drawRect(batch, xObject, yObject + height - SY_BUTTON, width - 1, SY_BUTTON - 1, color, CSpriteGen.BOP_COPY, 0);
			
			color=0xF4F4F4;
			if (selected==0)
			{
				color=0xA6DCFF;
			}
            rhPtr.rhApp.services.fillRect(batch, xObject + 1, yObject + 1, width - 3, SY_BUTTON - 3, color, CSpriteGen.BOP_COPY, 0);
			color=0xF4F4F4;
			if (selected==2)
			{
				color=0xA6DCFF;
			}
            rhPtr.rhApp.services.fillRect(batch, xObject + 1, yObject + height - SY_BUTTON, width - 3, SY_BUTTON - 3, color, CSpriteGen.BOP_COPY, 0);

            tempRect.X = xObject+SX_BUTTON/2-SX_ARROW/2;
            tempRect.Y = yObject+SY_BUTTON/2-SY_ARROW/2;
            tempRect.Width = upArrow.Width;
            tempRect.Height = upArrow.Height;
            batch.Draw(upArrow, tempRect, null, Color.White);

            tempRect.Y = yObject+height-SY_BUTTON+SY_BUTTON/2-SY_ARROW/2;
            batch.Draw(downArrow, tempRect, null, Color.White);

			if (bActivated && bEnabled)
			{
				ySlider=((height-SY_BUTTON*2)*yPos)/yMax+SY_BUTTON;
				sySlider=(syCenter*(height-SY_BUTTON*2))/yMax;
				if (sySlider<10)
				{
					sySlider=10;
				}
				if (ySlider+sySlider>height-SY_BUTTON)
				{
					ySlider=height-SY_BUTTON-sySlider;
				}
				color=0x808080;
				if (hilight==1)
				{
					color=0x64CFFF;
				}
                rhPtr.rhApp.services.drawRect(batch, xObject, yObject + ySlider, width - 1, sySlider - 1, color, CSpriteGen.BOP_COPY, 0);

				color=0xF4F4F4;
				if (selected==1)
				{
					color=0xA6DCFF;
				}
                rhPtr.rhApp.services.fillRect(batch, xObject + 1, yObject + ySlider + 1, width - 3, sySlider - 3, color, CSpriteGen.BOP_COPY, 0);

				if (syCenter>15)
				{
					int n, y;
					for (n=0; n<5; n++)
					{
						y=ySlider+sySlider/2-5+n*2;
                        rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + width / 2 - SX_LINES / 2, yObject + y, xObject + width / 2 + SX_LINES / 2, yObject + y, 0x929292, 1, CSpriteGen.BOP_COPY, 0);
					}
				}							
			}								
        }
		public void setRange(int ySize, int y, int sy)
		{
			bActivated=false;
			yMax=ySize;
			yPos=y;
			syCenter=sy;
			if (yPos+syCenter>yMax)
			{
				yPos=yMax-syCenter;
				if (yPos<0)
				{
					yPos=0;
				}
			}
			if (yMax>0 && yPos+syCenter<=yMax)
			{
				bActivated=true;
			}
		}		
		public void setEnabled(bool b)
		{
			if (b!=bEnabled)
			{
				bEnabled=b;
				createDisplay();
			}
		}
        public void setVisible(bool b)
        {
            bVisible = b;
        }
    }
}
