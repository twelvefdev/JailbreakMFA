﻿//----------------------------------------------------------------------------------
//
// CRUNACTIVEBACKDROP
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;

namespace RuntimeXNA.Extensions
{
    class CRunGet : CRunExtension
    {
        const int ACT_GETURL=0;
        const int ACT_ADDPOSTDATA = 1;
        const int CND_ONCOMPLETE = 0;
		const int CND_PENDING=1;
		const int EXP_CONTENT=0;
        const int POSTDATA_STEP = 10;

        bool bComplete;
        string result;
        int completeEventCount;
        string[] postData=null;

        public override int getNumberOfConditions()
        {
            return 2;
	    }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            completeEventCount = -1;
            result = "";
            bComplete = false;
            return true;
        }

        // Actions
	    // -------------------------------------------------
        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_GETURL:
                    openURL(act);
                    break;
                case ACT_ADDPOSTDATA:
                    addPostData(act);
                    break;
            }
        }

        void addPostData(CActExtension act)
        {
            int key= act.getParamExpression(rh, 0);
            string value = act.getParamExpString(rh, 1);
            if (key >= 0)
            {
                if (postData == null)
                    postData = new string[key+POSTDATA_STEP];
                else if (key >= postData.Length)
                {
                    string[] temp = new string[key + POSTDATA_STEP];
                    int n;
                    for (n = 0; n < postData.Length; n++)
                        temp[n] = postData[n];
                    postData = temp;
                }
                postData[key] = value;
            }
        }

        void openURL(CActExtension act)
        {
            result = "";
            bComplete = false;
            string url=act.getParamExpString(rh, 0);
            System.Uri uri = new Uri(url);

            System.Net.WebClient client = new System.Net.WebClient();
            if (postData==null)
            {
                client.OpenReadCompleted += new System.Net.OpenReadCompletedEventHandler(OpenReadCompleted);
                client.OpenReadAsync(uri);
            }
            else
            {
                System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
                int n, l=0;
                int[] dataLength = new int[postData.Length];
                for (n=0; n<postData.Length; n++)
                {
                    if (postData[n]!=null)
                    {
                        dataLength[n]=encoding.GetByteCount(postData[n]);
                        l += dataLength[n]+2;
                    }
                }
                byte[] data=new byte[l];
                int position=0;
                for (n = 0; n < postData.Length; n++)
                {
                    if (dataLength[n] > 0)
                    {
                        byte[] temp = encoding.GetBytes(postData[n]);
                        temp.CopyTo(data, position);
                        position += temp.Length;
                        temp[position++] = 13;
                        temp[position++] = 10;
                    }
                }
                client.OpenWriteCompleted += new System.Net.OpenWriteCompletedEventHandler(OpenWriteCompleted);
                client.OpenWriteAsync(uri, null, data);
                postData = null;
            }
        }

        void OpenReadCompleted(object sender, System.Net.OpenReadCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                bComplete=false;
            }
            else
            {
                using (Stream s = e.Result)
                {
                    using (StreamReader lector = new StreamReader(s))
                    {
                        Char[] ret={(Char)13, (Char)10};
                        bool bFlag = (lector.Peek() >= 0);
                        while (bFlag)
                        {
                            result += lector.ReadLine();
                            bFlag = (lector.Peek() >= 0);
                            if (!bFlag)
                                break;
                            result += new string(ret);
                        }
                    }
                }
                bComplete=true;
                completeEventCount = ho.getEventCount();
                ho.pushEvent(CND_ONCOMPLETE, 0);	
            } 
        }

        void OpenWriteCompleted(object sender, System.Net.OpenWriteCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                bComplete = false;
            }
            else
            {
                bComplete = true;
                completeEventCount = ho.getEventCount();
                ho.pushEvent(CND_ONCOMPLETE, 0);
            }
        }

        // Conditions
	    // --------------------------------------------------
	    public override bool condition(int num, CCndExtension cnd)
	    {
	        switch (num)
	        {
	        	case CND_ONCOMPLETE:
	        		return cndOnComplete();
	        	case CND_PENDING:
	        		return bComplete==false;
	        }
	        return false;
	    }
	    bool cndOnComplete()
	    {
	        // If this condition is first, then always true
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
	            return true;
	        }
	
	        // If condition second, check event number matches
	        if (rh.rh4EventCount == completeEventCount)
	        {
	            return true;
	        }	
	        return false;	    	
	    }
	    
   	    // Expressions
	    // --------------------------------------------
        public override CValue expression(int num)
        {
            if (num == EXP_CONTENT)
            {
                return expContent();
            }
            return null;
        }
        private CValue expContent()
	    {
	    	CValue ret=new CValue("");
	    	if (bComplete)
	    	{
		    	ret.forceString(result);	    		
		    }
	    	return ret;
	    }

    }
}
