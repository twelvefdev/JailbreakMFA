//----------------------------------------------------------------------------------
//
// CRUNAdControl
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.GamerServices;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;
using Microsoft.Advertising.Mobile.Xna;
using System.Device.Location;

namespace RuntimeXNA.Extensions
{
    class CRunXNAAdControl : CRunExtension
    {
        const int CND_NEWAD=0;
        const int CND_ENGAGED = 1;
        const int CND_VISIBLE=2;
        const int CND_AUTOREFRESH = 3;
        const int CND_LAST = 4;
        const int ACT_SETVISIBLE=0;
        const int ACT_NEXTAD=1;

        const int ADFLAG_AUTOREFRESH=0x0001;
        const int ADFLAG_BORDER=0x0002;
        const int ADFLAG_DROPSHADOW=0x0004;
        const int ADFLAG_VISIBLE=0x0008;
        const int ADFLAG_LOCATION=0x0010;
        const int ADFLAG_KEEPOPEN=0x0020;

        int oldX;
        int oldY;
        int flags;
        string identifier;
        string keywords;
        int borderColor;
        CDrawableAd ad;
        GeoCoordinateWatcher gcw = null;
        EventHandler adRefreshed = null;
        int newAdCount = 0;

        public override int getNumberOfConditions()
        {
            return CND_LAST;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            ho.hoImgWidth=file.readAInt();
            ho.hoImgHeight=file.readAInt();
            flags=file.readAInt();
            borderColor=file.readAInt();
            identifier=file.readAString(32);
            keywords=file.readAString();

            ad=null;
            if (rh.rhApp.advertisements!=null)
            {
                int n;
                for (n=0; n<rh.rhApp.advertisements.size(); n++)
                {
                    CDrawableAd ad2=(CDrawableAd)rh.rhApp.advertisements.get(n);
                    if (string.Compare(identifier, ad2.ad.AdUnitId)==0)
                    {
                        ad=ad2;
                        break;
                    }
                }
            }
            Rectangle r=new Rectangle(ho.hoX-rh.rhWindowX, ho.hoY-rh.rhWindowY, ho.hoImgWidth, ho.hoImgHeight);
            if (ad==null)
            {
                if (rh.rhApp.advertisements==null)
                {
                    rh.rhApp.advertisements=new CArrayList();
                }
                ad=new CDrawableAd();
                ad.ad=Game1.adGameComponent.CreateAd(identifier, r);
                rh.rhApp.advertisements.add(ad);
            }

            //ad.ad.AutoRefreshEnabled = (flags & ADFLAG_AUTOREFRESH) != 0;
            ad.ad.DisplayRectangle = r;
            ad.ad.BorderEnabled = (flags & ADFLAG_BORDER) != 0;
            ad.ad.BorderColor=CServices.getColor(borderColor);
            ad.ad.DropShadowEnabled = (flags & ADFLAG_DROPSHADOW) != 0;
            ad.ad.Visible = (flags & ADFLAG_VISIBLE) != 0;
            if ((flags & ADFLAG_LOCATION) != (ad.flags & ADFLAG_LOCATION))
            {
                if ((flags & ADFLAG_LOCATION) != 0)
                {
                    gcw = new GeoCoordinateWatcher();
                    gcw.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(gcw_PositionChanged);
                    gcw.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(gcw_StatusChanged);
                    gcw.Start();
                    AdGameComponent.Current.Enabled = false;
                }
            }
            ad.flags = flags;
            adRefreshed = new EventHandler(bannerAd_AdRefreshed);
            ad.ad.AdRefreshed += adRefreshed;

            if (string.Compare(ad.keywords, keywords) != 0)
            {
                ad.ad.Keywords = keywords;
                ad.keywords = keywords;
            }
            oldX = ho.hoX;
            oldY = ho.hoY;
            return true;
        }

        private void bannerAd_AdRefreshed(object sender, EventArgs e)
        {
            ho.generateEvent(CND_NEWAD, ho.getEventParam());
            newAdCount = ho.getEventCount();
        }

        private void gcw_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            this.gcw.Stop();

            AdGameComponent.Current.Enabled = true;
            ad.ad.LocationLatitude = e.Position.Location.Latitude;
            ad.ad.LocationLongitude = e.Position.Location.Longitude;
        }

        private void gcw_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            if (e.Status == GeoPositionStatus.Disabled || e.Status == GeoPositionStatus.NoData)
            {
                AdGameComponent.Current.Enabled = true;
            }
        }

        public override void destroyRunObject(bool bFast)
        {
            if (ad != null)
            {
                ad.ad.AdRefreshed -= adRefreshed;
                if ((flags & ADFLAG_KEEPOPEN) == 0)
                {
                    Game1.adGameComponent.RemoveAd(ad.ad);
                    rh.rhApp.advertisements.remove(ad);
                }
            }
            if (gcw!=null)
            {
                gcw.Stop();
            }
            AdGameComponent.Current.Enabled = true;
        }

        public override void displayRunObject(SpriteBatchEffect batch)
        {
            if (ho.hoX != oldX || ho.hoY != oldY)
            {
                Rectangle r = new Rectangle(ho.hoX - rh.rhWindowX, ho.hoY - rh.rhWindowY, ho.hoImgWidth, ho.hoImgHeight);
                ad.ad.DisplayRectangle = r;
                oldX = ho.hoX;
                oldY = ho.hoY;
            }
        }


        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_NEWAD:
                    return cndNewAd();
                case CND_ENGAGED:
                    return ad.ad.Engaged;
                case CND_VISIBLE:
                    return ad.ad.Visible;
                case CND_AUTOREFRESH:
                    return ad.ad.AutoRefreshEnabled;
            }
            return false;
        }

        bool cndNewAd()
        {
            if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
            {
                return true;
            }
            if (ho.getEventCount() == newAdCount)
            {
                return true;
            }
            return false;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_SETVISIBLE:
                    actSetVisible(act);
                    break;
                case ACT_NEXTAD:
                    ad.ad.Refresh();
                    break;
            }
        }
        void actSetVisible(CActExtension act)
        {
            int flag = act.getParamExpression(rh, 0);
            ad.ad.Visible = flag != 0;
        }
    }

    class CDrawableAd
    {
        public DrawableAd ad=null;
        public int flags=0;
        public string keywords="";
    }
}
