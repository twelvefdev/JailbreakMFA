﻿//----------------------------------------------------------------------------------
//
// CRUNMVTVECTOR
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Movements;
using RuntimeXNA.Services;
using RuntimeXNA.Objects;
using RuntimeXNA.Animations;
using RuntimeXNA.Sprites;
using RuntimeXNA.Application;

namespace RuntimeXNA.Movements
{
    class CRunMvtclickteam_vector : CRunMvtExtension
    {
        const int MOVEATSTART = 1;
        const int HANDLE_DIRECTION = 2;
        const double ToDegrees = 57.295779513082320876798154814105;
        const double ToRadians = 0.017453292519943295769236907684886;
        int m_dwFlags;
        int m_dwVel;
        int m_dwVelAngle;
        int m_dwAcc;
        int m_dwAccAngle;
        bool r_Stopped = false;
        bool handleDirection = false;
        double posX = 0;
        double posY = 0;
        double velX = 0;
        double velY = 0;
        double accX = 0;
        double accY = 0;
        double angle = 0;
        double minSpeed = -1;
        double maxSpeed = -1;

        public override void initialize(CFile file)
        {
            file.skipBytes(1);
            m_dwFlags = file.readAInt();
            m_dwVel = file.readAInt();
            m_dwVelAngle = file.readAInt();
            m_dwAcc = file.readAInt();
            m_dwAccAngle = file.readAInt();

            //*** General variables
            r_Stopped = ((m_dwFlags & MOVEATSTART) == 0);
            handleDirection = ((m_dwFlags & HANDLE_DIRECTION) != 0);

            double vel = m_dwVel;
            double velAngle = m_dwVelAngle * ToRadians;

            double acc = m_dwAcc * 0.01;
            double accAngle = m_dwAccAngle * ToRadians;

            posX = ho.hoX;
            posY = ho.hoY;

            velX = vel * Math.Cos(velAngle);
            velY = -vel * Math.Sin(velAngle);

            accX = acc * Math.Cos(accAngle);
            accY = -acc * Math.Sin(accAngle);
        }

        public override bool move()
        {
            //*** Object needs to be moved?
            if (!r_Stopped)
            {
                //*** Update internal variables
                double calculs;
                calculs = accX;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                velX += calculs;
                calculs = accY;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                velY += calculs;
                calculs = velX;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                posX += calculs * 0.01;
                calculs = velY;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }
                posY += calculs * 0.01;

                //*** Code the handle the min / max speed control
                checkSpeed();

                //*** Calculate the current direction
                angle = Math.Atan2(-velY, velX);
                if (angle < 0)
                {
                    angle += 2 * Math.PI;
                }

                if (handleDirection)
                {
                    ho.roc.rcDir = ((int)(((angle + (Math.PI / 32)) * 32) / (2 * Math.PI))) % 32;
                }

                //*** Update MMF2 with the new position
                animations(CAnim.ANIMID_WALK);
                ho.hoX = (int)(posX + 0.5);
                ho.hoY = (int)(posY + 0.5);
                collisions();

                //*** Indicate the object has been moved
                return true;
            }
            animations(CAnim.ANIMID_STOP);
            collisions();
            return ho.roc.rcChanged;
        }

        void reset()
        {
            double vel = m_dwVel;
            double velAngle = m_dwVelAngle * ToRadians;

            double acc = m_dwAcc / 100.0;
            double accAngle = m_dwAccAngle * ToRadians;

            posX = ho.hoX;
            posY = ho.hoY;

            velX = vel * Math.Cos(velAngle);
            velY = -vel * Math.Sin(velAngle);

            accX = acc * Math.Cos(accAngle);
            accY = -acc * Math.Sin(accAngle);
        }

        bool checkSpeed()
        {
            //*** Code the handle the min / max speed control
            if (maxSpeed != -1)
            {
                if (velX * velX + velY * velY > maxSpeed * maxSpeed)
                {
                    recalculateAngle();
                    //*** Recalculate velocity components
                    velX = maxSpeed * Math.Cos(angle);
                    velY = -maxSpeed * Math.Sin(angle);
                    return true;
                }
            }
            else if (minSpeed != -1)
            {
                if (velX * velX + velY * velY < minSpeed * minSpeed)
                {
                    recalculateAngle();
                    //*** Recalculate velocity components
                    velX = minSpeed * Math.Cos(angle);
                    velY = -minSpeed * Math.Sin(angle);
                    return true;
                }
            }
            return false;
        }

        void recalculateAngle()
        {
            angle = Math.Atan2(-velY, velX);
            if (angle < 0)
            {
                angle += 2 * Math.PI;
            }
        }

        public override void setPosition(int x, int y)
        {
            posX -= ho.hoX - x;
            posY -= ho.hoY - y;

            ho.hoX = x;
            ho.hoY = y;
        }

        public override void setXPosition(int x)
        {
            posX -= ho.hoX - x;
            ho.hoX = x;
        }

        public override void setYPosition(int y)
        {
            posY -= ho.hoY - y;
            ho.hoY = y;
        }

        public override void stop(bool bCurrent)
        {
            r_Stopped = true;
        }

        public override void reverse()
        {
            velX *= -1;
            velY *= -1;
            recalculateAngle();
        }

        public override void start()
        {
            r_Stopped = false;
        }

        public override void setSpeed(int speed)
        {
            velX = speed * Math.Cos(angle);
            velY = -speed * Math.Sin(angle);

            if (checkSpeed())
            {
                recalculateAngle();
            }
        }

        public override void setMaxSpeed(int speed)
        {
            maxSpeed = speed;
            if (checkSpeed())
            {
                recalculateAngle();
            }
        }

        public override void setGravity(int gravity)
        {
            double accAngle = Math.Atan2(-accY, accX);
            double acc = gravity * 0.01;

            accX = acc * Math.Cos(accAngle);
            accY = -acc * Math.Sin(accAngle);
        }

        public override double actionEntry(int action)
        {
            int param;
            double vel;
            double accAngle;
            double acc;
            double flo;
            switch (action)
            {
                case 3845:	    // SET_Vector_X = 3845,
                    param = (int)getParamDouble();
                    posX = param;
                    break;
                case 3846:	    // SET_Vector_Y,
                    param = (int)getParamDouble();
                    posY = param;
                    break;
                case 3847:	    // SET_Vector_XY,
                    param = (int)getParamDouble();
                    break;
                case 3848:	    // SET_Vector_AddDistX,
                    param = (int)getParamDouble();
                    posX += 0.01 * param;
                    break;
                case 3849:	    // SET_Vector_AddDistY,
                    param = (int)getParamDouble();
                    posY -= 0.01 * param;
                    break;
                case 3850:	    // SET_Vector_Dir,
                    param = (int)getParamDouble();
                    angle = ((int)param) * ToRadians;
                    vel = Math.Sqrt(velX * velX + velY * velY);
                    velX = vel * Math.Cos(angle);
                    velY = -vel * Math.Sin(angle);
                    break;
                case 3851:	    // SET_Vector_RotateTowardsAngle,
                    param = (int)getParamDouble();
                    break;
                case 3852:	    // SET_Vector_RotateTowardsPoint,
                    param = (int)getParamDouble();
                    break;
                case 3853:	    // SET_Vector_RotateTowardsObject,
                    param = (int)getParamDouble();
                    break;
                case 3854:	    // SET_Vector_Speed,
                    param = (int)getParamDouble();
                    vel = param;
                    velX = vel * Math.Cos(angle);
                    velY = -vel * Math.Sin(angle);
                    if (checkSpeed())
                    {
                        recalculateAngle();
                    }
                    break;
                case 3855:	    // SET_Vector_SpeedX,
                    param = (int)getParamDouble();
                    velX = param;
                    if (checkSpeed())
                    {
                        recalculateAngle();
                    }
                    break;
                case 3856:	    // SET_Vector_SpeedY,
                    param = (int)getParamDouble();
                    velY = param;
                    if (checkSpeed())
                    {
                        recalculateAngle();
                    }
                    break;
                case 3857:	    // SET_Vector_AddSpeedX,
                    param = (int)getParamDouble();
                    velX += 0.01 * param;
                    if (checkSpeed())
                    {
                        recalculateAngle();
                    }
                    break;
                case 3858:	    // SET_Vector_AddSpeedY,
                    param = (int)getParamDouble();
                    velY -= 0.01 * param;
                    if (checkSpeed())
                    {
                        recalculateAngle();
                    }
                    break;
                case 3859:	    // SET_Vector_MinSpeed,
                    param = (int)getParamDouble();
                    minSpeed = param;
                    if (checkSpeed())
                    {
                        recalculateAngle();
                    }
                    break;
                case 3860:	    // SET_Vector_MaxSpeed,
                    param = (int)getParamDouble();
                    maxSpeed = param;
                    if (checkSpeed())
                    {
                        recalculateAngle();
                    }
                    break;
                case 3861:	    // SET_Vector_Gravity,
                    param = (int)getParamDouble();
                    accAngle = Math.Atan2(-accY, accX);
                    acc = param * 0.01;
                    accX = acc * Math.Cos(accAngle);
                    accY = -acc * Math.Sin(accAngle);
                    break;
                case 3862:	    // SET_Vector_GravityDir,
                    param = (int)getParamDouble();
                    accAngle = param * ToRadians;
                    acc = Math.Sqrt(accX * accX + accY * accY);
                    accX = acc * Math.Cos(accAngle);
                    accY = -acc * Math.Sin(accAngle);
                    break;
                case 3863:	    // SET_Vector_BounceCoeff,
                    param = (int)getParamDouble();
                    break;
                case 3864:	    // SET_Vector_ForceBounce,
                    param = (int)getParamDouble();
                    angle = param * ToRadians * 2;
                    posX -= velX * 0.01;
                    posY -= velY * 0.01;
                    angle -= Math.Atan2(-velY, velX);
                    vel = Math.Sqrt(velX * velX + velY * velY);
                    velX = vel * Math.Cos(angle);
                    velY = -vel * Math.Sin(angle);
                    break;

                case 3865:	    // GET_Vector_X,
                    return posX;
                case 3866:	    // GET_Vector_Y,
                    return posY;
                case 3867:	    // GET_Vector_Dir,
                    flo = (angle * ToDegrees);
                    if (flo < 0)
                    {
                        flo += 360;
                    }
                    return flo;
                case 3868:	    // GET_Vector_Speed,
                    return Math.Sqrt(velX * velX + velY * velY);
                case 3869:	    // GET_Vector_SpeedX,
                    return velX;
                case 3870:	    // GET_Vector_SpeedY,
                    return velY;
                case 3871:	    // GET_Vector_MinSpeed,
                    return minSpeed;
                case 3872:	    // GET_Vector_MaxSpeed,
                    return maxSpeed;
                case 3873:	    // GET_Vector_Gravity,
                    return (100 * Math.Sqrt(accX * accX + accY * accY));
                case 3874:	    // GET_Vector_GravityDir,
                    flo = (Math.Atan2(-accY, accX) * ToDegrees);
                    if (flo < 0)
                    {
                        flo += 360;
                    }
                    return flo;
                case 3875:	    // GET_Vector_BounceCoef
                    return 0;

            }
            return 0;
        }

        public override int getSpeed()
        {
            return (int)(Math.Sqrt(velX * velX + velY * velY));
        }

        public override int getGravity()
        {
            return (int)(100 * Math.Sqrt(accX * accX + accY * accY));
        }

    }
}
