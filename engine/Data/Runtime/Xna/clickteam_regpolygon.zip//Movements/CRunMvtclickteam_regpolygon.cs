﻿//----------------------------------------------------------------------------------
//
// CRUNMVTREGPOLYGON : Movement polyone!
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Movements;
using RuntimeXNA.Services;
using RuntimeXNA.Objects;
using RuntimeXNA.Animations;
using RuntimeXNA.Sprites;
using RuntimeXNA.Application;

namespace RuntimeXNA.Movements
{
    class CRunMvtclickteam_regpolygon : CRunMvtExtension
    {
        const int MFLAG1_MOVEATSTART = 1;
        int m_dwCX;
        int m_dwCY;
        int m_dwNumSides;
        int m_dwRadius;
        int m_dwFlags;
        int m_dwRotAng;
        int m_dwVel;
        bool r_Stopped;
        int r_CX;
        int r_CY;
        int r_Sides;
        double r_Vel;
        double r_CurrentAngle;
        double r_SideRemainder;
        double r_Radius;
        double r_CurrentX;
        double r_CurrentY;
        double r_SideSize;
        double r_TurnAngle;

        public override void initialize(CFile file)
        {
            // Version number
            file.skipBytes(1);
            m_dwCX = file.readAInt();
            m_dwCY = file.readAInt();
            m_dwNumSides = file.readAInt();
            m_dwRadius = file.readAInt();
            m_dwFlags = file.readAInt();
            m_dwRotAng = file.readAInt();
            m_dwVel = file.readAInt();

            //*** General variables
            double r_StartAngle = m_dwRotAng * (Math.PI / 180.0);

            r_Stopped = ((m_dwFlags & MFLAG1_MOVEATSTART) == 0);
            r_CX = m_dwCX;
            r_CY = m_dwCY;
            r_Sides = m_dwNumSides;
            r_Vel = m_dwVel / 50.0;
            r_Radius = m_dwRadius;

            r_CurrentX = r_CX + r_Radius * Math.Cos(r_StartAngle);
            r_CurrentY = r_CY - r_Radius * Math.Sin(r_StartAngle);
            r_SideSize = 2 * r_Radius * Math.Sin(Math.PI / r_Sides);
            r_TurnAngle = (2.0 / r_Sides) * Math.PI;
            r_CurrentAngle = Math.PI * (0.5 + (1.0 / r_Sides)) + r_StartAngle;
            r_SideRemainder = r_SideSize;

            ho.roc.rcSpeed = Math.Abs(m_dwVel);

            if (r_Vel < 0.0)
            {
                r_CurrentAngle = r_CurrentAngle + Math.PI * (1.0 - (2.0 / r_Sides));
                r_TurnAngle += 2 * Math.PI * (1.0 - (2.0 / r_Sides));
                r_Vel *= -1;
            }
        }

        void reset()
        {
            //*** General variables
            double r_StartAngle = m_dwRotAng * (Math.PI / 180.0);

            r_CX = m_dwCX;
            r_CY = m_dwCY;
            r_Sides = m_dwNumSides;
            r_Vel = m_dwVel / 50.0;
            r_Radius = m_dwRadius;

            r_CurrentX = r_CX + r_Radius * Math.Cos(r_StartAngle);
            r_CurrentY = r_CY - r_Radius * Math.Sin(r_StartAngle);
            r_SideSize = 2 * r_Radius * Math.Sin(Math.PI / r_Sides);
            r_TurnAngle = (2.0 / r_Sides) * Math.PI;
            r_CurrentAngle = Math.PI * (0.5 + (1.0 / r_Sides)) + r_StartAngle;
            r_SideRemainder = r_SideSize;

            if (r_Vel < 0.0)
            {
                r_CurrentAngle = r_CurrentAngle + Math.PI * (1.0 - (2.0 / r_Sides));
                r_TurnAngle += 2 * Math.PI * (1.0 - (2.0 / r_Sides));
                r_Vel *= -1;
            }
        }

        public override bool move()
        {
            //*** Object needs to be moved?
            if (!r_Stopped)
            {
                double toMove = r_Vel;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    toMove = toMove * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }

                bool complete = false;

                while (complete == false)
                {
                    if (toMove >= r_SideRemainder)
                    {
                        //*** move to the next vertex and turn the angle ready to move along next section
                        r_CurrentX += r_SideRemainder * Math.Cos(r_CurrentAngle);
                        r_CurrentY -= r_SideRemainder * Math.Sin(r_CurrentAngle);
                        toMove -= r_SideRemainder;
                        r_SideRemainder = r_SideSize;
                        r_CurrentAngle += r_TurnAngle;
                    }
                    else
                    {
                        //*** move along the side
                        r_CurrentX += toMove * Math.Cos(r_CurrentAngle);
                        r_CurrentY -= toMove * Math.Sin(r_CurrentAngle);
                        r_SideRemainder -= toMove;
                        complete = true;
                    }
                }
                //*** Move object, run animation and collision detection
                animations(CAnim.ANIMID_WALK);
                ho.hoX = (int)r_CurrentX;
                ho.hoY = (int)r_CurrentY;
                collisions();

                //*** Indicate the object has been moved
                return true;
            }
            animations(CAnim.ANIMID_STOP);
            collisions();
            return ho.roc.rcChanged;
        }

        public override void setPosition(int x, int y)
        {
            r_CurrentX -= ho.hoX - x;
            r_CurrentY -= ho.hoY - y;

            r_CX -= ho.hoX - x;
            r_CY -= ho.hoY - y;

            ho.hoX = x;
            ho.hoY = y;
        }

        public override void setXPosition(int x)
        {
            r_CurrentX -= ho.hoX - x;
            r_CX -= ho.hoX - x;

            ho.hoX = x;
        }

        public override void setYPosition(int y)
        {
            r_CurrentY -= ho.hoY - y;
            r_CY -= ho.hoY - y;

            ho.hoY = y;
        }

        public override void stop(bool bCurrent)
        {
            r_Stopped = true;
        }

        public override void reverse()
        {
            r_CurrentAngle += Math.PI;
            r_TurnAngle = 2 * Math.PI - r_TurnAngle;
            r_SideRemainder = r_SideSize - r_SideRemainder;
        }

        public override void start()
        {
            r_Stopped = false;
        }

        public override void setSpeed(int speed)
        {
            r_Vel = Math.Abs(speed) / 50.0;
        }

        public override double actionEntry(int action)
        {
            int param;
            switch (action)
            {
                case 3445:	    // SET_CENTRE_X = 3445,
                    param = (int)getParamDouble();
                    r_CurrentX += param - r_CX;
                    r_CX = param;
                    break;
                case 3446:	    // SET_CENTRE_Y,
                    param = (int)getParamDouble();
                    r_CurrentY += param - r_CY;
                    r_CY = param;
                    break;
                case 3447:	    // SET_NUMSIDES,
                    param = (int)getParamDouble();
                    m_dwNumSides = Math.Max(param, 0);
                    reset();
                    break;
                case 3448:	    // SET_RADIUS,
                    param = (int)getParamDouble();
                    m_dwRadius = Math.Max(param, 0);
                    reset();
                    break;
                case 3449:	    // SET_ROTATION_ANGLE,
                    param = (int)getParamDouble();
                    m_dwRotAng = Math.Max(param, 0);
                    reset();
                    break;
                case 3450:	    // SET_VELOCITY,
                    param = (int)getParamDouble();
                    r_Vel = Math.Abs(param) / 50.0;
                    break;
                case 3451:	    // GET_CENTRE_X,
                    return r_CX;
                case 3452:	    // GET_CENTRE_Y,
                    return r_CY;
                case 3453:	    // GET_NUMSIDES,
                    return r_Sides;
                case 3454:	    // GET_RADIUS,
                    return r_Radius;
                case 3455:	    // GET_ROTATION_ANGLE,
                    return m_dwRotAng;
                case 3456:	    // GET_VELOCITY
                    return r_Vel * 50;
            }
            return 0;
        }

        public override int getSpeed()
        {
            return (int)(r_Vel * 50);
        }
    }
}
