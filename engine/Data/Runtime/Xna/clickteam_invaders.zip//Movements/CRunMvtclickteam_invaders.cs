﻿//----------------------------------------------------------------------------------
//
// CRUNMVTINVADERS
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Movements;
using RuntimeXNA.Services;
using RuntimeXNA.Objects;
using RuntimeXNA.Animations;
using RuntimeXNA.Sprites;
using RuntimeXNA.Application;

namespace RuntimeXNA.Movements
{
    class CRunMvtclickteam_invaders : CRunMvtExtension
    {
        const int IDENTIFIER = 2;

        public override void initialize(CFile file)
        {
            CGlobalDataInvader data = (CGlobalDataInvader)rh.getStorage(IDENTIFIER);
            if (data == null)
            {
                file.skipBytes(1);
                int m_dwFlagMoveAtStart = file.readAInt();
                int m_dwFlagAutoSpeed = file.readAInt();
                int m_dwInitialDirection = file.readAInt();
                int m_dwDX = file.readAInt();
                int m_dwDY = file.readAInt();
                int m_dwSpeed = file.readAInt();
                int m_dwGroup = file.readAInt();

                data = new CGlobalDataInvader();
                data.count = 0;

                if (m_dwFlagMoveAtStart == 1)
                {
                    data.isMoving = true;
                }
                else
                {
                    data.isMoving = false;
                }

                data.autoSpeed = m_dwFlagAutoSpeed == 1;
                data.dx = m_dwDX;
                data.dy = m_dwDY;
                data.minX = 0;
                data.maxX = ho.hoAdRunHeader.rhLevelSx;
                data.initialSpeed = m_dwSpeed;
                if (m_dwInitialDirection == 0)
                {
                    data.cdx = -data.dx;
                }
                else
                {
                    data.cdx = data.dx;
                }
                data.speed = 101 - data.initialSpeed;

                data.myList = new CArrayList();
                rh.addStorage(data, IDENTIFIER);
            }
            //*** Adds this object to the end of our list
            data.count++;
            data.myList.add(ho);
        }

        public override void kill()
        {
            CGlobalDataInvader data = (CGlobalDataInvader)rh.getStorage(IDENTIFIER);
            if (data != null)
            {
                int n;
                for (n = 0; n < data.myList.size(); n++)
                {
                    CObject obj = (CObject)data.myList.get(n);
                    if (obj == (CObject)ho)
                    {
                        data.myList.remove(n);
                        break;
                    }
                }
                data.count--;
                if (data.count == 0)
                {
                    rh.delStorage(IDENTIFIER);
                }
            }
        }

        public override bool move()
        {
            CGlobalDataInvader data = (CGlobalDataInvader)rh.getStorage(IDENTIFIER);
            if (data != null)
            {
                if (!data.isMoving)
                {
                    return false;
                }
                if (data.myList.size() > 0)
                {
                    CObject myObject = (CObject)data.myList.get(0);
                    if (myObject == ho)
                    {
                        data.frames++;
                        if (data.frames % data.speed == 0)
                        {
                            data.cdy = 0;

                            //*** Loop over all objects to ensure non have left the playing field
                            int index;
                            CObject hoPtr;
                            for (index = 0; index < data.myList.size(); index++)
                            {
                                hoPtr = (CObject)data.myList.get(index);
                                if ((hoPtr.hoX < data.minX + hoPtr.hoImgXSpot) && data.cdx < 0)
                                {
                                    data.cdx = data.dx;
                                    data.cdy = data.dy;
                                    break;
                                }
                                else if (hoPtr.hoX > (data.maxX + hoPtr.hoImgXSpot - hoPtr.hoImgWidth) && data.cdx > 0)
                                {
                                    data.cdx = -data.dx;
                                    data.cdy = data.dy;
                                    break;
                                }
                            }

                            //*** Loop over all objects and move them
                            for (index = 0; index < data.myList.size(); index++)
                            {
                                hoPtr = (CObject)data.myList.get(index);
                                if (data.cdy != 0)
                                {
                                    hoPtr.hoY = (hoPtr.hoY + data.cdy);
                                    ho.roc.rcAnim = CAnim.ANIMID_WALK;
                                    if (hoPtr.roa != null)
                                    {
                                        hoPtr.roa.animations();
                                    }
                                    moveIt();
                                }
                                else
                                {
                                    hoPtr.hoX = (hoPtr.hoX + data.cdx);
                                    ho.roc.rcAnim = CAnim.ANIMID_WALK;
                                    if (hoPtr.roa != null)
                                    {
                                        hoPtr.roa.animations();
                                    }
                                    moveIt();
                                }
                            }
                        }
                    }
                }
                //*** Objects have been moved return true
                if (data.frames % data.speed == 0)
                {
                    return true;
                }
            }
            //** The object has not been moved
            return false;
        }

        public override void setPosition(int x, int y)
        {
            ho.hoX = x;
            ho.hoY = y;
        }

        public override void setXPosition(int x)
        {
            ho.hoX = x;
        }

        public override void setYPosition(int y)
        {
            ho.hoY = y;
        }

        public override void stop(bool bCurrent)
        {
            CGlobalDataInvader data = (CGlobalDataInvader)rh.getStorage(IDENTIFIER);
            if (data != null)
            {
                data.isMoving = false;
            }
        }

        public override void reverse()
        {
            CGlobalDataInvader data = (CGlobalDataInvader)rh.getStorage(IDENTIFIER);
            if (data != null)
            {
                data.cdx *= -1;
            }
        }

        public override void start()
        {
            CGlobalDataInvader data = (CGlobalDataInvader)rh.getStorage(IDENTIFIER);
            if (data != null)
            {
                data.isMoving = true;
            }
        }

        public override void setSpeed(int speed)
        {
            CGlobalDataInvader data = (CGlobalDataInvader)rh.getStorage(IDENTIFIER);
            if (data != null)
            {
                data.speed = 101 - speed;
                if (data.speed < 1)
                {
                    data.speed = 1;
                }
            }
        }


        public override double actionEntry(int action)
        {
            CGlobalDataInvader data = (CGlobalDataInvader)rh.getStorage(IDENTIFIER);
            if (data == null)
            {
                return 0;
            }

            int param;
            switch (action)
            {
                case 3745:		// SET_INVADERS_SPEED = 3745,
                    param = (int)getParamDouble();
                    data.speed = param;
                    if (data.speed < 1)
                    {
                        data.speed = 1;
                    }
                    break;
                case 3746:		// SET_INVADERS_STEPX,
                    param = (int)getParamDouble();
                    data.dx = param;
                    break;
                case 3747:		// SET_INVADERS_STEPY,
                    param = (int)getParamDouble();
                    data.dy = param;
                    break;
                case 3748:		// SET_INVADERS_LEFTBORDER,
                    param = (int)getParamDouble();
                    data.minX = param;
                    break;
                case 3749:		// SET_INVADERS_RIGHTBORDER,
                    param = (int)getParamDouble();
                    data.maxX = param;
                    break;
                case 3750:		// GET_INVADERS_SPEED,
                    return data.speed;
                case 3751:		// GET_INVADERS_STEPX,
                    return data.dx;
                case 3752:		// GET_INVADERS_STEPY,
                    return data.dy;
                case 3753:		// GET_INVADERS_LEFTBORDER,
                    return data.minX;
                case 3754:		// GET_INVADERS_RIGHTBORDER,
                    return data.maxX;
            }
            return 0;
        }
    }

    class CGlobalDataInvader : CExtStorage
    {
        public int count = 0;
        public int tillSpeedIncrease = 0;
        public int dx = 1;
        public int dy = 0;
        public int cdx = 0;
        public int cdy = 0;
        public int speed = 0;
        public int frames = 0;
        public int initialSpeed = 0;
        public int minX = 0;
        public int maxX = 640;
        public bool isMoving = false;
        public bool autoSpeed = false;
        public CArrayList myList = null;
    }
}
