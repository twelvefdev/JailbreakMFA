﻿//----------------------------------------------------------------------------------
//
// CRUNMVTSIMPLEELLIPSE
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Movements;
using RuntimeXNA.Services;
using RuntimeXNA.Objects;
using RuntimeXNA.Animations;
using RuntimeXNA.Sprites;
using RuntimeXNA.Application;

namespace RuntimeXNA.Movements
{
    class CRunMvtclickteam_simple_ellipse : CRunMvtExtension
    {
        const int MFLAG1_MOVEATSTART = 1;
        int m_dwCX;
        int m_dwCY;
        int m_dwRadiusX;
        int m_dwRadiusY;
        int m_dwStartAngle;
        int m_dwFlags;
        int m_dwAngVel;
        int m_dwOffset;
        bool r_Stopped;
        int r_CX;
        int r_CY;
        int r_radiusX;
        int r_radiusY;
        double r_AngVel;
        double r_Offset;
        double r_CurrentAngle;

        public override void initialize(CFile file)
        {
            file.skipBytes(1);
            m_dwCX = file.readAInt();
            m_dwCY = file.readAInt();
            m_dwRadiusX = file.readAInt();
            m_dwRadiusY = file.readAInt();
            m_dwStartAngle = file.readAInt();
            m_dwFlags = file.readAInt();
            m_dwAngVel = file.readAInt();
            m_dwOffset = file.readAInt();

            r_Stopped = ((m_dwFlags & MFLAG1_MOVEATSTART) == 0);

            r_CX = m_dwCX;
            r_CY = m_dwCY;
            r_AngVel = m_dwAngVel / 50.0 * (Math.PI / 180.0);
            r_Offset = m_dwOffset * (Math.PI / 180.0);
            r_CurrentAngle = m_dwStartAngle * (Math.PI / 180.0);
            r_radiusX = m_dwRadiusX;
            r_radiusY = m_dwRadiusY;

            ho.roc.rcSpeed = m_dwAngVel;
        }

        public override bool move()
        {
            //*** Object needs to be moved?
            if (!r_Stopped)
            {
                double x = r_radiusX * Math.Cos(r_CurrentAngle);
                double y = r_radiusY * Math.Sin(r_CurrentAngle);

                //*** Carry out 2D transform if needed
                if (Math.Abs(r_Offset) > 0.0001)
                {
                    double xprime = Math.Cos(r_Offset) * x - y * Math.Sin(r_Offset);
                    double yprime = Math.Sin(r_Offset) * x + y * Math.Cos(r_Offset);

                    x = xprime;
                    y = yprime;
                }

                double calculs = r_AngVel;
                if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
                {
                    calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
                }

                r_CurrentAngle += calculs;

                if (r_CurrentAngle < 0)
                {
                    r_CurrentAngle += 2 * Math.PI;
                }
                else if (r_CurrentAngle > 2 * Math.PI)
                {
                    r_CurrentAngle -= 2 * Math.PI;
                }

                animations(CAnim.ANIMID_WALK);
                ho.hoX = (int) (r_CX + x);
                ho.hoY = (int) (r_CY - y);
                collisions();

                //*** Indicate the object has been moved
                return true;
            }
            animations(CAnim.ANIMID_STOP);
            collisions();

            //*** The object has not been moved
            return ho.roc.rcChanged;
        }

        void reset()
        {
            r_CX = m_dwCX;
            r_CY = m_dwCY;
            r_AngVel = m_dwAngVel / 50.0 * (Math.PI / 180.0);
            r_Offset = m_dwOffset * (Math.PI / 180.0);
            r_CurrentAngle = m_dwStartAngle * (Math.PI / 180.0);
            r_radiusX = m_dwRadiusX;
            r_radiusY = m_dwRadiusY;
        }

        public override void setPosition(int x, int y)
        {
            r_CX -= ho.hoX - x;
            r_CY -= ho.hoY - y;

            ho.hoX = x;
            ho.hoY = y;
        }

        public override void setXPosition(int x)
        {
            r_CX -= ho.hoX - x;
            ho.hoX = x;
        }

        public override void setYPosition(int y)
        {
            r_CY -= ho.hoY - y;
            ho.hoY = y;
        }

        public override void stop(bool bCurrent)
        {
            r_Stopped = true;
        }

        public override void reverse()
        {
            r_AngVel *= -1;
        }

        public override void start()
        {
            r_Stopped = false;
        }

        public override void setSpeed(int speed)
        {
            //*** Linear motion components;
            r_AngVel = (speed) / 50.0 * (Math.PI / 180.0);
            ho.roc.rcSpeed = speed;
        }

        public override double actionEntry(int action)
        {
            int param;
            switch (action)
            {
                case 3645:	    // SET_CENTRE_X = 3645,
                    param = (int) getParamDouble();
                    r_CX = param;
                    break;
                case 3646:	    // SET_CENTRE_Y,
                    param = (int) getParamDouble();
                    r_CY = param;
                    break;
                case 3647:	    // SET_RADIUS_X,
                    param = (int) getParamDouble();
                    r_radiusX = param;
                    break;
                case 3648:	    // SET_RADIUS_Y,
                    param = (int) getParamDouble();
                    r_radiusY = param;
                    break;
                case 3649:	    // SET_ANGSPEED,
                    param = (int) getParamDouble();
                    r_AngVel = param / 50.0 * (Math.PI / 180.0);
                    ho.roc.rcSpeed = param;
                    break;
                case 3650:	    // SET_CURRENTANGLE,
                    param = (int) getParamDouble();
                    r_CurrentAngle = param * (Math.PI / 180.0);
				    break;
                case 3651:	    // SET_OFFSETANGLE,
                    param = (int) getParamDouble();
                    r_Offset = param * (Math.PI / 180.0);
				    break;
                case 3652:	    // GET_CENTRE_X,
                    return r_CX;
                case 3653:	    // GET_CENTRE_Y,
                    return r_CY;
                case 3654:	    // GET_RADIUS_X,
                    return r_radiusX;
                case 3655:	    // GET_RADIUS_Y,
                    return r_radiusY;
                case 3656:	    // GET_ANGSPEED,
                    return r_AngVel * 50.0 * (180.0 / Math.PI);
                case 3657:	    // GET_CURRENTANGLE,
                    return r_CurrentAngle * (180 / Math.PI);
                case 3658:	    // GET_OFFSETANGLE
                    return r_Offset * (180 / Math.PI);
            }
            return 0;
        }

        public override int getSpeed()
        {
            return ho.roc.rcSpeed;
        }
    }
}
