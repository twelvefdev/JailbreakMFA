﻿//----------------------------------------------------------------------------------
//
// CRUNMVTPINBALL : movement pinball
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Movements;
using RuntimeXNA.Services;
using RuntimeXNA.Objects;
using RuntimeXNA.Animations;
using RuntimeXNA.Sprites;
using RuntimeXNA.Application;

namespace RuntimeXNA.Movements
{
    class CRunMvtpinball : CRunMvtExtension
    {
        public const int EFLAG_MOVEATSTART = 1;
        public const int MFLAG_STOPPED = 1;
        int m_dwInitialSpeed;
        int m_dwDeceleration;
        int m_dwGravity;
        int m_dwInitialDir;
        int m_dwFlags;
        double m_gravity;
        double m_xVector;
        double m_yVector;
        double m_X;
        double m_Y;
        double m_deceleration;
        int m_flags;

        public override void initialize(CFile file)
        {
            file.skipBytes(1);
            m_dwInitialSpeed = file.readAInt();
            m_dwDeceleration = file.readAInt();
            m_dwGravity = file.readAInt();
            m_dwInitialDir = file.readAInt();
            m_dwFlags = file.readAInt();

            // Initialisations
            m_X = ho.hoX;
            m_Y = ho.hoY;
            ho.roc.rcSpeed = m_dwInitialSpeed;

            // Finds the initial direction
            ho.roc.rcDir = dirAtStart(m_dwInitialDir);
            double angle = (ho.roc.rcDir * 2 * Math.PI) / 32.0;

            // Calculates the vectors
            m_gravity = m_dwGravity;
            m_deceleration = m_dwDeceleration;
            m_xVector = ho.roc.rcSpeed * Math.Cos(angle);
            m_yVector = -ho.roc.rcSpeed * Math.Sin(angle);

            // Move at start
            m_flags = 0;
            if ((m_dwFlags & EFLAG_MOVEATSTART) == 0)
            {
                m_flags |= MFLAG_STOPPED;
            }
        }

        double getAngle(double vX, double vY)
        {
            double vector = Math.Sqrt(vX * vX + vY * vY);
            if (vector == 0.0)
            {
                return 0.0;
            }
            double angle = Math.Acos(vX / vector);
            if (vY > 0.0)
            {
                angle = 2.0 * Math.PI - angle;
            }
            return angle;
        }

        public double getVector(double vX, double vY)
        {
            return Math.Sqrt(vX * vX + vY * vY);
        }

        public override bool move()
        {
            // Stopped?
            if ((m_flags & MFLAG_STOPPED) != 0)
            {
                animations(CAnim.ANIMID_STOP);
                collisions();
                return ho.roc.rcChanged;
            }

            // Increase Y speed
            m_yVector += m_gravity / 10.0;

            // Get the current vector of the ball
            double angle = getAngle(m_xVector, m_yVector);	// Get the angle and vector
            double vector = getVector(m_xVector, m_yVector);
            double calculs = m_deceleration;
            if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
            {
                calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
            }
            vector -= calculs / 50.0;
            if (vector < 0.0)
            {
                vector = 0.0;
            }
            m_xVector = vector * Math.Cos(angle);					// Restores X and Y speeds
            m_yVector = -vector * Math.Sin(angle);

            // Calculate the new position
            calculs = m_xVector;
            if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
            {
                calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
            }
            m_X = m_X + (calculs / 10.0);
            calculs = m_yVector;
            if ((ho.hoAdRunHeader.rhFrame.leFlags & CRunFrame.LEF_TIMEDMVTS) != 0)
            {
                calculs = calculs * ho.hoAdRunHeader.rh4MvtTimerCoef;
            }
            m_Y = m_Y + (calculs / 10.0);

            // Performs the animation
            ho.roc.rcSpeed = (int)vector;
            if (ho.roc.rcSpeed > 100)
            {
                ho.roc.rcSpeed = 100;
            }
            ho.roc.rcDir = (int)((angle * 32) / (2.0 * Math.PI));
            animations(CAnim.ANIMID_WALK);

            // detects the collisions
            ho.hoX = (int)m_X;
            ho.hoY = (int)m_Y;
            collisions();

            // The object has been moved
            return true;
        }

        public override void setPosition(int x, int y)
        {
            ho.hoX = (int)x;
            ho.hoY = (int)y;
            m_X = x;
            m_Y = y;
        }

        public override void setXPosition(int x)
        {
            ho.hoX = (int)x;
            m_X = x;
        }

        public override void setYPosition(int y)
        {
            ho.hoY = (int)y;
            m_Y = y;
        }

        public override void stop(bool bCurrent)
        {
            m_flags |= MFLAG_STOPPED;
        }

        public override void bounce(bool bCurrent)
        {
            if (!bCurrent)
            {
                m_xVector = -m_xVector;
                m_yVector = -m_yVector;
                return;
            }

            // Takes the object against the obstacle
            CPoint pt = new CPoint();
            approachObject(ho.hoX, ho.hoY, ho.roc.rcOldX, ho.roc.rcOldY, 0, CColMask.CM_TEST_PLATFORM, pt);
            ho.hoX = pt.x;
            ho.hoY = pt.y;
            m_X = pt.x;
            m_Y = pt.y;

            // Get the current vector of the ball
            double angle = getAngle(m_xVector, m_yVector);
            double vector = getVector(m_xVector, m_yVector);

            // Finds the shape of the obstacle
            double a;
            double aFound = -1000;
            for (a = 0.0; a < 2.0 * Math.PI; a += Math.PI / 32.0)
            {
                double xVector = 16 * Math.Cos(angle + a);
                double yVector = -16 * Math.Sin(angle + a);
                double x = m_X + xVector;
                double y = m_Y + yVector;

                if (testPosition((int)x, (int)y, 0, CColMask.CM_TEST_PLATFORM, false))
                {
                    aFound = a;
                    break;
                }
            }

            // If nothing is found, simply go backward
            if (aFound == -1000)
            {
                m_xVector = -m_xVector;
                m_yVector = -m_yVector;
            }
            else
            {
                // The angle is found, proceed with the bounce
                angle += aFound * 2;
                if (angle > 2.0 * Math.PI)
                {
                    angle -= 2.0 * Math.PI;
                }

                // Restores the speed vectors
                m_xVector = vector * Math.Cos(angle);
                m_yVector = -vector * Math.Sin(angle);
            }
        }

        public override void reverse()
        {
            m_xVector = -m_xVector;
            m_yVector = -m_yVector;
        }

        public override void start()
        {
            m_flags &= ~MFLAG_STOPPED;
        }

        public override void setSpeed(int speed)
        {
            ho.roc.rcSpeed = speed;

            // Gets the current speed vector
            double angle = getAngle(m_xVector, m_yVector);
            double vector = getVector(m_xVector, m_yVector);

            // Changes the current x and y vectors
            m_xVector = speed * Math.Cos(angle);
            m_yVector = -speed * Math.Sin(angle);
        }

        public override void setDir(int dir)
        {
            ho.roc.rcDir = dir;

            // Get the current speed vector
            double angle = getAngle(m_xVector, m_yVector);
            double vector = getVector(m_xVector, m_yVector);

            // Converts the angle in 32 directions to a angle in radian
            angle = dir * 2.0 * Math.PI / 32.0;

            // Changes the speeds
            m_xVector = vector * Math.Cos(angle);
            m_yVector = -vector * Math.Sin(angle);
        }

        public override void setGravity(int gravity)
        {
            m_gravity = gravity;
        }

        public override double actionEntry(int action)
        {
            switch (action)
            {
                default:		// SET_INVADERS_SPEED = 3745,
                    m_gravity = getParamDouble();
                    break;
            }
            return 0;
        }

        public override int getSpeed()
        {
            return ho.roc.rcSpeed;
        }

        public override int getDeceleration()
        {
            return (int)m_deceleration;
        }

        public override int getGravity()
        {
            return (int)m_gravity;
        }

    }
}
