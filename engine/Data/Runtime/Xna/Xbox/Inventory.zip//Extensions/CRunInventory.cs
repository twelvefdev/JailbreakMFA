﻿//----------------------------------------------------------------------------------
//
// CRUNKCBUTTON
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;
#if !WINDOWS_PHONE
using Microsoft.Xna.Framework.Storage;
#else
using System.IO.IsolatedStorage;
#endif

namespace RuntimeXNA.Extensions
{
    class CRunInventory : CRunExtension, IControl
    {
	    const int CND_NAMEDITEMSELECTED=0;
	    const int CND_NAMEDCOMPARENITEMS=1;
	    const int CND_ITEMSELECTED=2;
	    const int CND_COMPARENITEMS=3;
	    const int CND_NAMEDITEMPRESENT=4;
	    const int CND_ITEMPRESENT=5;
	    const int CND_NAMEDHILIGHTED=6;
	    const int CND_HILIGHTED=7;
	    const int CND_CANADD=8;
	    const int CND_NAMEDCANADD=9;
	    const int CND_LAST=10;
	    const int ACT_NAMEDADDITEM=0;
	    const int ACT_NAMEDADDNITEMS=1;
	    const int ACT_NAMEDDELITEM=2;
	    const int ACT_NAMEDDELNITEMS=3;
	    const int ACT_NAMEDHIDEITEM=4;
	    const int ACT_NAMEDSHOWITEM=5;
	    const int ACT_ADDITEM=6;
	    const int ACT_ADDNITEMS=7;
	    const int ACT_DELITEM=8;
	    const int ACT_DELNITEMS=9;
	    const int ACT_HIDEITEM=10;
	    const int ACT_SHOWITEM=11;
	    const int ACT_LEFT=12;
	    const int ACT_RIGHT=13;
	    const int ACT_UP=14;
	    const int ACT_DOWN=15;
	    const int ACT_SELECT=16;
	    const int ACT_CURSOR=17;
	    const int ACT_NAMEDSETSTRING=18;
	    const int ACT_SETSTRING=19;
	    const int ACT_ACTIVATE=20;
	    const int ACT_NAMEDSETMAXIMUM=21;
	    const int ACT_SETMAXIMUM=22;
	    const int ACT_SETPOSITION=23;
	    const int ACT_SETPAGE=24;
	    const int ACT_ADDPROPERTY=25;
	    const int ACT_NAMEDSETPROPMINMAX=26;
	    const int ACT_SETPROPMINMAX=27;
	    const int ACT_NAMEDADDPROPERTY=28;
	    const int ACT_ADDGRIDITEM=29;
	    const int ACT_ADDGRIDNITEMS=30;
	    const int ACT_NAMEDADDGRIDITEM=31;
	    const int ACT_NAMEDADDGRIDNITEMS=32;
	    const int ACT_HILIGHTDROP=33;
	    const int ACT_NAMEDHILIGHTDROP=34;
	    const int ACT_SAVE=35;
	    const int ACT_LOAD=36;
	    const int ACT_ADDLISTITEM=37;
	    const int ACT_ADDLISTNITEMS=38;
	    const int ACT_NAMEDADDLISTITEM=39;
	    const int ACT_NAMEDADDLISTNITEMS=40;
	    const int EXP_NITEM=0;
	    const int EXP_NAMEOFHILIGHTED=1;
	    const int EXP_NAMEOFSELECTED=2;
	    const int EXP_POSITION=3;
	    const int EXP_PAGE=4;
	    const int EXP_TOTAL=5;
	    const int EXP_DISPLAYED=6;
	    const int EXP_NUMOFSELECTED=7;
	    const int EXP_NUMOFHILIGHTED=8;
	    const int EXP_NAMEOFNUM=9;
	    const int EXP_MAXITEM=10;
	    const int EXP_NUMBERMAXITEM=11;
	    const int EXP_NUMBERNITEM=12;
	    const int EXP_GETPROPERTY=13;
	    const int EXP_NUMBERGETPROPERTY=14;

	    const int IFLAG_CURSOR=0x0001;
	    const int IFLAG_HSCROLL=0x0002;
	    const int IFLAG_VSCROLL=0x0004;
	    const int IFLAG_SORT=0x0010;
	    const int IFLAG_MOUSE=0x0020;
	    const int IFLAG_FORCECURSOR=0x0040;
	    const int IFLAG_CURSORBYACTION=0x0080;
	    const int IFLAG_DISPLAYGRID=0x0100;
	    const int INVTYPE_LIST=0;
	    const int INVTYPE_GRID=1;

        const int VK_LEFT = 1;
        const int VK_RIGHT = 2;
        const int VK_UP = 3;
        const int VK_DOWN = 4;
        const int VK_RETURN = 5;

        public static CInventoryList inventory = new CInventoryList();
		int				type;
		int				number;
		int				itemSx;
		int				itemSy;
		int				flags;
		int				textAlignment;
		CFontInfo		logFont;
		int				fontColor;
		int				scrollColor;
		int				scrollColor2;
		int				cursorColor;
		int				gridColor;
		int				cursorType;
		string			pDisplayString;

		CArrayList		displayList=new CArrayList();
		CArrayList		objectList=new CArrayList();
		CScrollBar		slider=new CScrollBar();
		int				nColumns;
		int				nLines;
		int				position;
		int				xCursor;
		int				yCursor;
		bool			bUpdateList;
		bool			bRedraw;
		int				displayQuantity;
		int				showQuantity;
		int				oldKey;
		int				selectedCount;
		bool			oldBMouse;
		bool			bActivated;
		string			pNameSelected;
		string			pNameHilighted;
		int				maximum;
		int				numSelected;
		int				numHilighted;
		int[]			pGrid;
		CRect			rcDrop=new CRect();
		bool			bDropItem;
		int				scrollX;
		int				scrollY;
		int				scrollPosition;
		bool			oldBHidden;
		CFont			font;
        string          conditionString;
#if !WINDOWS_PHONE
        Object stateobj;
#endif
#if XBOX
        GamePadState[] states=new GamePadState[4];
#endif
        public override int getNumberOfConditions()
        {
            return CND_LAST;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
			ho.hoImgWidth=file.readAInt();
			ho.hoImgHeight=file.readAInt();
			number=file.readAShort();
			itemSx=file.readAShort();
			itemSy=file.readAShort();
			flags=file.readAInt();
			textAlignment=file.readAInt();
			logFont=file.readLogFont();
			fontColor=file.readAColor();
			scrollColor=file.readAColor();
			displayQuantity=file.readAInt();
			showQuantity=file.readAInt();
			scrollColor2=file.readAColor();
			maximum=file.readAInt();
			cursorColor=file.readAColor();
			cursorType=file.readAInt();
			type=file.readAShort();
			gridColor=file.readAColor();
			pDisplayString=file.readAString();
			nColumns=Math.Max(ho.hoImgWidth/itemSx, 1);
			nLines=Math.Max(ho.hoImgHeight/itemSy, 1);
			selectedCount=-1;
			numSelected=-1;
			numHilighted=-1;
			position=0;
			bDropItem=false;
			if (type==INVTYPE_LIST)
			{
				SetSlider();
			}
			UpdateDisplayList();
			oldBHidden=false;
			bUpdateList=true;
            font=CFont.createFromFontInfo(logFont, ho.hoAdRunHeader.rhApp);
#if XBOX
            ho.hoAdRunHeader.addControl((IControl)this);
#endif
            return true;
        }

        public override void destroyRunObject(bool bFast)
        {
            ho.hoAdRunHeader.delControl((IControl)this);
        }

		void SetSlider()
		{
			if ((flags&IFLAG_HSCROLL)!=0)
			{
				int x=ho.hoX-rh.rhWindowX;
				int y=ho.hoY-rh.rhWindowY+ho.hoImgHeight-CScrollBar.SY_SLIDER;
				slider.Initialise(rh, x, y, ho.hoImgWidth, CScrollBar.SY_SLIDER, scrollColor, scrollColor2, this);
			}
			else if ((flags&IFLAG_VSCROLL)!=0)
			{
				int x=ho.hoX-rh.rhWindowX+ho.hoImgWidth-CScrollBar.SX_SLIDER;
				int y=ho.hoY-rh.rhWindowY;
				slider.Initialise(rh, x, y, CScrollBar.SX_SLIDER, ho.hoImgHeight, scrollColor, scrollColor2, this);
			}
		}
		void obHide(CObject hoPtr)
		{
			if ((hoPtr.ros.rsFlags&CRSpr.RSFLAG_HIDDEN)==0)
			{
				hoPtr.ros.rsFlags|=CRSpr.RSFLAG_HIDDEN;
				hoPtr.ros.rsCreaFlags|=CSprite.SF_HIDDEN;
				hoPtr.ros.rsFadeCreaFlags|=CSprite.SF_HIDDEN;
				hoPtr.roc.rcChanged=true;
				if (hoPtr.roc.rcSprite!=null)
				{
					rh.rhApp.spriteGen.showSprite(hoPtr.roc.rcSprite, false);
				}
			}
		}

		void obShow(CObject hoPtr)
		{
			if ((hoPtr.ros.rsFlags&CRSpr.RSFLAG_HIDDEN)!=0)
			{
				hoPtr.ros.rsCreaFlags&=~CSprite.SF_HIDDEN;
				hoPtr.ros.rsFadeCreaFlags&=~CSprite.SF_HIDDEN;
				hoPtr.ros.rsFlags&=~CRSpr.RSFLAG_HIDDEN;
				hoPtr.hoFlags&=~CObject.HOF_NOCOLLISION;	
				hoPtr.roc.rcChanged=true;
				if (hoPtr.roc.rcSprite!=null)
				{
					rh.rhApp.spriteGen.showSprite(hoPtr.roc.rcSprite, true);
				}
			}
		}

		int GetFixedValue(CObject pHo)
		{
			return (pHo.hoCreationId<<16)|(pHo.hoNumber&0xFFFF);
		}

		CObject GetHO(int fixedValue)
		{
			CObject hoPtr=rh.rhObjectList[fixedValue&0xFFFF];
			if (hoPtr!=null && hoPtr.hoCreationId==fixedValue>>16)
			{
				return hoPtr;
			}
			return null;
		}

		void showHide(bool bHidden)
		{
			int n;
			if (!bHidden)
			{
				for (n=0; n<objectList.size(); n++)
				{
					CObject hoPtr=GetHO((int)objectList.get(n));
					if (hoPtr!=null)
					{
						obShow(hoPtr);
					}
				}
			}
			else
			{
				for (n=0; n<objectList.size(); n++)
				{
					CObject hoPtr=GetHO((int)objectList.get(n));
					if (hoPtr!=null)
					{
						obHide(hoPtr);
					}
				}
			}
		}

		void CenterDisplay(int pos)
		{
			int size=nColumns*nLines;
			if (pos<position)
			{
				position=pos;
			}
			else if (pos>=position+size)
			{
				position=Math.Max(0, pos-size+1);
			}
		}

		void UpdateDisplayList()
		{
			displayList.clear();
			objectList.clear();
			if (type==INVTYPE_GRID)
			{
				if (pGrid==null)
				{
					pGrid=new int[nColumns*nLines];
				}
				int n;
				for (n=nColumns*nLines-1; n>=0; n--)
					pGrid[n]=0;
			}

			CInventoryItem pItem;
			for (pItem=inventory.FirstItem(number); pItem!=null; pItem=inventory.NextItem(number))
			{
				string pName=pItem.GetName();
				int objectNum=0;
				for (int nObject=0; nObject<rh.rhNObjects; objectNum++, nObject++)
				{
					while(rh.rhObjectList[objectNum]==null) objectNum++;
					CObject hoPtr=rh.rhObjectList[objectNum];
					if (hoPtr.hoType==2)
					{
						CObjInfo pOiList=hoPtr.hoOiList;
						if (pOiList.oilName==pName)
						{
							if (pItem.GetQuantity()>=showQuantity)
							{
								if ((pItem.GetFlags()&CInventoryItem.FLAG_VISIBLE)!=0)
								{
									displayList.add(pItem);
									int fix=GetFixedValue(hoPtr);
									objectList.add(fix);
									if (type==INVTYPE_GRID)
									{
										int sx=(hoPtr.hoImgWidth+itemSx-1)/itemSx;
										int sy=(hoPtr.hoImgHeight+itemSy-1)/itemSy;
										int x, y;
										for (y=0; y<sy; y++)
										{
											for (x=0; x<sx; x++)
											{
												pGrid[(pItem.y+y)*nColumns+pItem.x+x]=fix;
											}
										}
										rh.rhApp.spriteGen.moveSpriteToFront(hoPtr.roc.rcSprite);
									}
								}
								else
								{
									obHide(hoPtr);
								}
								break;
							}
							else
							{
								obHide(hoPtr);
							}
						}
					}
				}
			}
			if (type==INVTYPE_LIST && displayList.size()>2 && (flags&IFLAG_SORT)!=0)
			{
				int n;
				bool bFlag=true;
				while(bFlag==true)
				{
					bFlag=false;
					for (n=0; n<displayList.size()-1; n++)
					{
						CInventoryItem pItem1=(CInventoryItem)displayList.get(n);
						CInventoryItem pItem2=(CInventoryItem)displayList.get(n+1);
						string pName1=pItem1.GetName();
						string pName2=pItem2.GetName();
						if (String.Compare(pName1, pName2)>0)
						{
							displayList.swap(n, n+1);
							objectList.swap(n, n+1);
							bFlag=true;
						}
					}
				}
			}
			bUpdateList=true;
			ho.redraw();
		}


		void SetPosition(CObject pHo, int x, int y)
		{
			pHo.hoX=x+pHo.hoImgXSpot;
			pHo.hoY=y+pHo.hoImgYSpot;
			pHo.rom.rmMoveFlag=true;	
			pHo.roc.rcChanged=true;
			pHo.roc.rcCheckCollides=true;
		}

		bool CheckDisplayList()
		{
			bool bRet=false;
			int o;
			for (o=0; o<displayList.size(); o++)
			{
				CInventoryItem pItem=(CInventoryItem)displayList.get(o);
				int fixedValue=(int)objectList.get(o);
				CObject hoPtr=GetHO(fixedValue);
				if (hoPtr==null)
				{
					displayList.remove(o);
					objectList.remove(o);
					o--;
					bRet=true;
				}
			}
			return bRet;
		}

		public void Scroll(int type, int slide)
		{
			int pos=position;
			if (slider.bHorizontal==false)
			{
				switch(type)
				{
				case CScrollBar.SCROLL_UP:
					pos--;
					break;
				case CScrollBar.SCROLL_PAGEUP:
					pos-=nColumns;
					break;
				case CScrollBar.SCROLL_PAGEDOWN:
					pos+=nColumns;
					break;
				case CScrollBar.SCROLL_DOWN:
					pos++;
					break;
				case CScrollBar.SCROLL_SLIDE:
					pos=slide;
					break;
				}
			}
			else
			{
				switch(type)
				{
				case CScrollBar.SCROLL_UP:
					pos--;
					break;
				case CScrollBar.SCROLL_PAGEUP:
					pos-=nLines;
					break;
				case CScrollBar.SCROLL_PAGEDOWN:
					pos+=nLines;
					break;
				case CScrollBar.SCROLL_DOWN:
					pos++;
					break;
				case CScrollBar.SCROLL_SLIDE:
					pos=slide;
					break;
				}
			}
			if (pos<0)
			{
				pos=0;
			}
			if (pos>displayList.size()-nColumns*nLines)
			{
				pos=displayList.size()-nColumns*nLines;
			}
			if (pos!=position)
			{
				position=pos;
				slider.SetPosition(position, Math.Min(displayList.size()-position, nLines*nColumns), displayList.size()); 
				bRedraw=true;
				bUpdateList=true;
			}
		}

		int GetGridRect(int x, int y, CRect pRc)
		{
			int fix=pGrid[y*nColumns+x];
			if (fix!=0)
			{
				int xx, yy;
				for (xx=0; xx<x; xx++)
				{
					if (pGrid[y*nColumns+xx]==fix)
					{
						break;
					}
				}
				pRc.left=ho.hoX-rh.rhWindowX+xx*itemSx;
				for (xx=x; xx<nColumns; xx++)
				{
					if (pGrid[y*nColumns+xx]!=fix)
					{
						break;
					}
				}
				pRc.right=ho.hoX-rh.rhWindowX+xx*itemSx;
				for (yy=0; yy<y; yy++)
				{
					if (pGrid[yy*nColumns+x]==fix)
					{
						break;
					}
				}
				pRc.top=ho.hoY-rh.rhWindowY+yy*itemSy;
				for (yy=y; yy<nLines; yy++)
				{
					if (pGrid[yy*nColumns+x]!=fix)
					{
						break;
					}
				}
				pRc.bottom=ho.hoY-rh.rhWindowY+yy*itemSy;
			}
			else
			{
				pRc.left=ho.hoX-rh.rhWindowX+x*itemSx;
				pRc.right=pRc.left+itemSx;
				pRc.top=ho.hoY-rh.rhWindowY+y*itemSy;
				pRc.bottom=pRc.top+itemSy;
			}
			return fix;
		}
        int getKeys()
        {
            int key=0;
#if WINDOWS
            if (rh.isKeyDown(Keys.Up))
                key = VK_UP;
            if (rh.isKeyDown(Keys.Down))
                key = VK_DOWN;
            if (rh.isKeyDown(Keys.Left))
                key = VK_LEFT;
            if (rh.isKeyDown(Keys.Right))
                key = VK_RIGHT;
            if (rh.isKeyDown(Keys.Enter))
                key = VK_RETURN;
#endif
#if XBOX
            int n;
            for (n = 0; n < 4; n++)
            {
                states[n] = GamePad.GetState(getPlayer(n));

                if (states[n].DPad.Up == ButtonState.Pressed)
                {
                    key = VK_UP;
                    break;
                }
                if (states[n].DPad.Down== ButtonState.Pressed)
                {
                    key = VK_DOWN;
                    break;
                }
                if (states[n].DPad.Left == ButtonState.Pressed)
                {
                    key = VK_LEFT;
                    break;
                }
                if (states[n].DPad.Right == ButtonState.Pressed)
                {
                    key = VK_RIGHT;
                    break;
                }
                if (states[n].Buttons.A == ButtonState.Pressed)
                {
                    key = VK_RETURN;
                    break;
                }
            }
#endif
            return key;
        }
        PlayerIndex getPlayer(int num)
        {
            switch (num)
            {
                case 0:
                    return PlayerIndex.One;
                case 1:
                    return PlayerIndex.Two;
                case 2:
                    return PlayerIndex.Three;
                case 3:
                    return PlayerIndex.Four;
            }
            return PlayerIndex.One;
        }

        // IControl interface
        public void click(int nClicks)
        {
        }
        public void drawControl(SpriteBatchEffect batch)
        {
        }
        public int getX()
        {
            return ho.hoX;
        }
        public int getY()
        {
            return ho.hoY;
        }
        public void setMouseControlled(bool bFlag)
        {
        }
        public void setFocus(bool bFlag)
        {
            bActivated=bFlag;
        }
		private void CleanList()
		{
			int n;
			for (n=0; n<objectList.size(); n++)
			{
				int fix=(int)objectList.get(n);
				if (GetHO(fix)==null)
				{
					CInventoryItem pItem=(CInventoryItem)displayList.get(n);
					inventory.list.remove(pItem);
				}
			}
		}

        public override int handleRunObject()
        {
			short ret=0;
			bool bUpdate=false;

            CleanList();

			if (bUpdateList)
			{
				UpdateDisplayList();
				ret=REFLAG_DISPLAY;
			}
			else
			{
				if (CheckDisplayList())
				{
					ret=REFLAG_DISPLAY;
				}
			}
			if (bRedraw)
			{
				ret=REFLAG_DISPLAY;
                bRedraw = false;
			}

			bool bHidden=(ho.ros.rsFlags&CRSpr.RSFLAG_HIDDEN)!=0;
			if (bHidden!=oldBHidden)
			{
				oldBHidden=bHidden;
				showHide(bHidden);
			}
			if (bHidden)
			{
				return ret;
			}

            int fix;
            int x, y, xx, yy;
            bool bFlag;
            numHilighted = -1;
            pNameHilighted = "";
            if (type == INVTYPE_LIST)
			{
				if (position>0 && position>Math.Max(0, displayList.size()-nLines*nColumns))
				{
					position=Math.Max(displayList.size()-nLines*nColumns, 0);
					bUpdate=true;
				}
				if (position+yCursor*nColumns+xCursor>=displayList.size())
				{
					xCursor=0;
					yCursor=0;
					bUpdate=true;
				}
				if (displayList.size()>0)
				{
					xx=rh.rh2MouseX-ho.hoX;
					yy=rh.rh2MouseY-ho.hoY;
					x=xx;
					y=yy;
					bFlag=false;
					if ((flags&IFLAG_MOUSE)!=0)
					{
						if (x>=0 && y>=0 && x<ho.hoImgWidth && y<ho.hoImgHeight)
						{
#if WINDOWS
							if (slider.IsMouseInBar()==false)
#endif
							{
								x/=itemSx;
								y/=itemSy;
								if (x<nColumns && y<nLines)
								{
									int o=position+y*nColumns+x;
									if (o<position+displayList.size())
									{
										bFlag=true;
										if (xCursor!=x || yCursor!=y)
										{
											xCursor=x;
											yCursor=y;
											bUpdate=true;
										}
                                        CInventoryItem pItem = (CInventoryItem)displayList.get(o);
                                        pNameHilighted = pItem.GetName();
                                        numHilighted = o;
                                    }
								}
							}
						}
					}
					bool bMouse=(rh.mouseKey==0);
					if (bMouse!=oldBMouse)
					{
						oldBMouse=bMouse;
						if (bMouse==true && (flags&IFLAG_MOUSE)!=0)
						{
							scrollX=x*itemSx;
							scrollY=y*itemSy;
							scrollPosition=position;
							pNameSelected=pNameHilighted;
							numSelected=position+yCursor*nColumns+xCursor;
							selectedCount=rh.rh4EventCount;
							CInventoryItem pItem=(CInventoryItem)displayList.get(position+yCursor*nColumns+xCursor);
							CObject hoPtr=GetHO((int)objectList.get(position+yCursor*nColumns+xCursor));
                            conditionString=pItem.GetName();
							ho.generateEvent(CND_NAMEDITEMSELECTED, 0);
							ho.generateEvent(CND_ITEMSELECTED, hoPtr.hoOi);
						}
						if ((flags&IFLAG_CURSOR)!=0 && x>=0 && y>=0 && x<ho.hoImgWidth && y<ho.hoImgHeight)
						{
							bActivated=true;
							xCursor=x/itemSx;
							yCursor=y/itemSy;
							bUpdate=true;
						}
						else
						{
							bActivated=false;
							bUpdate=true;
						}
					}
					if (bMouse)
					{
#if WINDOWS
						if (slider.IsDragging()==false)
#endif
						{
							if ((flags&IFLAG_VSCROLL)!=0)
							{
								if (yy<scrollY)
									position=scrollPosition-((yy-scrollY-itemSy)/itemSy)*nColumns;
								else
									position=scrollPosition-((yy-scrollY)/itemSy)*nColumns;
								if (position<0)
									position=0;
								if (position>Math.Max(0, displayList.size()-nLines*nColumns))
									position=Math.Max(displayList.size()-nLines*nColumns, 0);
								bUpdate=true;
							}
							else if ((flags&IFLAG_HSCROLL)!=0)
							{
								if (xx<scrollX)
									position=scrollPosition-((xx-scrollX-itemSx)/itemSx)*nLines;
								else
									position=scrollPosition-((xx-scrollX)/itemSx)*nLines;
								if (position<0)
									position=0;
								if (position>Math.Max(0, displayList.size()-nLines*nColumns))
									position=Math.Max(displayList.size()-nLines*nColumns, 0);
								bUpdate=true;
							}
						}
					}
					if (bActivated)
					{
						bFlag=true;
					}
                    int key = getKeys();
					if (bActivated && (flags&IFLAG_CURSOR)!=0)
					{
						if (key!=oldKey)
						{
							oldKey=key;
							switch(key)
							{
							case VK_UP:
								yCursor--;
								if (yCursor<0)
								{
									yCursor++;
									position=Math.Max(position-nColumns, 0);
								}
								break;
							case VK_DOWN:
								yCursor++;
								if (yCursor>=nLines)
								{
									yCursor--;
									position=Math.Min(position+nColumns, displayList.size()-nColumns*nLines);
									position=Math.Max(position, 0);
								}
								break;
							case VK_RIGHT:
								xCursor++;
								if (xCursor>=nColumns)
								{
									xCursor--;
									position=Math.Min(position+1, displayList.size()-nColumns*nLines);
									position=Math.Max(position, 0);
								}
								break;
							case VK_LEFT:
								xCursor--;
								if (xCursor<0)
								{
									xCursor++;
									position=Math.Max(position-1, 0);
								}
								break;
							case VK_RETURN:
								{
									pNameSelected=pNameHilighted;
									selectedCount=rh.rh4EventCount;
									numSelected=position+yCursor*nColumns+xCursor;
									CInventoryItem pItem=(CInventoryItem)displayList.get(position+yCursor*nColumns+xCursor);
									CObject hoPtr=GetHO((int)objectList.get(position+yCursor*nColumns+xCursor));
                                    conditionString=pItem.GetName();
									ho.generateEvent(CND_NAMEDITEMSELECTED, 0);
									ho.generateEvent(CND_ITEMSELECTED, hoPtr.hoOi);
								}
								break;
							}
							bUpdate=true;
						}
					}
					if ((flags&IFLAG_CURSORBYACTION)==0)
					{
						if (bFlag)
						{
							if ((flags&IFLAG_FORCECURSOR)==0)
							{
								flags|=IFLAG_FORCECURSOR;
								bUpdate=true;
							}
						}
						else
						{
							if ((flags&IFLAG_FORCECURSOR)!=0)
							{
								flags&=~IFLAG_FORCECURSOR;
								bUpdate=true;
							}
						}
					}
				}

				if (bUpdate)
				{
					if (slider.bInitialised)
					{
						slider.SetPosition(position, Math.Min(displayList.size()-position, nLines*nColumns), displayList.size()); 
					}
				}
#if WINDOWS               
				if (slider.bInitialised)
				{
					slider.Handle();	
				}
#endif
			}
			else
			{
				// Grid display
				x=rh.rh2MouseX-ho.hoX;
				y=rh.rh2MouseY-ho.hoY;
				bFlag=false;
				if ((flags&IFLAG_MOUSE)!=0)
				{
					if (x>=0 && y>=0 && x<ho.hoImgWidth && y<ho.hoImgHeight)
					{
						x/=itemSx;
						y/=itemSy;
						if (x<nColumns && y<nLines)
						{
							bFlag=true;
							if (xCursor!=x || yCursor!=y)
							{
								xCursor=x;
								yCursor=y;
								ret=REFLAG_DISPLAY;
							}
							int o=y*nColumns+x;
							fix=pGrid[o];
							if (fix!=0) 
							{
								int n;
								for (n=0; n<objectList.size(); n++)
									if (fix==(int)objectList.get(n))
										break;
								if (n<objectList.size())
								{
									CInventoryItem pItem=(CInventoryItem)displayList.get(n);
									pNameHilighted=pItem.GetName();
									numHilighted=o;
								}
							}
						}
					}
				}
				bool bMouse=rh.mouseKey==0;
				if (bMouse!=oldBMouse)
				{
					oldBMouse=bMouse;
					if (bMouse && (flags&IFLAG_MOUSE)!=0)
					{
						fix=pGrid[yCursor*nColumns+xCursor];
						if (fix!=0)
						{
							pNameSelected=pNameHilighted;
							numSelected=yCursor*nColumns+xCursor;
							selectedCount=rh.rh4EventCount;
							CObject hoPtr=GetHO(fix);
                            conditionString=hoPtr.hoOiList.oilName;
							ho.generateEvent(CND_NAMEDITEMSELECTED, 0);
							ho.generateEvent(CND_ITEMSELECTED, hoPtr.hoOi);
						}
					}
					if ((flags&IFLAG_CURSOR)!=0 && x>=0 && y>=0 && x<ho.hoImgWidth && y<ho.hoImgHeight)
					{
						bActivated=true;
						xCursor=x/itemSx;
						yCursor=y/itemSy;
						ret=REFLAG_DISPLAY;
					}
					else
					{
						bActivated=false;
						ret=REFLAG_DISPLAY;
					}
				}
				if (bActivated)
				{
					bFlag=true;
				}
				int key=getKeys();
				if (bActivated && (flags&IFLAG_CURSOR)!=0)
				{
					if (key!=oldKey)
					{
						oldKey=key;
						switch(key)
						{
						case VK_UP:
							if (yCursor>0)
							{
								y=yCursor-1;
								fix=pGrid[y*nColumns+xCursor];
								if (fix!=0)
								{
									while (y>0)
									{
										if (pGrid[(y-1)*nColumns+xCursor]!=fix)
										{
											break;
										}
										y--;
									}
								}
								yCursor=y;
							}
							break;
						case VK_DOWN:
							if (yCursor<nLines-1)
							{
								fix=pGrid[yCursor*nColumns+xCursor];
								y=yCursor+1;
								if (fix!=0)
								{
									while (pGrid[y*nColumns+xCursor]==fix && y<nLines-1)
										y++;
								}
								yCursor=y;
							}
							break;
						case VK_RIGHT:
							if (xCursor<nColumns-1)
							{
								fix=pGrid[yCursor*nColumns+xCursor];
								x=xCursor+1;
								if (fix!=0)
								{
									while (pGrid[yCursor*nColumns+x]==fix && x>0)
										x++;
								}
								xCursor=x;
							}
							break;
						case VK_LEFT:
							if (xCursor>0)
							{
								x=xCursor-1;
								fix=pGrid[yCursor*nColumns+x];
								if (fix!=0)
								{
									while (x>0)
									{
										if (pGrid[yCursor*nColumns+x-1]!=fix)
										{
											break;
										}
										x--;
									}
								}
								xCursor=x;
							}
							break;
						case VK_RETURN:
							{
								pNameSelected=pNameHilighted;
								selectedCount=rh.rh4EventCount;
								numSelected=position+yCursor*nColumns+xCursor;
								CInventoryItem pItem=(CInventoryItem)displayList.get(position+yCursor*nColumns+xCursor);
                                if (pItem!=null)
                                {
								    CObject hoPtr=GetHO((int)objectList.get(position + yCursor * nColumns + xCursor));
                                    conditionString=pItem.GetName();
								    ho.generateEvent(CND_NAMEDITEMSELECTED, 0);
								    ho.generateEvent(CND_ITEMSELECTED, hoPtr.hoOi);
                                }
							}
							break;
						}
						ret=REFLAG_DISPLAY;
					}
				}
				if ((flags&IFLAG_CURSORBYACTION)==0)
				{
					if (bFlag)
					{
						if ((flags&IFLAG_FORCECURSOR)==0)
						{
							flags|=IFLAG_FORCECURSOR;
							ret=REFLAG_DISPLAY;
						}
					}
					else
					{
						if ((flags&IFLAG_FORCECURSOR)!=0)
						{
							flags&=~IFLAG_FORCECURSOR;
							ret=REFLAG_DISPLAY;
						}
					}
				}
			}
			if (bUpdate)
			{
				bUpdateList=true;
				ret=REFLAG_DISPLAY;
			}
			return ret;
        }


		const int SX_SEPARATION=8;
		const int SY_SEPARATION=8;

        public override void displayRunObject(SpriteBatchEffect batch)
        {
			if (type==INVTYPE_LIST)
			{
				if (displayList.size()==0)
				{
					return;
				}

				int o;
				for (o=0; o<displayList.size(); o++)
				{
					CObject hoPtr=GetHO((int)objectList.get(o));
					if (hoPtr!=null && o>=position && o<position+nLines*nColumns)
					{
						CInventoryItem pItem=(CInventoryItem)displayList.get(o);
						obShow(hoPtr);

						int line=(o-position)/nColumns;
						int column=(o-position)-line*nColumns;		
						int xObject=column*itemSx+itemSx/2-hoPtr.hoImgWidth/2;
						int yObject=line*itemSy+itemSy/2-hoPtr.hoImgHeight/2;
						int sy;

                        if (o == position + xCursor + yCursor * nColumns)
                        {
                            CRect rc = new CRect();
                            rc.left = ho.hoX - rh.rhWindowX + column * itemSx;
                            rc.top = ho.hoY - rh.rhWindowY + line * itemSy;
                            rc.right = rc.left + itemSx - 1;
                            rc.bottom = rc.top + itemSy - 1;
                            if ((flags & IFLAG_FORCECURSOR) != 0 && cursorType > 0) 
						    {
								if (cursorType==1)
									rh.rhApp.services.drawRect(batch, rc, cursorColor, 0, 0);
								else
									rh.rhApp.services.fillRect(batch, rc, cursorColor, 0, 0);
							}
						}

						if (maximum>1)
						{
							CRect rcText;
							int dtFlags;
                            string text=pItem.GetDisplayString();
                            string temp=null;
                            int pos=text.IndexOf("%q");
                            if (pos>=0)
                            {
                                temp=text.Substring(0, pos);
                                temp+=pItem.GetQuantity().ToString();
                                temp+=text.Substring(pos+2);
                                text = temp;
                            }
                            pos=text.IndexOf("%m");
                            if (pos>=0)
                            {
                                temp=text.Substring(0, pos);
                                temp+=pItem.GetMaximum().ToString();
                                temp+=text.Substring(pos+2);
                            }
                            text=temp;
							rcText=new CRect();
							rcText.right=1000;
							rcText.bottom=1000;
                            CServices.drawText(batch, text, CServices.DT_LEFT | CServices.DT_TOP | CServices.DT_CALCRECT, rcText, 0, font, 0, 0);
							int sxText=rcText.right-rcText.left;
							int syText=rcText.bottom-rcText.top;

							if ((textAlignment&0x00000001)!=0)       // TEXT_ALIGN_LEFT)
							{
								rcText.left=column*itemSx;
								rcText.right=rcText.left+itemSx;
								dtFlags=CServices.DT_LEFT;
								xObject=(column+1)*itemSx-hoPtr.hoImgWidth;
							}
							else if ((textAlignment&0x00000002)!=0)  //TEXT_ALIGN_HCENTER)
							{
								rcText.left=column*itemSx;
								rcText.right=rcText.left+itemSx;
								dtFlags=CServices.DT_CENTER;
							}
							else											// (textAlignment&TEXT_ALIGN_RIGHT)
							{
								xObject=column*itemSx;
								rcText.left=xObject+hoPtr.hoImgWidth+SX_SEPARATION;
								rcText.right=xObject+itemSx;
								dtFlags=CServices.DT_LEFT;
							}
							if ((textAlignment&0x00000008)!=0)       //TEXT_ALIGN_TOP)
							{
								sy=hoPtr.hoImgHeight+SY_SEPARATION+syText;
								rcText.top=line*itemSy+itemSy/2-sy/2;
								rcText.bottom=rcText.top+syText;
								yObject=rcText.top+syText+SY_SEPARATION;
								dtFlags|=CServices.DT_TOP;
							}
							else if ((textAlignment&0x00000010)!=0)  //TEXT_ALIGN_VCENTER)
							{
								rcText.top=line*itemSy+itemSy/2-syText/2;
								rcText.bottom=rcText.top+syText;
								yObject=line*itemSy+itemSy/2-hoPtr.hoImgHeight/2;
								dtFlags|=CServices.DT_VCENTER;
							}
							else											// (textAlignment&TEXT_ALIGN_BOTTOM)
							{
								sy=hoPtr.hoImgHeight+SY_SEPARATION+syText;
								yObject=line*itemSy+itemSy/2-sy/2;
								rcText.top=yObject+hoPtr.hoImgHeight+SY_SEPARATION;
								rcText.bottom=rcText.top+syText;
								dtFlags|=CServices.DT_TOP;
							}
							if (pItem.GetQuantity()>=displayQuantity)
							{
								rcText.left+=ho.hoX-rh.rhWindowX;
								rcText.right+=ho.hoX-rh.rhWindowX;
								rcText.top+=ho.hoY-rh.rhWindowY;
								rcText.bottom+=ho.hoY-rh.rhWindowY;
                                CServices.drawText(batch, text, (short)dtFlags, rcText, fontColor, font, 0, 0);
							}
						}
						if (bUpdateList)
						{
							SetPosition(hoPtr, ho.hoX+xObject, ho.hoY+yObject);
						}
					}
					else
					{
						obHide(hoPtr);
					}
				}
				SetSlider();
				slider.DrawBar(batch);
			}
			else
			{
				if ((flags&IFLAG_DISPLAYGRID)!=0)
				{
					CRect rc=new CRect();
					int x, y;
					for (y=0; y<nLines; y++)
					{
						for (x=0; x<nColumns; x++)
						{
							GetGridRect(x, y, rc);
                            rh.rhApp.services.drawRect(batch, rc, gridColor, 0, 0);
						}
					}		

					if (bDropItem==false)
					{
						GetGridRect(xCursor, yCursor, rc);
					}
					else
					{
						rc.copyRect(rcDrop);
					}
					if (bDropItem || ((flags&IFLAG_FORCECURSOR)!=0 && cursorType>0)) 
					{
						rh.rhApp.services.fillRect(batch, rc, cursorColor, 0, 0);
					}
				}
				if (bUpdateList)
				{
					int o;
					for (o=0; o<displayList.size(); o++)
					{
						CObject hoPtr=GetHO((int)objectList.get(o));
						if (hoPtr!=null)
						{
							CInventoryItem pItem=(CInventoryItem)displayList.get(o);
							obShow(hoPtr);

							int sx=(hoPtr.hoImgWidth+itemSx-1)/itemSx;
							int sy=(hoPtr.hoImgHeight+itemSy-1)/itemSy;
							CRect rc=new CRect();
							GetGridRect(pItem.x, pItem.y, rc);
							int xObject=(rc.left+rc.right)/2-sx+rh.rhWindowX-hoPtr.hoImgWidth/2;
							int yObject=(rc.top+rc.bottom)/2-sy+rh.rhWindowY-hoPtr.hoImgHeight/2;
							SetPosition(hoPtr, xObject, yObject);
						}
					}
				}
			}
			bUpdateList=false;
			bDropItem=false;
        }

	    public override CFontInfo getRunObjectFont()
	    {
	        return logFont;
	    }
	
	    public override void setRunObjectFont(CFontInfo fi, CRect rc)
	    {
	        logFont = fi;
            font = CFont.createFromFontInfo(fi, ho.hoAdRunHeader.rhApp);
	        if (rc!=null)
	        {
	        	ho.hoImgWidth=rc.right-rc.left;
	        	ho.hoImgHeight=rc.bottom-rc.top;
	        }
			ho.redraw();
	    }
	
	    public override int getRunObjectTextColor()
	    {
	        return fontColor;
	    }
	
	    public override void setRunObjectTextColor(int rgb)
	    {
	        fontColor = rgb;
			ho.redraw();
	    }



		public override bool condition(int num, CCndExtension cnd)
		{
			switch(num)
			{
				case CND_NAMEDITEMSELECTED:
					return RCND_NAMEDITEMSELECTED(cnd);
				case CND_NAMEDCOMPARENITEMS:
					return RCND_NAMEDCOMPARENITEMS(cnd);
				case CND_ITEMSELECTED:
					return RCND_ITEMSELECTED(cnd);
				case CND_COMPARENITEMS:
					return RCND_COMPARENITEMS(cnd);
				case CND_NAMEDITEMPRESENT:
					return RCND_NAMEDITEMPRESENT(cnd);
				case CND_ITEMPRESENT:
					return RCND_ITEMPRESENT(cnd);
				case CND_NAMEDHILIGHTED:
					return RCND_NAMEDHILIGHTED(cnd);
				case CND_HILIGHTED:
					return RCND_HILIGHTED(cnd);
				case CND_CANADD:
					return RCND_CANADD(cnd);
				case CND_NAMEDCANADD:
					return RCND_NAMEDCANADD(cnd);												
			}
			return false;
		}

		bool RCND_NAMEDITEMSELECTED(CCndExtension cnd)
		{
			string pName=cnd.getParamExpString(rh, 0);
            if (pName == conditionString)
			{
				if ((ho.hoFlags & CObject.HOF_TRUEEVENT)!=0)
				{
					return true;
				}

				if (rh.rh4EventCount == selectedCount)
				{
					return true;
				}
			}
			return false;
		}
		bool RCND_NAMEDCOMPARENITEMS(CCndExtension cnd)
		{
			CInventoryItem pItem=inventory.GetItem(number, cnd.getParamExpString(rh, 0));
			if (pItem!=null)
			{
                CValue value=new CValue(pItem.GetQuantity());
                return cnd.compareValues(rh, 0, value);
			}
			return false;
		}
		bool RCND_ITEMSELECTED(CCndExtension cnd)
		{
			short oi=cnd.getParamObject(rh, 0).oi;

			if (oi==rh.rhEvtProg.rhCurParam0)
			{
				if ((ho.hoFlags & CObject.HOF_TRUEEVENT)!=0)
				{
					return true;
				}

				if (rh.rh4EventCount == selectedCount)
				{
					return true;
				}
			}
			return false;
		}
		bool RCND_COMPARENITEMS(CCndExtension cnd)
		{
			short oi=cnd.getParamObject(rh, 0).oi;

			int n;
			for (n=0; n<objectList.size(); n++)
			{
				CObject hoPtr=GetHO((int)objectList.get(n));
				if (hoPtr.hoOi==oi)
				{
					CInventoryItem pItem=(CInventoryItem)displayList.get(n);
					CValue value=new CValue(pItem.GetQuantity());
					return cnd.compareValues(rh, 1, value);
				}
			}
			return false;
		}
		bool RCND_NAMEDITEMPRESENT(CCndExtension cnd)
		{
			CInventoryItem pItem=inventory.GetItem(number, cnd.getParamExpString(rh, 0));
			if (pItem!=null)
			{
				if (pItem.GetQuantity()>0)
				{
					return true;
				}
			}
			return false;
		}
		bool RCND_ITEMPRESENT(CCndExtension cnd)
		{
			short oi=cnd.getParamObject(rh, 0).oi;

			int n;
			for (n=0; n<objectList.size(); n++)
			{
				CObject hoPtr=GetHO((int)objectList.get(n));
				if (hoPtr.hoOi==oi)
				{
					CInventoryItem pItem=(CInventoryItem)displayList.get(n);
					if (pItem.GetQuantity()>0)
					{
						return true;
					}
				}
			}
			return false;
		}
		bool RCND_NAMEDHILIGHTED(CCndExtension cnd)
		{
			string pName=cnd.getParamExpString(rh, 0);
			if (pNameHilighted!=null)
			{
				if (pName==pNameHilighted)
				{
					return true;
				}
			}
			return false;
		}
		bool RCND_HILIGHTED(CCndExtension cnd)
		{
			short oiList=cnd.getParamObject(rh, 0).oiList;
			CObjInfo pOiList=rh.rhOiList[oiList];
			if (pNameHilighted!=null)
			{
				if (pOiList.oilName==pNameHilighted)
				{
					return true;
				}
			}
			return false;
		}

		bool RCND_CANADD(CCndExtension cnd)
		{
			if (type!=INVTYPE_GRID)
			{
				return false;
			}

			int xx=cnd.getParamExpression(rh, 1);
			int yy=cnd.getParamExpression(rh, 2);

			if (xx<0 || xx>=nColumns || yy<0 || yy>=nLines)
			{
				return false;
			}

			CObject hoPtr;
			CObjInfo pOiList=rh.rhOiList[cnd.getParamObject(rh, 0).oiList];
			short number=pOiList.oilObject;
			if (number>=0)
			{
				hoPtr=rh.rhObjectList[number];
				int sx=(hoPtr.hoImgWidth+itemSx-1)/itemSx;
				int sy=(hoPtr.hoImgHeight+itemSy-1)/itemSy;
				if (xx+sx>nColumns || yy+sy>nLines)
				{
					return false;
				}
				int x, y;
				for (y=0; y<sy; y++)
				{
					for (x=0; x<sx; x++)
					{
						if (pGrid[(yy+y)*nColumns+xx+x]!=0)
						{
							return false;
						}
					}
				}
				rcDrop.left=ho.hoX-rh.rhWindowX+xx*itemSx;
				rcDrop.right=rcDrop.left+itemSx;
				rcDrop.top=ho.hoY-rh.rhWindowY+yy*itemSy;
				rcDrop.bottom=rcDrop.top+itemSy;
				bDropItem=true;
				return true;
			}
			return false;
		}
		bool GridCanAdd(string pName, int xx, int yy, bool bDrop)
		{
			if (type!=INVTYPE_GRID)
			{
				return false;
			}
			if (xx<0 || xx>=nColumns || yy<0 || yy>=nLines)
			{
				return false;
			}

			CObject hoPtr;
			int n;
			for (n=0; n<rh.rhOiList.Length; n++)
			{
				if (rh.rhOiList[n].oilName==pName)
				{
                    short number = rh.rhOiList[n].oilObject;
					if (number>=0)
					{
						hoPtr=rh.rhObjectList[number];
						int sx=(hoPtr.hoImgWidth+itemSx-1)/itemSx;
						int sy=(hoPtr.hoImgHeight+itemSy-1)/itemSy;
						if (xx+sx>nColumns || yy+sy>nLines)
						{
							return false;
						}
						int x, y;
						for (y=0; y<sy; y++)
						{
							for (x=0; x<sx; x++)
							{
								if (pGrid[(yy+y)*nColumns+xx+x]!=0)
								{
									return false;
								}
							}
						}
						if (bDrop)
						{
							rcDrop.left=ho.hoX-rh.rhWindowX+xx*itemSx;
							rcDrop.right=rcDrop.left+itemSx;
							rcDrop.top=ho.hoY-rh.rhWindowY+yy*itemSy;
							rcDrop.bottom=rcDrop.top+itemSy;
							bDropItem=true;
						}
						return true;
					}
				}
			}
			return false;
		}
		bool RCND_NAMEDCANADD(CCndExtension cnd)
		{
			if (type==INVTYPE_GRID)
			{
				string name=cnd.getParamExpString(rh, 0);
				int xx=cnd.getParamExpression(rh, 1);
				int yy=cnd.getParamExpression(rh, 2);
				return GridCanAdd(name, xx, yy, true);
			}
			return false;
		}





        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_NAMEDADDITEM:
                    RACT_NAMEDADDITEM(act);
                    break;
                case ACT_NAMEDADDNITEMS:
                    RACT_NAMEDADDNITEMS(act);
                    break;
                case ACT_NAMEDDELITEM:
                    RACT_NAMEDDELITEM(act);
                    break;
                case ACT_NAMEDDELNITEMS:
                    RACT_NAMEDDELNITEMS(act);
                    break;
                case ACT_NAMEDHIDEITEM:
                    RACT_NAMEDHIDEITEM(act);
                    break;
                case ACT_NAMEDSHOWITEM:
                    RACT_NAMEDSHOWITEM(act);
                    break;
                case ACT_ADDITEM:
                    RACT_ADDITEM(act);
                    break;
                case ACT_ADDNITEMS:
                    RACT_ADDNITEMS(act);
                    break;
                case ACT_DELITEM:
                    RACT_DELITEM(act);
                    break;
                case ACT_DELNITEMS:
                    RACT_DELNITEMS(act);
                    break;
                case ACT_HIDEITEM:
                    RACT_HIDEITEM(act);
                    break;
                case ACT_SHOWITEM:
                    RACT_SHOWITEM(act);
                    break;
                case ACT_LEFT:
                    RACT_LEFT(act);
                    break;
                case ACT_RIGHT:
                    RACT_RIGHT(act);
                    break;
                case ACT_UP:
                    RACT_UP(act);
                    break;
                case ACT_DOWN:
                    RACT_DOWN(act);
                    break;
                case ACT_SELECT:
                    RACT_SELECT(act);
                    break;
                case ACT_CURSOR:
                    RACT_CURSOR(act);
                    break;
                case ACT_NAMEDSETSTRING:
                    RACT_NAMEDSETSTRING(act);
                    break;
                case ACT_SETSTRING:
                    RACT_SETSTRING(act);
                    break;
                case ACT_ACTIVATE:
                    RACT_ACTIVATE(act);
                    break;
                case ACT_NAMEDSETMAXIMUM:
                    RACT_NAMEDSETMAXIMUM(act);
                    break;
                case ACT_SETMAXIMUM:
                    RACT_SETMAXIMUM(act);
                    break;
                case ACT_SETPOSITION:
                    RACT_SETPOSITION(act);
                    break;
                case ACT_SETPAGE:
                    RACT_SETPAGE(act);
                    break;
                case ACT_ADDPROPERTY:
                    RACT_ADDPROPERTY(act);
                    break;
                case ACT_NAMEDSETPROPMINMAX:
                    RACT_NAMEDSETPROPMINMAX(act);
                    break;
                case ACT_SETPROPMINMAX:
                    RACT_SETPROPMINMAX(act);
                    break;
                case ACT_NAMEDADDPROPERTY:
                    RACT_NAMEDADDPROPERTY(act);
                    break;
                case ACT_ADDGRIDITEM:
                    RACT_ADDGRIDITEM(act);
                    break;
                case ACT_ADDGRIDNITEMS:
                    RACT_ADDGRIDNITEMS(act);
                    break;
                case ACT_NAMEDADDGRIDITEM:
                    RACT_NAMEDADDGRIDITEM(act);
                    break;
                case ACT_NAMEDADDGRIDNITEMS:
                    RACT_NAMEDADDGRIDNITEMS(act);
                    break;
                case ACT_HILIGHTDROP:
                    RACT_HILIGHTDROP(act);
                    break;
                case ACT_NAMEDHILIGHTDROP:
                    RACT_NAMEDHILIGHTDROP(act);
                    break;
                case ACT_SAVE:
                    RACT_SAVE(act);
                    break;
                case ACT_LOAD:
                    RACT_LOAD(act);
                    break;
                case ACT_ADDLISTITEM:
                    RACT_ADDLISTITEM(act);
                    break;
                case ACT_ADDLISTNITEMS:
                    RACT_ADDLISTNITEMS(act);
                    break;
                case ACT_NAMEDADDLISTITEM:
                    RACT_NAMEDADDLISTITEM(act);
                    break;
                case ACT_NAMEDADDLISTNITEMS:
                    RACT_NAMEDADDLISTNITEMS(act);
                    break;
            }
        }

		CInventoryItem FindItem(string pName)
		{
			int n;
			CObject hoPtr;
			for (n=0; n<objectList.size(); n++)
			{
				hoPtr=GetHO((int)objectList.get(n));
				if (pName==hoPtr.hoOiList.oilName)
				{
					return (CInventoryItem)displayList.get(n);
				}
			}
			return null;
		}
		CObject FindHO(string pName)
		{
			int n;
			CObject hoPtr;
			for (n=0; n<objectList.size(); n++)
			{
				hoPtr=GetHO((int)objectList.get(n));
				if (pName==hoPtr.hoOiList.oilName)
				{
					return hoPtr;
				}
			}
			return null;
		}

		void RACT_NAMEDADDPROPERTY(CActExtension act)		
		{
			string pItem=act.getParamExpString(rh, 0);
			string pProperty=act.getParamExpString(rh, 1);
			int value=act.getParamExpression(rh, 2);
			inventory.AddProperty(number, pItem, pProperty, value);
			return;
		}
		void RACT_NAMEDSETPROPMINMAX(CActExtension act)		
		{
			string pItem=act.getParamExpString(rh, 0);
			string pProperty=act.getParamExpString(rh, 1);
			int min=act.getParamExpression(rh, 2);
			int max=act.getParamExpression(rh, 3);
			inventory.SetPropertyMinimum(number, pItem, pProperty, min);
			inventory.SetPropertyMaximum(number, pItem, pProperty, max);
			return;
		}

		void RACT_NAMEDADDLISTITEM(CActExtension act)		
		{
			if (type==INVTYPE_LIST)
			{
				string pName=act.getParamExpString(rh, 0);
				int pos=act.getParamExpression(rh, 1);
				string namePos="";
                CInventoryItem pItem;
				if (pos>=0 && pos<displayList.size())
				{
					pItem=(CInventoryItem)displayList.get(pos);
					namePos=pItem.pName;
				}
				pItem=inventory.AddItemToPosition(number, namePos, (string)pName, 1, maximum, pDisplayString);
				bool bAbsent=true;
				int n;
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==(CInventoryItem)displayList.get(n))
					{
						bAbsent=false;
						break;
					}
				}
				UpdateDisplayList();
				if (bAbsent)
				{
					for (n=0; n<displayList.size(); n++)
					{
						if (pItem==(CInventoryItem)displayList.get(n))
						{
							CenterDisplay(n);
							break;
						}
					}
				}
			}
			return;
		}
		void RACT_NAMEDADDLISTNITEMS(CActExtension act)		
		{
			if (type==INVTYPE_LIST)
			{
				string pName=act.getParamExpString(rh, 0);
				int pos=act.getParamExpression(rh, 1);
				int number=act.getParamExpression(rh, 2);
				string namePos="";
                CInventoryItem pItem;
				if (pos>=0 && pos<displayList.size())
				{
					pItem=(CInventoryItem)displayList.get(pos);
					namePos=pItem.pName;
				}
				pItem=inventory.AddItemToPosition(number, namePos, pName, number, maximum, pDisplayString);
				bool bAbsent=true;
				int n;
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==(CInventoryItem)displayList.get(n))
					{
						bAbsent=false;
						break;
					}
				}
				UpdateDisplayList();
				if (bAbsent)
				{
					for (n=0; n<displayList.size(); n++)
					{
						if (pItem==(CInventoryItem)displayList.get(n))
						{
							CenterDisplay(n);
							break;
						}
					}
				}
			}
			return;
		}
		void RACT_NAMEDADDITEM(CActExtension act)		
		{
			CInventoryItem pItem;
			string param1=act.getParamExpString(rh, 0);
			if (type==INVTYPE_LIST)
			{
				pItem=inventory.AddItem(number, param1, 1, maximum, pDisplayString);
				bool bAbsent=true;
				int n;
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==(CInventoryItem)displayList.get(n))
					{
						bAbsent=false;
						break;
					}
				}
				UpdateDisplayList();
				if (bAbsent)
				{
					for (n=0; n<displayList.size(); n++)
					{
						if (pItem==(CInventoryItem)displayList.get(n))
						{
							CenterDisplay(n);
							break;
						}
					}
				}
			}
			else
			{
				int x, y;
				for (y=0; y<nLines; y++)
				{
					for (x=0; x<nColumns; x++)
					{
						if (GridCanAdd(param1, x, y, false))
						{
							pItem=inventory.AddItem(number, param1, 1, maximum, pDisplayString);
							pItem.x=x;
							pItem.y=y;
							UpdateDisplayList();
							return;
						}
					}
				}
			}
			return;
		}
				
		void RACT_NAMEDADDNITEMS(CActExtension act)		
		{
			string param1=act.getParamExpString(rh, 0);
			int param2=act.getParamExpression(rh, 1);
			if (param2>=0)
			{
				CInventoryItem pItem;
				if (type==INVTYPE_LIST)
				{
					pItem=inventory.AddItem(number, param1, param2, maximum, pDisplayString);
					bool bAbsent=true;
					int n;
					for (n=0; n<displayList.size(); n++)
					{
						if (pItem==(CInventoryItem)displayList.get(n))
						{
							bAbsent=false;
							break;
						}
					}
					UpdateDisplayList();
					if (bAbsent)
					{
						for (n=0; n<displayList.size(); n++)
						{
							if (pItem==(CInventoryItem)displayList.get(n))
							{
								CenterDisplay(n);
								break;
							}
						}
					}
				}
				else
				{
					int x, y;
					for (y=0; y<nLines; y++)
					{
						for (x=0; x<nColumns; x++)
						{
							if (GridCanAdd(param1, x, y, false))
							{
								pItem=inventory.AddItem(number, param1, param2, maximum, pDisplayString);
								pItem.x=x;
								pItem.y=y;
								UpdateDisplayList();
								return;
							}
						}
					}
				}
			}
			return;
		}
				
		void RACT_NAMEDSETMAXIMUM(CActExtension act)		
		{
			string param1=act.getParamExpString(rh, 0);
			int param2=act.getParamExpression(rh, 1);
			if (param2>=0)
			{
				inventory.SetMaximum(number, param1, param2);
				UpdateDisplayList();
			}
			return;
		}
				
		void RACT_NAMEDDELITEM(CActExtension act)		
		{
			string param1=act.getParamExpString(rh, 0);
			CObject hoPtr=FindHO((string)param1);
			if (inventory.SubQuantity(number, param1, 1))
			{
				if (hoPtr!=null)
				{
					obHide(hoPtr);
				}
			}
			UpdateDisplayList();
            return;
		}
				
		void RACT_NAMEDDELNITEMS(CActExtension act)		
		{
			string param1=act.getParamExpString(rh, 0);
			int param2=act.getParamExpression(rh, 1);
			if (param2>=0)
			{
				CObject hoPtr=FindHO(param1);
				if (inventory.SubQuantity(number, param1, param2))
				{
					if (hoPtr!=null)
					{
						obHide(hoPtr);
					}
				}
				UpdateDisplayList();
			}
			return;
		}
		void RACT_NAMEDHIDEITEM(CActExtension act)		
		{
			string param1=act.getParamExpString(rh, 0);
			inventory.SetFlags(number, param1, ~CInventoryItem.FLAG_VISIBLE, 0);
			UpdateDisplayList();
			return;
		}
		void RACT_NAMEDSHOWITEM(CActExtension act)		
		{
			string param1=act.getParamExpString(rh, 0);
			inventory.SetFlags(number, param1, -1, CInventoryItem.FLAG_VISIBLE);
			UpdateDisplayList();
			return;
		}
		void RACT_ADDLISTITEM(CActExtension act)		
		{
			if (type==INVTYPE_LIST)
			{
				CObject hoPtr=act.getParamObject(rh, 0);;
				string pName=hoPtr.hoOiList.oilName;

				int pos=act.getParamExpression(rh, 1);
				string namePos="";
                CInventoryItem pItem;
				if (pos>=0 && pos<displayList.size())
				{
					pItem=(CInventoryItem)displayList.get(pos);
					namePos=pItem.pName;
				}
				pItem=inventory.AddItemToPosition(number, namePos, pName, 1, maximum, pDisplayString);
				bool bAbsent=true;
				int n;
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==(CInventoryItem)displayList.get(n))
					{
						bAbsent=false;
						break;
					}
				}
				UpdateDisplayList();
				if (bAbsent)
				{
					for (n=0; n<displayList.size(); n++)
					{
						if (pItem==(CInventoryItem)displayList.get(n))
						{
							CenterDisplay(n);
							break;
						}
					}
				}
			}
			return;
		}
		void RACT_ADDLISTNITEMS(CActExtension act)		
		{
			if (type==INVTYPE_LIST)
			{
				CObject hoPtr=act.getParamObject(rh, 0);
				string pName=hoPtr.hoOiList.oilName;
				int pos=act.getParamExpression(rh, 1);
				int number=act.getParamExpression(rh, 2);
				string namePos="";
                CInventoryItem pItem;
				if (pos>=0 && pos<displayList.size())
				{
					pItem=(CInventoryItem)displayList.get(pos);
					namePos=pItem.pName;
				}
				pItem=inventory.AddItemToPosition(number, namePos, pName, number, maximum, pDisplayString);
				bool bAbsent=true;
				int n;
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==(CInventoryItem)displayList.get(n))
					{
						bAbsent=false;
						break;
					}
				}
				UpdateDisplayList();
				if (bAbsent)
				{
					for (n=0; n<displayList.size(); n++)
					{
						if (pItem==(CInventoryItem)displayList.get(n))
						{
							CenterDisplay(n);
							break;
						}
					}
				}
			}
			return;
		}
		void RACT_ADDITEM(CActExtension act)		
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			CObjInfo pOiList=hoPtr.hoOiList;
			CInventoryItem pItem;
			if (type==INVTYPE_LIST)
			{
				pItem=inventory.AddItem(number, pOiList.oilName, 1, maximum, pDisplayString);
				bool bAbsent=true;
				int n;
				for (n=0; n<displayList.size(); n++)
				{
					if (pItem==(CInventoryItem)displayList.get(n))
					{
						bAbsent=false;
						break;
					}
				}
				UpdateDisplayList();
				if (bAbsent)
				{
					for (n=0; n<displayList.size(); n++)
					{
						if (pItem==(CInventoryItem)displayList.get(n))
						{
							CenterDisplay(n);
							break;
						}
					}
				}
			}
			else
			{
				int x, y;
				for (y=0; y<nLines; y++)
				{
					for (x=0; x<nColumns; x++)
					{
						if (GridCanAdd(pOiList.oilName, x, y, false))
						{
							pItem=inventory.AddItem(number, pOiList.oilName, 1, maximum, pDisplayString);
							pItem.x=x;
							pItem.y=y;
							UpdateDisplayList();
							return;
						}
					}
				}
			}
			return;
		}
		void RACT_ADDPROPERTY(CActExtension act)		
		{
			CObject hoPtr=(CObject)act.getParamObject(rh, 0);
			string pProperty=act.getParamExpString(rh, 1);
			int value=act.getParamExpression(rh, 2);

			CObjInfo pOiList=hoPtr.hoOiList;
			inventory.AddProperty(number, pOiList.oilName, pProperty, value);
			return;
		}
		void RACT_SETPROPMINMAX(CActExtension act)		
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			string pProperty=act.getParamExpString(rh, 1);
			int min=act.getParamExpression(rh, 2);
			int max=act.getParamExpression(rh, 3);

			CObjInfo pOiList=hoPtr.hoOiList;
			inventory.SetPropertyMinimum(number, pOiList.oilName, pProperty, min);
			inventory.SetPropertyMaximum(number, pOiList.oilName, pProperty, max);
			return;
		}
		void RACT_ADDNITEMS(CActExtension act)		
		{
            int param2 = act.getParamExpression(rh, 1);
            if (param2 >= 0)
			{
				CObject hoPtr=act.getParamObject(rh, 0);
				CObjInfo pOiList=hoPtr.hoOiList;
				CInventoryItem pItem;
				if (type==INVTYPE_LIST)
				{
					pItem=inventory.AddItem(number, pOiList.oilName, param2, maximum, pDisplayString);
					bool bAbsent=true;
					int n;
					for (n=0; n<displayList.size(); n++)
					{
						if (pItem==(CInventoryItem)displayList.get(n))
						{
							bAbsent=false;
							break;
						}
					}
					UpdateDisplayList();
					if (bAbsent)
					{
						for (n=0; n<displayList.size(); n++)
						{
							if (pItem==(CInventoryItem)displayList.get(n))
							{
								CenterDisplay(n);
								break;
							}
						}
					}
				}
				else
				{
					int x, y;
					for (y=0; y<nLines; y++)
					{
						for (x=0; x<nColumns; x++)
						{
							if (GridCanAdd(pOiList.oilName, x, y, false))
							{
								pItem=inventory.AddItem(number, pOiList.oilName, param2, maximum, pDisplayString);
								pItem.x=x;
								pItem.y=y;
								UpdateDisplayList();
								return;
							}
						}
					}
				}
			}
			return;
		}
		void RACT_SETMAXIMUM(CActExtension act)		
		{
            int param2 = act.getParamExpression(rh, 1);
			if (param2>=0)
			{
				CObject hoPtr=act.getParamObject(rh, 0);
				CObjInfo pOiList=hoPtr.hoOiList;
				inventory.SetMaximum(number, pOiList.oilName, param2);
				UpdateDisplayList();
			}
			return;
		}
		void RACT_DELITEM(CActExtension act)		
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			CObjInfo pOiList=hoPtr.hoOiList;
			hoPtr=FindHO(pOiList.oilName);
			if (inventory.SubQuantity(number, pOiList.oilName, 1))
			{
				if (hoPtr!=null)
				{
					obHide(hoPtr);
				}
			}
			UpdateDisplayList();
			return;
		}
		void RACT_DELNITEMS(CActExtension act)		
		{
			int param2=act.getParamExpression(rh, 1);
			if (param2>=0)
			{
				CObject hoPtr=act.getParamObject(rh, 0);
				CObjInfo pOiList=hoPtr.hoOiList;
				hoPtr=FindHO(pOiList.oilName);
				if (inventory.SubQuantity(number, pOiList.oilName, param2))
				{
					if (hoPtr!=null)
					{
						obHide(hoPtr);
					}
				}
				UpdateDisplayList();
			}
			return;
		}
		void RACT_HIDEITEM(CActExtension act)		
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			CObjInfo pOiList=hoPtr.hoOiList;
			inventory.SetFlags(number, pOiList.oilName, ~CInventoryItem.FLAG_VISIBLE, 0);
			UpdateDisplayList();
			return;
		}
		void RACT_SHOWITEM(CActExtension act)		
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			CObjInfo pOiList=hoPtr.hoOiList;
			inventory.SetFlags(number, pOiList.oilName, -1, CInventoryItem.FLAG_VISIBLE);
			UpdateDisplayList();
			return;
		}

		void RACT_LEFT(CActExtension act)		
		{
			if (displayList.size()>0)
			{
				xCursor--;
				if (xCursor<0)
				{
					xCursor++;
					position=Math.Max(position-1, 0);
				}
				bRedraw=true;
			}
			return;
		}
		void RACT_RIGHT(CActExtension act)		
		{
			if (displayList.size()>0)
			{
				xCursor++;
				if (xCursor>=nColumns)
				{
					xCursor--;
					position=Math.Min(position+1, displayList.size()-nColumns*nLines);
				}
				bRedraw=true;
			}
			return;
		}
		void RACT_UP(CActExtension act)		
		{
			if (displayList.size()>0)
			{
				yCursor--;
				if (yCursor<0)
				{
					yCursor++;
					position=Math.Max(position-nColumns, 0);
				}
				bRedraw=true;
			}
			return;
		}
		void RACT_DOWN(CActExtension act)		
		{
			if (displayList.size()>0)
			{
				yCursor++;
				if (yCursor>=nLines)
				{
					yCursor--;
					position=Math.Min(position+nColumns, displayList.size()-nColumns*nLines);
				}
				bRedraw=true;
			}
			return;
		}
		void RACT_SELECT(CActExtension act)		
		{
			if (displayList.size()>0)
			{
				selectedCount=rh.rh4EventCount;
				CInventoryItem pItem=(CInventoryItem)displayList.get(position+yCursor*nColumns+xCursor);
				CObject hoPtr=GetHO((int)objectList.get(position+yCursor*nColumns+xCursor));
				conditionString=pItem.GetName();
				ho.generateEvent(CND_NAMEDITEMSELECTED, 0);
				ho.generateEvent(CND_ITEMSELECTED, hoPtr.hoOi);
				bRedraw=true;
			}
			return;
		}
		void RACT_CURSOR(CActExtension act)		
		{
            int param1 = act.getParamExpression(rh, 0);
			if (param1==0)
			{
				flags&=~(IFLAG_FORCECURSOR|IFLAG_CURSORBYACTION);
			}
			else
			{
				flags|=IFLAG_FORCECURSOR|IFLAG_CURSORBYACTION;
			}
			bRedraw=true;
			return;
		}
		void RACT_ACTIVATE(CActExtension act)		
		{
            int param1 = act.getParamExpression(rh, 0);
            if (param1 != 0)
			{
				bActivated=true;
				flags|=IFLAG_CURSOR|IFLAG_FORCECURSOR;
			}
			else
			{
				bActivated=false;
				flags&=~(IFLAG_CURSOR|IFLAG_FORCECURSOR);
			}
			bRedraw=true;
			return;
		}
		void RACT_NAMEDSETSTRING(CActExtension act)		
		{
			inventory.SetDisplayString(number, act.getParamExpString(rh, 0), act.getParamExpString(rh, 1));
			UpdateDisplayList();
			return;
		}
		void RACT_SETSTRING(CActExtension act)		
		{
			CObject hoPtr=act.getParamObject(rh, 0);
			CObjInfo pOiList=hoPtr.hoOiList;
			inventory.SetDisplayString(number, pOiList.oilName, act.getParamExpString(rh, 1));
			UpdateDisplayList();
			return;
		}
		void RACT_SETPOSITION(CActExtension act)		
		{
			int param1=act.getParamExpression(rh, 1);
			if (type==INVTYPE_LIST)
			{
				if (param1<0)
					param1=0;
				int last=Math.Max(displayList.size()-nLines*nColumns, 0);
				if (param1>last)
					param1=last;
				position=last;
				bRedraw=true;
			}
			return;
		}
		void RACT_SETPAGE(CActExtension act)		
		{
			int param1=act.getParamExpression(rh, 1);
			if (type==INVTYPE_LIST)
			{
				param1=nLines*nColumns;
				if (param1<0)
					param1=0;
				int last=Math.Max(displayList.size()-nLines*nColumns, 0);
				if (param1>last)
					param1=last;
				position=last;
				bRedraw=true;
			}
			return;
		}
		void RACT_ADDGRIDITEM(CActExtension act)		
		{
			if (type==INVTYPE_GRID)
			{
				CObject hoPtr=act.getParamObject(rh, 0);
				int x=act.getParamExpression(rh, 1);
				int y=act.getParamExpression(rh, 2);
				CObjInfo pOiList=hoPtr.hoOiList;
				if (GridCanAdd(pOiList.oilName, x, y, false))
				{
					CInventoryItem pItem=FindItem(pOiList.oilName);
					if (pItem==null)
					{
						pItem=inventory.AddItem(number, pOiList.oilName, 1, maximum, pDisplayString);
					}
					else if (pItem.x==x && pItem.y==y)
					{
						inventory.AddItem(number, pOiList.oilName, 1, maximum, pDisplayString);
					}
					pItem.x=x;
					pItem.y=y;
					UpdateDisplayList();
				}
			}
			return;
		}
		void RACT_ADDGRIDNITEMS(CActExtension act)		
		{
			if (type==INVTYPE_GRID)
			{
				CObject hoPtr=act.getParamObject(rh, 0);
				int number=act.getParamExpression(rh, 1);
				int x=act.getParamExpression(rh, 2);
				int y=act.getParamExpression(rh, 3);
				CObjInfo pOiList=hoPtr.hoOiList;
				if (GridCanAdd(pOiList.oilName, x, y, false))
				{
					CInventoryItem pItem=FindItem(pOiList.oilName);
					if (pItem==null)
					{
						pItem=inventory.AddItem(number, pOiList.oilName, number, maximum, pDisplayString);
					}
					else if (pItem.x==x && pItem.y==y)
					{
						inventory.AddItem(number, pOiList.oilName, number, maximum, pDisplayString);
					}
					pItem.x=x;
					pItem.y=y;
					UpdateDisplayList();
				}
			}
			return;
		}
		void RACT_NAMEDADDGRIDITEM(CActExtension act)		
		{
			if (type==INVTYPE_GRID)
			{
				string pName=act.getParamExpString(rh, 0);
				int x=act.getParamExpression(rh, 1);
				int y=act.getParamExpression(rh, 2);
				if (GridCanAdd(pName, x, y, false))
				{
					CInventoryItem pItem=FindItem(pName);
					if (pItem==null)
					{
						pItem=inventory.AddItem(number, pName, 1, maximum, pDisplayString);
					}
					else if (pItem.x==x && pItem.y==y)
					{
						inventory.AddItem(number, pName, 1, maximum, pDisplayString);
					}
					pItem.x=x;
					pItem.y=y;
					UpdateDisplayList();
				}
			}
			return;
		}
		void RACT_NAMEDADDGRIDNITEMS(CActExtension act)		
		{
			if (type==INVTYPE_GRID)
			{
				string pName=act.getParamExpString(rh, 0);
				int number=act.getParamExpression(rh, 1);
				int x=act.getParamExpression(rh, 2);
                int y = act.getParamExpression(rh, 3);
				if (GridCanAdd(pName, x, y, false))
				{
					CInventoryItem pItem=FindItem(pName);
					if (pItem==null)
					{
						pItem=inventory.AddItem(number, pName, number, maximum, pDisplayString);
					}
					else if (pItem.x==x && pItem.y==y)
					{
						inventory.AddItem(number, pName, number, maximum, pDisplayString);
					}
					pItem.x=x;
					pItem.y=y;
					UpdateDisplayList();
				}
			}
			return;
		}
					
		void HilightDrop(string pName, int xx, int yy)
		{
			if (xx<0 || xx>=nColumns || yy<0 || yy>=nLines)
			{
				return;
			}

			CObject hoPtr;
			int n;
			for (n=0; n<rh.rhOiList.Length; n++)
			{
				if (rh.rhOiList[n].oilName==pName)
				{
					short number=rh.rhOiList[n].oilObject;
					if (number>=0)
					{
						hoPtr=rh.rhObjectList[number];
						int sx=(hoPtr.hoImgWidth+itemSx-1)/itemSx;
						int sy=(hoPtr.hoImgHeight+itemSy-1)/itemSy;
						if (xx+sx<=nColumns && yy+sy<=nLines)
						{
							rcDrop.left=ho.hoX-rh.rhWindowX+xx*itemSx;
							rcDrop.right=rcDrop.left+itemSx*sx;
                            rcDrop.top = ho.hoY - rh.rhWindowY + yy*itemSy;
							rcDrop.bottom=rcDrop.top+itemSy*sy;
							bDropItem=true;
							xCursor=xx;
							yCursor=yy;
							ho.redraw();
						}
					}
				}
			}
		}				
		void RACT_HILIGHTDROP(CActExtension act)		
		{
			if (type==INVTYPE_GRID)
			{
				CObject hoPtr=act.getParamObject(rh, 0);
				int x=act.getParamExpression(rh, 1);
				int y=act.getParamExpression(rh, 2);
				CObjInfo pOiList=hoPtr.hoOiList;
				HilightDrop(pOiList.oilName, x, y);
			}
			return;
		}
		void RACT_NAMEDHILIGHTDROP(CActExtension act)		
		{
			if (type==INVTYPE_GRID)
			{
				string pName=act.getParamExpString(rh, 0);
				int x=act.getParamExpression(rh, 1);
				int y=act.getParamExpression(rh, 2);
				HilightDrop(pName, x, y);
			}
			return;
		}

        string cleanName(string name)
        {
            int pos = name.LastIndexOf('\\');
            if (pos < 0)
            {
                pos = name.LastIndexOf('/');
            }
            if (pos >= 0 && pos + 1 < name.Length)
            {
                name = name.Substring(pos + 1);
            }
            return name;
        }
        void RACT_SAVE(CActExtension act)		
		{
            string path = cleanName(act.getParamFilename(rh, 0));
#if !WINDOWS_PHONE
            if (ho.hoAdRunHeader.rhApp.storageDevice == null)
            {
                stateobj = (Object)"Please choose a device";
                try
                {
                    StorageDevice.BeginShowSelector(rh.deviceSelectorPlayer, this.GetDevice, stateobj);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
            }
            if (ho.hoAdRunHeader.rhApp.storageDevice != null && ho.hoAdRunHeader.rhApp.storageDevice.IsConnected == true)
            {
                // Open a storage container.
                IAsyncResult result = ho.hoAdRunHeader.rhApp.storageDevice.BeginOpenContainer(ho.hoAdRunHeader.rhApp.appName, null, null);

                // Wait for the WaitHandle to become signaled.
                result.AsyncWaitHandle.WaitOne();

                StorageContainer container = ho.hoAdRunHeader.rhApp.storageDevice.EndOpenContainer(result);

                // Close the wait handle.
                result.AsyncWaitHandle.Close();

                // Create a new file.
                if (!container.FileExists(path))
                {
                    container.DeleteFile(path);
                }
                Stream stream = container.CreateFile(path);
                BinaryWriter writer = new BinaryWriter(stream);
                inventory.Save(writer);
                writer.Flush();
                writer.Close();
                writer.Dispose();
                container.Dispose();
            }
#else
            if (path != null)
            {
                using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    using (IsolatedStorageFileStream isfs = new IsolatedStorageFileStream(path, FileMode.Create, isf))
                    {
                        using (BinaryWriter writer = new BinaryWriter(isfs))
                        {
                            inventory.Save(writer);
                            writer.Flush();
                            writer.Close();
                            writer.Dispose();
                        }
                    }
                    isf.Dispose();
                }
            }
#endif
            return;
		}
        public static void WriteAString(BinaryWriter stream, string text)
        {
            int l = text.Length;
            int n;
            byte[] data = new byte[l+1];
            for (n = 0; n < l; n++)
            {
                data[n] = (byte)text[n];
            }
            data[n] = 0;
            try
            {
                stream.Write(data, 0, l+1);
            }
            catch (IOException e)
            {
                e.GetType();
            }
        }
        public static void WriteAByte(BinaryWriter stream, byte value)
        {
            byte[] data = new byte[1];
            data[0] = value;
            try
            {
                stream.Write(data, 0, 1);
            }
            catch (IOException e)
            {
                e.GetType();
            }
        }
        public static void WriteAShort(BinaryWriter stream, short value)
        {
            byte[] data = new byte[2];
            data[0] = (byte)(value & 255);
            data[1] = (byte)(value >> 8);
            try
            {
                stream.Write(data, 0, 2);
            }
            catch (IOException e)
            {
                e.GetType();
            }
        }
        public static void WriteAnInt(BinaryWriter stream, int value)
        {
            byte[] data = new byte[4];
            data[0] = (byte)(value & 255);
            data[1] = (byte)((value >> 8) & 255);
            data[2] = (byte)((value >> 16) & 255);
            data[3] = (byte)((value >> 24) & 255);
            try
            {
                stream.Write(data, 0, 4);
            }
            catch (IOException e)
            {
                e.GetType();
            }
        }
        
#if !WINDOWS_PHONE
        void GetDevice(IAsyncResult result)
        {
            ho.hoAdRunHeader.rhApp.storageDevice = StorageDevice.EndShowSelector(result);
        }
#endif
        public CFile loadFromProject(string name)
        {
            CFile cfile = null;
            CEmbeddedFile efile = rh.rhApp.getEmbeddedFile(name);
            if (efile!=null)
            {
                cfile = efile.open();
            }
            if (cfile==null)
            {
                int pos = name.LastIndexOf('.');
                if (pos >= 0)
                {
                    name = name.Substring(0, pos);
                }
                BinaryRead.Data iniFile = null;
                try
                {
                    iniFile = rh.rhApp.content.Load<BinaryRead.Data>(name);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
                if (iniFile != null)
                {
                    cfile = new CFile(iniFile.data);
                }
            }
            return cfile;
        }
        private CFile GetCFile(string path)
        {
            CFile cFile=null;

#if !WINDOWS_PHONE
            // Opens a StorageDevice
            if (ho.hoAdRunHeader.rhApp.storageDevice == null)
            {
                stateobj = (Object)"Please choose a device";
                try
                {
                    StorageDevice.BeginShowSelector(rh.deviceSelectorPlayer, this.GetDevice, stateobj);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
            }
            if (ho.hoAdRunHeader.rhApp.storageDevice != null && ho.hoAdRunHeader.rhApp.storageDevice.IsConnected == true)
            {
                // Open a storage container.
                IAsyncResult result = ho.hoAdRunHeader.rhApp.storageDevice.BeginOpenContainer(ho.hoAdRunHeader.rhApp.appName, null, null);

                // Wait for the WaitHandle to become signaled.
                result.AsyncWaitHandle.WaitOne();

                StorageContainer container = ho.hoAdRunHeader.rhApp.storageDevice.EndOpenContainer(result);

                // Close the wait handle.
                result.AsyncWaitHandle.Close();

                // Check to see whether the save exists.
                if (!container.FileExists(path))
                {
                    // If not, dispose of the container and return.
                    container.Dispose();
                    return loadFromProject(path);
                }

                // Open the file.
                Stream stream = container.OpenFile(path, FileMode.Open);
                int length=(int)stream.Length;
                byte[] data=new byte[length];
                try
                {
                    stream.Read(data, 0, length);
                }
                catch (IOException e)
                {
                    e.GetType();
                }
                stream.Close();
                stream.Dispose();
                container.Dispose();
                cFile=new CFile(data);
            }
#else
            using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (isf.FileExists(path))
                {
                    using (IsolatedStorageFileStream isfs = new IsolatedStorageFileStream(path, FileMode.Open, isf))
                    {
                        using (BinaryReader reader = new BinaryReader(isfs))
                        {
                            int length=(int)reader.BaseStream.Length;
                            byte[] data=new byte[length];
                            try
                            {
                                reader.Read(data, 0, length);
                            }
                            catch (IOException e)
                            {
                                e.GetType();
                            }
                            reader.Close();
                            reader.Dispose();
                            cFile=new CFile(data);
                        }
                    }
                }
                else
                {
                    loadFromProject(path);
                }
                isf.Dispose();
            } 
#endif
            return cFile;
        }
        void RACT_LOAD(CActExtension act)		
		{
            string path = cleanName(act.getParamFilename(rh, 0));
            CFile file = GetCFile(path);
            if (file!=null)
            {
				inventory.Load(file);
				position=0;
				xCursor=0;
				yCursor=0;
				UpdateDisplayList();
			}
			return;
		}					
						
						
		



        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_NITEM:
                    return REXP_NITEM();
                case EXP_NAMEOFHILIGHTED:
                    return REXP_NAMEOFHILIGHTED();
                case EXP_NAMEOFSELECTED:
                    return REXP_NAMEOFSELECTED();
                case EXP_POSITION:
                    return REXP_POSITION();
                case EXP_PAGE:
                    return REXP_PAGE();
                case EXP_TOTAL:
                    return REXP_TOTAL();
                case EXP_DISPLAYED:
                    return REXP_DISPLAYED();
                case EXP_NUMOFSELECTED:
                    return REXP_NUMOFSELECTED();
                case EXP_NUMOFHILIGHTED:
                    return REXP_NUMOFHILIGHTED();
                case EXP_NAMEOFNUM:
                    return REXP_NAMEOFNUM();
                case EXP_MAXITEM:
                    return REXP_MAXITEM();
                case EXP_NUMBERMAXITEM:
                    return REXP_NUMBERMAXITEM();
                case EXP_NUMBERNITEM:
                    return REXP_NUMBERNITEM();
                case EXP_GETPROPERTY:
                    return REXP_GETPROPERTY();
                case EXP_NUMBERGETPROPERTY:
                    return REXP_NUMBERGETPROPERTY();
            }
            return new CValue(0);
        }

				
		CValue REXP_NITEM()
		{
			string pName=ho.getExpParam().getString();
			CInventoryItem pItem=inventory.GetItem(number, pName);
			if (pItem!=null)
			{
				return new CValue(pItem.GetQuantity());
			}
			return new CValue(0);
		}
		CValue REXP_GETPROPERTY()
		{
			string pName=ho.getExpParam().getString();
			string pProperty=ho.getExpParam().getString();
			CInventoryItem pItem=inventory.GetItem(number, pName);
			if (pItem!=null)
			{
				return new CValue(pItem.GetProperty(pProperty));
			}
			return new CValue(0);
		}
		CValue REXP_MAXITEM()
		{
			string	pName = ho.getExpParam().getString();
			CInventoryItem pItem=inventory.GetItem(number, pName);
			if (pItem!=null)
			{
				return new CValue(pItem.GetMaximum());
			}
			return new CValue(0);
		}
		CValue REXP_NUMBERNITEM()
		{
            int num = ho.getExpParam().getInt();
			if (num>=0 && num<displayList.size())
			{
				CInventoryItem pItem=(CInventoryItem)displayList.get(num);
				if (pItem!=null)
				{
					return new CValue(pItem.GetQuantity());
				}
			}
			return new CValue(0);
		}
		CValue REXP_NUMBERGETPROPERTY()
		{
            int num = ho.getExpParam().getInt();
            string pProperty = (string)ho.getExpParam().getString();
			if (num>=0 && num<displayList.size())
			{
				CInventoryItem pItem=(CInventoryItem)displayList.get(num);
				if (pItem!=null)
				{
					return new CValue(pItem.GetProperty(pProperty));
				}
			}
            return new CValue(0);
        }
		CValue REXP_NUMBERMAXITEM()
		{
            int num = ho.getExpParam().getInt();
			if (num>=0 && num<displayList.size())
			{
				CInventoryItem pItem=(CInventoryItem)displayList.get(num);
				if (pItem!=null)
				{
					return new CValue(pItem.GetMaximum());
				}
			}
            return new CValue(0);
        }
		CValue REXP_NAMEOFHILIGHTED()
		{
			if (pNameHilighted!=null)
			{
				return new CValue(pNameHilighted);
			}
			return new CValue("");
		}
		CValue REXP_NAMEOFSELECTED()
		{
			if (pNameSelected!=null)
			{
				return new CValue(pNameSelected);
			}
			return new CValue("");
		}
		CValue REXP_POSITION()
		{
			return new CValue(position);
		}
		CValue REXP_PAGE()
		{
			return new CValue(position/(nLines*nColumns));
		}
		CValue REXP_TOTAL()
		{
			return new CValue(displayList.size());
		}
		CValue REXP_DISPLAYED()
		{
			return new CValue(Math.Min(displayList.size()-position, nLines*nColumns));
		}
		CValue REXP_NUMOFSELECTED()
		{
			return new CValue(numSelected);
		}
		CValue REXP_NUMOFHILIGHTED()
		{
			return new CValue(numHilighted);
		}
		CValue REXP_NAMEOFNUM()
		{
			int num = ho.getExpParam().getInt();
			if (num>=0 && num<displayList.size())
			{
				CInventoryItem pItem=(CInventoryItem)displayList.get(num);
				return new CValue(pItem.GetName());
			}
            return new CValue("");
		}

    }

	//////////////////////////////////////////////////////////////////////////////////////////////////
	// 																							    //
	//		InventoryList																			//
	// 																							    //
	//////////////////////////////////////////////////////////////////////////////////////////////////
    class CInventoryList
    {
		public CArrayList list=new CArrayList();
		public int position;

		public void Reset()
		{
			list.clear();
			position=0;
		}
        public CInventoryItem GetItem(int number, string pName)
		{
			int n;
			for (n=0; n<list.size(); n++)
			{
				CInventoryItem pItem=(CInventoryItem)list.get(n);
				if (pItem.GetNumber()==number)
				{
					if (pItem.GetName()==pName)
					{
						return pItem;
					}
				}
			}
			return null;
		}
        public int GetItemIndex(int number, string pName)
		{
			int n;
			for (n=0; n<list.size(); n++)
			{
				CInventoryItem pItem=(CInventoryItem)list.get(n);
				if (pItem.GetNumber()==number)
				{
					if (pItem.GetName()==pName)
					{
						return n;
					}
				}
			}
			return 0;
		}
        public CInventoryItem FirstItem(int number)
		{
			for (position=0; position<list.size(); position++)
			{
				CInventoryItem pItem=(CInventoryItem)list.get(position);
				if (pItem.GetNumber()==number)
				{
					position++;
					return pItem;
				}
			}
			return null;
		}
        public CInventoryItem NextItem(int number)
		{
			for (; position<list.size(); position++)
			{
				CInventoryItem pItem=(CInventoryItem)list.get(position);
				if (pItem.GetNumber()==number)
				{
					position++;
					return pItem;
				}
			}
			return null;
		}

		public void Load(CFile file)
		{
			Reset();
			short size;
			size=file.readAShort();
			int n;
			for (n=0; n<size; n++)
			{
				CInventoryItem pItem=new CInventoryItem(0, "", 0, 1, "");
				pItem.Load(file);
				list.add(pItem);
			}
		}

        public void Save(BinaryWriter writer)
        {
            CRunInventory.WriteAShort(writer, (short)list.size());
            int n;
            for (n=0; n<list.size(); n++)
            {
                CInventoryItem pItem=(CInventoryItem)list.get(n);
                pItem.Save(writer);
            }
        }

        public CInventoryItem AddItem(int number, string pName, int quantity, int maximum, string pDisplayString)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem==null)
			{
				pItem=new CInventoryItem(number, pName, quantity, maximum, pDisplayString);
				list.add(pItem);
			}
			else
			{
				pItem.AddQuantity(quantity);
				if (pItem.quantity==0)
				{
					list.remove(pItem);
				}
			}
			return pItem;
		}
        public CInventoryItem AddItemToPosition(int number, string insert, string pName, int quantity, int maximum, string pDisplayString)
		{
			int n;
			CInventoryItem pItem2=null;
			for (n=0; n<list.size(); n++)
			{
				pItem2=(CInventoryItem)list.get(n);
				if (insert==pItem2.pName)
				{
					break;
				}
			}
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem==null)
			{
				pItem=new CInventoryItem(number, pName, quantity, maximum, pDisplayString);
				list.add(n, pItem);
			}
			else
			{
				list.swap(pItem, pItem2);
			}
			return pItem;
		}

        public bool SubQuantity(int number, string pName, int quantity)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				pItem.SubQuantity(quantity);
				if (pItem.quantity==0)
				{
					list.remove(pItem);
					return true;
				}
			}
			return false;
		}
        public void SetMaximum(int number, string pName, int max)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				pItem.SetMaximum(max);
			}
		}
        public int GetQuantity(int number, string pName)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				return pItem.GetQuantity();
			}
			return -1;
		}
        public int GetMaximum(int number, string pName)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				return pItem.GetMaximum();
			}
			return -1;
		}
        public void DelItem(int number, string pName)
		{
			int index=GetItemIndex(number, pName);
			if (index>=0)
			{
				list.remove(index);
			}
		}
        public void SetFlags(int number, string pName, int mask, int flag)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				pItem.SetFlags(mask, flag);
			}
		}
        public int GetFlags(int number, string pName)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				return pItem.GetFlags();
			}
			return 0;
		}
        public void SetDisplayString(int number, string pName, string pDisplayString)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				pItem.SetDisplayString(pDisplayString);
			}
		}
        public string GetDisplayString(int number, string pName)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				return pItem.GetDisplayString();
			}
			return null;
		}
        public void AddProperty(int number, string pName, string propName, int value)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				pItem.AddProperty(propName, value);
			}
		}
        public void SetPropertyMinimum(int number, string pName, string propName, int value)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				pItem.SetPropertyMinimum(propName, value);
			}
		}
        public void SetPropertyMaximum(int number, string pName, string propName, int value)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				pItem.SetPropertyMinimum(propName, value);
			}
		}
        public int GetProperty(int number, string pName, string propName)
		{
			CInventoryItem pItem=GetItem(number, pName);
			if (pItem!=null)
			{
				return pItem.GetProperty(propName);
			}
			return 0;
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////
	// 																							    //
	//		InventoryItem																			//
	// 																							    //
	//////////////////////////////////////////////////////////////////////////////////////////////////
    class CInventoryItem
	{
		public int number;
        public string pName;
        public string pDisplayString;
        public int flags;
        public int quantity;
        public int maximum;
        public int x;
        public int y;
        public CArrayList properties;
		public const int FLAG_VISIBLE=0x0001;

        public CInventoryItem(int n, string ptr, int q, int max, string displayString)
		{
			number=n;
			pName=ptr;
			pDisplayString=displayString;
			maximum=Math.Max(max, 1);
			quantity=Math.Min(q, maximum);
			quantity=Math.Max(quantity, 0);
			flags=FLAG_VISIBLE;
			properties=new CArrayList();
			x=0;
			y=0;
		}
        public void Reset()
		{
			properties.clear();
		}
        public void SetFlags(int mask, int flag)
        {
            flags = (flags & mask) | flag;
        }
        public string GetName()
        {
            return pName;
        }
        public string GetDisplayString()
        {
            return pDisplayString;
        }
        public int GetQuantity()
        {
            return quantity;
        }
        public int GetMaximum()
        {
            return maximum;
        }
        public int GetNumber()
        {
            return number;
        }
        public int GetFlags()
        {
            return flags;
        }
        public void Save(BinaryWriter writer)
		{

			CRunInventory.WriteAnInt(writer, number);
			CRunInventory.WriteAnInt(writer, flags);
			CRunInventory.WriteAnInt(writer, quantity);
			CRunInventory.WriteAnInt(writer, maximum);
			CRunInventory.WriteAnInt(writer, x);
			CRunInventory.WriteAnInt(writer, y);

			CRunInventory.WriteAString(writer, pName);

			CRunInventory.WriteAString(writer, pDisplayString);

			int l=properties.size();
			CRunInventory.WriteAShort(writer, (short)l);
			int n;
			for (n=0; n<l; n++)
			{
				CInventoryProperty pProperty=(CInventoryProperty)properties.get(n);
				pProperty.Save(writer);
			}
		}
		public void Load(CFile file)
		{
			Reset();
			number=file.readAInt();
			flags=file.readAInt();
			quantity=file.readAInt();
			maximum=file.readAInt();
			x=file.readAInt();
			y=file.readAInt();

			pName=file.readAString();
			pDisplayString=file.readAString();

			int l=file.readAShort();
			int n;
			for (n=0; n<l; n++)
			{
				CInventoryProperty pProperty=new CInventoryProperty("", 0, 0, 0);
				pProperty.Load(file);
				properties.add(pProperty);
			}
		}
        public void SetDisplayString(string displayString)
		{
			pDisplayString=displayString;
		}
        public void SetQuantity(int q)
		{
			q=Math.Max(q, 0);
			q=Math.Min(q, maximum);
			quantity=q;
		}
        public void AddQuantity(int q)
		{
			q=Math.Max(q+quantity, 0);
			q=Math.Min(q, maximum);
			quantity=q;
		}
        public void SubQuantity(int q)
		{
			q=Math.Max(quantity-q, 0);
			q=Math.Min(q, maximum);
			quantity=q;
		}
        public void SetMaximum(int m)
		{
			maximum=Math.Max(m, 1);
			quantity=Math.Min(quantity, maximum);
		}
        public CInventoryProperty FindProperty(string pName)
		{
			int n;
			for (n=0; n<properties.size(); n++)
			{
				CInventoryProperty pProperty=(CInventoryProperty)properties.get(n);
				if (pName==pProperty.pName)
				{
					return pProperty;
				}
			}
			return null;
		}
        public void AddProperty(string pName, int value)
		{
			CInventoryProperty pProperty=FindProperty(pName);
			if (pProperty!=null)
			{
				pProperty.AddValue(value);
			}
			else
			{
				pProperty=new CInventoryProperty(pName, value, unchecked((int)0x80000000), (int)0x7FFFFFFF);
				properties.add(pProperty);
			}
		}
        public void SetPropertyMinimum(string pName, int min)
		{
			CInventoryProperty pProperty=FindProperty(pName);
			if (pProperty!=null)
			{
				pProperty.SetMinimum(min);
			}
			else
			{
				pProperty=new CInventoryProperty(pName, 0, min, 0x7FFFFFFF);
				properties.add(pProperty);
			}
		}
        public void SetPropertyMaximum(string pName, int max)
		{
			CInventoryProperty pProperty=FindProperty(pName);
			if (pProperty!=null)
			{
				pProperty.SetMaximum(max);
			}
			else
			{
				pProperty=new CInventoryProperty(pName, 0, unchecked((int)0x80000000), (int)max);
				properties.add(pProperty);
			}
		}
        public int GetProperty(string pName)
		{
			CInventoryProperty pProperty=FindProperty(pName);
			if (pProperty!=null)
			{
				return pProperty.GetValue();
			}
			return 0;
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////
	// 																							    //
	//		Inventory property																		//
	// 																							    //
	//////////////////////////////////////////////////////////////////////////////////////////////////
	class CInventoryProperty
	{
        public string pName;
        public int value;
        public int maximum;
        public int minimum;

        public CInventoryProperty(string name, int v, int min, int max)
		{
			pName=name;

			value=v;
			minimum=min;
			maximum=max;
		}
        public void Save(BinaryWriter writer)
		{
			CRunInventory.WriteAString(writer, pName);
			CRunInventory.WriteAnInt(writer, value);
			CRunInventory.WriteAnInt(writer, minimum);
            CRunInventory.WriteAnInt(writer, maximum);
		}
        public void Load(CFile file)
		{
			pName=file.readAString();
			value=file.readAInt();
			minimum=file.readAInt();
			maximum=file.readAInt();
		}
        public void AddValue(int v)
		{
			value=Math.Max(Math.Min(value+v, maximum), minimum);
		}
        public void SetMinimum(int m)
		{
			minimum=m;
			value=Math.Max(Math.Min(value, maximum), minimum);
		}
        public void SetMaximum(int m)
		{
			maximum=m;
			value=Math.Max(Math.Min(value, maximum), minimum);
		}
        public int GetValue()
        {
            return value;
        }
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////
	// 																							    //
	//		CScrollBar      																		//
	// 																							    //
	//////////////////////////////////////////////////////////////////////////////////////////////////
    class CScrollBar
    {
		public const int SX_SLIDER=8;
		public const int SY_SLIDER=8;
		public const int ZONE_NONE=0;
		public const int ZONE_TOPARROW=1;
		public const int ZONE_TOPCENTER=2;
		public const int ZONE_SLIDER=3;
		public const int ZONE_BOTTOMCENTER=4;
		public const int ZONE_BOTTOMARROW=5;
		public const int SCROLL_UP=0;
		public const int SCROLL_PAGEUP=1;
		public const int SCROLL_SLIDE=2;
		public const int SCROLL_PAGEDOWN=3;
		public const int SCROLL_DOWN=4;

	    public int position;
        public int length;
        public int total;
        public int color;
        public int colorHilight;
        public CRun rhPtr;
        public CRunInventory data;
        public CRect topArrow = new CRect();
        public CRect slider = new CRect();
        public CRect center = new CRect();
        public CRect bottomArrow = new CRect();
        public CRect surface = new CRect();
        public int zone;
        public bool oldBDown;
        public int xStart;
        public int yStart;
        public bool bDragging;
        public bool bInitialised;
        public bool bHorizontal;

        public CScrollBar()
        {
	        bInitialised=false;
        }

        public void Initialise(CRun rh, int x, int y, int sx, int sy, int c, int ch, CRunInventory d)
        {
	        rhPtr=rh;
	        data=d;
	        color=c;
	        colorHilight=ch;

	        surface.left=x;
	        surface.top=y;
	        surface.right=x+sx;
	        surface.bottom=y+sy;
	        if (sx>sy)
	        {
#if WINDOWS
                bHorizontal = true;
                center.left = x + SX_SLIDER;
                center.top = y;
                center.right = x + sx - SX_SLIDER;
                center.bottom = y + sy;
		        topArrow.left=x;
		        topArrow.top=y;
		        topArrow.right=x+SX_SLIDER;
		        topArrow.bottom=y+sy;
		        bottomArrow.left=x+sx-SX_SLIDER;
		        bottomArrow.top=y;
		        bottomArrow.right=x+sx;
		        bottomArrow.bottom=y+sy;
#else
                center.left = x;
                center.top = y;
                center.right = x + sx;
                center.bottom = y + sy;
#endif
            }
	        else
	        {
		        bHorizontal=false;
#if WINDOWS
                center.left = x;
                center.top = y + SY_SLIDER;
                center.right = x + sx;
                center.bottom = y + sy - SY_SLIDER;
                topArrow.left = x;
                topArrow.top = y;
		        topArrow.right=x+sx-1;
		        topArrow.bottom=y+SY_SLIDER-1;
		        bottomArrow.left=x;
		        bottomArrow.top=y+sy-SY_SLIDER;
		        bottomArrow.right=x+sx-1;
		        bottomArrow.bottom=y+sy-1;
#else
                center.left = x;
                center.top = y;
                center.right = x + sx;
                center.bottom = y + sy;
#endif
            }
	        SetPosition(position, length, total);
	        bInitialised=true;
        }
        public void SetPosition(int p, int l, int t)
        {
	        position=p;
	        length=l;
	        total=t;

	        if (total>0)
	        {
		        if (bHorizontal)
		        {
			        slider.left=Math.Min(center.left+(position*(center.right-center.left))/total, center.right);
			        slider.right=Math.Min(slider.left+(length*(center.right-center.left))/total, center.right);
			        slider.top=center.top;
			        slider.bottom=center.bottom;
		        }
		        else
		        {
			        slider.top=Math.Min(center.top+(position*(center.bottom-center.top))/total, center.bottom);
			        slider.bottom=Math.Min(slider.top+(length*(center.bottom-center.top))/total, center.bottom);		
			        slider.left=center.left;
			        slider.right=center.right;
		        }
	        }
        }
        public bool IsMouseInBar()
        {
	        if (bInitialised)
	        {
		        return surface.ptInRect(rhPtr.rh2MouseX, rhPtr.rh2MouseY);
	        }
	        return false;
        }
        public bool IsDragging()
        {
	        return bDragging;
        }
        public int GetZone()
        {
	        if (bDragging)
	        {
		        return ZONE_SLIDER;
	        }
	        if (topArrow.ptInRect(rhPtr.rh2MouseX, rhPtr.rh2MouseY))
	        {
		        return ZONE_TOPARROW;
	        }
	        if (bottomArrow.ptInRect(rhPtr.rh2MouseX, rhPtr.rh2MouseY))
	        {
		        return ZONE_BOTTOMARROW;
	        }
	        if (center.ptInRect(rhPtr.rh2MouseX, rhPtr.rh2MouseY))
	        {
    	        if (slider.ptInRect(rhPtr.rh2MouseX, rhPtr.rh2MouseY))
		        {
			        return ZONE_SLIDER;
		        }
		        if (bHorizontal)
		        {
			        if (rhPtr.rh2MouseX<slider.left)
			        {
				        return ZONE_TOPCENTER;
			        }
			        else
			        {
				        return ZONE_BOTTOMCENTER;
			        }
		        }
		        else
		        {
			        if (rhPtr.rh2MouseY<slider.top)
			        {
				        return ZONE_TOPCENTER;
			        }
			        else
			        {
				        return ZONE_BOTTOMCENTER;
			        }
		        }
	        }
	        return ZONE_NONE;
        }
        public void Handle()
        {
	        if (bInitialised && length<total)
	        {
		        zone=GetZone();

				bool bDown=(rhPtr.mouseKey==0);
		        if (bDown!=oldBDown)
		        {
			        oldBDown=bDown;
			        if (bDown)
			        {
				        switch (zone)
				        {
				        case ZONE_TOPARROW:
					        data.Scroll(SCROLL_UP, 0);
					        break;
				        case ZONE_TOPCENTER:
					        data.Scroll(SCROLL_PAGEUP, 0);
					        break;
				        case ZONE_BOTTOMCENTER:
					        data.Scroll(SCROLL_PAGEDOWN, 0);
					        break;
				        case ZONE_BOTTOMARROW:
					        data.Scroll(SCROLL_DOWN, 0);
					        break;
				        case ZONE_SLIDER:
					        xStart=rhPtr.rh2MouseX;
					        yStart=rhPtr.rh2MouseY;
					        bDragging=true;
					        break;
				        }
			        }
			        else
			        {
				        bDragging=false;
			        }
		        }
		        else
		        {
			        if (bDragging)
			        {
				        if (bHorizontal)
				        {
					        int delta=rhPtr.rh2MouseX-xStart;
					        delta=(delta*total)/(center.right-center.left);
					        if (delta!=0)
					        {
						        int pos=position+delta;
						        pos=Math.Max(pos, 0);
						        pos=Math.Min(pos, total-length);
						        data.Scroll(SCROLL_SLIDE, pos);
						        xStart=rhPtr.rh2MouseX;
					        }
				        }
				        else
				        {
					        int delta=rhPtr.rh2MouseY-yStart;
					        delta=(delta*total)/(center.bottom-center.top);
					        if (delta!=0)
					        {
						        int pos=position+delta;
						        pos=Math.Max(pos, 0);
						        pos=Math.Min(pos, total-length);
						        data.Scroll(SCROLL_SLIDE, pos);
						        yStart=rhPtr.rh2MouseY;
					        }
				        }
			        }
		        }
	        }
        }
        public void DrawBar(SpriteBatchEffect batch)
        {
	        if (bInitialised==true&& length<total)
	        {
                rhPtr.rhApp.services.drawRect(batch, center, color, 0, 0) ;
		        if (zone==ZONE_SLIDER)
                    rhPtr.rhApp.services.fillRect(batch, slider, colorHilight, 0, 0);
		        else
                    rhPtr.rhApp.services.fillRect(batch, slider, color, 0, 0);
		
#if WINDOWS
                int currentColor, y;
		        if (bHorizontal)
		        {
			        if (zone==ZONE_TOPARROW)
                        currentColor = colorHilight;
			        else
                        currentColor = color;
                    for (y=topArrow.top; y<=topArrow.bottom; y++)
                        rhPtr.rhApp.services.drawLine(batch, topArrow.left, (topArrow.bottom+topArrow.top)/2, topArrow.right, y, currentColor, 1, 0, 0);

			        if (zone==ZONE_BOTTOMARROW)
                        currentColor = colorHilight;
                    else
                        currentColor = color;
                    for (y = bottomArrow.top; y <= bottomArrow.bottom; y++)
                        rhPtr.rhApp.services.drawLine(batch, bottomArrow.left, y, bottomArrow.right, (bottomArrow.bottom + bottomArrow.top) / 2, currentColor, 1, 0, 0);
		        }
		        else
		        {
                    int x;
			        if (zone==ZONE_TOPARROW)
                        currentColor = colorHilight;
                    else
                        currentColor = color;
                    for (x = topArrow.left; x <= topArrow.right; x++)
                        rhPtr.rhApp.services.drawLine(batch, x, topArrow.bottom, (topArrow.left + topArrow.right) / 2, topArrow.top, currentColor, 1, 0, 0);

			        if (zone==ZONE_BOTTOMARROW)
                        currentColor = colorHilight;
                    else
                        currentColor = color;
                    for (x = bottomArrow.left; x <= bottomArrow.right; x++)
                        rhPtr.rhApp.services.drawLine(batch, x, bottomArrow.top, (bottomArrow.left + bottomArrow.right) / 2, bottomArrow.bottom, currentColor, 1, 0, 0);
		        }
#endif
	        }
        }
    }
}