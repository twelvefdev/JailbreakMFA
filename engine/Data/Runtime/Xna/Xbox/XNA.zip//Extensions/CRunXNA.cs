﻿//----------------------------------------------------------------------------------
//
// CRUNXNA Edit
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.GamerServices;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;
#if WINDOWS_PHONE 
using Microsoft.Phone.Tasks;
using Microsoft.Devices;
using Microsoft.Xna.Framework.Media;
#endif
#if !WINDOWS_PHONE
using Microsoft.Xna.Framework.Storage;
#endif

namespace RuntimeXNA.Extensions
{
    class CRunXNA : CRunExtension
    {
        const int CND_TRIAL = 0;
        const int CND_BACK = 1;
        const int CND_DEACTIVATED = 2;
        const int CND_REACTIVATED = 3;
        const int CND_MUSICPLAYING = 4;
        const int CND_LAST = 5;
        const int ACT_OPENURL = 0;
        const int ACT_VIBRATE = 1;
        const int ACT_SETPLAYER = 2;
        const int ACT_SETDEVICESELECTOR = 3;
        const int ACT_OPENDEVICESELECTOR = 4;
        const int FLAG_SIMULATE_TRIAL = 0x0001;
#if !WINDOWS_PHONE
        Object stateobj;
#else
        bool bBack;
#endif

        int flags;

        public override int getNumberOfConditions()
        {
            return CND_LAST;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            // Read in edPtr values
            flags = file.readAInt();
#if !WINDOWS_PHONE
            if ((flags & FLAG_SIMULATE_TRIAL) != 0)
            {
                Guide.SimulateTrialMode = true;
            }
            else
            {
                Guide.SimulateTrialMode = false;
            }
#else
            rh.rhApp.XNAObject = ho;
            bBack = false;
#endif
            return true;
        }

        public override void destroyRunObject(bool bFast)
        {
#if WINDOWS_PHONE
            rh.rhApp.XNAObject=null;
#endif
        }


        // Conditions
        // --------------------------------------------------
        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_TRIAL:
                    return Guide.IsTrialMode;
                case CND_BACK:
                    return cndBackPressed();
                case CND_DEACTIVATED:
                    return true;
                case CND_REACTIVATED:
                    return true;
                case CND_MUSICPLAYING:
#if WINDOWS_PHONE
                    return (Microsoft.Xna.Framework.Media.MediaPlayer.State == MediaState.Playing);
#else
                    return false;
#endif
            }
            return false;
        }

        public bool cndBackPressed()
        {
#if WINDOWS_PHONE
            bool button=GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed;
            if (button)
            {
                return bBack;
            }
            else
            {
                bBack=true;
            }
            return false;
#else
            return false;
#endif
        }

        // Actions
	    // -------------------------------------------------
        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_OPENURL:
                    openURL(act);
                    break;
                case ACT_VIBRATE:
                    vibrate(act);
                    break;
                case ACT_SETPLAYER:
                    setPlayer(act);
                    break;
                case ACT_SETDEVICESELECTOR:
                    setDeviceSelector(act);
                    break;
                case ACT_OPENDEVICESELECTOR:
                    openDeviceSelector(act);
                    break;
            }
        }

        void setDeviceSelector(CActExtension act)
        {
            int player = act.getParamExpression(rh, 0);
#if WINDOWS
            player=0;
#endif
            switch (player)
            {
                case 1:
                    rh.deviceSelectorPlayer = PlayerIndex.One;
                    break;
                case 2:
                    rh.deviceSelectorPlayer = PlayerIndex.Two;
                    break;
                case 3:
                    rh.deviceSelectorPlayer = PlayerIndex.Three;
                    break;
                case 4:
                    rh.deviceSelectorPlayer = PlayerIndex.Four;
                    break;
            }            
        }

        void openDeviceSelector(CActExtension act)
        {
#if !WINDOWS_PHONE
            if (ho.hoAdRunHeader.rhApp.storageDevice == null)
            {
                stateobj = (Object)"Please choose a device";
                try
                {
                    StorageDevice.BeginShowSelector(rh.deviceSelectorPlayer, this.GetDevice, stateobj);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
            }
#endif
        }

#if !WINDOWS_PHONE
        void GetDevice(IAsyncResult result)
        {
            ho.hoAdRunHeader.rhApp.storageDevice = StorageDevice.EndShowSelector(result);
        }
#endif

        void openURL(CActExtension act)
        {
#if WINDOWS_PHONE 
            string url=act.getParamExpString(rh, 0);
            var wbt = new WebBrowserTask();
            wbt.URL = url;
            wbt.Show();
#endif
        }

        void vibrate(CActExtension act)
        {
#if WINDOWS_PHONE 
            int duration = act.getParamExpression(rh, 0);
            if (duration <= 5)
            {
                TimeSpan span = new TimeSpan(0, 0, duration);
                VibrateController controller = VibrateController.Default;
                controller.Start(span);
            }
#endif
        }

        void setPlayer(CActExtension act)
        {
#if XBOX
            int player = act.getParamExpression(rh, 0);
            int gamepad = act.getParamExpression(rh, 1);
            if (player>=1 && player<=4)
            {
                ho.hoAdRunHeader.rhApp.getCtrlType()[player-1]=(short)(gamepad|0x80);
            }
#endif
        }
    }
}
