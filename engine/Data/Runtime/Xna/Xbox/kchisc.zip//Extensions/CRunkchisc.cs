﻿//----------------------------------------------------------------------------------
//
// CRunkchisc: high score object
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.GamerServices;
#if !WINDOWS_PHONE
using Microsoft.Xna.Framework.Storage;
#else
using System.IO.IsolatedStorage;
#endif
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunkchisc : CRunExtension
    {
        const int SCR_HIDEONSTART = 0x0001;
        const int SCR_NAMEFIRST = 0x0002;
        const int SCR_CHECKONSTART = 0x0004;
        const int SCR_DONTDISPLAYSCORES = 0x0008;
        const int SCR_FULLPATH = 0x0010;
        const int CND_ISPLAYER = 0;
        const int CND_VISIBLE = 1;
        const int ACT_ASKNAME = 0;
        const int ACT_HIDE = 1;
        const int ACT_SHOW = 2;
        const int ACT_RESET = 3;
        const int ACT_CHANGENAME = 4;
        const int ACT_CHANGESCORE = 5;
        const int ACT_SETPOSITION = 6;
        const int ACT_SETXPOSITION = 7;
        const int ACT_SETYPOSITION = 8;
        const int ACT_INSERTNEWSCORE = 9;
        const int ACT_SETCURRENTFILE = 10;
        const int EXP_VALUE = 0;
        const int EXP_NAME = 1;
        const int EXP_GETXPOSITION = 2;
        const int EXP_GETYPOSITION = 3;

        bool sVisible;
        short NbScores;
        short NameSize;
        short Flags;
        CFontInfo Logfont;
        int Colorref;
        String[] Names = new String[20];
        int[] Scores = new int[20];
        String[] originalNames= new String[20]; //used for reset action
        int[] originalScores = new int[20];
        int[] scrPlayer = new int[4]; //used for high score condition
        String IniName;
        CHSIni realIni;
        short started = 0;
        SpriteFont spriteFont;
        Vector2 vector=new Vector2();
        CRect rc = new CRect();
        int currentScore;
        bool bLoaded = false;
#if !WINDOWS_PHONE
        Object stateobj;
#endif
        public override int getNumberOfConditions()
        {
            return 2;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
//            ho.setX(cob.cobX);
//            ho.setY(cob.cobY);

            this.NbScores = file.readAShort();
            this.NameSize = file.readAShort();
            this.Flags = file.readAShort();
            if (ho.hoAdRunHeader.rhApp.bUnicode == false)
            {
                this.Logfont = file.readLogFont16();
            }
            else
            {
                this.Logfont = file.readLogFont();
            }
            this.Colorref = file.readAColor();
            file.readAString(40);
            for (int i = 0; i < 20; i++)
            {
                this.Names[i] = file.readAString(41);
            }
            for (int i = 0; i < 20; i++)
            {
                this.Scores[i] = file.readAInt();
            }
            ho.setWidth(file.readAShort());
            ho.setHeight(file.readAShort());
            if ((this.Flags & SCR_HIDEONSTART) == 0)
            {
                this.sVisible = true;
            }
            this.IniName = file.readAString(260);
            if (IniName.Length == 0)
            {
                IniName = "HiScores.ini";
            }
            this.realIni = new CHSIni(this);
            CFont f = CFont.createFromFontInfo(Logfont, ho.hoAdRunHeader.rhApp);
            spriteFont = f.getFont();

            // Opens a StorageDevice
#if !WINDOWS_PHONE
            if (ho.hoAdRunHeader.rhApp.storageDevice == null)
            {
                stateobj = (Object)"Please choose a device";
                try
                {
                    StorageDevice.BeginShowSelector(rh.deviceSelectorPlayer, this.GetDevice, stateobj);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
            }
            else if (ho.hoAdRunHeader.rhApp.storageDevice.IsConnected == true)
            {
                bLoaded = true;
                GetNames();
            }
#else
            for (int a = 0; a < 20; a++)
            {
                this.Names[a] = this.realIni.getPrivateProfileString(rh.rhApp.appName, "N" + a.ToString(), this.Names[a], this.IniName);
                this.originalNames[a] = this.Names[a];
                // Get scores
                String r = this.realIni.getPrivateProfileString(rh.rhApp.appName, "S" + a.ToString(), this.Scores[a].ToString(), this.IniName);
                if (r.Length == 0)
                {
                    this.Scores[a] = 0;
                }
                else
                {
                    try
                    {
                        this.Scores[a] = System.Convert.ToInt32(r, 10);
                    }
                    catch (FormatException e)
                    {
                        e.GetType();
                    }
                }
                this.originalScores[a] = this.Scores[a];
            }
            bLoaded = true;
#endif
            return true;
        }

#if !WINDOWS_PHONE
        void GetDevice(IAsyncResult result)
        {
            ho.hoAdRunHeader.rhApp.storageDevice = StorageDevice.EndShowSelector(result);
            bLoaded = true;
            GetNames();
        }
        void GetNames()
        {
            if (ho.hoAdRunHeader.rhApp.storageDevice != null && ho.hoAdRunHeader.rhApp.storageDevice.IsConnected==true)
            {
                for (int a = 0; a < 20; a++)
                {
                    this.Names[a] = this.realIni.getPrivateProfileString(rh.rhApp.appName, "N" + a.ToString(), this.Names[a], this.IniName);
                    this.originalNames[a] = this.Names[a];
                    // Get scores
                    String r = this.realIni.getPrivateProfileString(rh.rhApp.appName, "S" + a.ToString(), this.Scores[a].ToString(), this.IniName);
                    if (r.Length == 0)
                    {
                        this.Scores[a] = 0;
                    }
                    else
                    {
                        try
                        {
                            this.Scores[a] = System.Convert.ToInt32(r, 10);
                        }
                        catch (FormatException e)
                        {
                            e.GetType();
                        }
                    }
                    this.originalScores[a] = this.Scores[a];
                }
            }
        }
#endif
        public void saveIni()
        {
            for (int a = 0; a < this.NbScores; a++)
            {
                // Put name
                //(String group, String keyName, String value, String fileName)
                this.realIni.writePrivateProfileString(rh.rhApp.appName, "N" + a.ToString(), this.Names[a], this.IniName);
                // Put scores
                this.realIni.writePrivateProfileString(rh.rhApp.appName, "S" + a.ToString(), this.Scores[a].ToString(), this.IniName);
            }
            this.realIni.saveIni();
        }

        public override void destroyRunObject(bool bFast)
        {
            saveIni();
        }

        public override int handleRunObject()
        {
#if !WINDOWS_PHONE
            if (ho.hoAdRunHeader.rhApp.storageDevice == null)
            {
                stateobj = (Object)"Please choose a device";
                try
                {
                    StorageDevice.BeginShowSelector(rh.deviceSelectorPlayer, this.GetDevice, stateobj);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
            }
            else if (bLoaded==false && ho.hoAdRunHeader.rhApp.storageDevice.IsConnected == true)
            {
                bLoaded = true;
                GetNames();
            }
#endif
            short a, b;
            short[] players = new short[4];
            bool TriOk;
            CRun rhPtr = ho.hoAdRunHeader;
            int score1, score2;
            if (bLoaded)
            {
                if ((this.Flags & SCR_CHECKONSTART) != 0)
                {
                    // Init player order
                    for (a = 0; a < 4; a++)
                    {
                        players[a] = a;
                    }
                    // Sort player order (bigger score asked first)
                    do
                    {
                        TriOk = true;
                        for (a = 1; a < 4; a++)
                        {
                            score1 = rhPtr.rhApp.getScores()[players[a]];
                            score2 = rhPtr.rhApp.getScores()[players[a - 1]];
                            if (score1 > score2)
                            {
                                b = players[a - 1];
                                players[a - 1] = players[a];
                                players[a] = b;
                                TriOk = false;
                            }
                        }
                    } while (false == TriOk);
                    this.started++;
                    int shown = 0;
                    // Check for hi-scores
                    for (a = 0; a < rhPtr.rhNPlayers; a++)
                    {
                        if (CheckScore(players[a]) == true) //popup shown
                        {
                            shown++;
                        }
                    }
                    if (shown > 0)
                    {
                        return REFLAG_ONESHOT + REFLAG_DISPLAY;
                    }
                    if (this.started > 1)
                    {
                        return REFLAG_ONESHOT + REFLAG_DISPLAY;
                    }
                    return REFLAG_DISPLAY; //keep handlerunobject running.
                }
                else
                {
                    return REFLAG_ONESHOT + REFLAG_DISPLAY;
                }
            }
            return 0;
        }

        public override void displayRunObject(SpriteBatchEffect batch)
        {
            if (bLoaded && sVisible)
            {
                String[] localNames = new String[20];
                for (int i = 0; i < 20; i++)
                {
                    localNames[i] = this.Names[i];
                    if (localNames[i].Length > this.NameSize)
                    {
                        localNames[i] = localNames[i].Substring(0, this.NameSize);
                    }
                }
                CRun rhPtr = ho.hoAdRunHeader;
                Color cc = CServices.getColor(Colorref);
                string score;
                if ((this.Flags & SCR_DONTDISPLAYSCORES) != 0)
                {
                    // Compute coordinates
                    rc.left = ho.hoX - rhPtr.rhWindowX+rhPtr.rhApp.xOffset;
                    rc.right = rc.left + ho.hoImgWidth;
                    rc.top = ho.hoY - rhPtr.rhWindowY + rhPtr.rhApp.yOffset;
                    rc.bottom = rc.top + (ho.hoImgHeight / this.NbScores);

                    // draw names
                    for (int a = 0; a < this.NbScores; a++)
                    {
                        vector.X = rc.left;
                        vector.Y = rc.top;
                        batch.DrawString(spriteFont, localNames[a], vector, cc);
                        rc.top += ho.hoImgHeight / this.NbScores;
                        rc.bottom += ho.hoImgHeight / this.NbScores;
                    }
                }
                else
                {
                    // Draw text
                    if (0 != (this.Flags & SCR_NAMEFIRST))
                    {

                        // Compute coordinates
                        rc.left = ho.hoX - rhPtr.rhWindowX + rhPtr.rhApp.xOffset;
                        rc.right = rc.left + ((ho.hoImgWidth / 4) * 3);
                        rc.top = ho.hoY - rhPtr.rhWindowY + rhPtr.rhApp.yOffset;
                        rc.bottom = rc.top + (ho.hoImgHeight / this.NbScores);

                        // draw names
                        for (int a = 0; a < this.NbScores; a++)
                        {
                            vector.X = rc.left;
                            vector.Y = rc.top;
                            batch.DrawString(spriteFont, localNames[a], vector, cc);
                            rc.top += ho.hoImgHeight / this.NbScores;
                            rc.bottom += ho.hoImgHeight / this.NbScores;
                        }

                        // Compute coordinates
                        rc.left = ho.hoX - rhPtr.rhWindowX + ((ho.hoImgWidth / 4) * 3);
                        rc.right = rc.left + (ho.hoImgWidth / 4);
                        rc.top = ho.hoY - rhPtr.rhWindowY;
                        rc.bottom = rc.top + (ho.hoImgHeight / this.NbScores);

                        // draw scores
                        for (int a = 0; a < this.NbScores; a++)
                        {
                            score = Scores[a].ToString();
                            Vector2 size = spriteFont.MeasureString(score);
                            vector.X = rc.right-size.X;
                            vector.Y = rc.top;
                            batch.DrawString(spriteFont, score, vector, cc);
                            rc.top += ho.hoImgHeight / this.NbScores;
                            rc.bottom += ho.hoImgHeight / this.NbScores;
                        }
                    }
                    else
                    {
                        // Compute coordinates
                        rc.left = ho.hoX - rhPtr.rhWindowX + rhPtr.rhApp.xOffset;
                        rc.right = rc.left + (ho.hoImgWidth / 4);
                        rc.top = ho.hoY - rhPtr.rhWindowY + rhPtr.rhApp.yOffset;
                        rc.bottom = rc.top + (ho.hoImgHeight / this.NbScores);

                        // draw scores
                        for (int a = 0; a < this.NbScores; a++)
                        {
                            vector.X = rc.right;
                            vector.Y = rc.top;
                            batch.DrawString(spriteFont, Scores[a].ToString(), vector, cc);
                            rc.top += ho.hoImgHeight / this.NbScores;
                            rc.bottom += ho.hoImgHeight / this.NbScores;
                        }

                        // Compute coordinates
                        rc.left = ho.hoX - rhPtr.rhWindowX + (ho.hoImgWidth / 4);
                        rc.right = rc.left + ((ho.hoImgWidth / 4) * 3);
                        rc.top = ho.hoY - rhPtr.rhWindowY;
                        rc.bottom = rc.top + (ho.hoImgHeight / this.NbScores);

                        // draw names
                        for (int a = 0; a < this.NbScores; a++)
                        {
                            Vector2 size = spriteFont.MeasureString(localNames[a]);
                            vector.X = rc.right-size.X;
                            vector.Y = rc.top;
                            batch.DrawString(spriteFont, localNames[a], vector, cc);
                            rc.top += ho.hoImgHeight / this.NbScores;
                            rc.bottom += ho.hoImgHeight / this.NbScores;
                        }
                    }
                }
            }
        }

        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_ISPLAYER:
                    return IsPlayerHiScore(cnd.getParamPlayer(rh, 0));
                case CND_VISIBLE:
                    return IsVisible();
            }
            return false;//won't happen
        }

        private bool IsPlayerHiScore(short player)
        {
            CRun rhPtr = ho.hoAdRunHeader;
            int score = rhPtr.rhApp.scores[player];
            if ((score > this.Scores[this.NbScores - 1]) && (score != this.scrPlayer[player]))
            {
                this.scrPlayer[player] = score;
                return true;
            }
            return false;
        }

        private bool IsVisible()
        {
            return (sVisible);
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_ASKNAME:
                    CheckScore(act.getParamPlayer(rh, 0));
                    break;
                case ACT_HIDE:
                    Hide();
                    break;
                case ACT_SHOW:
                    Show();
                    break;
                case ACT_RESET:
                    Reset();
                    break;
                case ACT_CHANGENAME:
                    ChangeName(act.getParamExpression(rh, 0), act.getParamExpString(rh, 1));
                    break;
                case ACT_CHANGESCORE:
                    ChangeScore(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case ACT_SETPOSITION:
                    SetPosition(act.getParamPosition(rh, 0));
                    break;
                case ACT_SETXPOSITION:
                    SetXPosition(act.getParamExpression(rh, 0));
                    break;
                case ACT_SETYPOSITION:
                    SetYPosition(act.getParamExpression(rh, 0));
                    break;
                case ACT_INSERTNEWSCORE:
                    InsertNewScore(act.getParamExpression(rh, 0), act.getParamExpString(rh, 1));
                    break;
                case ACT_SETCURRENTFILE:
                    SetCurrentFile(act.getParamExpString(rh, 0));
                    break;
            }
        }

        public bool CheckScore(int player) //needed public and returns true when popup is shown
        {
            CRun rhPtr = ho.hoAdRunHeader;
            if (player < rhPtr.rhNPlayers)
            {
                currentScore = rhPtr.rhApp.scores[player];
                if (currentScore > Scores[NbScores - 1])
                {
                    if (Guide.IsVisible == false)
                    {
                        Guide.BeginShowKeyboardInput(PlayerIndex.One, rh.rhApp.appName, "Please enter your name", "", endKeyboard, (object)"TextInput");
                    }
                    return true;
                }
            }
            return false;
        }
        public void endKeyboard(IAsyncResult result)
        {
            String name = Guide.EndShowKeyboardInput(result);
            if (name != null)
            {
                InsertNewScore(currentScore, name);
            }
        }

        private void Hide()
        {
            sVisible = false;
            ho.redraw();
        }

        private void Show()
        {
            sVisible = true;
            ho.redraw();
        }

        private void Reset()
        {
            for (int a = 0; a < 20; a++)
            {
                this.Names[a] = this.originalNames[a];
                this.Scores[a] = this.originalScores[a];
            }
            ho.redraw();
        }

        private void ChangeName(int i, String name) //1based
        {
            if ((i > 0) && (i <= this.NbScores))
            {
                this.Names[i - 1] = name;
                ho.redraw();
            }
        }

        private void ChangeScore(int i, int score)//1based
        {
            if ((i > 0) && (i <= this.NbScores))
            {
                this.Scores[i - 1] = score;
                ho.redraw();
            }
        }

        private void SetPosition(Params.CPositionInfo p)
        {
            this.ho.setPosition(p.x, p.y);
            if (this.sVisible)
            {
                ho.redraw();
            }
        }

        private void SetXPosition(int x)
        {
            this.ho.setX(x);
            if (this.sVisible)
            {
                ho.redraw();
            }
        }

        private void SetYPosition(int y)
        {
            this.ho.setY(y);
            if (this.sVisible)
            {
                ho.redraw();
            }
        }

        private void InsertNewScore(int pScore, String pName)
        {
            if (pScore > Scores[NbScores - 1])
            {
                Scores[19] = pScore;
                Names[19] = pName;
                short b;
                bool TriOk;
                int score;
                String name;
                // Sort the hi-score table ws_visible
                do
                {
                    TriOk = true;
                    for (b = 1; b < 20; b++)
                    {
                        if (Scores[b] > Scores[b - 1])
                        {
                            score = Scores[b - 1];
                            name = Names[b - 1];
                            Scores[b - 1] = Scores[b];
                            Names[b - 1] = Names[b];
                            Scores[b] = score;
                            Names[b] = name;
                            TriOk = false;
                        }
                    }
                } while (false == TriOk);
                saveIni();

                // If hi-score table visible, set redraw
                if (sVisible)
                {
                    ho.redraw();
                }
            }
        }

        private void SetCurrentFile(String fileName)
        {
            this.IniName = fileName;
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_VALUE:
                    return GetValue(ho.getExpParam().getInt());
                case EXP_NAME:
                    return GetName(ho.getExpParam().getInt());
                case EXP_GETXPOSITION:
                    return GetXPosition();
                case EXP_GETYPOSITION:
                    return GetYPosition();
            }
            return new CValue(0);//won't happen
        }

        private CValue GetValue(int i) //1 based
        {
            if ((i > 0) && (i <= NbScores))
            {
                return new CValue(Scores[i - 1]);
            }
            return new CValue(0);
        }
        private CValue GetName(int i) //1 based
        {
            if ((i > 0) && (i <= NbScores))
            {
                return new CValue(Names[i - 1]);
            }
            return new CValue("");
        }
        private CValue GetXPosition()
        {
            return new CValue(ho.hoX);
        }
        private CValue GetYPosition()
        {
            return new CValue(ho.hoY);
        }
       




    }


    class CHSIni
    {
        CRunkchisc ini;
        CArrayList strings = null;
        public String currentFileName = null;

        public CHSIni(CRunkchisc i)
        {
            ini = i;
        }
        public void loadIni(String fileName)
        {
            bool reload = true;
            if (currentFileName != null)
            {
                if (string.Compare(currentFileName, fileName, StringComparison.OrdinalIgnoreCase) == 0)
                {
                    reload = false;
                }
            }
            if (reload)
            {
                saveIni();
                strings = new CArrayList();
#if !WINDOWS_PHONE
                if (ini.ho.hoAdRunHeader.rhApp.storageDevice != null && ini.ho.hoAdRunHeader.rhApp.storageDevice.IsConnected == true)
                {
                    currentFileName = fileName;

                    // Open a storage container.
                    IAsyncResult result = ini.ho.hoAdRunHeader.rhApp.storageDevice.BeginOpenContainer(ini.ho.hoAdRunHeader.rhApp.appName, null, null);

                    // Wait for the WaitHandle to become signaled.
                    result.AsyncWaitHandle.WaitOne();

                    StorageContainer container = ini.ho.hoAdRunHeader.rhApp.storageDevice.EndOpenContainer(result);

                    // Close the wait handle.
                    result.AsyncWaitHandle.Close();

                    // Check to see whether the save exists.
                    if (!container.FileExists(fileName))
                    {
                        // If not, dispose of the container and return.
                        container.Dispose();
                        return;
                    }

                    // Open the file.
                    Stream stream = container.OpenFile(fileName, FileMode.Open);
                    StreamReader reader = new StreamReader(stream);
                    try
                    {
                        while (true)
                        {
                            string currentLine = reader.ReadLine();
                            if (currentLine == null)
                            {
                                break;
                            }
                            strings.add(currentLine);
                        }
                    }
                    catch (IOException e)
                    {
                        e.GetType();
                    }
                    reader.Close();
                    reader.Dispose();
                    container.Dispose();
                }
                else
                {
                    ini.ho.hoAdRunHeader.rhApp.storageDevice = null;
                }
#else
                currentFileName = fileName;
                using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    if (isf.FileExists(currentFileName))
                    {
                        using (IsolatedStorageFileStream isfs = new IsolatedStorageFileStream(currentFileName, FileMode.Open, isf))
                        {
                            using (StreamReader reader = new StreamReader(isfs))
                            {
                                try
                                {
                                    while (true)
                                    {
                                        string currentLine = reader.ReadLine();
                                        if (currentLine == null)
                                        {
                                            break;
                                        }
                                        strings.add(currentLine);
                                    }
                                }
                                catch (IOException e)
                                {
                                    e.GetType();
                                }
                                reader.Close();
                                reader.Dispose();
                            }
                        }
                    }
                    isf.Dispose();
                }
#endif
            }
        }
        public void saveIni()
        {
#if !WINDOWS_PHONE
            if (ini.ho.hoAdRunHeader.rhApp.storageDevice == null || ini.ho.hoAdRunHeader.rhApp.storageDevice.IsConnected == false)
            {
                ini.ho.hoAdRunHeader.rhApp.storageDevice = null;
                return;
            }
            if (strings != null && currentFileName != null)
            {
                // Open a storage container.
                IAsyncResult result = ini.ho.hoAdRunHeader.rhApp.storageDevice.BeginOpenContainer(ini.ho.hoAdRunHeader.rhApp.appName, null, null);

                // Wait for the WaitHandle to become signaled.
                result.AsyncWaitHandle.WaitOne();

                StorageContainer container = ini.ho.hoAdRunHeader.rhApp.storageDevice.EndOpenContainer(result);

                // Close the wait handle.
                result.AsyncWaitHandle.Close();

                // Create a new file.
                if (!container.FileExists(currentFileName))
                {
                    container.DeleteFile(currentFileName);
                }
                Stream stream = container.CreateFile(currentFileName);
                StreamWriter writer = new StreamWriter(stream);
                try
                {
                    int i;
                    for (i = 0; i < strings.size(); i++)
                    {
                        writer.WriteLine((string)strings.get(i));
                    }
                }
                catch (IOException e)
                {
                    e.GetType();
                }
                writer.Close();
                writer.Dispose();

                // Dispose the container, to commit the data.
                container.Dispose();
            }
#else
            if (strings != null && currentFileName != null)
            {
                using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    using (IsolatedStorageFileStream isfs = new IsolatedStorageFileStream(currentFileName, FileMode.Create, isf))
                    {
                        using (StreamWriter writer = new StreamWriter(isfs))
                        {
                            try
                            {
                                int i;
                                for (i = 0; i < strings.size(); i++)
                                {
                                    writer.WriteLine((string)strings.get(i));
                                }
                            }
                            catch (IOException e)
                            {
                                e.GetType();
                            }
                            writer.Flush();
                            writer.Close();
                            writer.Dispose();
                        }
                    }
                    isf.Dispose();
                }
            }
#endif
        }
        int findSection(String sectionName)
        {
            int l;
            String s, s2;
            for (l = 0; l < strings.size(); l++)
            {
                s = (string)strings.get(l);
                if (s[0] == '[')
                {
                    int last = s.LastIndexOf(']');
                    if (last >= 1)
                    {
                        s2 = s.Substring(1, last - 1);
                        if (string.Compare(s2, sectionName, StringComparison.OrdinalIgnoreCase) == 0)
                        {
                            return l;
                        }
                    }
                }
            }
            return -1;
        }
        int findKey(int l, String keyName)
        {
            String s, s2;
            int last;
            for (; l < strings.size(); l++)
            {
                s = (string)strings.get(l);
                if (s[0] == '[')
                {
                    return -1;
                }
                last = s.IndexOf('=');
                if (last >= 0)
                {
                    s2 = s.Substring(0, last);
                    if (string.Compare(s2, keyName) == 0)
                    {
                        return l;
                    }
                }
            }
            return -1;
        }
        public String getPrivateProfileString(String sectionName, String keyName, String defaultString, String fileName)
        {
            loadIni(fileName);

            int l = findSection(sectionName);
            if (l >= 0)
            {
                l = findKey(l + 1, keyName);
                if (l >= 0)
                {
                    String s = (string)strings.get(l);
                    int last = s.IndexOf('=');
                    return s.Substring(last + 1);
                }
            }
            return defaultString;
        }
        public void writePrivateProfileString(String sectionName, String keyName, String name, String fileName)
        {
            loadIni(fileName);

            String s;
            int section = findSection(sectionName);
            if (section < 0)
            {
                s = "[" + sectionName + "]";
                strings.add(s);
                s = keyName + "=" + name;
                strings.add(s);
                return;
            }

            int key = findKey(section + 1, keyName);
            if (key >= 0)
            {
                s = keyName + "=" + name;
                strings.set(key, s);
                return;
            }

            for (key = section + 1; key < strings.size(); key++)
            {
                s = (string)strings.get(key);
                if (s[0] == '[')
                {
                    s = keyName + "=" + name;
                    strings.add(key, s);
                    return;
                }
            }
            s = keyName + "=" + name;
            strings.add(s);
        }
        public void deleteItem(String group, String item, String iniName)
        {
            loadIni(iniName);

            int s = findSection(group);
            if (s >= 0)
            {
                int k = findKey(s + 1, item);
                if (k >= 0)
                {
                    strings.remove(k);
                }
            }
        }
        public void deleteGroup(String group, String iniName)
        {
            loadIni(iniName);

            int s = findSection(group);
            if (s >= 0)
            {
                strings.remove(s);
                while (true)
                {
                    if (s >= strings.size())
                    {
                        break;
                    }
                    if (((string)strings.get(s))[0] == '[')
                    {
                        break;
                    }
                    strings.remove(s);
                }
            }
        }
    }
}
