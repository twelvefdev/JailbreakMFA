// -----------------------------------------------------------------------------
//
// ADD TO DEBUGGER
//
// -----------------------------------------------------------------------------
using System;
using RuntimeXNA.RunLoop;
namespace RuntimeXNA.Actions
{
	
	public class ACT_EXTADDTODEBUGGER:CAct
	{
		public override void  execute(CRun rhPtr)
		{
		}
	}
}