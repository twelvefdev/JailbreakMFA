﻿//----------------------------------------------------------------------------------
//
// IENUM : Interface pour l'enumeration des objets
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RuntimeXNA.Banks
{
    public interface IEnum
    {
        short enumerate(short num);
    }
}
