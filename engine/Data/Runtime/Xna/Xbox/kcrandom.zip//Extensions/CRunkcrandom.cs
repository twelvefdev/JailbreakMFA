﻿//----------------------------------------------------------------------------------
//
// CRunkcrandom: Randomizer object
// fin 26/09/09
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunkcrandom : CRunExtension
    {
        const int CND_RAND_EVENT	=	0;
        const int CND_RAND_EVENT_GROUP	= 1;
        const int CND_RAND_EVENT_GROUP_CUST =	2;
        const int ACT_NEW_SEED	=	0;
        const int ACT_SET_SEED	=	1;
        const int ACT_TRIGGER_RAND_EVENT_GROUP	=	2;
        const int ACT_TRIGGER_RAND_EVENT_GROUP_CUST =	3;
        const int EXP_RANDOM			=		0;
        const int EXP_RANDOM_MIN_MAX		=	1;
        const int EXP_GET_SEED		=		2;
        const int EXP_RANDOM_LETTER		=	3;
        const int EXP_RANDOM_ALPHANUM	=		4;
        const int EXP_RANDOM_CHAR		=		5;
        const int EXP_ASCII_TO_CHAR		=	6;
        const int EXP_CHAR_TO_ASCII		=	7;
        const int EXP_TO_UPPER		=		8;
        const int EXP_TO_LOWER		=		9;

        String currentGroupName;
        int currentPercentMax;
        int currentPosition;
        int currentRandom;
        int globalPercentMax;
        int globalPosition;
        int globalRandom;
        int lastSeed;
        Random rand;

        public override int getNumberOfConditions()
        {
            return 3;
        }
        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            this.lastSeed = newseed();
            return true;
        }
        public int newseed()
        {
            int seed = DateTime.Now.Millisecond;
            rand = new Random(seed);
            return seed;
        }
        public void setseed(int pSeed)
        {
            rand = new Random(pSeed);
        }
        public int random(int max)
        {
            return rand.Next(max);
        }
        public int randommm(int min, int max)
        {
            return rand.Next(min, max);
        }

        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_RAND_EVENT:
                    return RandomEvent(cnd.getParamExpression(rh, 0));
                case CND_RAND_EVENT_GROUP:
                    return RandomEventGroup(cnd.getParamExpression(rh, 0));
                case CND_RAND_EVENT_GROUP_CUST:
                    return RandomEventGroupCustom(cnd.getParamExpString(rh, 0), cnd.getParamExpression(rh, 1));
            }
            return false;//won't happen
        }

        private bool RandomEvent(int p)
        {
            if (random(100) < p)
                return true;
            return false;
        }
        private bool RandomEventGroup(int p)
        {
            globalPosition += p;
            if ((globalRandom >= globalPosition - p) &&
                    (globalRandom < globalPosition))
                return true;
            return false;
        }
        private bool RandomEventGroupCustom(String name, int p)
        {
            if (string.Compare(currentGroupName, name)==0)
            {
                currentPosition += p;
                if ((currentRandom >= currentPosition - p) &&
                    (currentRandom < currentPosition))
                    return true;
            }
            return false;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_NEW_SEED:
                    lastSeed = newseed();
                    break;
                case ACT_SET_SEED:
                    SetSeed(act.getParamExpression(rh, 0));
                    break;
                case ACT_TRIGGER_RAND_EVENT_GROUP:
                    TriggerRandomEventGroup(act.getParamExpression(rh, 0));
                    break;
                case ACT_TRIGGER_RAND_EVENT_GROUP_CUST:
                    TriggerRandomEventGroupCustom(act.getParamExpString(rh, 0), act.getParamExpression(rh, 1));
                    break;
            }
        }

        private void SetSeed(int pSeed)
        {
            lastSeed = pSeed;
            setseed(pSeed);
        }

        private void TriggerRandomEventGroup(int pPercentMax)
        {
            globalPercentMax = pPercentMax;
            if (globalPercentMax <= 0)
            {
                globalPercentMax = 100;
            }
            globalRandom = random(globalPercentMax);
            globalPosition = 0;
            ho.generateEvent(CND_RAND_EVENT_GROUP, ho.getEventParam());
        }

        private void TriggerRandomEventGroupCustom(String name, int pPercentMax)
        {
            int lastPercentMax = currentPercentMax;
            int lastRandom = currentRandom;
            int lastPosition = currentPosition;
            String lastGroupName = currentGroupName;

            currentGroupName = name;
            currentPercentMax = pPercentMax;
            if (currentPercentMax <= 0)
                currentPercentMax = 100;
            currentRandom = random(currentPercentMax);
            currentPosition = 0;
            ho.generateEvent(CND_RAND_EVENT_GROUP_CUST, ho.getEventParam());
            currentPercentMax = lastPercentMax;
            currentRandom = lastRandom;
            currentPosition = lastPosition;
            currentGroupName = lastGroupName;
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_RANDOM:
                    return new CValue(random(ho.getExpParam().getInt()));
                case EXP_RANDOM_MIN_MAX:
                    return new CValue(randommm(ho.getExpParam().getInt(), ho.getExpParam().getInt()));
                case EXP_GET_SEED:
                    return new CValue(lastSeed);
                case EXP_RANDOM_LETTER:
                    return GetRandomLetter();
                case EXP_RANDOM_ALPHANUM:
                    return GetRandomAlphaNum();
                case EXP_RANDOM_CHAR:
                    return GetRandomChar();
                case EXP_ASCII_TO_CHAR:
                    return GetAsciiToChar(ho.getExpParam().getInt());
                case EXP_CHAR_TO_ASCII:
                    return GetCharToAscii(ho.getExpParam().getString());
                case EXP_TO_UPPER:
                    return new CValue(ho.getExpParam().getString().ToUpper());
                case EXP_TO_LOWER:
                    return new CValue(ho.getExpParam().getString().ToLower());
            }
            return new CValue(0);//won't be used
        }

        private CValue GetRandomLetter()
        {
            byte b = (byte)randommm(97, 122);
            String r = new String((char)b, 1);
            return new CValue(r);
        }
        private CValue GetRandomAlphaNum()
        {
            byte b = (byte)random(36);
            if (b < 10)
            {
                b += 48;
            }
            else
            {
                b += 87;
            }
            String r = new String((char)b, 1);
            return new CValue(r);
        }
        private CValue GetRandomChar()
        {
            byte b = (byte)random(256);
            String r = new String((char)b, 1);
            return new CValue(r);
        }
        private CValue GetAsciiToChar(int ascii)
        {
            byte b = (byte)ascii;
            String r = new String((char)b, 1);
            return new CValue(r);
        }
        private CValue GetCharToAscii(String c)
        {
            if (c.Length > 0)
            {
                return new CValue((int)c[0]);
            }
            return new CValue(0);
        }

    }
}
