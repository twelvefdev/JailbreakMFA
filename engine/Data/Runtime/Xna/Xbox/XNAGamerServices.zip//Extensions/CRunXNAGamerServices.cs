//----------------------------------------------------------------------------------
//
// CRUNXNA Edit
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
#if !WINDOWS_PHONE
using Microsoft.Xna.Framework.GamerServices;
#endif
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunXNAGamerServices : CRunExtension
    {
        const int CND_CANPURCHASE=0;
        const int CND_ISCONNECTED=1;
        const int CND_ISSIGNEDIN = 2;
        const int CND_LAST = 3;
        const int ACT_CONNECT=0;
        const int ACT_SHOWMARKETPLACE=1;
        const int ACT_SIGNIN=2;
        const int ACT_SETPRESENCE = 3;
        const int ACT_SETPRESENCEVALUE = 4;
        const int EXP_NSIGNEDIN= 0;
        const int EXP_ALIAS = 1;
        const int EXP_PRESENCE = 2;
        const int EXP_PRESENCEVALUE = 3;


        const int FLAG_CANPURCHASE=0x0001;
        const int FLAG_CONNECTATSTART=0x0002;
        const int FLAG_SIGNINATSTART=0x0004;
        const int FLAG_SIGNINONLINE = 0x0008;

#if !WINDOWS_PHONE
        int flags;
        short signInPanes;
#endif

        public override int getNumberOfConditions()
        {
            return CND_LAST;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
#if !WINDOWS_PHONE
            // Read in edPtr values
            flags = file.readAInt();
            signInPanes = file.readAShort();

            if ((flags & FLAG_CONNECTATSTART) != 0)
            {
                if (GamerServicesDispatcher.IsInitialized == false)
                {
                    flags &= ~FLAG_CONNECTATSTART;
                    GamerServicesDispatcher.WindowHandle = rh.rhApp.game.Window.Handle;
                    GamerServicesDispatcher.Initialize(rh.rhApp.game.Services);
                }
            }
#endif
            return true;
        }

        public override int handleRunObject()
        {
#if !WINDOWS_PHONE
            if ((flags & FLAG_SIGNINATSTART) != 0)
            {
                if (GamerServicesDispatcher.IsInitialized == true && rh.rhApp.bSignedIn==false)
                {
                    flags &= ~FLAG_SIGNINATSTART;
                    Guide.ShowSignIn(signInPanes, (flags & FLAG_SIGNINONLINE) != 0);
                    rh.rhApp.bSignedIn = true;
                }
            }
#endif
            return 0;
        }

        // Conditions
        // --------------------------------------------------
        public override bool condition(int num, CCndExtension cnd)
        {
#if !WINDOWS_PHONE
            switch (num)
            {
                case CND_CANPURCHASE:
                    return cndCanPurchase(cnd);
                case CND_ISCONNECTED:
                    return GamerServicesDispatcher.IsInitialized;
                case CND_ISSIGNEDIN:
                    return cndIsSignedIn();
            }
#endif
            return false;
        }
#if !WINDOWS_PHONE
        bool cndIsSignedIn()
        {
            int n;
            for (n = 1; n <= 4; n++)
            {
                PlayerIndex player = getPlayer(n);
                if (Gamer.SignedInGamers[player] != null)
                {
                    return true;
                }
            }
            return false;
        }

        PlayerIndex getPlayer(int p)
        {
            PlayerIndex player = PlayerIndex.One;
            switch (p)
            {
                case 1:
                    player = PlayerIndex.One;
                    break;
                case 2:
                    player = PlayerIndex.Two;
                    break;
                case 3:
                    player = PlayerIndex.Three;
                    break;
                case 4:
                    player = PlayerIndex.Four;
                    break;
            }
            return player;
        }

        bool cndCanPurchase(CCndExtension cnd)
        {
            int p = cnd.getParamExpression(rh, 0);
            PlayerIndex player = getPlayer(p);

            // Check to see if the user is signed in
            if (Gamer.SignedInGamers[player] != null)
            {
                GamerPrivileges privileges = Gamer.SignedInGamers[player].Privileges;
                return privileges.AllowPurchaseContent;
            }
            return false;
        }
#endif

        // Actions
        // -------------------------------------------------
        public override void action(int num, CActExtension act)
        {
#if !WINDOWS_PHONE
            switch (num)
            {
                case ACT_CONNECT:
                    actConnect();
                    break;
                case ACT_SHOWMARKETPLACE:
                    actShowMarketplace(act);
                    break;
                case ACT_SIGNIN:
                    actSignIn(act);
                    break;
                case ACT_SETPRESENCE:
                    actSetPresence(act);
                    break;
                case ACT_SETPRESENCEVALUE:
                    actSetPresenceValue(act);
                    break;
            }
#endif
        }

#if !WINDOWS_PHONE
        void actConnect()
        {
            if (GamerServicesDispatcher.IsInitialized == false)
            {
                GamerServicesDispatcher.WindowHandle = rh.rhApp.game.Window.Handle;
                GamerServicesDispatcher.Initialize(rh.rhApp.game.Services);
            }
        }
        void actSignIn(CActExtension act)
        {
            int nPanes = act.getParamExpression(rh, 0);
            bool bOnLine = act.getParamExpression(rh, 1) != 0;
            if (GamerServicesDispatcher.IsInitialized == true)
            {
                Guide.ShowSignIn(nPanes, bOnLine);
                rh.rhApp.bSignedIn = cndIsSignedIn();
            }
        }
        void actShowMarketplace(CActExtension act)
        {
            int p = act.getParamExpression(rh, 0);
            PlayerIndex player = getPlayer(p);
            Guide.ShowMarketplace(player);
        }
        void actSetPresence(CActExtension act)
        {
            int param1 = act.getParamExpression(rh, 0);
            string param2 = act.getParamExpString(rh, 1);

            int n;
            for (n = 0; names[n] != ""; n++)
                if (names[n] == param2)
                    break;

            if (names[n] != "")
            {
                PlayerIndex player = getPlayer(param1);
                SignedInGamer gamer = Gamer.SignedInGamers[player];
                if (gamer != null)
                {
                    gamer.Presence.PresenceMode = modes[n];
                }
            }
        }
        void actSetPresenceValue(CActExtension act)
        {
            int param1 = act.getParamExpression(rh, 0);
            int param2 = act.getParamExpression(rh, 1);
            PlayerIndex player = getPlayer(param1);
            SignedInGamer gamer = Gamer.SignedInGamers[player];
            if (gamer != null)
            {
                gamer.Presence.PresenceValue = param2;
            }
        }
#endif
        // Expressions
        // --------------------------------------------
        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_NSIGNEDIN:
                    return expNSignedIn();
                case EXP_ALIAS:
                    return expAlias();
                case EXP_PRESENCE:
                    return expPresence();
                case EXP_PRESENCEVALUE:
                    return expPresenceValue();
            }
            return new CValue(0);
        }
#if !WINDOWS_PHONE
        static GamerPresenceMode[] modes =
        {
            GamerPresenceMode.ArcadeMode,
            GamerPresenceMode.AtMenu,
            GamerPresenceMode.BattlingBoss,
            GamerPresenceMode.CampaignMode,
            GamerPresenceMode.ChallengeMode,
            GamerPresenceMode.ConfiguringSettings,
            GamerPresenceMode.CoOpLevel,
            GamerPresenceMode.CoOpStage,
            GamerPresenceMode.CornflowerBlue,
            GamerPresenceMode.CustomizingPlayer,
            GamerPresenceMode.DifficultyEasy,
            GamerPresenceMode.DifficultyExtreme,
            GamerPresenceMode.DifficultyHard,
            GamerPresenceMode.DifficultyMedium,
            GamerPresenceMode.EditingLevel,
            GamerPresenceMode.ExplorationMode,
            GamerPresenceMode.FoundSecret,
            GamerPresenceMode.FreePlay,
            GamerPresenceMode.GameOver,
            GamerPresenceMode.InCombat,
            GamerPresenceMode.InGameStore,
            GamerPresenceMode.Level,
            GamerPresenceMode.LocalCoOp,
            GamerPresenceMode.LocalVersus,
            GamerPresenceMode.LookingForGames,
            GamerPresenceMode.Losing,
            GamerPresenceMode.Multiplayer,
            GamerPresenceMode.NearlyFinished,
            GamerPresenceMode.None,
            GamerPresenceMode.OnARoll,
            GamerPresenceMode.OnlineCoOp,
            GamerPresenceMode.OnlineVersus,
            GamerPresenceMode.Outnumbered,
            GamerPresenceMode.Paused,
            GamerPresenceMode.PlayingMinigame,
            GamerPresenceMode.PlayingWithFriends,
            GamerPresenceMode.PracticeMode,
            GamerPresenceMode.PuzzleMode,
            GamerPresenceMode.ScenarioMode,
            GamerPresenceMode.Score,
            GamerPresenceMode.ScoreIsTied,
            GamerPresenceMode.SettingUpMatch,
            GamerPresenceMode.SinglePlayer,
            GamerPresenceMode.Stage,
            GamerPresenceMode.StartingGame,
            GamerPresenceMode.StoryMode,
            GamerPresenceMode.StuckOnAHardBit,
            GamerPresenceMode.SurvivalMode,
            GamerPresenceMode.TimeAttack,
            GamerPresenceMode.TryingForRecord,
            GamerPresenceMode.TutorialMode,
            GamerPresenceMode.VersusComputer,
            GamerPresenceMode.VersusScore,
            GamerPresenceMode.WaitingForPlayers,
            GamerPresenceMode.WaitingInLobby,
            GamerPresenceMode.WastingTime,
            GamerPresenceMode.WatchingCredits,
            GamerPresenceMode.WatchingCutscene,
            GamerPresenceMode.Winning,
            GamerPresenceMode.WonTheGame,
            0};
        static string[] names =
        {
            "ArcadeMode",
            "AtMenu",
            "BattlingBoss",
            "CampaignMode",
            "ChallengeMode",
            "ConfiguringSettings",
            "CoOpLevel",
            "CoOpStage",
            "CornflowerBlue",
            "CustomizingPlayer",
            "DifficultyEasy",
            "DifficultyExtreme",
            "DifficultyHard",
            "DifficultyMedium",
            "EditingLevel",
            "ExplorationMode",
            "FoundSecret",
            "FreePlay",
            "GameOver",
            "InCombat",
            "InGameStore",
            "Level",
            "LocalCoOp",
            "LocalVersus",
            "LookingForGames",
            "Losing",
            "Multiplayer",
            "NearlyFinished",
            "None",
            "OnARoll",
            "OnlineCoOp",
            "OnlineVersus",
            "Outnumbered",
            "Paused",
            "PlayingMinigame",
            "PlayingWithFriends",
            "PracticeMode",
            "PuzzleMode",
            "ScenarioMode",
            "Score",
            "ScoreIsTied",
            "SettingUpMatch",
            "SinglePlayer",
            "Stage",
            "StartingGame",
            "StoryMode",
            "StuckOnAHardBit",
            "SurvivalMode",
            "TimeAttack",
            "TryingForRecord",
            "TutorialMode",
            "VersusComputer",
            "VersusScore",
            "WaitingForPlayers",
            "WaitingInLobby",
            "WastingTime",
            "WatchingCredits",
            "WatchingCutscene",
            "Winning",
            "WonTheGame",
            ""};
#endif

        CValue expPresence()
        {
#if !WINDOWS_PHONE
            int index = ho.getExpParam().getInt();
            PlayerIndex player = getPlayer(index);
            SignedInGamer gamer = Gamer.SignedInGamers[player];
            if (gamer != null)
            {
                GamerPresenceMode gp=gamer.Presence.PresenceMode;
                int n;
                GamerPresenceMode end = 0;
                for (n = 0; modes[n]!=end; n++)
                {
                    if (gp == modes[n]) 
                    {
                        return new CValue(names[n]);
                    }
                }
            }
#endif
            return new CValue("");
        }

        CValue expPresenceValue()
        {
#if !WINDOWS_PHONE
            int index = ho.getExpParam().getInt();
            PlayerIndex player = getPlayer(index);
            SignedInGamer gamer = Gamer.SignedInGamers[player];
            if (gamer != null)
            {
                return new CValue(gamer.Presence.PresenceValue);
            }
#endif
            return new CValue(0);
        }


        CValue expNSignedIn()
        {
#if !WINDOWS_PHONE
            int n;
            int count = 0;
            for (n = 1; n <= 4; n++)
            {
                PlayerIndex player = getPlayer(n);
                if (Gamer.SignedInGamers[player] != null)
                {
                    count++;
                }
            }
            return new CValue(count);
#else
            return new CValue(0);
#endif
        }
        CValue expAlias()
        {
#if !WINDOWS_PHONE
            int index = ho.getExpParam().getInt();
            PlayerIndex player = getPlayer(index);
            SignedInGamer gamer = Gamer.SignedInGamers[player];
            if (gamer != null)
            {
                return new CValue(gamer.Gamertag);
            }
            return new CValue("");
#else
            ho.getExpParam().getInt();
            return new CValue("");
#endif
        }

    }
}
