﻿//----------------------------------------------------------------------------------
//
// CRUNMVTINANDOUT : Movement inandout!
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Movements;
using RuntimeXNA.Services;
using RuntimeXNA.Objects;
using RuntimeXNA.Animations;
using RuntimeXNA.Sprites;
using RuntimeXNA.Application;

namespace RuntimeXNA.Movements
{
    class CRunMvtinandout : CRunMvtExtension
    {
	    const int MOVESTATUS_PREPAREOUT=0;
        const int MOVESTATUS_MOVEOUT=1;
	    const int MOVESTATUS_WAITOUT=2;
	    const int MOVESTATUS_PREPAREIN=3;
	    const int MOVESTATUS_MOVEIN=4;
	    const int MOVESTATUS_WAITIN=5;
	    const int MOVESTATUS_POSITIONIN=6;
	    const int MOVESTATUS_POSITIONOUT=7;
	    const int ACTION_POSITIONIN=0;
	    const int ACTION_POSITIONOUT=1;
	    const int ACTION_MOVEIN=2;
	    const int ACTION_MOVEOUT=3;
	    const int MFLAG_OUTATSTART=0x00000001;
	    const int MFLAG_MOVEATSTART=0x00000002;
	    const int MFLAG_STOPPED=0x00000004;
	    const int MOVETYPE_LINEAR=0;
	    const int MOVETYPE_SMOOTH=1;

	    int m_direction;
	    int m_speed;
	    int m_flags;
	    int	m_moveStatus;
	    double	m_angle;
	    double	m_maxPente;
	    long m_moveTimerStart;
	    long m_stopTimer;
	    int	m_type;
	    int	m_startX;
	    int	m_startY;
	    int	m_destX;
	    int	m_destY;

        public override void initialize(CFile file)
        {
            file.skipBytes(1);
            m_type = file.readAInt();
            m_direction = file.readAInt();
            m_speed = file.readAInt();
            m_flags = file.readAInt();
            m_destX = file.readAInt();
            m_destY = file.readAInt();
            m_angle = (m_direction * Math.PI) / 180.0;
            m_maxPente = 0;

            if ((m_flags & MFLAG_MOVEATSTART) != 0)
            {
                if ((m_flags & MFLAG_OUTATSTART) == 0)
                {
                    m_moveStatus = MOVESTATUS_PREPAREOUT;
                }
                else
                {
                    m_moveStatus = MOVESTATUS_PREPAREIN;
                }
                m_flags &= ~MFLAG_STOPPED;
            }
            else
            {
                if ((m_flags & MFLAG_OUTATSTART) == 0)
                {
                    m_moveStatus = MOVESTATUS_WAITIN;
                }
                else
                {
                    m_moveStatus = MOVESTATUS_WAITOUT;
                }
            }
        }

        public override bool move()
        {
            // Calcule la position de sortie
            if (m_maxPente == 0)
            {
                double maxPente;
                int x = 0, y = 0, rightX, bottomY;
                m_startX = ho.hoX;
                m_startY = ho.hoY;

                if (m_destX != 0 || m_destY != 0)
                {
                    int vX = m_destX - m_startX;
                    int vY = m_destY - m_startY;
                    maxPente = Math.Sqrt(vX * vX + vY * vY);
                    if (maxPente == 0.0)
                    {
                        m_angle = 0.0;
                    }
                    else
                    {
                        m_angle = Math.Acos(vX / maxPente);
                        if (m_destY > m_startY)
                        {
                            m_angle = 2.0 * Math.PI - m_angle;
                        }
                    }
                }
                else
                {
                    for (maxPente = 0; maxPente < 100000; maxPente += 5)
                    {
                        x = (int)(Math.Cos(m_angle) * maxPente + m_startX);
                        y = (int)(-Math.Sin(m_angle) * maxPente + m_startY);
                        rightX = x + ho.hoImgWidth;
                        bottomY = y + ho.hoImgHeight;
                        if (x > ho.hoAdRunHeader.rhLevelSx)
                        {
                            break;
                        }
                        if (y > ho.hoAdRunHeader.rhLevelSy)
                        {
                            break;
                        }
                        if (rightX < 0)
                        {
                            break;
                        }
                        if (bottomY < 0)
                        {
                            break;
                        }
                    }
                    m_destX = x;
                    m_destY = y;
                }
                if (maxPente == 0)
                {
                    maxPente = 5;
                }
                m_maxPente = maxPente;
            }

            bool bRet = false;
            if ((m_flags & MFLAG_OUTATSTART) != 0)
            {
                m_flags &= ~MFLAG_OUTATSTART;
                ho.hoX = m_destX;
                ho.hoY = m_destY;
                bRet = true;
            }

            // Stopped?
            if ((m_flags & MFLAG_STOPPED) != 0)
            {
                animations(CAnim.ANIMID_STOP);
                collisions();
                return ho.roc.rcChanged;
            }

            switch (m_moveStatus)
            {
                case MOVESTATUS_PREPAREOUT:
                    ho.hoX = m_startX;
                    ho.hoY = m_startY;
                    m_moveTimerStart = ho.hoAdRunHeader.rhTimer;
                    m_moveStatus = MOVESTATUS_MOVEOUT;
                    break;
                case MOVESTATUS_MOVEOUT:
                    {
                        int deltaTime = (int)(ho.hoAdRunHeader.rhTimer - m_moveTimerStart);
                        if (deltaTime >= m_speed)
                        {
                            ho.hoX = m_destX;
                            ho.hoY = m_destY;
                            m_moveStatus = MOVESTATUS_WAITOUT;
                        }
                        else
                        {
                            switch (m_type)
                            {
                                case MOVETYPE_LINEAR:
                                    {
                                        double pente = (m_maxPente * ((double)deltaTime / (double)m_speed));
                                        ho.hoX = (int)(Math.Cos(m_angle) * pente + m_startX);
                                        ho.hoY = (int)(-Math.Sin(m_angle) * pente + m_startY);
                                    }
                                    break;
                                case MOVETYPE_SMOOTH:
                                    {
                                        double pente = m_maxPente - Math.Cos(Math.PI / 2 * ((double)deltaTime / (double)m_speed)) * m_maxPente;
                                        ho.hoX = (int)(Math.Cos(m_angle) * pente + m_startX);
                                        ho.hoY = (int)(-Math.Sin(m_angle) * pente + m_startY);
                                    }
                                    break;
                            }
                        }
                        ho.roc.rcDir = (int)((m_direction * 32) / 360);
                        ho.roc.rcSpeed = 100;
                        animations(CAnim.ANIMID_WALK);
                        bRet = true;
                    }
                    break;
                case MOVESTATUS_WAITOUT:
                    animations(CAnim.ANIMID_STOP);
                    bRet = true;
                    break;
                case MOVESTATUS_POSITIONOUT:
                    ho.hoX = m_destX;
                    ho.hoY = m_destY;
                    m_moveStatus = MOVESTATUS_WAITOUT;
                    bRet = true;
                    break;
                case MOVESTATUS_PREPAREIN:
                    ho.hoX = m_destX;
                    ho.hoY = m_destY;
                    m_moveTimerStart = ho.hoAdRunHeader.rhTimer;
                    m_moveStatus = MOVESTATUS_MOVEIN;
                    break;
                case MOVESTATUS_MOVEIN:
                    {
                        int deltaTime = (int)(ho.hoAdRunHeader.rhTimer - m_moveTimerStart);
                        if (deltaTime >= m_speed)
                        {
                            ho.hoX = m_startX;
                            ho.hoY = m_startY;
                            m_moveStatus = MOVESTATUS_WAITIN;
                        }
                        else
                        {
                            switch (m_type)
                            {
                                case MOVETYPE_LINEAR:
                                    {
                                        double pente = (m_maxPente - (m_maxPente * ((double)deltaTime / (double)m_speed)));
                                        ho.hoX = (int)(Math.Cos(m_angle) * pente + m_startX);
                                        ho.hoY = (int)(-Math.Sin(m_angle) * pente + m_startY);
                                    }
                                    break;
                                case MOVETYPE_SMOOTH:
                                    {
                                        double pente = m_maxPente - Math.Sin(Math.PI / 2 * ((double)deltaTime / (double)m_speed)) * m_maxPente;
                                        ho.hoX = (int)(Math.Cos(m_angle) * pente + m_startX);
                                        ho.hoY = (int)(-Math.Sin(m_angle) * pente + m_startY);
                                    }
                                    break;
                            }
                        }
                        ho.roc.rcDir = ((int)((m_direction * 32) / 360 + 16)) % 32;
                        ho.roc.rcSpeed = 100;
                        animations(CAnim.ANIMID_WALK);
                        bRet = true;
                    }
                    break;
                case MOVESTATUS_WAITIN:
                    animations(CAnim.ANIMID_STOP);
                    bRet = true;
                    break;
                case MOVESTATUS_POSITIONIN:
                    ho.hoX = m_startX;
                    ho.hoY = m_startY;
                    m_moveStatus = MOVESTATUS_WAITIN;
                    bRet = true;
                    break;
            }

            // detects the collisions
            collisions();

            // The object has been moved
            return bRet;
        }

        public override void stop(bool bCurrent)
        {
            m_flags |= MFLAG_STOPPED;
            m_stopTimer = ho.hoAdRunHeader.rhTimer;
        }

        public override void start()
        {
            if ((m_flags & MFLAG_STOPPED) != 0)
            {
                m_flags &= ~MFLAG_STOPPED;
                m_moveTimerStart += ho.hoAdRunHeader.rhTimer - m_stopTimer;
            }
            if (m_moveStatus == MOVESTATUS_WAITOUT)
            {
                m_moveStatus = MOVESTATUS_PREPAREIN;
            }
            else if (m_moveStatus == MOVESTATUS_WAITIN)
            {
                m_moveStatus = MOVESTATUS_PREPAREOUT;
            }
        }

        public override double actionEntry(int action)
        {
            switch (action)
            {
                case ACTION_POSITIONIN:
                    m_moveStatus = MOVESTATUS_POSITIONIN;
                    m_flags &= ~MFLAG_STOPPED;
                    break;
                case ACTION_POSITIONOUT:
                    m_moveStatus = MOVESTATUS_POSITIONOUT;
                    m_flags &= ~MFLAG_STOPPED;
                    break;
                case ACTION_MOVEIN:
                    m_moveStatus = MOVESTATUS_PREPAREIN;
                    m_flags &= ~MFLAG_STOPPED;
                    break;
                case ACTION_MOVEOUT:
                    m_moveStatus = MOVESTATUS_PREPAREOUT;
                    m_flags &= ~MFLAG_STOPPED;
                    break;
                default:
                    break;
            }
            return 0;
        }

        public override int getSpeed()
        {
            return ho.roc.rcSpeed;
        }

    }
}
