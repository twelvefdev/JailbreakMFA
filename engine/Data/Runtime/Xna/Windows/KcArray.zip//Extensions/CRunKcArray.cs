﻿//----------------------------------------------------------------------------------
//
// CRunKcArray: array object
//
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework;
#if !WINDOWS_PHONE
using Microsoft.Xna.Framework.Storage;
#else
using System.IO.IsolatedStorage;
#endif
using Microsoft.Xna.Framework.GamerServices;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunKcArray : CRunExtension
    {
        const int ARRAY_GLOBAL = 0x0008;
        const int ARRAY_TYPENUM = 0x0001;
        const int ARRAY_TYPETXT = 0x0002;
        const int INDEX_BASE1 = 0x0004;

        const int CND_INDEXAEND = 0;
        const int CND_INDEXBEND = 1;
        const int CND_INDEXCEND = 2;
        const int ACT_SETINDEXA = 0;
        const int ACT_SETINDEXB = 1;
        const int ACT_SETINDEXC = 2;
        const int ACT_ADDINDEXA = 3;
        const int ACT_ADDINDEXB = 4;
        const int ACT_ADDINDEXC = 5;
        const int ACT_WRITEVALUE = 6;
        const int ACT_WRITESTRING = 7;
        const int ACT_CLEARARRAY = 8;
        const int ACT_LOAD = 9;
        const int ACT_LOADSELECTOR = 10;
        const int ACT_SAVE = 11;
        const int ACT_SAVESELECTOR = 12;
        const int ACT_WRITEVALUE_X = 13;
        const int ACT_WRITEVALUE_XY = 14;
        const int ACT_WRITEVALUE_XYZ = 15;
        const int ACT_WRITESTRING_X = 16;
        const int ACT_WRITESTRING_XY = 17;
        const int ACT_WRITESTRING_XYZ = 18;
        const int EXP_INDEXA = 0;
        const int EXP_INDEXB = 1;
        const int EXP_INDEXC = 2;
        const int EXP_READVALUE = 3;
        const int EXP_READSTRING = 4;
        const int EXP_READVALUE_X = 5;
        const int EXP_READVALUE_XY = 6;
        const int EXP_READVALUE_XYZ = 7;
        const int EXP_READSTRING_X = 8;
        const int EXP_READSTRING_XY = 9;
        const int EXP_READSTRING_XYZ = 10;
        const int EXP_DIMX = 11;
        const int EXP_DIMY = 12;
        const int EXP_DIMZ = 13;

        public KcArrayData pArray;
        public bool bDeviceOK = false;
#if !WINDOWS_PHONE
        Object stateobj;
#endif

        public override int getNumberOfConditions()
        {
            return 3;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            CRun rhPtr = this.ho.hoAdRunHeader;

            int lDimensionX = file.readAInt();
            int lDimensionY = file.readAInt();
            int lDimensionZ = file.readAInt();
            int lFlags = file.readAInt();

            KcArrayCGlobalDataList pData = null;
            if ((lFlags & ARRAY_GLOBAL) != 0)
            {
                CExtStorage pExtData = rhPtr.getStorage(ho.hoIdentifier);
                if (pExtData == null) //first global object of this type
                {
                    pArray = new KcArrayData(lFlags, lDimensionX, lDimensionY, lDimensionZ);
                    pData = new KcArrayCGlobalDataList();
                    pData.AddObject(this);
                    rhPtr.addStorage(pData, ho.hoIdentifier);
                }
                else
                {
                    pData = (KcArrayCGlobalDataList)pExtData;
                    KcArrayData found = pData.FindObject(ho.hoOiList.oilName);
                    if (found != null) //found array object of same name
                    {
                        pArray = found; //share data
                    }
                    else
                    {
                        pArray = new KcArrayData(lFlags, lDimensionX, lDimensionY, lDimensionZ);
                        pData.AddObject(this);
                    }
                }
            }
            else
            {
                pArray = new KcArrayData(lFlags, lDimensionX, lDimensionY, lDimensionZ);
            }
            return true;
        }

        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_INDEXAEND:
                    return EndIndexA();
                case CND_INDEXBEND:
                    return EndIndexB();
                case CND_INDEXCEND:
                    return EndIndexC();
            }
            return false;
        }

        private bool EndIndexA()
        {
            if (pArray.lIndexA >= pArray.lDimensionX - 1)
            {
                return true;
            }
            return false;
        }

        private bool EndIndexB()
        {
            if (pArray.lIndexB >= pArray.lDimensionY - 1)
            {
                return true;
            }
            return false;
        }
        private bool EndIndexC()
        {
            if (pArray.lIndexC >= pArray.lDimensionZ - 1)
            {
                return true;
            }
            return false;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_SETINDEXA:
                    SetIndexA(act.getParamExpression(rh, 0));
                    break;
                case ACT_SETINDEXB:
                    SetIndexB(act.getParamExpression(rh, 0));
                    break;
                case ACT_SETINDEXC:
                    SetIndexC(act.getParamExpression(rh, 0));
                    break;
                case ACT_ADDINDEXA:
                    IncIndexA();
                    break;
                case ACT_ADDINDEXB:
                    IncIndexB();
                    break;
                case ACT_ADDINDEXC:
                    IncIndexC();
                    break;
                case ACT_WRITEVALUE:
                    WriteValue(act.getParamExpression(rh, 0));
                    break;
                case ACT_WRITESTRING:
                    WriteString(act.getParamExpString(rh, 0));
                    break;
                case ACT_CLEARARRAY:
                    ClearArray();
                    break;
                case ACT_LOAD:
                    ActLoad(act);
                    break;
                case ACT_LOADSELECTOR:
                    break;
                case ACT_SAVE:
                    ActSave(act);
                    break;
                case ACT_SAVESELECTOR:
                    break;
                case ACT_WRITEVALUE_X:
	                WriteValue_X(act.getParamExpression(rh, 0),
	                        act.getParamExpression(rh, 1));
                    break;
                case ACT_WRITEVALUE_XY:
	                WriteValue_XY(act.getParamExpression(rh, 0),
	                        act.getParamExpression(rh, 1),
	                        act.getParamExpression(rh, 2));
                    break;
                case ACT_WRITEVALUE_XYZ:
	                WriteValue_XYZ(act.getParamExpression(rh, 0),
	                        act.getParamExpression(rh, 1),
	                        act.getParamExpression(rh, 2),
	                        act.getParamExpression(rh, 3));
                    break;
                case ACT_WRITESTRING_X:
	                WriteString_X(act.getParamExpString(rh, 0),
	                        act.getParamExpression(rh, 1));
                    break;
                case ACT_WRITESTRING_XY:
	                WriteString_XY(act.getParamExpString(rh, 0),
	                        act.getParamExpression(rh, 1),
	                        act.getParamExpression(rh, 2));
                    break;
                case ACT_WRITESTRING_XYZ:
	                WriteString_XYZ(act.getParamExpString(rh, 0),
	                        act.getParamExpression(rh, 1),
	                        act.getParamExpression(rh, 2),
	                        act.getParamExpression(rh, 3));
                    break;
            }
        }

        string cleanName(string name)
        {
            int pos = name.LastIndexOf('\\');
            if (pos < 0)
            {
                pos = name.LastIndexOf('/');
            }
            if (pos >= 0 && pos + 1 < name.Length)
            {
                name = name.Substring(pos + 1);
            }
            return name;
        }
        public CFile loadFromProject(string name)
        {
            CFile cfile = null;
            CEmbeddedFile efile = rh.rhApp.getEmbeddedFile(name);
            if (efile!=null)
            {
                cfile = efile.open();
            }
            if (cfile==null)
            {
                int pos = name.LastIndexOf('.');
                if (pos >= 0)
                {
                    name = name.Substring(0, pos);
                }
                BinaryRead.Data iniFile = null;
                try
                {
                    iniFile = rh.rhApp.content.Load<BinaryRead.Data>(name);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
                if (iniFile != null)
                {
                    cfile = new CFile(iniFile.data);
                }
            }
            return cfile;
        }
#if !WINDOWS_PHONE
        void GetDevice(IAsyncResult result)
        {
            ho.hoAdRunHeader.rhApp.storageDevice = StorageDevice.EndShowSelector(result);
            if (ho.hoAdRunHeader.rhApp.storageDevice != null && ho.hoAdRunHeader.rhApp.storageDevice.IsConnected)
            {
                bDeviceOK = true;
            }
        }
#endif
        private CFile GetCFile(string path)
        {
            CFile cFile=null;

#if !WINDOWS_PHONE
            // Opens a StorageDevice
            bDeviceOK = ho.hoAdRunHeader.rhApp.storageDevice.IsConnected;
            if (ho.hoAdRunHeader.rhApp.storageDevice == null || (ho.hoAdRunHeader.rhApp.storageDevice != null && bDeviceOK == false))
            {
                stateobj = (Object)"Please choose a device";
                try
                {
                    StorageDevice.BeginShowSelector(rh.deviceSelectorPlayer, this.GetDevice, stateobj);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
            }
            if (bDeviceOK)
            {
                // Open a storage container.
                IAsyncResult result = ho.hoAdRunHeader.rhApp.storageDevice.BeginOpenContainer(ho.hoAdRunHeader.rhApp.appName, null, null);

                // Wait for the WaitHandle to become signaled.
                result.AsyncWaitHandle.WaitOne();

                StorageContainer container = ho.hoAdRunHeader.rhApp.storageDevice.EndOpenContainer(result);

                // Close the wait handle.
                result.AsyncWaitHandle.Close();

                // Check to see whether the save exists.
                if (!container.FileExists(path))
                {
                    // If not, dispose of the container and return.
                    container.Dispose();
                    return loadFromProject(path);
                }

                // Open the file.
                Stream stream = container.OpenFile(path, FileMode.Open);
                int length=(int)stream.Length;
                byte[] data=new byte[length];
                try
                {
                    stream.Read(data, 0, length);
                }
                catch (IOException e)
                {
                    e.GetType();
                }
                stream.Close();
                stream.Dispose();
                container.Dispose();
                cFile=new CFile(data);
            }
#else
            using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (isf.FileExists(path))
                {
                    using (IsolatedStorageFileStream isfs = new IsolatedStorageFileStream(path, FileMode.Open, isf))
                    {
                        using (BinaryReader reader = new BinaryReader(isfs))
                        {
                            int length=(int)reader.BaseStream.Length;
                            byte[] data=new byte[length];
                            try
                            {
                                reader.Read(data, 0, length);
                            }
                            catch (IOException e)
                            {
                                e.GetType();
                            }
                            reader.Close();
                            reader.Dispose();
                            cFile=new CFile(data);
                        }
                    }
                }
                else
                {
                    loadFromProject(path);
                }
                isf.Dispose();
            } 
#endif
            return cFile;
        }
        private void ActLoad(CActExtension act)
        {
            string path = cleanName(act.getParamFilename(rh, 0));
            CFile file = GetCFile(path);
            if (file!=null)
            {
                string header=file.readAString(9);
                if (header=="CNC ARRAY")
                {
                    file.skipBytes(1);
                    short version = file.readAShort();
                    short revision = file.readAShort();
                    if (((version == 1) || (version == 2)) && (revision == 0))
                    {
                        int dimX = file.readAInt();
                        int dimY = file.readAInt();
                        int dimZ = file.readAInt();
                        int flags = file.readAInt();
                        if ((dimX >= 0) && (dimY >= 0) && (dimZ >= 0))
                        {
                            pArray=new KcArrayData(flags, dimX, dimY, dimZ);
                            if ((flags & ARRAY_TYPENUM) != 0)
                            {
                                for (int z = 0; z < dimZ; z++)
                                {
                                    for (int y = 0; y < dimY; y++)
                                    {
                                        for (int x = 0; x < dimX; x++)
                                        {
                                            pArray.numberArray[z * pArray.lDimensionY * pArray.lDimensionX + y * pArray.lDimensionX + x] = file.readAInt();
                                        }
                                    }
                                }
                            }
                            else if ((flags & ARRAY_TYPETXT) != 0)
                            {
                                for (int z = 0; z < dimZ; z++)
                                {
                                    for (int y = 0; y < dimY; y++)
                                    {
                                        for (int x = 0; x < dimX; x++)
                                        {
                                            int length = file.readAInt();
                                            if (length>0)
                                            {
                                                pArray.stringArray[z * pArray.lDimensionY * pArray.lDimensionX + y * pArray.lDimensionX + x] = file.readAString(length);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        private void WriteAString(BinaryWriter stream, string text)
        {
            int l=text.Length;
            int n;
            byte[] data=new byte[l];
            for (n=0; n<l; n++)
            {
                data[n]=(byte)text[n];
            }
            try
            {
                stream.Write(data, 0, l);
            }
            catch (IOException e)
            {
                e.GetType();
            }
        }
        private void WriteAByte(BinaryWriter stream, byte value)
        {
            byte[] data = new byte[1];
            data[0] = value;
            try
            {
                stream.Write(data, 0, 1);
            }
            catch (IOException e)
            {
                e.GetType();
            }
        }
        private void WriteAShort(BinaryWriter stream, short value)
        {
            byte[] data=new byte[2];
            data[0]=(byte)(value&255);
            data[1]=(byte)(value>>8);
            try
            {
                stream.Write(data, 0, 2);
            }
            catch (IOException e)
            {
                e.GetType();
            }
        }
        private void WriteAnInt(BinaryWriter stream, int value)
        {
            byte[] data=new byte[4];
            data[0]=(byte)(value&255);
            data[1]=(byte)((value>>8)&255);
            data[2]=(byte)((value>>16)&255);
            data[3]=(byte)((value>>24)&255);
            try
            {
                stream.Write(data, 0, 4);
            }
            catch (IOException e)
            {
                e.GetType();
            }
        }
        private void WriteArray(BinaryWriter stream)
        {
            WriteAString(stream, "CNC ARRAY");
            WriteAByte(stream, 0);
            WriteAShort(stream, (short)2);//version
            WriteAShort(stream, (short)0);//revision
            WriteAnInt(stream, pArray.lDimensionX);
            WriteAnInt(stream, pArray.lDimensionY);
            WriteAnInt(stream, pArray.lDimensionZ);
            WriteAnInt(stream, pArray.lFlags);
            if ((pArray.lFlags & ARRAY_TYPENUM) != 0)
            {
                //reverse loop order for save
                for (int z = 0; z < pArray.lDimensionZ; z++)
                {
                    for (int y = 0; y < pArray.lDimensionY; y++)
                    {
                        for (int x = 0; x < pArray.lDimensionX; x++)
                        {
                            WriteAnInt(stream, pArray.numberArray[z * pArray.lDimensionY * pArray.lDimensionX + y * pArray.lDimensionX + x]);
                        }
                    }
                }
            }
            else if ((pArray.lFlags & ARRAY_TYPETXT) != 0)
            {
                //reverse loop order for save
                for (int z = 0; z < pArray.lDimensionZ; z++)
                {
                    for (int y = 0; y < pArray.lDimensionY; y++)
                    {
                        for (int x = 0; x < pArray.lDimensionX; x++)
                        {
                            string g = pArray.stringArray[z * pArray.lDimensionY * pArray.lDimensionX + y * pArray.lDimensionX + x];
                            if (g == null)
                            {
                                WriteAnInt(stream, 0);
                            }
                            else
                            {
                                WriteAnInt(stream, g.Length);
                                if (g.Length > 0)
                                {
                                    WriteAString(stream, g);
                                }
                            }
                        }
                    }
                }
            }
        }
        private void ActSave(CActExtension act)
        {
            string path = cleanName(act.getParamFilename(rh, 0));
#if !WINDOWS_PHONE
            // Opens a StorageDevice
            bDeviceOK = ho.hoAdRunHeader.rhApp.storageDevice.IsConnected;
            if (ho.hoAdRunHeader.rhApp.storageDevice == null || (ho.hoAdRunHeader.rhApp.storageDevice != null && bDeviceOK == false))
            {
                stateobj = (Object)"Please choose a device";
                try
                {
                    StorageDevice.BeginShowSelector(rh.deviceSelectorPlayer, this.GetDevice, stateobj);
                }
                catch (Exception e)
                {
                    e.GetType();
                }
            }
            if (bDeviceOK)
            {
                // Open a storage container.
                IAsyncResult result = ho.hoAdRunHeader.rhApp.storageDevice.BeginOpenContainer(ho.hoAdRunHeader.rhApp.appName, null, null);

                // Wait for the WaitHandle to become signaled.
                result.AsyncWaitHandle.WaitOne();

                StorageContainer container = ho.hoAdRunHeader.rhApp.storageDevice.EndOpenContainer(result);

                // Close the wait handle.
                result.AsyncWaitHandle.Close();

                // Create a new file.
                if (!container.FileExists(path))
                {
                    container.DeleteFile(path);
                }
                Stream stream = container.CreateFile(path);
                BinaryWriter writer = new BinaryWriter(stream);
                WriteArray(writer);
                writer.Flush();
                writer.Close();
                writer.Dispose();
                container.Dispose();
            }
#else
            if (path != null)
            {
                using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    using (IsolatedStorageFileStream isfs = new IsolatedStorageFileStream(path, FileMode.Create, isf))
                    {
                        using (BinaryWriter writer = new BinaryWriter(isfs))
                        {
                            WriteArray(writer);
                            writer.Flush();
                            writer.Close();
                            writer.Dispose();
                        }
                    }
                    isf.Dispose();
                }
            }
#endif


        }
        private void SetIndexA(int i)
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                pArray.lIndexA = i - 1;
            }
            else
            {
                pArray.lIndexA = i;
            }
        }
        private void SetIndexB(int i)
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                pArray.lIndexB = i - 1;
            }
            else
            {
                pArray.lIndexB = i;
            }
        }
        private void SetIndexC(int i)
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                pArray.lIndexC = i - 1;
            }
            else
            {
                pArray.lIndexC = i;
            }
        }
        private void IncIndexA()
        {
            pArray.lIndexA++;
        }

        private void IncIndexB()
        {
            pArray.lIndexB++;
        }
        private void IncIndexC()
        {
            pArray.lIndexC++;
        }
        private void WriteValue(int value)
        {
            WriteValueXYZ(value, pArray.lIndexA, pArray.lIndexB, pArray.lIndexC);
        }
        private void WriteString(String value)
        {
            WriteStringXYZ(value, pArray.lIndexA, pArray.lIndexB, pArray.lIndexC);
        }
        private void ClearArray()
        {
            pArray.Clean();
        }
        private void WriteValue_X(int value, int x)
        {
            x -= pArray.oneBased();
            WriteValueXYZ(value, x, pArray.lIndexB, pArray.lIndexC);
        }
        private void WriteValue_XY(int value, int x, int y)
        {
            x -= pArray.oneBased();
            y -= pArray.oneBased();
            WriteValueXYZ(value, x, y, pArray.lIndexC);
        }
        private void WriteValue_XYZ(int value, int x, int y, int z)
        {
            x -= pArray.oneBased();
            y -= pArray.oneBased();
            z -= pArray.oneBased();
            WriteValueXYZ(value, x, y, z);
        }
        private void WriteValueXYZ(int value, int x, int y, int z)
        {
            //x,y,z should be fixed for 1-based index if used before this function
            if ((x < 0) || (y < 0) || (z < 0))
            {
                return;
            }
            if ((pArray.lFlags & ARRAY_TYPENUM) != 0)
            {
                // Expand if required
                if ((x >= pArray.lDimensionX) || (y >= pArray.lDimensionY) || (z >= pArray.lDimensionZ))
                {
                    int newDimX = Math.Max(pArray.lDimensionX, x + 1);
                    int newDimY = Math.Max(pArray.lDimensionY, y + 1);
                    int newDimZ = Math.Max(pArray.lDimensionZ, z + 1);
                    pArray.Expand(newDimX, newDimY, newDimZ);
                }
                //write
                pArray.lIndexA = x;
                pArray.lIndexB = y;
                pArray.lIndexC = z;
                pArray.numberArray[z * pArray.lDimensionY * pArray.lDimensionX + y * pArray.lDimensionX + x] = value;
            }
        }

        private void WriteString_X(String value, int x)
        {
            x -= pArray.oneBased();
            WriteStringXYZ(value, x, pArray.lIndexB, pArray.lIndexC);
        }
        private void WriteString_XY(String value, int x, int y)
        {
            x -= pArray.oneBased();
            y -= pArray.oneBased();
            WriteStringXYZ(value, x, y, pArray.lIndexC);
        }
        private void WriteString_XYZ(String value, int x, int y, int z)
        {
            x -= pArray.oneBased();
            y -= pArray.oneBased();
            z -= pArray.oneBased();
            WriteStringXYZ(value, x, y, z);
        }
        private void WriteStringXYZ(String value, int x, int y, int z)
        {
            //x,y,z should be fixed for 1-based index if used before this function
            if ((x < 0) || (y < 0) || (z < 0))
            {
                return;
            }
            if ((pArray.lFlags & ARRAY_TYPETXT) != 0)
            {
                // Expand if required
                if ((x >= pArray.lDimensionX) || (y >= pArray.lDimensionY) || (z >= pArray.lDimensionZ))
                {
                    int newDimX = Math.Max(pArray.lDimensionX, x + 1);
                    int newDimY = Math.Max(pArray.lDimensionY, y + 1);
                    int newDimZ = Math.Max(pArray.lDimensionZ, z + 1);
                    pArray.Expand(newDimX, newDimY, newDimZ);
                }
                //write
                pArray.lIndexA = x;
                pArray.lIndexB = y;
                pArray.lIndexC = z;
                pArray.stringArray[z * pArray.lDimensionY * pArray.lDimensionX + y * pArray.lDimensionX + x] = value;
            }
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_INDEXA:
                    return IndexA();
                case EXP_INDEXB:
                    return IndexB();
                case EXP_INDEXC:
                    return IndexC();
                case EXP_READVALUE:
                    return ReadValue();
                case EXP_READSTRING:
                    return ReadString();
                case EXP_READVALUE_X:
                    return ReadValue_X(ho.getExpParam().getInt());
                case EXP_READVALUE_XY:
                    return ReadValue_XY(ho.getExpParam().getInt(),
                        ho.getExpParam().getInt());
                case EXP_READVALUE_XYZ:
                    return ReadValue_XYZ(ho.getExpParam().getInt(),
                        ho.getExpParam().getInt(),
                        ho.getExpParam().getInt());
                case EXP_READSTRING_X:
                    return ReadString_X(ho.getExpParam().getInt());
                case EXP_READSTRING_XY:
                    return ReadString_XY(ho.getExpParam().getInt(),
                        ho.getExpParam().getInt());
                case EXP_READSTRING_XYZ:
                    return ReadString_XYZ(ho.getExpParam().getInt(),
                        ho.getExpParam().getInt(),
                        ho.getExpParam().getInt());
                case EXP_DIMX:
                    return Exp_DimX();
                case EXP_DIMY:
                    return Exp_DimY();
                case EXP_DIMZ:
                    return Exp_DimZ();
            }
            return new CValue(0);//won't be used
        }
        private CValue IndexA()
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                return new CValue(pArray.lIndexA + 1);
            }
            else
            {
                return new CValue(pArray.lIndexA);
            }
        }
        private CValue IndexB()
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                return new CValue(pArray.lIndexB + 1);
            }
            else
            {
                return new CValue(pArray.lIndexB);
            }
        }
        private CValue IndexC()
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                return new CValue(pArray.lIndexC + 1);
            }
            else
            {
                return new CValue(pArray.lIndexC);
            }
        }
        private CValue ReadValue()
        {
            return ReadValueXYZ(pArray.lIndexA,
                    pArray.lIndexB,
                    pArray.lIndexC);
        }
        private CValue ReadString()
        {
            return ReadStringXYZ(pArray.lIndexA,
                    pArray.lIndexB,
                    pArray.lIndexC);
        }

        private CValue ReadValue_X(int x)
        {
            return ReadValueXYZ(x - pArray.oneBased(),
                    pArray.lIndexB,
                    pArray.lIndexC);
        }
        private CValue ReadValue_XY(int x, int y)
        {
            return ReadValueXYZ(x - pArray.oneBased(),
                    y - pArray.oneBased(),
                    pArray.lIndexC);
        }
        private CValue ReadValue_XYZ(int x, int y, int z)
        {
            return ReadValueXYZ(x - pArray.oneBased(),
                    y - pArray.oneBased(),
                    z - pArray.oneBased());
        }
        private CValue ReadValueXYZ(int x, int y, int z)
        {
            //x y z should be fixed for 1-based, if so
            if ((x < 0) || (y < 0) || (z < 0))
            {
                return new CValue(0);
            }
            if ((pArray.lFlags & ARRAY_TYPENUM) != 0)
            {
                if ((x < pArray.lDimensionX) && (y < pArray.lDimensionY) && (z < pArray.lDimensionZ))
                {
                    return new CValue(pArray.numberArray[z * pArray.lDimensionY * pArray.lDimensionX + y * pArray.lDimensionX + x]);
                }
            }
            return new CValue(0);
        }
        private CValue ReadString_X(int x)
        {
            return ReadStringXYZ(x - pArray.oneBased(),
                    pArray.lIndexB,
                    pArray.lIndexC);
        }
        private CValue ReadString_XY(int x, int y)
        {
            return ReadStringXYZ(x - pArray.oneBased(),
                    y - pArray.oneBased(),
                    pArray.lIndexC);
        }
        private CValue ReadString_XYZ(int x, int y, int z)
        {
            return ReadStringXYZ(x - pArray.oneBased(),
                    y - pArray.oneBased(),
                    z - pArray.oneBased());
        }
        private CValue ReadStringXYZ(int x, int y, int z)
        {
            //x y z should be fixed for 1-based, if so
            if ((x < 0) || (y < 0) || (z < 0))
            {
                return new CValue(0);
            }
            if ((pArray.lFlags & ARRAY_TYPETXT) != 0)
            {
                if ((x < pArray.lDimensionX) && (y < pArray.lDimensionY) && (z < pArray.lDimensionZ))
                {
	                string r = pArray.stringArray[z*pArray.lDimensionY*pArray.lDimensionX+y*pArray.lDimensionX+x];
                    if (r != null)
                    {
                        return new CValue(r);
                    }
                }
            }
            return new CValue("");
        }
        private CValue Exp_DimX()
        {
            return new CValue(pArray.lDimensionX);
        }
        private CValue Exp_DimY()
        {
            return new CValue(pArray.lDimensionY);
        }
        private CValue Exp_DimZ()
        {
            return new CValue(pArray.lDimensionZ);
        }
    

    }
    class KcArrayCGlobalDataList : CExtStorage 
    {
        //should be equal, comparable
        public CArrayList dataList;
        public CArrayList names;    
        
        public KcArrayCGlobalDataList() 
        {
            dataList = new CArrayList();
            names = new CArrayList();
        }
        public KcArrayData FindObject(String objectName)
        {
            for (int i = 0; i < names.size(); i++)
            {
                 if ( string.Compare((string)names.get(i), objectName) == 0)
                {
                    return (KcArrayData)dataList.get(i);
                }
            }
            return null;
        }
        public void AddObject(CRunKcArray o)
        {
            dataList.add(o.pArray);
            names.add(o.ho.hoOiList.oilName);
        }        
    }

    class KcArrayData 
    {
        const int ARRAY_TYPENUM = 0x0001;
        const int ARRAY_TYPETXT = 0x0002;
        const int INDEX_BASE1 = 0x0004;

            
        public int			lDimensionX;
        public int lDimensionY;
        public int lDimensionZ;
        public int lFlags;
        //indicies will never be 1-based
        public int lIndexA;
        public int lIndexB;
        public int lIndexC;
         //int			lArraySize;
        public int[] numberArray;
        public String[] stringArray;
        
        public KcArrayData(int flags, int dimX, int dimY, int dimZ) 
        {
            dimX = Math.Max(1, dimX);
            dimY = Math.Max(1, dimY);
            dimZ = Math.Max(1, dimZ);
            
            lFlags = flags;
            lDimensionX = dimX;
            lDimensionY = dimY;
            lDimensionZ = dimZ;
            if ((flags & ARRAY_TYPENUM) != 0)
            {
                numberArray = new int[dimZ*dimY*dimX];
            }
            else if ((flags & ARRAY_TYPETXT) != 0)
            {
                stringArray = new String[dimZ*dimY*dimX];
            }
        } 
        public int oneBased()
        {
            if ((lFlags & INDEX_BASE1) != 0)
            {
                return 1;
            }
            return 0;
        }
        public void Expand(int newX, int newY, int newZ)
        {
            //inputs should always be equal or larger than current dimensions
            if ((lFlags & ARRAY_TYPENUM) != 0)
            {
                int[] temp = numberArray;
                numberArray = new int[newZ*newY*newX];
                for (int z = 0; z < lDimensionZ; z++)
                {
                    for (int y = 0; y < lDimensionY; y++)
                    {
                        for (int x = 0; x < lDimensionX; x++)
                        {
	                        numberArray[z*newY*newX+y*newX+x] = temp[z*lDimensionY*lDimensionX+y*lDimensionX+x];
                        }
                    }
                }
            }
            else if ((lFlags & ARRAY_TYPETXT) != 0)
            {
                String[] temp = stringArray;
                stringArray = new String[newZ*newY*newX];
                for (int z = 0; z < lDimensionZ; z++)
                {
                    for (int y = 0; y < lDimensionY; y++)
                    {
                        for (int x = 0; x < lDimensionX; x++)
                        {
	                        stringArray[z*newY*newX+y*newX+x] = temp[z*lDimensionY*lDimensionX+y*lDimensionX+x];
                        }
                    }
                }           
            }
            lDimensionX = newX;
            lDimensionY = newY;
            lDimensionZ = newZ;
        }
        public void Clean()
        {
            if ((lFlags & ARRAY_TYPENUM) != 0)
            {
                for (int z = 0; z < lDimensionZ; z++)
                {
                    for (int y = 0; y < lDimensionY; y++)
                    {
                        for (int x = 0; x < lDimensionX; x++)
                        {
	                        numberArray[z*lDimensionY*lDimensionX+y*lDimensionX+x] = 0;
                        }
                    }
                }
            }
            else if ((lFlags & ARRAY_TYPETXT) != 0)
            {
                for (int z = 0; z < lDimensionX; z++)
                {
                    for (int y = 0; y < lDimensionY; y++)
                    {
                        for (int x = 0; x < lDimensionX; x++)
                        {
	                        stringArray[z*lDimensionY*lDimensionX+y*lDimensionX+x] = null;
                        }
                    }
                }           
            }
        }
    }
}
