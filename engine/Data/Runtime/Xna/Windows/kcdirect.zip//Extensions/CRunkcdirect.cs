﻿//----------------------------------------------------------------------------------
//
// CRunkcdirect: Direction Calculator pObject
// fin 26/03/09
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunkcdirect : CRunExtension
    {
        const int ACT_SET_TURN = 0;
        const int ACT_TURN_DIRECTIONS = 1;
        const int ACT_TURN_POS = 2;
        const int ACT_ADD_DIR = 3;
        const int ACT_DIR_SET = 4;
        const int EXP_XY_TO_DIR = 0;
        const int EXP_XY_TO_SPD = 1;
        const int EXP_DIR_TO_X = 2;
        const int EXP_DIR_TO_Y = 3;
        const int EXP_TURN_TOWARD = 4;

        int angle_to_turn = 1;
        int dir_to_add = 16;

        public override int getNumberOfConditions()
        {
            return 0;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            return true;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_SET_TURN: //"Set the amount to rotate"
                    SetTurn(act.getParamExpression(rh, 0));
                    break;
                case ACT_TURN_DIRECTIONS: //"Rotate pObject toward a direction"
                    TurnToDirection(act.getParamExpression(rh, 0), act.getParamObject(rh, 1));
                    break;
                case ACT_TURN_POS: //"Rotate pObject toward a position"
                    TurnToPosition(act.getParamObject(rh, 0), act.getParamPosition(rh, 1));
                    break;
                case ACT_ADD_DIR: //"Add a directional speed to an pObject"
                    AddDir_act(act.getParamExpression(rh, 0), act.getParamObject(rh, 1));
                    break;
                case ACT_DIR_SET: //"Set the direction to add"
                    AngleSet(act.getParamExpression(rh, 0));
                    break;
            }
        }

        private void SetTurn(int v)
        {
            angle_to_turn = v;
        }

        private void TurnToDirection(int dir, CObject pObject)
        {
            if (pObject==null)
            {
                return;
            }
            int goal_angle, direction;
            int cc;
            int cl;
            int angle;

            direction = pObject.roc.rcDir;
            goal_angle = dir;

            goal_angle = goal_angle % 32;
            if (goal_angle < 0)
            {
                goal_angle += 32;
            }

            cc = goal_angle - direction;
            if (cc < 0)
            {
                cc += 32;
            }
            cl = direction - goal_angle;
            if (cl < 0)
            {
                cl += 32;
            }
            if (cc < cl)
            {
                angle = cc;
            }
            else
            {
                angle = cl;
            }
            if (angle > angle_to_turn)
            {
                angle = angle_to_turn;
            }
            if (cl < cc)
            {
                angle = -angle;
            }

            direction += angle;
            if (direction >= 32)
            {
                direction -= 32;
            }
            if (direction <= -1)
            {
                direction += 32;
            }
            pObject.roc.rcDir = (short) direction;

            pObject.roc.rcChanged = true;
            pObject.roc.rcCheckCollides = true;
        }

        private void TurnToPosition(CObject pObject, CPositionInfo position)
        {
            if (pObject==null)
            {
                return;
            }

            int goal_angle, direction;
            int cc;
            int cl;
            int angle;
            double look_angle;
            int l1, l2;
            direction = pObject.roc.rcDir;

            l1 = position.x;
            l2 = position.y;

            l1 -= pObject.hoX;
            l2 -= pObject.hoY;

            look_angle = Math.Atan2((double) (-l2), (double) l1);
            if (look_angle < 0.0)
            {
                look_angle = look_angle + 2.0 * 3.1416;
            }

            goal_angle = (int) (look_angle * 32.0 / (2.0 * 3.1416) + 0.5);

            cc = goal_angle - direction;
            if (cc < 0)
            {
                cc += 32;
            }
            cl = direction - goal_angle;
            if (cl < 0)
            {
                cl += 32;
            }
            if (cc < cl)
            {
                angle = cc;
            }
            else
            {
                angle = cl;
            }
            if (angle > angle_to_turn)
            {
                angle = angle_to_turn;
            }
            if (cl < cc)
            {
                angle = -angle;
            }

            direction += angle;
            if (direction > 31)
            {
                direction -= 32;
            }
            if (direction < 0)
            {
                direction += 32;
            }
            pObject.roc.rcDir = (short) direction;
            pObject.roc.rcChanged = true;
            pObject.roc.rcCheckCollides = true;
        }

        private void AddDir_act(int speed, CObject pObject)
        {
            if (pObject==null)
            {
                return;
            }

            double angle1, angle2;
            double x1, y1;
            double x2, y2;
            double x2_delta, y2_delta;
            double look_angle;
            double diff_ang;
            int final_dir;
            int final_speed;
            int direction1;
            int object_speed;
            int add_speed;
            add_speed = speed;

            object_speed = pObject.roc.rcSpeed;
            direction1 = pObject.roc.rcDir;
            angle1 = (direction1 * 2 * 3.1416 / 32);
            angle2 = (dir_to_add * 2 * 3.1416 / 32);

            x1 = object_speed * Math.Cos(angle1);
            y1 = object_speed * Math.Sin(angle1);

            x2_delta = add_speed * Math.Cos(angle2);
            y2_delta = add_speed * Math.Sin(angle2);
            x2 = x1 + x2_delta;
            y2 = y1 + y2_delta;

            if (Math.Abs((dir_to_add - direction1) % 32) != 16)
            {
                // Round the original angle of the pObject in the direction we are trying to
                //  move it.
                look_angle = Math.Atan2(y2, x2);
                diff_ang = look_angle - angle1;
                if (diff_ang > 3.1416)
                {
                    diff_ang -= 2 * 3.1416;
                }
                else if (diff_ang < -3.1416)
                {
                    diff_ang += 2 * 3.1416;
                }
                if (diff_ang < 0.0)
                {
                    angle1 -= 3.1416 / 32;
                }
                else
                {
                    angle1 += 3.1416 / 32;
                }

                x1 = object_speed * Math.Cos(angle1);
                y1 = object_speed * Math.Sin(angle1);

                x2 = x1 + x2_delta;
                y2 = y1 + y2_delta;
            }
            look_angle = Math.Atan2(y2, x2);
            if (look_angle < 0.0)
            {
                look_angle = look_angle + 2.0 * 3.1416;
            }
            final_dir = (int) (look_angle * 32.0 / (2.0 * 3.1416) + 0.5);
            if (final_dir >= 32)
            {
                final_dir -= 32;
            }
            pObject.roc.rcDir = (short) final_dir;
            final_speed = (int) (Math.Sqrt(x2 * x2 + y2 * y2) + .5);
            if (final_speed > 100)
            {
                final_speed = 100;
            }
            pObject.roc.rcSpeed = (short) final_speed;
            pObject.roc.rcChanged = true;
            pObject.roc.rcCheckCollides = true;
        }

        private void AngleSet(int angle)
        {
            dir_to_add = angle;
            dir_to_add = dir_to_add % 32;
            if (dir_to_add < 0)
            {
                dir_to_add += 32;
            }
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_XY_TO_DIR:
                    return XYtoDir(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_XY_TO_SPD:
                    return XyToSpeed(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_DIR_TO_X:
                    return DirectionToX(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_DIR_TO_Y:
                    return DirectionToY(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_TURN_TOWARD:
                    return TurnToward(ho.getExpParam().getInt(), ho.getExpParam().getInt());
            }
            return new CValue(0);//won't be used
        }

        private CValue XYtoDir(int x, int y)
        {
            double angle;
            int iang;
            angle = Math.Atan2((double)(-y), (double)x);
            if (angle < 0.0)
            {
                angle = angle + 2.0 * 3.1416;
            }
            iang = (int)(angle * 32.0 / (2.0 * 3.1416) + 0.5);
            return new CValue(iang);
        }

        private CValue XyToSpeed(int x, int y)
        {
            int ispeed;
            double speed;

            speed = Math.Sqrt(x * x + y * y);
            ispeed = (int)(speed + (speed < 0.0 ? -.5 : .5));

            return new CValue(ispeed);
        }

        private CValue DirectionToX(int dir, int speed)
        {
            int x;
            double xval;

            dir = dir % 32;
            if (dir < 0)
            {
                dir += 32;
            }

            xval = speed * Math.Cos(dir * 2 * 3.1416 / 32);
            x = (int)(xval + (speed < 0 ? -.5 : .5));
            return new CValue(x);
        }

        private CValue DirectionToY(int dir, int speed)
        {
            int y;
            double yval;

            dir = dir % 32;
            if (dir < 0)
            {
                dir += 32;
            }

            yval = speed * Math.Sin(dir * 2 * 3.1416 / 32);
            y = (int)(yval + (speed < 0 ? -.5 : .5));

            return new CValue(-y);
        }

        private CValue TurnToward(int direction, int goal_angle)
        {
            int cc;
            int cl;
            int angle;

            goal_angle = goal_angle % 32;
            if (goal_angle < 0)
            {
                goal_angle += 32;
            }

            direction = direction % 32;
            if (direction < 0)
            {
                direction += 32;
            }

            cc = goal_angle - direction;
            if (cc < 0)
            {
                cc += 32;
            }
            cl = direction - goal_angle;
            if (cl < 0)
            {
                cl += 32;
            }
            if (cc < cl)
            {
                angle = cc;
            }
            else
            {
                angle = cl;
            }
            if (angle > angle_to_turn)
            {
                angle = angle_to_turn;
            }
            if (cl < cc)
            {
                angle = -angle;
            }
            direction += angle;
            return new CValue(direction);
        }



    }
}
