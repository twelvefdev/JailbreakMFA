﻿//----------------------------------------------------------------------------------
//
// CRUNIIF
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunIIF : CRunExtension
    {
        private const int EXP_INT_INT=0;
        private const int EXP_INT_STRING=1;
        private const int EXP_INT_FLOAT=2;
        private const int EXP_STRING_INT=3;
        private const int EXP_STRING_STRING=4;
        private const int EXP_STRING_FLOAT=5;
        private const int EXP_FLOAT_INT=6;
        private const int EXP_FLOAT_STRING=7;
        private const int EXP_FLOAT_FLOAT=8;
        private const int EXP_INT_BOOL=9;
        private const int EXP_STRING_BOOL=10;
        private const int EXP_FLOAT_BOOL=11;
        private const int EXP_BOOL_INT=12;
        private const int EXP_BOOL_STRING=13;
        private const int EXP_BOOL_FLOAT=14;
        private const int EXP_LAST_COMP=15;

        private bool Last;

        public override int getNumberOfConditions()
        {
            return 0;
        }
        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            Last = false;
            return false;
        }

        // Expressions
        // --------------------------------------------
        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_INT_INT:
                    return IntInt();
                case EXP_INT_STRING:
                    return IntString();
                case EXP_INT_FLOAT:
                    return IntFloat();
                case EXP_STRING_INT:
                    return StringInt();
                case EXP_STRING_STRING:
                    return StringString();
                case EXP_STRING_FLOAT:
                    return StringFloat();
                case EXP_FLOAT_INT:
                    return FloatInt();
                case EXP_FLOAT_STRING:
                    return FloatString();
                case EXP_FLOAT_FLOAT:
                    return FloatFloat();
                case EXP_INT_BOOL:
                    return IntBool();
                case EXP_STRING_BOOL:
                    return StringBool();
                case EXP_FLOAT_BOOL:
                    return FloatBool();
                case EXP_BOOL_INT:
                    return BoolInt();
                case EXP_BOOL_STRING:
                    return BoolString();
                case EXP_BOOL_FLOAT:
                    return BoolFloat();
                case EXP_LAST_COMP:
                    return LastComp();
            }
            return null;
        }
        private CValue IntInt()
        {
            //get parameters
            int p1 = ho.getExpParam().getInt();
            String comp = ho.getExpParam().getString();
            int p2 = ho.getExpParam().getInt();
            int r1 = ho.getExpParam().getInt();
            int r2 = ho.getExpParam().getInt();

            Last = CompareInts(p1, comp, p2);
            if (Last)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue IntString()
        {
            //get parameters
            String p1 = ho.getExpParam().getString();
            String comp = ho.getExpParam().getString();
            String p2 = ho.getExpParam().getString();
            int r1 = ho.getExpParam().getInt();
            int r2 = ho.getExpParam().getInt();

            Last = CompareStrings(p1, comp, p2);
            if (Last)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue IntFloat()
        {
            //get parameters
            double p1 = ho.getExpParam().getDouble();
            String comp = ho.getExpParam().getString();
            double p2 = ho.getExpParam().getDouble();
            int r1 = ho.getExpParam().getInt();
            int r2 = ho.getExpParam().getInt();

            Last = CompareFloats(p1, comp, p2);
            if (Last)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue StringInt()
        {
            //get parameters
            int p1 = ho.getExpParam().getInt();
            String comp = ho.getExpParam().getString();
            int p2 = ho.getExpParam().getInt();
            String r1 = ho.getExpParam().getString();
            String r2 = ho.getExpParam().getString();

            Last = CompareInts(p1, comp, p2);
            if (Last)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue StringString()
        {
            //get parameters
            String p1 = ho.getExpParam().getString();
            String comp = ho.getExpParam().getString();
            String p2 = ho.getExpParam().getString();
            String r1 = ho.getExpParam().getString();
            String r2 = ho.getExpParam().getString();

            Last = CompareStrings(p1, comp, p2);
            if (Last)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue StringFloat()
        {
            //get parameters
            double p1 = ho.getExpParam().getDouble();
            String comp = ho.getExpParam().getString();
            double p2 = ho.getExpParam().getDouble();
            String r1 = ho.getExpParam().getString();
            String r2 = ho.getExpParam().getString();

            Last = CompareFloats(p1, comp, p2);
            if (Last)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue FloatInt()
        {
            //get parameters
            int p1 = ho.getExpParam().getInt();
            String comp = ho.getExpParam().getString();
            int p2 = ho.getExpParam().getInt();
            double r1 = ho.getExpParam().getDouble();
            double r2 = ho.getExpParam().getDouble();

            Last = CompareInts(p1, comp, p2);
            if (Last)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue FloatString()
        {
            //get parameters
            String p1 = ho.getExpParam().getString();
            String comp = ho.getExpParam().getString();
            String p2 = ho.getExpParam().getString();
            double r1 = ho.getExpParam().getDouble();
            double r2 = ho.getExpParam().getDouble();

            Last = CompareStrings(p1, comp, p2);
            if (Last)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue FloatFloat()
        {
            //get parameters
            double p1 = ho.getExpParam().getDouble();
            String comp = ho.getExpParam().getString();
            double p2 = ho.getExpParam().getDouble();
            double r1 = ho.getExpParam().getDouble();
            double r2 = ho.getExpParam().getDouble();

            Last = CompareFloats(p1, comp, p2);
            if (Last)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue IntBool()
        {
            //get parameters
            bool p1 = ho.getExpParam().getInt() != 0;
            int r1 = ho.getExpParam().getInt();
            int r2 = ho.getExpParam().getInt();

            if (p1)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue StringBool()
        {
            //get parameters
            bool p1 = ho.getExpParam().getInt() != 0;
            String r1 = ho.getExpParam().getString();
            String r2 = ho.getExpParam().getString();

            if (p1)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue FloatBool()
        {
            //get parameters
            bool p1 = ho.getExpParam().getInt() != 0;
            double r1 = ho.getExpParam().getDouble();
            double r2 = ho.getExpParam().getDouble();

            if (p1)
                return new CValue(r1);
            else
                return new CValue(r2);
        }

        private CValue BoolInt()
        {
            //get parameters
            int p1 = ho.getExpParam().getInt();
            String comp = ho.getExpParam().getString();
            int p2 = ho.getExpParam().getInt();

            Last = CompareInts(p1, comp, p2);
            if (Last)
                return new CValue(1);
            else
                return new CValue(0);
        }

        public CValue BoolString()
        {
            //get parameters
            String p1 = ho.getExpParam().getString();
            String comp = ho.getExpParam().getString();
            String p2 = ho.getExpParam().getString();

            Last = CompareStrings(p1, comp, p2);
            if (Last)
                return new CValue(1);
            else
                return new CValue(0);
        }

        public CValue BoolFloat()
        {
            //get parameters
            double p1 = ho.getExpParam().getDouble();
            String comp = ho.getExpParam().getString();
            double p2 = ho.getExpParam().getDouble();

            Last = CompareFloats(p1, comp, p2);
            if (Last)
                return new CValue(1);
            else
                return new CValue(0);
        }

        public CValue LastComp()
        {
            if (Last)
                return new CValue(1);
            else
                return new CValue(0);
        }

        // ============================================================================
        //
        // MATT'S FUNCTIONS
        //
        // ============================================================================
        private bool CompareInts(int p1, String comp, int p2)
        {
            //catch NULL
            if (comp == null)
                return p1 == p2;

            if ((comp[0] == '=') || (comp[0] == '\0'))
                return p1 == p2;
            if (comp[0] == '!')
                return p1 != p2;

            if (comp[0] == '>')
            {
                if (comp.Length > 1 && comp[1] == '=')
                    return p1 >= 0;
                return p1 > 0;
            }

            if (comp[0] == '<')
            {
                if (comp.Length > 1 && comp[1] == '=')
                    return p1 <= p2;
                if (comp.Length > 1 && comp[1] == '>')
                    return p1 != p2;
                return p1 < p2;
            }

            //default
            return p1 == p2;
        }

        private bool CompareStrings(String p1, String comp, String p2)
        {
            //catch NULLs
            String NullStr = "";
            if (p1 == null)
                p1 = NullStr;
            if (p2 == null)
                p2 = NullStr;

            if (comp == null)
                return string.Compare(p1, p2) == 0;

            if ((comp[0] == '=') || (comp[0] == '\0'))
                return string.Compare(p1, p2) == 0;
            if (comp[0] == '!')
                return string.Compare(p1, p2) != 0;

            if (comp[0] == '>')
            {
                if (comp.Length > 1 && comp[1] == '=')
                    return string.Compare(p1, p2) >= 0;
                return string.Compare(p1, p2) > 0;
            }

            if (comp[0] == '<')
            {
                if (comp.Length > 1 && comp[1] == '=')
                    return string.Compare(p1, p2) <= 0;
                if (comp.Length > 1 && comp[1] == '>')
                    return string.Compare(p1, p2) != 0;
                return string.Compare(p1, p2) < 0;
            }

            return string.Compare(p1, p2) == 0;
        }

        private bool CompareFloats(double p1, String comp, double p2)
        {
            //catch NULL
            if (comp == null)
                return p1 == p2;

            if ((comp[0] == '=') || (comp[0] == '\0'))
                return p1 == p2;
            if (comp[0] == '!')
                return p1 != p2;

            if (comp[0] == '>')
            {
                if (comp.Length > 1 && comp[1] == '=')
                    return p1 >= p2;
                return p1 > p2;
            }

            if (comp[0] == '<')
            {
                if (comp.Length > 1 && comp[1] == '=')
                    return p1 <= p2;
                if (comp.Length > 1 && comp[1] == '>')
                    return p1 != p2;
                return p1 < p2;
            }

            //default
            return p1 == p2;
        }


    }
}
