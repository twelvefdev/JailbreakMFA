//----------------------------------------------------------------------------------
//
// CRUNXBOX GAMEPAD
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.GamerServices;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunXBOXGamepad : CRunExtension
    {
        const int CND_ISCONNECTED=0;
        const int CND_BUTTONA=1;
        const int CND_BUTTONB=2;
        const int CND_BUTTONX=3;
        const int CND_BUTTONY=4;
        const int CND_BUTTONBACK=5;
        const int CND_BUTTONBIGBUTTON=6;
        const int CND_BUTTONLEFTSHOULDER=7;
        const int CND_BUTTONLEFTSTICK=8;
        const int CND_BUTTONRIGHTSHOULDER=9;
        const int CND_BUTTONRIGHTSTICK=10;
        const int CND_BUTTONSTART=11;
        const int CND_DPADUP=12;
        const int CND_DPADDOWN=13;
        const int CND_DPADLEFT=14;
        const int CND_DPADRIGHT = 15;
        const int CND_BUTTONS = 16;
        const int CND_ANYBUTTON = 17;
        const int CND_LAST = 18;
        const int ACT_VIBRATE = 0;
        const int EXP_STICKLEFTH=0;
        const int EXP_STICKLEFTV=1;
        const int EXP_STICKRIGHTH=2;
        const int EXP_STICKRIGHTV=3;
        const int EXP_TRIGGERLEFT=4;
        const int EXP_TRIGGERRIGHT = 5;
        const int EXP_BUTTONA=6;
        const int EXP_BUTTONB=7;				
        const int EXP_BUTTONX=8;					
        const int EXP_BUTTONY=9;				
        const int EXP_BUTTONBACK=10;				
        const int EXP_BUTTONBIGBUTTON=11;			
        const int EXP_BUTTONLEFTSHOULDER=12;		
        const int EXP_BUTTONLEFTSTICK=13;			
        const int EXP_BUTTONRIGHTSHOULDER=14;		
        const int EXP_BUTTONRIGHTSTICK=15;		
        const int EXP_BUTTONSTART=16;				
        const int EXP_DPADUP=17;					
        const int EXP_DPADDOWN=18;				
        const int EXP_DPADLEFT=19;
        const int EXP_DPADRIGHT = 20;
        const int EXP_BUTTONS = 21;
        const int EXP_BUTTON = 22;

        long[] timers;
        GamePadState[] states;

	    public override int getNumberOfConditions()
	    {
	        return CND_LAST;
	    }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            timers = new long[4];
            int n;
            for (n = 0; n < 4; n++)
            {
                timers[n] = 0;
            }
            states=new GamePadState[4];

            return true;
        }
        public override void destroyRunObject(bool bFast)
        {
            int n;
            for (n = 0; n < 4; n++)
            {
                GamePad.SetVibration(getPlayer(n), 0, 0);
            }
        }
        public override int handleRunObject()
        {
            int n;
            long tick = ho.hoAdRunHeader.rhApp.timer;
            for (n = 0; n < 4; n++)
            {
                if (timers[n] != 0)
                {
                    if (tick > timers[n])
                    {
                        GamePad.SetVibration(getPlayer(n), 0, 0);
                        timers[n] = 0;
                    }
                }
            }
            for (n = 0; n < 4; n++)
            {
                switch (n)
                {
                    case 0:
                        states[n] = GamePad.GetState(PlayerIndex.One);
                        break;
                    case 1:
                        states[n] = GamePad.GetState(PlayerIndex.Two);
                        break;
                    case 2:
                        states[n] = GamePad.GetState(PlayerIndex.Three);
                        break;
                    case 3:
                        states[n] = GamePad.GetState(PlayerIndex.Four);
                        break;
                }
            }
            return 0;
        }

        public override void pauseRunObject()
        {
            int n;
            for (n = 0; n < 4; n++)
            {
                GamePad.SetVibration(getPlayer(n), 0, 0);
            }
        }

	    // Conditions
	    // --------------------------------------------------
        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_ISCONNECTED:
                    return RCND_ISCONNECTED(cnd);
                case CND_BUTTONA:
                    return RCND_BUTTONA(cnd);
                case CND_BUTTONB:
                    return RCND_BUTTONB(cnd);
                case CND_BUTTONX:
                    return RCND_BUTTONX(cnd);
                case CND_BUTTONY:
                    return RCND_BUTTONY(cnd);
                case CND_BUTTONBACK:
                    return RCND_BUTTONBACK(cnd);
                case CND_BUTTONBIGBUTTON:
                    return RCND_BUTTONBIGBUTTON(cnd);
                case CND_BUTTONLEFTSHOULDER:
                    return RCND_BUTTONLEFTSHOULDER(cnd);
                case CND_BUTTONLEFTSTICK:
                    return RCND_BUTTONLEFTSTICK(cnd);
                case CND_BUTTONRIGHTSHOULDER:
                    return RCND_BUTTONRIGHTSHOULDER(cnd);
                case CND_BUTTONRIGHTSTICK:
                    return RCND_BUTTONRIGHTSTICK(cnd);
                case CND_BUTTONSTART:
                    return RCND_BUTTONSTART(cnd);
                case CND_DPADUP:
                    return RCND_DPADUP(cnd);
                case CND_DPADDOWN:
                    return RCND_DPADDOWN(cnd);
                case CND_DPADLEFT:
                    return RCND_DPADLEFT(cnd);
                case CND_DPADRIGHT:
                    return RCND_DPADRIGHT(cnd);
                case CND_BUTTONS:
                    return RCND_BUTTONS(cnd);
                case CND_ANYBUTTON:
                    return RCND_ANYBUTTON(cnd);
            }
            return false;
        }

        PlayerIndex getPlayer(int num)
        {
            switch(num)
            {
                case 0:
                    return PlayerIndex.One;
                case 1:
                    return PlayerIndex.Two;
                case 2:
                    return PlayerIndex.Three;
                case 3:
                    return PlayerIndex.Four;
            }
            return PlayerIndex.One;
        }

        bool RCND_ISCONNECTED(CCndExtension cnd)
        {
            int player=cnd.getParamExpression(rh, 0);
            if (player>=0 && player<=3)
            {
                GamePadState currentState = GamePad.GetState(getPlayer(player));
                return currentState.IsConnected;
            }
            return false;
        }
        bool RCND_BUTTONS(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int button = cnd.getParamExpression(rh, 1);
            return CndButtons(player, button);
        }
        bool RCND_ANYBUTTON(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int b;
            for (b = 0; b <= 13; b++)
            {
                if (CndButtons(player, b))
                {
                    return true;
                }
            }
            return false;
        }
        bool CndButtons(int player, int button)
        {
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    switch (button)
                    {
                        case 0:
                            if (states[n].Buttons.A == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 1:
                            if (states[n].Buttons.B == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 2:
                            if (states[n].Buttons.X == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 3:
                            if (states[n].Buttons.Y == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 4:
                            if (states[n].Buttons.LeftShoulder == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 5:
                            if (states[n].Buttons.RightShoulder == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 6:
                            if (states[n].Buttons.Back == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 7:
                            if (states[n].Buttons.Start == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 8:
                            if (states[n].Buttons.LeftStick == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 9:
                            if (states[n].Buttons.RightStick == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 10:
                            if (states[n].DPad.Up== ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 11:
                            if (states[n].DPad.Down == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 12:
                            if (states[n].DPad.Left == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                        case 13:
                            if (states[n].DPad.Right == ButtonState.Pressed)
                            {
                                return true;
                            }
                            break;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONA(CCndExtension cnd)
        {
            int player=cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.A == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONB(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.B == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONX(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.X == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONY(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.Y == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONBACK(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.Back == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONBIGBUTTON(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.BigButton == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONLEFTSHOULDER(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.LeftShoulder == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONRIGHTSHOULDER(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.RightShoulder == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONLEFTSTICK(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.LeftStick == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONRIGHTSTICK(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.RightStick == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_BUTTONSTART(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.Start == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_DPADUP(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].DPad.Up == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_DPADDOWN(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].DPad.Down == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_DPADLEFT(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].DPad.Left == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        bool RCND_DPADRIGHT(CCndExtension cnd)
        {
            int player = cnd.getParamExpression(rh, 0);
            int n;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].DPad.Right == ButtonState.Pressed)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

	    // Actions
	    // -------------------------------------------------
        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_VIBRATE:
                    RACT_VIBRATE(act);
                    break;
            }
        }
        void RACT_VIBRATE(CActExtension act)
        {
            int player=act.getParamExpression(rh, 0);
            float left = (float)(act.getParamExpression(rh, 1) / 100.0);
            float right = (float)(act.getParamExpression(rh, 2) / 100.0);
            int duration = act.getParamExpression(rh, 3);
            int n;
            for (n=0; n<4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    PlayerIndex index = getPlayer(n);
                    timers[n] = ho.hoAdRunHeader.rhApp.timer + duration;
                    GamePad.SetVibration(index, left, right);
                }
            }
        }

   	    // Expressions
	    // --------------------------------------------
        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_STICKLEFTH:
                    return REXP_STICKLEFTH();
                case EXP_STICKLEFTV:
                    return REXP_STICKLEFTV();
                case EXP_STICKRIGHTH:
                    return REXP_STICKRIGHTH();
                case EXP_STICKRIGHTV:
                    return REXP_STICKRIGHTV();
                case EXP_TRIGGERLEFT:
                    return REXP_TRIGGERLEFT();
                case EXP_TRIGGERRIGHT:
                    return REXP_TRIGGERRIGHT();
                case EXP_BUTTONA:
                    return REXP_BUTTONA();
                case EXP_BUTTONB:
                    return REXP_BUTTONB();
                case EXP_BUTTONX:
                    return REXP_BUTTONX();
                case EXP_BUTTONY:
                    return REXP_BUTTONY();
                case EXP_BUTTONBACK:
                    return REXP_BUTTONBACK();
                case EXP_BUTTONSTART:
                    return REXP_BUTTONSTART();
                case EXP_BUTTONBIGBUTTON:
                    return REXP_BUTTONBIGBUTTON();
                case EXP_BUTTONLEFTSHOULDER:
                    return REXP_BUTTONLEFTSHOULDER();
                case EXP_BUTTONRIGHTSHOULDER:
                    return REXP_BUTTONRIGHTSHOULDER();
                case EXP_DPADUP:
                    return REXP_BUTTONDPADUP();
                case EXP_DPADDOWN:
                    return REXP_BUTTONDPADDOWN();
                case EXP_DPADLEFT:
                    return REXP_BUTTONDPADLEFT();
                case EXP_DPADRIGHT:
                    return REXP_BUTTONDPADRIGHT();
                case EXP_BUTTONLEFTSTICK:
                    return REXP_BUTTONLEFTSTICK();
                case EXP_BUTTONRIGHTSTICK:
                    return REXP_BUTTONRIGHTSTICK();
                case EXP_BUTTON:
                    return REXP_BUTTON();
            }
            return new CValue(0);
        }

        CValue REXP_STICKLEFTH()
        {
            int player = ho.getExpParam().getInt();
            int n, value=0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    value = (int)(states[n].ThumbSticks.Left.X * 100);
                    if (value != 0)
                    {
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_STICKLEFTV()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    value = -(int)(states[n].ThumbSticks.Left.Y * 100);
                    if (value != 0)
                    {
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_STICKRIGHTH()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    value = (int)(states[n].ThumbSticks.Right.X * 100);
                    if (value != 0)
                    {
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_STICKRIGHTV()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    value = -(int)(states[n].ThumbSticks.Right.Y * 100);
                    if (value != 0)
                    {
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_TRIGGERLEFT()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    value = (int)(states[n].Triggers.Left * 100);
                    if (value != 0)
                    {
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_TRIGGERRIGHT()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    value = (int)(states[n].Triggers.Right * 100);
                    if (value != 0)
                    {
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONS()
        {
            int player = ho.getExpParam().getInt();
            int button = ho.getExpParam().getInt();
            return new CValue(ExpButtons(player, button));
        }
        CValue REXP_BUTTON()
        {
            int player = ho.getExpParam().getInt();
            int b;
            for (b = 0; b <= 13; b++)
            {
                if (ExpButtons(player, b) != 0)
                {
                    return new CValue(b);
                }
            }
            return new CValue(-1);
        }
        int ExpButtons(int player, int button)
        {
            int n;
            int ret = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    switch (button)
                    {
                        case 0:
                            if (states[n].Buttons.A == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 1:
                            if (states[n].Buttons.B == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 2:
                            if (states[n].Buttons.X == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 3:
                            if (states[n].Buttons.Y == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 4:
                            if (states[n].Buttons.LeftShoulder == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 5:
                            if (states[n].Buttons.RightShoulder == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 6:
                            if (states[n].Buttons.Back == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 7:
                            if (states[n].Buttons.Start == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 8:
                            if (states[n].Buttons.LeftStick == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 9:
                            if (states[n].Buttons.RightStick == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 10:
                            if (states[n].DPad.Up == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 11:
                            if (states[n].DPad.Down == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 12:
                            if (states[n].DPad.Left == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                        case 13:
                            if (states[n].DPad.Right == ButtonState.Pressed)
                            {
                                ret = 1;
                            }
                            break;
                    }
                }
                if (ret != 0)
                {
                    break;
                }
            }
            return ret;
        }
        CValue REXP_BUTTONA()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.A == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONB()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.B == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONX()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.X == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONY()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.Y == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONBIGBUTTON()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.BigButton == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONSTART()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.Start == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONBACK()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.Back == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONLEFTSHOULDER()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.LeftShoulder == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONRIGHTSHOULDER()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.RightShoulder == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONDPADUP()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].DPad.Up == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONDPADDOWN()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].DPad.Down == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONDPADLEFT()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].DPad.Left == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONDPADRIGHT()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].DPad.Right == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }

        CValue REXP_BUTTONLEFTSTICK()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.LeftStick == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }
        CValue REXP_BUTTONRIGHTSTICK()
        {
            int player = ho.getExpParam().getInt();
            int n, value = 0;
            for (n = 0; n < 4; n++)
            {
                if ((player & (1 << n)) != 0)
                {
                    if (states[n].Buttons.RightStick == ButtonState.Pressed)
                    {
                        value = 1;
                        break;
                    }
                }
            }
            return new CValue(value);
        }


    }
}
