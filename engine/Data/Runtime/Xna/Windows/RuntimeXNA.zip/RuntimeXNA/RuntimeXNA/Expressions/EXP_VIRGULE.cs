//----------------------------------------------------------------------------------
//
// VIRGULE
//
//----------------------------------------------------------------------------------
using System;
using RuntimeXNA.RunLoop;
namespace RuntimeXNA.Expressions
{
	
	public class EXP_VIRGULE:CExp
	{
		public override void  evaluate(CRun rhPtr)
		{
		}
	}
}