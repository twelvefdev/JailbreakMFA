﻿// -----------------------------------------------------------------------------
//
// SET EFFECT PARAM
//
// -----------------------------------------------------------------------------
using System;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Params;
using RuntimeXNA.Objects;
using RuntimeXNA.Sprites;
namespace RuntimeXNA.Actions
{
    class ACT_EXTSETEFFECTPARAM : CAct
    {
        public override void execute(CRun rhPtr)
        {
        }			
    }
}
