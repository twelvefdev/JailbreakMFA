// -----------------------------------------------------------------------------
//
// CLOOP une fast loop
//
// -----------------------------------------------------------------------------
using System;
namespace RuntimeXNA.Actions
{
	
	public class CLoop
	{
		public short flags;
		public string name;
		public int index;
		public const short FLFLAG_STOP = (short) (0x0001);
	}
}