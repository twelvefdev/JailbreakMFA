﻿//----------------------------------------------------------------------------------
//
// CRUNKCWCTRL : objet window control
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunkcwctrl : CRunExtension
    {
        const int CND_ISICONIC=0;
        const int CND_ISMAXIMIZED=1;
        const int CND_ISVISIBLE=2;
        const int CND_ISAPPACTIVE=3;
        const int CND_HASFOCUS=4;
        const int CND_ISATTACHEDTODESKTOP=5;
        const int CND_LAST = 6;

        const int ACT_SETBACKCOLOR = 23;

        const int EXP_GETXPOSITION=0;
        const int EXP_GETYPOSITION=1;
        const int EXP_GETXSIZE=2;
        const int EXP_GETYSIZE=3;
        const int EXP_GETSCREENXSIZE=4;
        const int EXP_GETSCREENYSIZE=5;
        const int EXP_GETSCREENDEPTH=6;
        const int EXP_GETCLIENTXSIZE=7;
        const int EXP_GETCLIENTYSIZE=8;
        const int EXP_GETTITLE=9;
        const int EXP_GETBACKCOLOR=10;
        const int EXP_GETXFRAME=11;
        const int EXP_GETYFRAME=12;
        const int EXP_GETWFRAME=13;
        const int EXP_GETHFRAME = 14;

	    public override int getNumberOfConditions()
	    {
	        return CND_LAST;
	    }

	    public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
	    {
            return false;
        }

        // Conditions
        // --------------------------------------------------
        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_ISICONIC:
                    return false;
                case CND_ISMAXIMIZED:
                    return false;
                case CND_ISVISIBLE:
                    return true;
                case CND_ISAPPACTIVE:
                    return true;
                case CND_HASFOCUS:
                    return true;                    
                case CND_ISATTACHEDTODESKTOP:
                    return false;
            }
            return false;
        }

	    // Actions
	    // -------------------------------------------------
        public override void action(int num, CActExtension act)
        {
            if (num == ACT_SETBACKCOLOR)
            {
                rh.rhApp.gaBorderColour = act.getParamColour(rh, 0);
            }
        }

	    // Expressions
	    // --------------------------------------------
	    public override CValue expression(int num)
	    {
	        switch (num)
	        {
                case EXP_GETXPOSITION:
                    return new CValue(0);
                case EXP_GETYPOSITION:
                    return new CValue(0);
                case EXP_GETXSIZE:
                    return new CValue(rh.rhApp.game.Window.ClientBounds.Width);
                case EXP_GETYSIZE:
                    return new CValue(rh.rhApp.game.Window.ClientBounds.Height);
                case EXP_GETSCREENXSIZE:
                    return new CValue(GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width);
                case EXP_GETSCREENYSIZE:
                    return new CValue(GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height);
                case EXP_GETSCREENDEPTH:
                    return new CValue(0);
                case EXP_GETCLIENTXSIZE:
                    return new CValue(rh.rhApp.game.Window.ClientBounds.Width);
                case EXP_GETCLIENTYSIZE:
                    return new CValue(rh.rhApp.game.Window.ClientBounds.Height);
                case EXP_GETTITLE:
                    return new CValue(rh.rhApp.game.Window.Title);
                case EXP_GETBACKCOLOR:
                    return new CValue(rh.rhApp.gaBorderColour);
                case EXP_GETXFRAME:
                    return new CValue(0);
                case EXP_GETYFRAME:
                    return new CValue(0);
                case EXP_GETWFRAME:
                    return new CValue(rh.rhApp.game.Window.ClientBounds.Width);
                case EXP_GETHFRAME:
                    return new CValue(rh.rhApp.game.Window.ClientBounds.Height);
	        }
	        return null;
	    }
    }
}
