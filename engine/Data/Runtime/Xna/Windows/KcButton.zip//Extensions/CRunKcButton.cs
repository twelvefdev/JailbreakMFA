﻿//----------------------------------------------------------------------------------
//
// CRUNKCBUTTON
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunKcButton : CRunExtension, IControl
    {
        const int BTNTYPE_PUSHTEXT = 0;
        const int BTNTYPE_CHECKBOX = 1;
        const int BTNTYPE_RADIOBTN = 2;
        const int BTNTYPE_PUSHBITMAP = 3;
        const int BTNTYPE_PUSHTEXTBITMAP = 4;
        const int MAX_BUTTONS = 32;
        const int MAX_TEXTSIZE = 4096;
        const int ALIGN_ONELINELEFT = 0;
        const int ALIGN_CENTER = 1;
        const int ALIGN_CENTERINVERSE = 2;
        const int ALIGN_ONELINERIGHT = 3;
        const int BTN_HIDEONSTART = 0x0001;
        const int BTN_DISABLEONSTART = 0x0002;
        const int BTN_TEXTONLEFT = 0x0004;
        const int BTN_TRANSP_BKD = 0x0008;
        const int BTN_SYSCOLOR = 0x0010;
		const int SX_BUTTONBORDER=4;
		const int SY_BUTTONBORDER=4;
		const int SX_TEXTIMAGE=6;
		const int SY_TEXTIMAGE=4;
		const int SX_CHECKBOX=12;
		const int SY_CHECKBOX=13;
		const int R_RADIO=7;

	    const int CND_BOXCHECK = 0;
	    const int CND_CLICKED = 1;
	    const int CND_BOXUNCHECK = 2;
	    const int CND_VISIBLE = 3;
	    const int CND_ISENABLED = 4;
	    const int CND_ISRADIOENABLED = 5;
	    const int CND_LAST = 6;
	    const int ACT_CHANGETEXT = 0;
	    const int ACT_SHOW = 1;
	    const int ACT_HIDE = 2;
	    const int ACT_ENABLE = 3;
	    const int ACT_DISABLE = 4;
	    const int ACT_SETPOSITION = 5;
	    const int ACT_SETXSIZE = 6;
	    const int ACT_SETYSIZE = 7;
	    const int ACT_CHGRADIOTEXT = 8;
	    const int ACT_RADIOENABLE = 9;
	    const int ACT_RADIODISABLE = 10;
	    const int ACT_SELECTRADIO = 11;
	    const int ACT_SETXPOSITION = 12;
	    const int ACT_SETYPOSITION = 13;
	    const int ACT_CHECK = 14;
	    const int ACT_UNCHECK = 15;
	    const int ACT_SETCMDID = 16;
	    const int ACT_SETTOOLTIP = 17;
	    const int ACT_LAST = 18;
	    const int EXP_GETXSIZE = 0;
	    const int EXP_GETYSIZE = 1;
	    const int EXP_GETX = 2;
	    const int EXP_GETY = 3;
	    const int EXP_GETSELECT = 4;
	    const int EXP_GETTEXT = 5;
	    const int EXP_GETTOOLTIP = 6;
	    const int EXP_LAST = 7;

        public short[] buttonImages;
	    public int buttonType;
	    public int buttonCount;
	    public int flags;
	    public int alignImageText;
	    public CFontInfo font;
	    public int fontColor;
	    public int backColor;
	    public int clickedEvent;
		public string[] strings;
		public string toolTipText;
		public int focus;
		public int oldFocus;
		public int hilight;
		public int oldHilight;
		public int selected;
		public int oldSelected;
		public int check;
		public int oldChecked;
		public int syText;
		public int oldWidth;
		public int oldHeight;
		public int zone;
		public int oldZone;
		public int oldKey;
		public bool bEnabled;
		public bool bVisible;
		public int syButton;
		public bool[] radioEnabled;
        bool bMouseControlled;
        Rectangle tempRect = new Rectangle();
        Texture2D texture=null;
        Vector2 vector = new Vector2();
        bool bFocus;

        public override int getNumberOfConditions()
        {
            return CND_LAST;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
	        // Read in edPtr values
	        ho.hoImgWidth = file.readAShort();
	        ho.hoImgHeight = file.readAShort();
	        oldWidth=ho.hoImgWidth;
	        oldHeight=ho.hoImgHeight;
	        buttonType = file.readAShort();
	        buttonCount = file.readAShort();
	        flags = file.readAInt();
	        font = file.readLogFont();
	        fontColor = file.readAColor();
	        backColor = file.readAColor();
	        buttonImages = new short[3];
	        int i;
	        for (i = 0; i < 3; i++)
	        {
	            buttonImages[i] = file.readAShort();
	        }
	        if ((buttonType == BTNTYPE_PUSHBITMAP) || (buttonType == BTNTYPE_PUSHTEXTBITMAP))
	        {
	            ho.loadImageList(buttonImages);
	        }
			if (buttonType==BTNTYPE_PUSHBITMAP)
			{
				ho.hoImgWidth = 0;
				ho.hoImgHeight = 0;
				for (i = 0; i < 3; i++)
				{
					if (buttonImages[i]!=-1)
					{
						CImage image=ho.hoAdRunHeader.rhApp.imageBank.getImageFromHandle(buttonImages[i]);
						ho.hoImgWidth = Math.Max(ho.hoImgWidth, image.width);
						ho.hoImgHeight = Math.Max(ho.hoImgHeight, image.height);
					}
				}
				if (ho.hoImgWidth==0)
				{
					ho.hoImgWidth=32;
				}
				if (ho.hoImgHeight==0)
				{
					ho.hoImgHeight=32;
				}
			}
	        file.readAShort(); // fourth word in img array
	        file.readAInt(); // ebtnSecu
	        alignImageText = file.readAShort();
	
	        if (buttonType!=BTNTYPE_RADIOBTN)
	        {
	        	buttonCount=1;
	            strings = new string[1];
	            strings[0] = file.readAString();
	            toolTipText = file.readAString();
	        }
	        else
	        {
	            strings = new string[buttonCount];
	            for (i = 0; i < buttonCount; i++)
	            {
	                strings[i] = file.readAString();
	            }
	        }
			int b;
            int n;
			for (b=0; b<buttonCount; b++)
			{
				string s=strings[b];
				for (n=0; n<s.Length; n++)
				{
					if (s[n]=='&')
					{
						s=s.Substring(0, n)+s.Substring(n+1);
						if (s[n]!='&')
						{
							n--;
						}
					}	
				}				
				strings[b]=s;
			}	
			
			focus=-1;
			oldFocus=-1;
			hilight=-1;
			oldHilight=-1;
			selected=-1;
			oldSelected=-1;
			oldZone=-1;
			oldKey=-1;
			check=-1;			
			oldChecked=-1;
			bEnabled=true;			
			clickedEvent=-1;
            bFocus = false;
			if ((flags&BTN_DISABLEONSTART)!=0)
			{
				bEnabled=false;
			}			
			bVisible=true;
			if ((flags&BTN_HIDEONSTART)!=0)
			{
				bVisible=false;
			}
            radioEnabled = new bool[buttonCount];
            for (n = 0; n < buttonCount; n++)
            {
                radioEnabled[n] = true;
            }

            CFont f = CFont.createFromFontInfo(font, ho.hoAdRunHeader.rhApp);
            SpriteFont sf = f.getFont();
            syText = sf.LineSpacing;

            createDisplay();
            ho.hoAdRunHeader.addControl((IControl)this);

	        return false;
        }

        public override void destroyRunObject(bool bFast)
        {
            ho.hoAdRunHeader.delControl((IControl)this);
        }

  		public int getZone(int xMouse, int yMouse)
		{
			if (buttonType!=BTNTYPE_RADIOBTN)
			{
				if (xMouse>=ho.hoX && xMouse<ho.hoX+ho.hoImgWidth)
				{
					if (yMouse>=ho.hoY && yMouse<ho.hoY+ho.hoImgHeight)
					{
						return 0;
					}
				}
			}
			else
			{
				if (xMouse>=ho.hoX && xMouse<ho.hoX+ho.hoImgWidth)
				{
					if (yMouse>=ho.hoY && yMouse<ho.hoY+ho.hoImgHeight)
					{
						int n=(yMouse-ho.hoY)/syButton;
						if (n<buttonCount && radioEnabled[n]==true)
						{
							return n;
						}
						return -1;
					}
				}
			}
			return -1; 
		}

        public int getX()
        {
            return ho.hoX;
        }
        public int getY()
        {
            return ho.hoY;
        }
        public void setMouseControlled(bool bFlag)
        {
            bMouseControlled = bFlag;
        }
        public void setFocus(bool bFlag)
        {
            if (bMouseControlled == false)
            {
                if (bFlag != bFocus)
                {
                    bFocus = bFlag;
                    if (focus < 0)
                    {
                        focus = 0;
                    }
                    createDisplay();
                }
            }
        }
        public override int handleRunObject()
        {
			bool bDisplay=false;
			int key=-1, n;
            if (bMouseControlled)
            {
                bFocus = true;
			    zone=getZone(ho.hoAdRunHeader.rh2MouseX, ho.hoAdRunHeader.rh2MouseY);
			    if (zone!=oldZone)
			    {
				    oldZone=zone;
				    if (bEnabled && bVisible)
				    {
					    hilight=zone;
					    bDisplay=true;
				    }
			    }	
				if (buttonType==BTNTYPE_RADIOBTN)
				{
					focus=zone;
                }
			    if ((ho.hoAdRunHeader.rh2MouseKeys&0x01)!=0)
			    {
				    key=0;
			    }
            }
            else if (bFocus)
            {
                if (buttonType == BTNTYPE_RADIOBTN)
                {
                    if ((ho.hoAdRunHeader.rhPlayer[0] & 0x01)!=0)
                    {
                        key = 1;
                    }
                    if ((ho.hoAdRunHeader.rhPlayer[0] & 0x02)!=0)
                    {
                        key = 2;
                    }
                }
                if ((ho.hoAdRunHeader.rhPlayer[0] & 0x10) != 0)
                {
                    key = 0;
                }
            }
		    if (key!=oldKey)
			{            
				if (bEnabled && bVisible)
				{				
					if (buttonType==BTNTYPE_PUSHTEXT || buttonType==BTNTYPE_PUSHBITMAP || buttonType==BTNTYPE_PUSHTEXTBITMAP)
					{
						if (key==0)
						{
							if (zone==0)
							{
								selected=0;						        						
								bDisplay=true;
							}
						}
						if (key==-1)
						{
							if (zone==0 && selected==0)
							{
								if (oldKey==0)
								{
							        clickedEvent = rh.rh4EventCount;
							        ho.pushEvent(CND_CLICKED, 0);	
								}
							}
                            selected = -1;
                            bDisplay = true;
						}
				    }
					if (buttonType==BTNTYPE_CHECKBOX)
					{
						if (key==0)
						{
							if (zone==0)
							{
								selected=0;
								if (check==0)
								{
									check=-1;
									clickedEvent = rh.rh4EventCount;
									ho.pushEvent(CND_CLICKED, 0);							
								}
								else if (check<0)
								{
									check=0;
							        clickedEvent = rh.rh4EventCount;
							        ho.pushEvent(CND_CLICKED, 0);							
								}
							}
						}
                        else
                        {
                            selected=-1;
                        }
				    }
					if (buttonType==BTNTYPE_RADIOBTN)
					{
						if (zone>=0 && bMouseControlled)
						{
							focus=zone;
						}
						if (key==0)
						{
							if (focus>=0)
							{
								selected=focus;
								if (check!=focus)
								{
									check=focus;
							        clickedEvent = rh.rh4EventCount;
							        ho.pushEvent(CND_CLICKED, 0);							
								}
							}
						}
                        else if (key == 1)
                        {
                            if (focus >= 0)
                            {
                                n = focus;
                                if (n > 0)
                                {
                                    n--;
                                    while (n > 0 && radioEnabled[n] == false)
                                    {
                                        n--;
                                    }
                                    if (radioEnabled[n] == true)
                                    {
                                        focus = n;
                                        bDisplay = true;
                                    }
                                }
                            }
                        }
                        else if (key == 2)
                        {
                            if (focus >= 0)
                            {
                                n = focus;
                                if (n < buttonCount - 1)
                                {
                                    n++;
                                    while (n < buttonCount - 1 && radioEnabled[n] == false)
                                    {
                                        n++;
                                    }
                                    if (radioEnabled[n] == true)
                                    {
                                        focus = n;
                                        bDisplay = true;
                                    }
                                }
                            }
                        }
                        else
						{
							selected=-1;
						}
					}
			    }
			    oldKey=key;
                bDisplay = true;
		    }
            if (bDisplay)
            {
                createDisplay();
            }
            return 0;
        }

        public void createDisplay()
        {
            if (buttonType == BTNTYPE_PUSHTEXT || buttonType == BTNTYPE_PUSHTEXTBITMAP)
            {
                oldWidth = ho.hoImgWidth;
                oldHeight = ho.hoImgHeight;

                int[] colorsRect;
                int[] colorsFill;
                colorsRect=new int[2];
                colorsFill=new int[2];
		    	colorsRect[0]=0xB7BABC;
                colorsRect[1]=0x5E6162;
		    	colorsFill[0]=0xDBE1E5;
                colorsFill[1]=0x9EABB2;
                if (bFocus)
                {
                    if (focus >= 0)
                    {
                        colorsRect[0] = 0x009BFC;
                        colorsRect[1] = 0x0078C4;
                        colorsFill[0] = 0xE8EDEF;
                        colorsFill[1] = 0xC7CFD2;
                    }
                    if (hilight >= 0)
                    {
                        colorsRect[0] = 0x009DFF;
                        colorsRect[1] = 0x0076C1;
                        colorsFill[0] = 0xE8EDEF;
                        colorsFill[1] = 0xC7CFD2;
                    }
                    if (selected >= 0)
                    {
                        colorsRect[0] = 0x0081FF;
                        colorsRect[1] = 0x0076C1;
                        colorsFill[0] = 0xD8F0FF;
                        colorsFill[1] = 0x9BD8FF;
                    }
                }
                texture=CServices.createRoundedRect(ho.hoAdRunHeader.rhApp, ho.hoImgWidth, ho.hoImgHeight, colorsRect[0], colorsRect[1], colorsFill[0], colorsFill[1]);
            }
            else if (buttonType==BTNTYPE_CHECKBOX)
            {
                int borderColor;
                int[] colorsFill;
                colorsFill=new int[2];
		    	borderColor=0x5E6162;
		    	colorsFill[0]=0xDBE1E5;
                colorsFill[1]=0x9EABB2;
                if (bEnabled)
                {
                    if (bFocus)
                    {
                        if (focus >= 0)
                        {
                            borderColor = 0x0078C4;
                        }
                        if (hilight >= 0)
                        {
                            borderColor = 0x0076C1;
                            colorsFill[0] = 0xE8EDEF;
                            colorsFill[1] = 0xC7CFD2;
                        }
                        if (selected >= 0)
                        {
                            borderColor = 0x0076C1;
                            colorsFill[0] = 0xD8F0FF;
                            colorsFill[1] = 0x9BD8FF;
                        }
                    }
                }
                else
                {
			    	borderColor=0xB7BABC;
			    	colorsFill[0]=0xDBE1E5;
                    colorsFill[1]=0xDBE1E5;
                }
                texture = CServices.createGradientRectangle(ho.hoAdRunHeader.rhApp, SX_CHECKBOX, SY_CHECKBOX, colorsFill[0], colorsFill[1], true, 1, borderColor);
			}
        }
        Texture2D createRadioTexture(int n)
        {
            Texture2D tex;
            int borderColor;
            int[] colorsFill;
            colorsFill = new int[2];
            borderColor = 0x5E6162;
            colorsFill[0] = 0xDBE1E5;
            colorsFill[1] = 0x9EABB2;
            if (bEnabled)
            {
                if (bFocus)
                {
                    if (focus == n)
                    {
                        borderColor = 0x00FFFF;
                    }
                    if (hilight == n)
                    {
                        borderColor = 0x0076C1;
                        colorsFill[0] = 0xE8EDEF;
                        colorsFill[1] = 0xC7CFD2;
                    }
                    if (selected == n)
                    {
                        borderColor = 0x0076C1;
                        colorsFill[0] = 0xD8F0FF;
                        colorsFill[1] = 0x9BD8FF;
                    }
                }
            }
            else
            {
                borderColor = 0xB7BABC;
                colorsFill[0] = 0xDBE1E5;
                colorsFill[1] = 0xDBE1E5;
            }
            tex = CServices.createGradientEllipse(ho.hoAdRunHeader.rhApp, R_RADIO*2, R_RADIO*2, colorsFill[0], colorsFill[1], true, 1, borderColor);
            return tex;
        }
        public void click(int nClicks)
        {
        }
        public void drawControl(SpriteBatchEffect batch)
        {
            if (bVisible == false)
            {
                return;
            }

			int color;
			int x, y;
			
			short i=0;
			CImage image=null;
			int sxText;		
            int c;
            Color cc;

            int xObject=ho.hoX-ho.hoAdRunHeader.rhWindowX+ho.hoAdRunHeader.rhApp.xOffset;
            int yObject=ho.hoY-ho.hoAdRunHeader.rhWindowY+ho.hoAdRunHeader.rhApp.yOffset;
            CFont f;
			if (buttonType==BTNTYPE_PUSHTEXT || buttonType==BTNTYPE_PUSHTEXTBITMAP)
			{
                tempRect.X = xObject;
                tempRect.Y = yObject;
                tempRect.Width = texture.Width;
                tempRect.Height = texture.Height;
                batch.Draw(texture, tempRect, null, Color.White);
				if (buttonType==BTNTYPE_PUSHTEXT)
				{
                    f=CFont.createFromFontInfo(font, ho.hoAdRunHeader.rhApp);
					c=0x000000;
					if (bEnabled==false)
					{
						c=0xA0A0A0;
					}
                    CRect rc = new CRect();
                    rc.left = xObject;
                    rc.top = yObject;
                    rc.right = xObject + ho.hoImgWidth;
                    rc.bottom = yObject + ho.hoImgHeight;
                    CServices.drawText(batch, strings[0], (short)(CServices.DT_CENTER|CServices.DT_VCENTER), rc, c, f, 0, 0);
				}				
			}	
			if (buttonType==BTNTYPE_PUSHBITMAP)
			{
				i=0;
				if (selected==0)
				{
					i=1;
				}
				if (bEnabled==false)
				{
					i=2;
				}
				i=buttonImages[i];
				if (i<0)
				{
					i=buttonImages[0];
				}
				if (i>=0)
				{
					image=ho.hoAdRunHeader.rhApp.imageBank.getImageFromHandle(i);
                    tempRect.X = xObject + ho.hoImgWidth/2-image.width/2;
                    tempRect.Y = yObject + ho.hoImgHeight/2-image.height/2;
                    tempRect.Width = image.width;
                    tempRect.Height = image.height;
                    Texture2D texture = image.image;
                    Nullable<Rectangle> sourceRect = null;
                    if (image.mosaic != 0)
                    {
                        texture = rh.rhApp.imageBank.mosaics[image.mosaic];
                        sourceRect = image.mosaicRectangle;
                    }
                    batch.Draw(image.image, tempRect, sourceRect, Color.White);
				}
			} 
			if (buttonType==BTNTYPE_PUSHTEXTBITMAP)
			{
				int sx;
				if (selected==0)
				{
					i=1;
				}
				if (bEnabled==false)
				{
					i=2;
				}
				i=buttonImages[i];
				if (i<0)
				{
					i=buttonImages[0];
				}
				if (i>=0)
				{
					image=ho.hoAdRunHeader.rhApp.imageBank.getImageFromHandle(i);
				}
				c=0;
				if (bEnabled==false)
				{
					c=0xA0A0A0;
				}
				if (image!=null)
				{
                    f=CFont.createFromFontInfo(font, ho.hoAdRunHeader.rhApp);
                    SpriteFont sf=f.getFont();
                    Vector2 size=sf.MeasureString(strings[0]);
                    sxText=(int)size.X;
					switch (alignImageText)
					{					
						case ALIGN_ONELINELEFT:
							sx=sxText+image.width+SX_TEXTIMAGE;
                            vector.X=xObject+ho.hoImgWidth/2-sx/2+image.width+SX_TEXTIMAGE;
                            vector.Y=yObject+ho.hoImgHeight/2-syText/2;
                            tempRect.X=xObject+ho.hoImgWidth/2-sx/2;
                            tempRect.Y=yObject+ho.hoImgHeight/2-image.height/2;
							break;					
						case ALIGN_ONELINERIGHT:
							sx=sxText+image.width+SX_TEXTIMAGE;
                            vector.X=xObject+ho.hoImgWidth/2-sx/2;
                            vector.Y=yObject+ho.hoImgHeight/2-syText/2;
                            tempRect.X=xObject+ho.hoImgWidth/2-sx/2+sxText+SX_TEXTIMAGE;
                            tempRect.Y=yObject+ho.hoImgHeight/2-image.height/2;
							break;					
						case ALIGN_CENTER:
                            vector.X=xObject+ho.hoImgWidth/2-sxText/2;
                            vector.Y=yObject+ho.hoImgHeight/2-(syText+image.height+SY_TEXTIMAGE)/2+image.height+SY_TEXTIMAGE;
                            tempRect.X=xObject+ho.hoImgWidth/2-image.width/2;
                            tempRect.Y=yObject+ho.hoImgHeight/2-(syText+image.height+SY_TEXTIMAGE)/2;
							break;					
						case ALIGN_CENTERINVERSE:
                            vector.X=xObject+ho.hoImgWidth/2-sxText/2;
                            vector.Y=yObject+ho.hoImgHeight/2-(syText+image.height+SY_TEXTIMAGE)/2;
                            tempRect.X=xObject+ho.hoImgWidth/2-image.width/2;
                            tempRect.Y=yObject+ho.hoImgHeight/2-(syText+image.height+SY_TEXTIMAGE)/2+syText+SY_TEXTIMAGE;
							break;					
					}
                    tempRect.Width = image.width;
                    tempRect.Height = image.height;
                    Texture2D texture = image.image;
                    Nullable<Rectangle> sourceRect = null;
                    if (image.mosaic != 0)
                    {
                        texture = rh.rhApp.imageBank.mosaics[image.mosaic];
                        sourceRect = image.mosaicRectangle;
                    }
                    batch.Draw(image.image, tempRect, sourceRect, Color.White);
                    cc=CServices.getColor(c);
                    batch.DrawString(sf, strings[0], vector, cc);
				}
			}
			if (buttonType==BTNTYPE_CHECKBOX)
			{
				if ((flags&BTN_TRANSP_BKD)==0)
				{
					if ((flags&BTN_SYSCOLOR)==0)
					{
						color=backColor;
					}
					else
					{
						color=0xFFFFFF;
					}
                    cc=CServices.getColor(color);
                    ho.hoAdRunHeader.rhApp.services.drawFilledRectangleSub(batch, xObject, yObject, ho.hoImgWidth, ho.hoImgHeight, cc, CSpriteGen.BOP_COPY, 0);
				}
				
				if (bEnabled)
				{
		    	    x=0;
		    	    if ((flags&BTN_TEXTONLEFT)!=0)
		    	    {
		    		    x=ho.hoImgWidth-SX_CHECKBOX-1;
		    	    }
                    tempRect.X=xObject+x;
                    tempRect.Y=yObject+ho.hoImgHeight/2-SY_CHECKBOX/2;
                    tempRect.Width=texture.Width;
                    tempRect.Height=texture.Height;
                    batch.Draw(texture, tempRect, null, Color.White);
				
				    if (check==0)
				    {
					    y=ho.hoImgHeight/2-SY_CHECKBOX/2+SY_CHECKBOX/5;
                        ho.hoAdRunHeader.rhApp.services.drawLine(ho.hoAdRunHeader.rhApp.spriteBatch, xObject + x + SX_CHECKBOX / 3 + 1, yObject + y + (SY_CHECKBOX * 2) / 5, xObject + x + SX_CHECKBOX / 2, yObject + y + (SY_CHECKBOX * 2) / 3, 0x000000, 2, CSpriteGen.BOP_COPY, 0);
                        ho.hoAdRunHeader.rhApp.services.drawLine(ho.hoAdRunHeader.rhApp.spriteBatch, xObject + x + SX_CHECKBOX / 2, yObject + y + (SY_CHECKBOX * 2) / 3, xObject + x + SX_CHECKBOX - 3, yObject + y + 1, 0x000000, 2, CSpriteGen.BOP_COPY, 0);
				    }
				    c=0x000000;
				    if ((flags&BTN_SYSCOLOR)==0)
				    {
					    c=fontColor;
				    }
				    if (bEnabled==false)
				    {
					    c=0xA0A0A0;
				    }
                    f=CFont.createFromFontInfo(font, ho.hoAdRunHeader.rhApp);
                    SpriteFont sf=f.getFont();
                    Vector2 size=sf.MeasureString(strings[0]);
                    sxText=(int)size.X;
    		    	if ((flags&BTN_TEXTONLEFT)==0)
	    	    	{
		    			vector.X=xObject+SX_CHECKBOX+6;
		    	    }
		    	    else
		    	    {
                        vector.X=xObject+ho.hoImgWidth-SX_CHECKBOX-6;
                    }
                    vector.Y=yObject+ho.hoImgHeight/2-syText/2;
                    cc=CServices.getColor(c);
                    batch.DrawString(sf, strings[0], vector, cc);
		    	}
			}
			if (buttonType==BTNTYPE_RADIOBTN)
			{
				if ((flags&BTN_TRANSP_BKD)==0)
				{
					if ((flags&BTN_SYSCOLOR)==0)
					{
						color=backColor;
					}
					else
					{
						color=0xFFFFFF;
					}
                    cc=CServices.getColor(color);
                    ho.hoAdRunHeader.rhApp.services.drawFilledRectangleSub(batch, xObject, yObject, ho.hoImgWidth, ho.hoImgHeight, cc, CSpriteGen.BOP_COPY, 0);
				}

				int n;
				syButton=ho.hoImgHeight/buttonCount;
                f=CFont.createFromFontInfo(font, ho.hoAdRunHeader.rhApp);
                SpriteFont sf=f.getFont();
				for (n=0; n<buttonCount; n++)
				{
			    	x=2;
			    	if ((flags&BTN_TEXTONLEFT)!=00)
			    	{
			    		x=ho.hoImgWidth-R_RADIO-2;
			    	}
                    tempRect.X=xObject+x;
                    tempRect.Y=yObject+n*syButton+syButton/2-R_RADIO+1;
                    Texture2D tex = createRadioTexture(n);
                    tempRect.Width = tex.Width;
                    tempRect.Height = tex.Height;
                    batch.Draw(tex, tempRect, null, Color.White);

					if (check==n)
					{
						if (bEnabled && radioEnabled[n]==true)
						{
							color=0x000000;
						}
						else
						{
							color=0xA0A0A0;
						}
                        int R_CHECK = 5;
                        tex = CServices.createFilledEllipse(ho.hoAdRunHeader.rhApp, R_CHECK*2, R_CHECK*2, color, 0, 0);
                        tempRect.X = xObject + x + 2;
                        tempRect.Y = yObject + n * syButton + syButton / 2 - R_CHECK;
                        tempRect.Width = tex.Width;
                        tempRect.Height = tex.Height;
                        batch.Draw(tex, tempRect, null, Color.White);
                    }

                    color=0x000000;
					if ((flags&BTN_SYSCOLOR)==0)
					{
						color=fontColor;
					}
					if (bEnabled==false || radioEnabled[n]==false)
					{
						color=0xA0A0A0;
					}
			    	if ((flags&BTN_TEXTONLEFT)==0)
			    	{					
						vector.X=xObject+R_RADIO*2+9;
			    	}
			    	else
			    	{
                        Vector2 size=sf.MeasureString(strings[n]);
                        sxText=(int)size.X;
						vector.X=xObject+ho.hoImgWidth-R_RADIO-9-sxText;
			    	}
                    vector.Y = yObject + n * syButton +syButton/2 - syText / 2;
                    cc = CServices.getColor(color);
                    batch.DrawString(sf, strings[n], vector, cc);
                }	
			}
        }

        public override CFontInfo getRunObjectFont()
        {
            return font;
        }

        public override void setRunObjectFont(CFontInfo fi, CRect rc)
        {
            font = fi;
            CFont f = CFont.createFromFontInfo(font, ho.hoAdRunHeader.rhApp);
            SpriteFont sf = f.getFont();
            syText = sf.LineSpacing;

            if (rc != null)
            {
                ho.hoImgWidth = rc.right;
                ho.hoImgHeight = rc.bottom;
                createDisplay();
            }
        }

        public override int getRunObjectTextColor()
        {
            return fontColor;
        }

        public override void setRunObjectTextColor(int rgb)
        {
            fontColor = rgb;
        }

        // Conditions
        // --------------------------------------------------
        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_BOXCHECK:
                    return cndBOXCHECK(cnd);
                case CND_CLICKED:
                    return cndCLICKED(cnd);
                case CND_BOXUNCHECK:
                    return cndBOXUNCHECK(cnd);
                case CND_VISIBLE:
                    return cndVISIBLE(cnd);
                case CND_ISENABLED:
                    return cndISENABLED(cnd);
                case CND_ISRADIOENABLED:
                    return cndISRADIOENABLED(cnd);
            }
            return false;
        }

	    public bool cndBOXCHECK(CCndExtension cnd)
	    {
	        if (buttonType == BTNTYPE_CHECKBOX)
	        {
	            return check==0;
	        }
	        return false;
	    }
	
	    public bool cndCLICKED(CCndExtension cnd)
	    {
	        // If this condition is first, then always true
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
	            return true;
	        }
	
	        // If condition second, check event number matches
	        if (rh.rh4EventCount == clickedEvent)
	        {
	            return true;
	        }
	
	        return false;
	    }
	
	    public bool cndBOXUNCHECK(CCndExtension cnd)
	    {
	        if (buttonType == BTNTYPE_CHECKBOX)
	        {
	            return check<0;
	        }
	        return false;
	    }
	
	    public bool cndVISIBLE(CCndExtension cnd)
	    {
	        return bVisible;
	    }
	
	    public bool cndISENABLED(CCndExtension cnd)
	    {
	        return bEnabled;
	    }
	
	    public bool cndISRADIOENABLED(CCndExtension cnd)
	    {
	        int index = cnd.getParamExpression(rh, 0);
	        if ((index >= 0) && (index < buttonCount))
	        {
	            return radioEnabled[index];
	        }
	        return false;
	    }

	    // Actions
	    // -------------------------------------------------
	    public override void action(int num, CActExtension act)
	    {
	        switch (num)
	        {
	            case ACT_CHANGETEXT:
	                actCHANGETEXT(act);
	                break;
	            case ACT_SHOW:
	                actSHOW(act);
	                break;
	            case ACT_HIDE:
	                actHIDE(act);
	                break;
	            case ACT_ENABLE:
	                actENABLE(act);
	                break;
	            case ACT_DISABLE:
	                actDISABLE(act);
	                break;
	            case ACT_SETPOSITION:
	                actSETPOSITION(act);
	                break;
	            case ACT_SETXSIZE:
	                actSETXSIZE(act);
	                break;
	            case ACT_SETYSIZE:
	                actSETYSIZE(act);
	                break;
	            case ACT_CHGRADIOTEXT:
	                actCHGRADIOTEXT(act);
	                break;
	            case ACT_RADIOENABLE:
	                actRADIOENABLE(act);
	                break;
	            case ACT_RADIODISABLE:
	                actRADIODISABLE(act);
	                break;
	            case ACT_SELECTRADIO:
	                actSELECTRADIO(act);
	                break;
	            case ACT_SETXPOSITION:
	                actSETXPOSITION(act);
	                break;
	            case ACT_SETYPOSITION:
	                actSETYPOSITION(act);
	                break;
	            case ACT_CHECK:
	                actCHECK(act);
	                break;
	            case ACT_UNCHECK:
	                actUNCHECK(act);
	                break;
	        }
        }

        public void actCHANGETEXT(CActExtension act)
	    {
	        strings[0]=act.getParamExpString(rh, 0);
			createDisplay();
	    }
	
	    public void actSHOW(CActExtension act)
	    {
	    	bVisible=true;
	    }
	
	    public void actHIDE(CActExtension act)
	    {
	    	bVisible=false;
	    }
	
	    public void actENABLE(CActExtension act)
	    {
	    	if (bEnabled==false)
	    	{
	    		bEnabled=true;
	    		createDisplay();
	    	}
	    }
	
	    public void actDISABLE(CActExtension act)
	    {
	    	if (bEnabled)
	    	{
	    		bEnabled=false;
	    		createDisplay();
	    	}
	    }
	
	    public void actSETPOSITION(CActExtension act)
	    {
	        CPositionInfo pos= act.getParamPosition(rh, 0);
	        ho.setPosition(pos.x, pos.y);
	    }
	
	    public void actSETXSIZE(CActExtension act)
	    {
	        ho.setWidth(act.getParamExpression(rh, 0));
	    }
	
	    public void actSETYSIZE(CActExtension act)
	    {
	        ho.setHeight(act.getParamExpression(rh, 0));
	    }
	
	    public void actCHGRADIOTEXT(CActExtension act)
	    {
	        int index= act.getParamExpression(rh, 0);
	        string newText= act.getParamExpString(rh, 1);
	        if ((index >= 0) && (index < buttonCount))
	        {
	            strings[index]=newText;
	            createDisplay();
	        }
	    }
	
	    public void actRADIOENABLE(CActExtension act)
	    {
	        int index = act.getParamExpression(rh, 0);
	        if ((index >= 0) && (index < buttonCount))
	        {
	        	if (radioEnabled[index]==false)
	        	{
	        		radioEnabled[index]=true;
	        		createDisplay();
	        	}
	        }
	    }
	
	    public void actRADIODISABLE(CActExtension act)
	    {
	        int index = act.getParamExpression(rh, 0);
	        if ((index >= 0) && (index < buttonCount))
	        {
	        	if (radioEnabled[index]==true)
	        	{
	        		radioEnabled[index]=false;
	        		createDisplay();
	        	}
	        }
	    }
	
	    public void actSELECTRADIO(CActExtension act)
	    {
	        int index = act.getParamExpression(rh, 0);
	
	        if (check!=index)
	        {
	        	if (radioEnabled[index])
	        	{
	        		check=index;
	        		createDisplay();
	        	}
	        }
	    }
	
	    public void actSETXPOSITION(CActExtension act)
	    {
	        ho.setPosition(act.getParamExpression(rh, 0), ho.hoY);
	    }
	
	    public void actSETYPOSITION(CActExtension act)
	    {
	        ho.setPosition(ho.hoX, act.getParamExpression(rh, 0));
	    }
	
	    public void actCHECK(CActExtension act)
	    {
	        if (buttonType == BTNTYPE_CHECKBOX)
	        {
	        	if (check==-1)
	        	{
	        		check=0;
	        		createDisplay();
	        	}
	        }
	    }
	
	    public void actUNCHECK(CActExtension act)
	    {
	        if (buttonType == BTNTYPE_CHECKBOX)
	        {
	        	if (check==0)
	        	{
	        		check=-1;
	        		createDisplay();
	        	}
	        }
	    }

	    // Expressions
	    // --------------------------------------------
	    public override CValue expression(int num)
	    {
	        switch (num)
	        {
	            case EXP_GETXSIZE:
	                return expGETXSIZE();
	            case EXP_GETYSIZE:
	                return expGETYSIZE();
	            case EXP_GETX:
	                return expGETX();
	            case EXP_GETY:
	                return expGETY();
	            case EXP_GETSELECT:
	                return expGETSELECT();
	            case EXP_GETTEXT:
	                return expGETTEXT();
	            case EXP_GETTOOLTIP:
	                return expGETTOOLTIP();
	        }
	        return null;
	    }
	
	    public CValue expGETXSIZE()
	    {
	        return new CValue(ho.getWidth());
	    }
	
	    public CValue expGETYSIZE()
	    {
	        return new CValue(ho.getHeight());
	    }
	
	    public CValue expGETX()
	    {
	        return new CValue(ho.getX());
	    }
	
	    public CValue expGETY()
	    {
	        return new CValue(ho.getY());
	    }
	
	    public CValue expGETSELECT()
	    {
	        if (buttonType == BTNTYPE_RADIOBTN)
	        {
	        	return new CValue(check);
	        }
	        return new CValue(0);
	    }
	
	    public CValue expGETTEXT()
	    {
	    	CValue ret=new CValue("");
	    	
	        int index= ho.getExpParam().getInt();
	        if (buttonType == BTNTYPE_RADIOBTN)
	        {
	            if ((index < 0) || (index >= buttonCount))
	            {
	                return ret;
	            }
	        }
	        else
	        {
	            index = 0;
	        }
			ret.forceString(strings[index]);
			return ret;
	    }
	
	    public CValue expGETTOOLTIP()
	    {
	    	var ret=new CValue(0);
	    	ret.forceString(toolTipText);
	    	return ret;
	    }
    }
}
