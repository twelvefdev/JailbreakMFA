﻿//----------------------------------------------------------------------------------
//
// CRunAdvPathMov: advanced path movement pObject
// fin 6th march 09
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunAdvPathMov : CRunExtension
    {
        const int CID_ismoving = 0;
        const int CID_nodesconnected = 1;
        const int CID_isstopping = 2;
        const int CID_Hasreachedend = 3;
        const int CID_touchednewnod = 4;
        const int AID_creatpathnod = 0;
        const int AID_removepathnod = 1;
        const int AID_Clearpath = 2;
        const int AID_Connectnods = 3;
        const int AID_Addnodjourney = 4;
        const int AID_Insertnodjourney = 5;
        const int AID_Removelastnodjourney = 6;
        const int AID_Deletenodjourney = 7;
        const int AID_Findjourney = 8;
        const int AID_LoadPath = 9;
        const int AID_SavePath = 10;
        const int AID_MovementStart = 11;
        const int AID_MovementStop = 12;
        const int AID_MovementPause = 13;
        const int AID_Setspeed = 14;
        const int AID_Setobject = 15;
        const int AID_setXoffset = 16;
        const int AID_setYoffset = 17;
        const int AID_Enableautostep = 18;
        const int AID_Disableautostep = 19;
        const int AID_Forcemovexsteps = 20;
        const int AID_SetNodeX = 21;
        const int AID_SetNodeY = 22;
        const int AID_Disconnectnode = 23;
        const int AID_ClearJourney = 24;
        const int AID_ChangeX = 25;
        const int AID_ChangeY = 26;
        const int AID_ChangeDirection = 27;
        const int EID_Findnode  = 0;
        const int EID_Numberofnods = 1;
        const int EID_GetJourneynode              =2;
        const int EID_Countjourneynode            =3;
        const int EID_ObjectGetX                  =4;
        const int EID_ObjectGetY                  =5;
        const int EID_ObjectGetSpeed              =6;
        const int EID_NodeDistance                =7;
        const int EID_NodeX                       =8;
        const int EID_NodeY                       =9;
        const int EID_GetCurrentSpeed             =10;
        const int EID_GetXoffset                  =11;
        const int EID_GetYoffset                  =12;
        const int EID_GetAngle                    =13;
        const int EID_GetDirection                =14;
        const int EID_Getconnection               =15;
        const int EID_GetNumberconnections        =16;
        const int EID_GetNodesSpeed               =17;
        const int EID_AutochangeX                 =18;
        const int EID_AutochangeY                 =19;
        const int EID_AutochangeDirection         =20;


        AdvPathMovmyclass mypointer;
        float distance, speed, totaldist;
        bool ismoving, muststop, enableautostep, ChangeX, ChangeY, ChangeDirection;
        int debug, x, y, xoffset, yoffset, angle;
        CObject myObject;

        public override int getNumberOfConditions()
        {
            return 5;
        }
        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            file.setUnicode(false);
            this.mypointer = new AdvPathMovmyclass();
            ho.hoX = cob.cobX;
            ho.hoY = cob.cobY;
            file.skipBytes(4);
            ho.hoImgWidth = file.readAShort();
            ho.hoImgHeight = file.readAShort();
            this.speed = (float)file.readAInt() / 100.0f;
            this.xoffset = file.readAInt();
            this.yoffset = file.readAInt();
            this.ChangeX = file.readAByte() == 1 ? true : false;
            this.ChangeY = file.readAByte() == 1 ? true : false;
            this.ChangeDirection = file.readAByte() == 1 ? true : false;
            this.enableautostep = file.readAByte() == 1 ? true : false;

            return true;
        }

        public override int handleRunObject()
        {
            if (this.mypointer.myjourney.size() == 1)
            {
                //	MessageBox(NULL,"Hi",NULL,NULL);
                //This is so the pObject is at the first point if its not moving.
                this.mypointer.JourneyIterator = (AdvPathMovJourney)this.mypointer.myjourney.get(0);
                this.mypointer.theIterator = (AdvPathMovPoints)this.mypointer.myvector.get(this.mypointer.JourneyIterator.Node);
                this.x = this.mypointer.theIterator.X;
                this.y = this.mypointer.theIterator.Y;
                if (this.ChangeX == true) { this.myObject.hoX = this.x; }
                if (this.ChangeY == true) { this.myObject.hoY = this.y; }
                this.myObject.roc.rcChanged = true;
            }
            if (this.ismoving == false) { return 0; }
            if (this.enableautostep == false) { return 0; }
            this.distance += this.speed;

            int FirstNode = 0;
            int NextNode = 0;
            bool connectfound = false;

            while ((this.ismoving == true) && (this.distance >= this.totaldist))
            {

                //Take away the distance travelled so far :)
                this.mypointer.myjourney.remove(0);

                ////Calculate position ( for when it touches a new node )
                this.mypointer.JourneyIterator = (AdvPathMovJourney)this.mypointer.myjourney.get(0);
                FirstNode = this.mypointer.JourneyIterator.Node;
                this.mypointer.theIterator = (AdvPathMovPoints)this.mypointer.myvector.get(FirstNode);
                this.x = this.mypointer.theIterator.X + this.xoffset;
                this.y = this.mypointer.theIterator.Y + this.yoffset;

                if (this.ChangeX == true) { this.myObject.hoX = this.x; }
                if (this.ChangeY == true) { this.myObject.hoY = this.y; }

                this.myObject.roc.rcChanged = true;
                ho.generateEvent(CID_touchednewnod, ho.getEventParam());
                //callRunTimeFunction(rdPtr, RFUNCTION_GENERATEEVENT, 4, 0);

                if ((this.mypointer.myjourney.size()) <= 1
                    || (this.muststop == true))
                {
                    this.ismoving = false;
                    this.distance = 0;
                    this.muststop = false;
                    this.totaldist = 0;
                    ho.generateEvent(CID_Hasreachedend, ho.getEventParam());
                    //callRunTimeFunction(rdPtr, RFUNCTION_GENERATEEVENT, 3, 0);
                }

                if (this.ismoving == true)
                {
                    this.distance -= this.totaldist;

                    //Set the iterator to the first journey step
                    this.mypointer.JourneyIterator = (AdvPathMovJourney)this.mypointer.myjourney.get(0);
                    //Now we know what the current point has to be :)
                    FirstNode = this.mypointer.JourneyIterator.Node;
                    this.mypointer.JourneyIterator = (AdvPathMovJourney)this.mypointer.myjourney.get(1);
                    //Now we what what the next point is going to be :)
                    NextNode = this.mypointer.JourneyIterator.Node;

                    //now we select the first point
                    this.mypointer.theIterator = (AdvPathMovPoints)this.mypointer.myvector.get(FirstNode);
                    //Great...now we need to run through all the connections and find the right one
                    for (int i = 0;
                         i < this.mypointer.theIterator.Connections.size();
                         i++)
                    {
                        this.mypointer.theIterator.ConnectIterator = (AdvPathMovConnect)this.mypointer.theIterator.Connections.get(i);
                        if (this.mypointer.theIterator.ConnectIterator.PointID == NextNode)
                        {
                            this.totaldist = this.mypointer.theIterator.ConnectIterator.Distance;
                            connectfound = true;
                        }
                    }
                    if (connectfound == false)
                    {
                        this.ismoving = false;
                        this.distance = 0;
                        this.muststop = false;
                        this.totaldist = 0;
                    }
                }
            }

            if ((this.ismoving == true) && (this.distance != 0))
            {
                ////Get points
                this.mypointer.JourneyIterator = (AdvPathMovJourney)this.mypointer.myjourney.get(0);
                //Now we know what the current point has to be :)
                FirstNode = this.mypointer.JourneyIterator.Node;
                this.mypointer.JourneyIterator = (AdvPathMovJourney)this.mypointer.myjourney.get(1);
                //Now we want what the next point is going to be :)
                NextNode = this.mypointer.JourneyIterator.Node;

                this.mypointer.theIterator = (AdvPathMovPoints)this.mypointer.myvector.get(FirstNode);
                int x1 = this.mypointer.theIterator.X;
                int y1 = this.mypointer.theIterator.Y;

                this.mypointer.theIterator = (AdvPathMovPoints)this.mypointer.myvector.get(NextNode);
                int x2 = this.mypointer.theIterator.X;
                int y2 = this.mypointer.theIterator.Y;
                int deltax = x2 - x1;
                int deltay = y2 - y1;

                /////Below need to go in main

                if (this.totaldist != 0)
                {
                    float myval = (float)(Math.Atan2((deltax + 0.0), (deltay + 0.0)) / 3.1415926535897932384626433832795 * 180.0);
                    this.angle = (int)(180.0 - myval);
                }


                ///////////////////////////End
                /////Below need to go in main
                if (this.totaldist != 0)
                {
                    this.x = (int)(x1 + deltax * (this.distance / this.totaldist) + this.xoffset);
                    this.y = (int)(y1 + deltay * (this.distance / this.totaldist) + this.yoffset);
                    if (this.ChangeX == true) { this.myObject.hoX = this.x; }
                    if (this.ChangeY == true) { this.myObject.hoY = this.y; }

                    if (this.ChangeDirection == true)
                    {
                        int direction = (this.angle * 32 + 180) / 360;
                        direction = 8 - direction;
                        if (direction < 0) { direction += 32; }
                        //	return direction;
                        this.myObject.roc.rcDir = direction;
                    }
                    this.myObject.roc.rcChanged = true;
                }
            }
            return 0;
        }

        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CID_ismoving:
                    return ismoving;
                case CID_nodesconnected:
                    return nodesconnected(cnd.getParamExpression(rh, 0), cnd.getParamExpression(rh, 1));
                case CID_isstopping:
                    return muststop;
                case CID_Hasreachedend:
                    return true;
                case CID_touchednewnod:
                    return true;
            }
            return false;//won't happen
        }
        private bool nodesconnected(int param1, int param2)
        {
            param1--;
            param2--;
            if (param1 < 0 || param2 < 0) { return false; }
            if ((param1 >= mypointer.myvector.size())
                || (param2 >= mypointer.myvector.size())) { return false; }

            //param1 contains the number inputed by the user
            //param2 contains the number inputed by the user
            mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(param1);
            for (int i = 0;
                i < mypointer.theIterator.Connections.size();
                i++)
            {
                mypointer.theIterator.ConnectIterator = (AdvPathMovConnect)mypointer.theIterator.Connections.get(i);
                if (mypointer.theIterator.ConnectIterator.PointID == param2)
                {
                    return true;
                }
            }
            return false;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case AID_creatpathnod:
                    creatpathnod(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_removepathnod:
                    removepathnod(act.getParamExpression(rh, 0));
                    break;
                case AID_Clearpath:
                    Clearpath(act.getParamExpression(rh, 0));
                    break;
                case AID_Connectnods:
                    Connectnods(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1), act.getParamExpDouble(rh, 2));
                    break;
                case AID_Addnodjourney:
                    Addnodjourney(act.getParamExpression(rh, 0));
                    break;
                case AID_Insertnodjourney:
                    Insertnodjourney(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_Removelastnodjourney:
                    mypointer.myjourney.remove(mypointer.myjourney.size() - 1);
                    break;
                case AID_Deletenodjourney:
                    Deletenodjourney(act.getParamExpression(rh, 0));
                    break;
                case AID_Findjourney:
                    Findjourney(act.getParamExpression(rh, 0));
                    break;
                case AID_LoadPath:
                    //LoadPath(act.getParamExpString(rh, 0));
                    break;
                case AID_SavePath:
                    //SavePath(act.getParamExpString(rh, 0));
                    break;
                case AID_MovementStart:
                    MovementStart();
                    break;
                case AID_MovementStop:
                    muststop = true;
                    break;
                case AID_MovementPause:
                    ismoving = false;
                    break;
                case AID_Setspeed:
                    Setspeed(act.getParamExpDouble(rh, 0));
                    break;
                case AID_Setobject:
                    Setobject(act.getParamObject(rh, 0));
                    break;
                case AID_setXoffset:
                    xoffset = act.getParamExpression(rh, 0);
                    break;
                case AID_setYoffset:
                    yoffset = act.getParamExpression(rh, 0);
                    break;
                case AID_Enableautostep:
                    enableautostep = true;
                    break;
                case AID_Disableautostep:
                    enableautostep = true;
                    break;
                case AID_Forcemovexsteps:
                    Forcemovexsteps(act.getParamExpDouble(rh, 0));
                    break;
                case AID_SetNodeX:
                    SetNodeX(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_SetNodeY:
                    SetNodeY(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_Disconnectnode:
                    Disconnectnode(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_ClearJourney:
                    ClearJourney();
                    break;
                case AID_ChangeX:
                    setChangeX(act.getParamExpression(rh, 0));
                    break;
                case AID_ChangeY:
                    setChangeY(act.getParamExpression(rh, 0));
                    break;
                case AID_ChangeDirection:
                    setChangeDirection(act.getParamExpression(rh, 0));
                    break;
            }
        }

        private void creatpathnod(int param1, int param2)
        {
            mypointer.myvector.add(new AdvPathMovPoints(param1, param2));
        }

        private void removepathnod(int param1)
        {
            if (distance != 0)
            {
                return;
            }
            if (mypointer.myjourney.size() != 0)
            {
                return;
            }
            if (param1 < 1)
            {
                return;
            }
            if (param1 > mypointer.myvector.size())
            {
                return;
            }
            mypointer.myvector.remove(param1 - 1);
            int connectionspot;
            ///Loop through all the vectors!

            for (int i = 0;
                    i < mypointer.myvector.size();
                    i++)
            {
                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(i);
                connectionspot = -1;
                for (int j = 0;
                        j < mypointer.theIterator.Connections.size();
                        j++)
                {
                    mypointer.theIterator.ConnectIterator = (AdvPathMovConnect) mypointer.theIterator.Connections.get(j);
                    connectionspot++;
                    if (mypointer.theIterator.ConnectIterator.PointID == param1 - 1)
                    {
                        mypointer.theIterator.Connections.remove(connectionspot);
                    }
                    if (mypointer.theIterator.ConnectIterator.PointID >= param1 - 1)
                    {
                        mypointer.theIterator.ConnectIterator.PointID -= 1;
                    }
                }
            }
        }

        private void remove(CArrayList array, int from, int to)
        {
            int i = from;
            while (i <= to)
            {
                array.remove(from);
                i++;
            }
        }

        private void Clearpath(int param1)
        {
            ////THIS IS ACTUALLY CLEAR JOURNEY
            if (mypointer.myjourney.size() < 2)
            {
                distance = 0;
                totaldist = 0;
                ismoving = false;
                return;
            }
            if (param1 == 0)
            {
                mypointer.myjourney.clear();
                distance = 0;
                totaldist = 0;
                ismoving = false;
                return;
            }
            if ((param1 == 1) && (distance == 0))
            {
                remove(mypointer.myjourney, 1, mypointer.myjourney.size());

                distance = 0;
                totaldist = 0;
            }

            if ((param1 == 1) && (distance > 0))
            {
                remove(mypointer.myjourney, 2, mypointer.myjourney.size());
            }
        }

        private void Connectnods(int p1, int p2, double p3)
        {
            p1--;
            p2--;
            /// Idiot Proof :P
            if (p1 < 0 || p2 < 0 || p1 >= mypointer.myvector.size() || p2 >= mypointer.myvector.size() || p1 == p2)
            {
                return;
            }
            //int myval = 0;
            /////Check for existing connections.
            mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(p1);

            for (int i = 0;
                    i < mypointer.theIterator.Connections.size();
                    i++)
            {
                mypointer.theIterator.ConnectIterator = (AdvPathMovConnect) mypointer.theIterator.Connections.get(i);

                if (mypointer.theIterator.ConnectIterator.PointID == p2)
                {
                    mypointer.theIterator.Connections.remove(mypointer.theIterator.ConnectIterator);
                }
            //	myval ++;
            }

            /////
            //Get second vector
            mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(p2);
            int v2x = mypointer.theIterator.X;
            int v2y = mypointer.theIterator.Y;

            //Get first vector
            mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(p1);
            int v1x = mypointer.theIterator.X;
            int v1y = mypointer.theIterator.Y;
            int deltax = v2x - v1x;
            int deltay = v2y - v1y;
            float distance = (float) Math.Sqrt(deltax * deltax + deltay * deltay);
            float vectorentry = (float) (distance / p3);
            // now stick the data into the first vector
            if (p3 == 0)
            {
                p3 = 1;
            }
            mypointer.theIterator.Connections.add(new AdvPathMovConnect(p2, vectorentry));
        }

        private void Addnodjourney(int param1)
        {
            if (param1 < 1 || param1 > mypointer.myvector.size())
            {
                return;
            }
            if (mypointer.myjourney.size() > 0)
            {
                mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(mypointer.myjourney.size() - 1);
                if (param1 - 1 == mypointer.JourneyIterator.Node)
                {
                    return;
                }
            }
            mypointer.myjourney.add(new AdvPathMovJourney(param1 - 1));
        }

        private void Insertnodjourney(int param1, int param2)
        {
            //param1 is the Node

            if (param1 < 0)
            {
                param1 = 0;
            }
            param1--;

            //param2 is the position ( starting at 0 )
            if (param2 >= mypointer.myjourney.size())
            {
                mypointer.myjourney.add(new AdvPathMovJourney(param1));
                return;
            }

            if (param2 < 0)
            {
                param2 = 0;
            }
            //param2--;
            //	int temp;
            for (int i = mypointer.myjourney.size() - 1; i >= 0; i--)
            {
                mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(i);

                if (i == mypointer.myjourney.size() - 1)
                {
                    mypointer.myjourney.add(new AdvPathMovJourney(mypointer.JourneyIterator.Node));
                }
                else
                {
                    int temp = mypointer.JourneyIterator.Node;
                    mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(i + 1);
                    mypointer.JourneyIterator.Node = temp;
                }

            }

            mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(param2);
            mypointer.JourneyIterator.Node = param1;
        }

        private void Deletenodjourney(int param1)
        {
            ///FOOL PROOF
            if (param1 < 0 || param1 > mypointer.myjourney.size())
            {
                return;
            }
            ///////////

            if (distance == 0)
            {
                mypointer.myjourney.remove(param1);
            }
        //param1 contains the number inputed by the user
        }

        private void Findjourney(int param1)
        {
            param1--;
            if (param1 < 0)
            {
                return;
            }
            if (param1 > mypointer.myvector.size())
            {
                return;
            }
            if (mypointer.myjourney.size() == 0)
            {
                return;
            }

            /////stuff from the class
            CArrayList ThePoints = new CArrayList();//holds the point numbers
            CArrayList Connection = new CArrayList();//holds which connection id it has
            CArrayList distance = new CArrayList();
            CArrayList Results = new CArrayList();
            int Get;
            //all CArrayList<Integer>

            int Resultdistance = 0;
            bool Resultfound = false;
            int TheDistance = 0;
            //Put the first point into the point array
            mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(mypointer.myjourney.size() - 1);
            ThePoints.add((int)(mypointer.JourneyIterator.Node));
            Connection.add((int)(0));
            distance.add((int)(0));
            Resultfound = false;

            bool dontstop = true;
            debug = -1;

            while (dontstop)
            {
                // Get the point we need to check for connections
                Get = (int) ThePoints.get(ThePoints.size() - 1);
                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(Get);
                // Check the point
                //check that there will be another conection spot
                if (mypointer.theIterator.Connections.size() > ((int) Connection.get(Connection.size() - 1)))
                {
                    //Select the next connection point
                    mypointer.theIterator.ConnectIterator = (AdvPathMovConnect) mypointer.theIterator.Connections.get(((int) Connection.get(Connection.size() - 1)));


                    /// We look through all the points used so far ( this is necassary so not to go over the same point twice)
                    bool worked = true;
                    for (int Currentpos = 0;
                            Currentpos < ThePoints.size();
                            Currentpos++)
                    {
                        Get = (int) ThePoints.get(Currentpos);

                        if (mypointer.theIterator.ConnectIterator.PointID == Get)
                        {
                            worked = false;

                            if (ThePoints.size() == 0)
                            {
                                dontstop = false;
                            }
                            else
                            {
                                int v = ((int) Connection.get(Connection.size() - 1));
                                Connection.set(Connection.size() - 1, (int)(v + 1));
                            }
                        }
                    }
                    //// MUST STICK SOMETHING IN HERE FOR ADDING TO THE DISTANCE
                    if (worked)
                    {
                        ThePoints.add((int)(mypointer.theIterator.ConnectIterator.PointID));
                        distance.add((int)((int) mypointer.theIterator.ConnectIterator.Distance));
                        TheDistance += (int)mypointer.theIterator.ConnectIterator.Distance;

                        Connection.add((int)(0));
                        if (TheDistance > Resultdistance && Resultfound == true)
                        {
                            Connection.remove(Connection.size() - 1);
                            TheDistance -= ((int) distance.get(distance.size() - 1));
                            distance.remove(distance.size() - 1);
                            ThePoints.remove(ThePoints.size() - 1);
                            int v = ((int) Connection.get(Connection.size() - 1));
                            Connection.set(Connection.size() - 1, (int)(v + 1));
                        }
                        ///check if the point we have just added is the one we are after
                        Get = (int) ThePoints.get(ThePoints.size() - 1);
                        if (Get == param1)
                        {
                            ///////////////////////////////////////////////////////////////////////////////
                            /////    WOOOHOOOOO PATH HAS BEEN FOUND FRIGGIN AWSOME :D!!!!                //
                            ///////////////////////////////////////////////////////////////////////////////

                            ////first we calculate the total distance of the journey....i love C++ :)
                            //   int totaldis = 0;
                            // for(int x = 0;x<distance.size();x++)
                            // {
                            //	   totaldis += distance.at(x);}


                            ///no point doing anything if the route is longer

                            if (Resultdistance > TheDistance || Resultfound == false)
                            {
                                Resultfound = true;
                                Resultdistance = TheDistance;
                                Results.clear();

                                //////Now we must stick the distance in the vector and copy all the points
                                for (int y = 0; y < ThePoints.size(); y++)
                                {
                                    Get = (int) ThePoints.get(y);
                                    Results.add((int)(Get));
                                }
                            }
                            Connection.remove(Connection.size() - 1);
                            TheDistance -= ((int) distance.get(distance.size() - 1));
                            distance.remove(distance.size() - 1);
                            ThePoints.remove(ThePoints.size() - 1);
                            int v = ((int) Connection.get(Connection.size() - 1));
                            Connection.set(Connection.size() - 1, (int)(v + 1));
                        }
                    }
                }
                else
                {
                    ThePoints.remove(ThePoints.size() - 1);
                    Connection.remove(Connection.size() - 1);
                    TheDistance -= ((int) distance.get(distance.size() - 1));
                    distance.remove(distance.size() - 1);
                    if (ThePoints.size() == 0)
                    {
                        dontstop = false;
                    }
                    else
                    {
                        int v = ((int) Connection.get(Connection.size() - 1));
                        Connection.set(Connection.size() - 1, (int)(v + 1));
                    }
                }
            }

            ///Now we have found all the paths, we must stick them into the journey:)

            for (int z = 1; z < Results.size(); z++)
            {
                Get = (int) Results.get(z);
                mypointer.myjourney.add(new AdvPathMovJourney(Get));
            }
            //param1 contains the number inputed by the user
            Results.clear();
            ThePoints.clear();
            Connection.clear();
            distance.clear();
            debug = ThePoints.size() + Connection.size() + distance.size() + Results.size();

        }

        private void MovementStart()
        {
            if (mypointer.myjourney.size() < 1)
            {
                return;
            }
            ismoving = true;
            muststop = false;

            //Set the iterator to the first journey step
            mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(0);
            //Now we know what the current point has to be :)
            int FirstNode = mypointer.JourneyIterator.Node;
            int NextNode = 0;
            if (mypointer.myjourney.size() > 1)
            {
                mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(1);
                //Now we what what the next point is going to be :)
                NextNode = mypointer.JourneyIterator.Node;
            }

            bool connectfound = false;

            //now we select the first point
            mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(FirstNode);
            //Great...now we need to run through all the connections and find the right one
            for (int i = 0;
                    i < mypointer.theIterator.Connections.size();
                    i++)
            {
                mypointer.theIterator.ConnectIterator = (AdvPathMovConnect) mypointer.theIterator.Connections.get(i);
                if (mypointer.theIterator.ConnectIterator.PointID == NextNode)
                {
                    totaldist = mypointer.theIterator.ConnectIterator.Distance;
                    connectfound = true;
                }
            }
            if (connectfound == false)
            {
                ismoving = false;
                distance = 0;
                muststop = false;
                totaldist = 0;
            }
        }

        private void Setspeed(double speed)
        {
            if (speed <= 0)
            {
                return;
            }
            speed = (float) speed;
        }

        private void Setobject(CObject pObject)
        {
            myObject = pObject;
        }

        private void Forcemovexsteps(double p1)
        {
            if (p1 <= 0)
            {
                return;
            }
            float oldspeed = speed;
            speed = (float) p1;

            ///////////////////////////////////////////////////
            //////////////////////////////////////////////////
            /////////////////////////////////////////////////
            ////////////////////////////////////////////////
            ///////////////////////////////////////////////
            //////////////////////////////////////////////
            if (mypointer.myjourney.size() == 1)
            {
                //	MessageBox(NULL,"Hi",NULL,NULL);
                //This is so the pObject is at the first point if its not moving.
                mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(0);
                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(mypointer.JourneyIterator.Node);
                x = mypointer.theIterator.X;
                y = mypointer.theIterator.Y;
                if (ChangeX == true)
                {
                    myObject.hoX = x;
                }
                if (ChangeY == true)
                {
                    myObject.hoY = y;
                }
                myObject.roc.rcChanged = true;
            }

            if (ismoving == false)
            {
                return;
            }

            distance += speed;

            int FirstNode = 0;
            int NextNode = 0;
            bool connectfound = false;
            while ((ismoving == true) && (distance >= totaldist))
            {
                //Take away the distance travelled so far :)
                mypointer.myjourney.remove(0);

                ////Calculate position ( for when it touches a new node )
                mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(0);
                FirstNode = mypointer.JourneyIterator.Node;
                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(FirstNode);
                x = mypointer.theIterator.X + xoffset;
                y = mypointer.theIterator.Y + yoffset;

                if (ChangeX == true)
                {
                    myObject.hoX = x;
                }
                if (ChangeY == true)
                {
                    myObject.hoY = y;
                }

                myObject.roc.rcChanged = true;
                ho.generateEvent(CID_touchednewnod, ho.getEventParam());
                //callRunTimeFunction(rdPtr, RFUNCTION_GENERATEEVENT, 4, 0);

                if (mypointer.myjourney.size() <= 1 || muststop == true)
                {
                    ismoving = false;
                    distance = 0;
                    muststop = false;
                    totaldist = 0;
                    ho.generateEvent(CID_Hasreachedend, ho.getEventParam());
                //callRunTimeFunction(rdPtr, RFUNCTION_GENERATEEVENT, 3, 0);
                }
                if (ismoving == true)
                {
                    distance -= totaldist;

                    //Set the iterator to the first journey step
                    mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(0);
                    //Now we know what the current point has to be :)
                    FirstNode = mypointer.JourneyIterator.Node;
                    mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(1);
                    //Now we what what the next point is going to be :)
                    NextNode = mypointer.JourneyIterator.Node;

                    //now we select the first point
                    mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(FirstNode);
                    //Great...now we need to run through all the connections and find the right one
                    for (int i = 0;
                            i < mypointer.theIterator.Connections.size();
                            i++)
                    {
                        mypointer.theIterator.ConnectIterator = (AdvPathMovConnect) mypointer.theIterator.Connections.get(i);
                        if (mypointer.theIterator.ConnectIterator.PointID == NextNode)
                        {
                            totaldist = mypointer.theIterator.ConnectIterator.Distance;
                            connectfound = true;
                        }
                    }
                    if (connectfound == false)
                    {
                        ismoving = false;
                        distance = 0;
                        muststop = false;
                        totaldist = 0;
                    }
                }
            }
            if ((ismoving == true) && (distance != 0))
            {
                ////Get points
                mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(0);
                //Now we know what the current point has to be :)
                FirstNode = mypointer.JourneyIterator.Node;
                mypointer.JourneyIterator = (AdvPathMovJourney) mypointer.myjourney.get(1);
                //Now we want what the next point is going to be :)
                NextNode = mypointer.JourneyIterator.Node;


                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(FirstNode);
                int x1 = mypointer.theIterator.X;
                int y1 = mypointer.theIterator.Y;

                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(NextNode);
                int x2 = mypointer.theIterator.X;
                int y2 = mypointer.theIterator.Y;
                int deltax = x2 - x1;
                int deltay = y2 - y1;

                /////Below need to go in main

                if (totaldist != 0)
                {
                    float myval = (float) (Math.Atan2((deltax + 0.0), (deltay + 0.0)) / 3.1415926535897932384626433832795 * 180);
                    angle = (int) (180 - myval);
                }


                ///////////////////////////End


                /////Below need to go in main
                if (totaldist != 0)
                {
                    x = (int) (x1 + deltax * (distance / totaldist) + xoffset);
                    y = (int) (y1 + deltay * (distance / totaldist) + yoffset);
                    if (ChangeX == true)
                    {
                        myObject.hoX = x;
                    }
                    if (ChangeY == true)
                    {
                        myObject.hoY = y;
                    }

                    if (ChangeDirection == true)
                    {
                        int direction = (angle * 32 + 180) / 360;
                        direction = 8 - direction;
                        if (direction < 0)
                        {
                            direction += 32;
                        }
                        //	return direction;
                        myObject.roc.rcDir = direction;
                    }
                    myObject.roc.rcChanged = true;
                }
            }
            /////////////////////////////////////
            /////////////////
            ////////////////
            ///////////////
            speed = oldspeed;
        }

        private void SetNodeX(int param1, int param2)
        {
            param1--; // 1 based index convert to 0 based
            //use param1
            // and 2
            if ((param1 >= 0) && (param1 < mypointer.myvector.size()))
            {
                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(param1);
                int OldX = mypointer.theIterator.X;
                int OldY = mypointer.theIterator.Y;
                mypointer.theIterator.X = param2;
                int NewX = mypointer.theIterator.X;
                int NewY = mypointer.theIterator.Y;

                for (int i = 0;
                        i < mypointer.myvector.size();
                        i++)
                {
                    mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(i);
                    if (mypointer.theIterator != (AdvPathMovPoints) mypointer.myvector.get(param1))
                    {
                        for (int j = 0;
                                j < mypointer.theIterator.Connections.size();
                                j++)
                        {
                            mypointer.theIterator.ConnectIterator = (AdvPathMovConnect) mypointer.theIterator.Connections.get(j);
                            if (mypointer.theIterator.ConnectIterator.PointID == param1)
                            {
                                //we need to figure the speed
                                int X1 = mypointer.theIterator.X;
                                int Y1 = mypointer.theIterator.Y;
                                float Olddist = (float) (Math.Sqrt((X1 - OldX) * (X1 - OldX) + (Y1 - OldY) * (Y1 - OldY)));
                                float vecspeed = mypointer.theIterator.ConnectIterator.Distance / Olddist;
                                float Newdist = (float) (Math.Sqrt((X1 - NewX) * (X1 - NewX) + (Y1 - NewY) * (Y1 - NewY)));
                                mypointer.theIterator.ConnectIterator.Distance = vecspeed * Newdist;
                            }
                        }
                    }
                }
                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(param1);


                for (int i = 0;
                        i < mypointer.theIterator.Connections.size();
                        i++)
                {
                    mypointer.theIterator.ConnectIterator = (AdvPathMovConnect) mypointer.theIterator.Connections.get(i);
                    //rdPtr->mypointer->theIterator->ConnectIterator = rdPtr->mypointer->theIterator->Connections.begin() + temp;

                    float Distancexspeed = mypointer.theIterator.ConnectIterator.Distance;

                    mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(mypointer.theIterator.ConnectIterator.PointID);
                    int X1 = mypointer.theIterator.X;
                    int Y1 = mypointer.theIterator.Y;
                    float Olddist = (float) (Math.Sqrt((X1 - OldX) * (X1 - OldX) + (Y1 - OldY) * (Y1 - OldY)));
                    float vecspeed = Distancexspeed / Olddist;
                    float Newdist = (float) (Math.Sqrt((X1 - NewX) * (X1 - NewX) + (Y1 - NewY) * (Y1 - NewY)));
                    mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(param1);
                    mypointer.theIterator.ConnectIterator.Distance = vecspeed * Newdist;

                }
            }
        }

        private void SetNodeY(int param1, int param2)
        {
            param1--; // 1 based index convert to 0 based
            //use param1
            // and 2
            if ((param1 >= 0) && (param1 < mypointer.myvector.size()))
            {
                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(param1);
                int OldX = mypointer.theIterator.X;
                int OldY = mypointer.theIterator.Y;
                mypointer.theIterator.Y = param2;
                int NewX = mypointer.theIterator.X;
                int NewY = mypointer.theIterator.Y;

                for (int i = 0;
                        i < mypointer.myvector.size();
                        i++)
                {
                    mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(i);
                    // For points that are connected to the just moved one we need to update
                    if (mypointer.theIterator != (AdvPathMovPoints) mypointer.myvector.get(param1))
                    {

                        for (int j = 0;
                                j < mypointer.theIterator.Connections.size();
                                j++)
                        {
                            mypointer.theIterator.ConnectIterator = (AdvPathMovConnect) mypointer.theIterator.Connections.get(j);
                            if (mypointer.theIterator.ConnectIterator.PointID == param1)
                            {
                                //we need to figure the speed
                                int X1 = mypointer.theIterator.X;
                                int Y1 = mypointer.theIterator.Y;
                                float Olddist = (float) (Math.Sqrt((X1 - OldX) * (X1 - OldX) + (Y1 - OldY) * (Y1 - OldY)));
                                float vecspeed = mypointer.theIterator.ConnectIterator.Distance / Olddist;
                                float Newdist = (float) (Math.Sqrt((X1 - NewX) * (X1 - NewX) + (Y1 - NewY) * (Y1 - NewY)));
                                mypointer.theIterator.ConnectIterator.Distance = vecspeed * Newdist;
                            }
                        }
                    }
                }
                ///Ok now we must update the point so all the things its connected to will change

                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(param1);

                for (int i = 0;
                        i < mypointer.theIterator.Connections.size();
                        i++)
                {
                    mypointer.theIterator.ConnectIterator = (AdvPathMovConnect) mypointer.theIterator.Connections.get(i);
                    //rdPtr->mypointer->theIterator->ConnectIterator = rdPtr->mypointer->theIterator->Connections.begin() + temp;

                    float Distancexspeed = mypointer.theIterator.ConnectIterator.Distance;

                    mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(mypointer.theIterator.ConnectIterator.PointID);
                    int X1 = mypointer.theIterator.X;
                    int Y1 = mypointer.theIterator.Y;
                    float Olddist = (float) (Math.Sqrt((X1 - OldX) * (X1 - OldX) + (Y1 - OldY) * (Y1 - OldY)));
                    float vecspeed = Distancexspeed / Olddist;
                    float Newdist = (float) (Math.Sqrt((X1 - NewX) * (X1 - NewX) + (Y1 - NewY) * (Y1 - NewY)));
                    mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(param1);
                    mypointer.theIterator.ConnectIterator.Distance = vecspeed * Newdist;

                }
            }
        }

        private void Disconnectnode(int param1, int param2)
        {
            param1--;
            param2--;
            //param 1 and param 2
            if ((param1 >= 0) && (param1 < mypointer.myvector.size()))
            {
                mypointer.theIterator = (AdvPathMovPoints) mypointer.myvector.get(param1);

                for (int i = 0;
                        i < mypointer.theIterator.Connections.size();
                        i++)
                {
                    mypointer.theIterator.ConnectIterator = (AdvPathMovConnect) mypointer.theIterator.Connections.get(i);
                    if (mypointer.theIterator.ConnectIterator.PointID == param2)
                    {
                        mypointer.theIterator.Connections.remove(mypointer.theIterator.ConnectIterator);
                    //         rdPtr->mypointer->theIterator->ConnectIterator--;
                    }
                }
            }
        }

        private void ClearJourney()
        {
            ////THIS IS ACTUALLY CLEAR PATH!!!!!!
            mypointer.myvector.clear();
            mypointer.myjourney.clear();
            ismoving = false;
        }

        private void setChangeX(int param1)
        {
            if (param1 == 1)
            {
                ChangeX = true;
            }
            if (param1 == 0)
            {
                ChangeX = false;
            }
        }

        private void setChangeY(int param1)
        {
            if (param1 == 1)
            {
                ChangeY = true;
            }
            if (param1 == 0)
            {
                ChangeY = false;
            }
        }

        private void setChangeDirection(int param1)
        {
            if (param1 == 1)
            {
                ChangeDirection = true;
            }
            if (param1 == 0)
            {
                ChangeDirection = false;
            }
        }

        public override CValue expression(int num)
        {
            switch (num){
                case EID_Findnode:
                    return Findnode(ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EID_Numberofnods:
                    return new CValue(mypointer.myvector.size());
                case EID_GetJourneynode:
                    return GetJourneynode(ho.getExpParam().getInt());
                case EID_Countjourneynode:
                    return new CValue(mypointer.myjourney.size());
                case EID_ObjectGetX:
                    return new CValue(x);
                case EID_ObjectGetY:
                    return new CValue(y);
                case EID_ObjectGetSpeed:
                    return new CValue(speed);
                case EID_NodeDistance:
                    return NodeDistance(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EID_NodeX:
                    return NodeX(ho.getExpParam().getInt());
                case EID_NodeY:
                    return NodeY(ho.getExpParam().getInt());
                case EID_GetCurrentSpeed:
                    return new CValue(0);
                case EID_GetXoffset:
                    return new CValue(xoffset);
                case EID_GetYoffset:
                    return new CValue(yoffset);
                case EID_GetAngle:
                    return new CValue(angle);
                case EID_GetDirection:
                    return GetDirection();
                case EID_Getconnection:
                    return Getconnection(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EID_GetNumberconnections:
                    return GetNumberconnections(ho.getExpParam().getInt());
                case EID_GetNodesSpeed:
                    return GetNodesSpeed(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EID_AutochangeX:
                    return new CValue(ChangeX ? 1 : 0);
                case EID_AutochangeY:
                    return new CValue(ChangeY ? 1 : 0);
                case EID_AutochangeDirection:
                    return new CValue(ChangeDirection ? 1 : 0);
            }
            return new CValue(0);//won't be used
        }

        private CValue Findnode(int p1, int p2, int p3){
            int Answer = p3*p3;
            int result = 0;
            int deltaX = 0;
            int deltaY = 0;
            int loopcount =0;

            for(int i = 0;
                i < mypointer.myvector.size();
                i++){
                mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(i);
                loopcount ++;
                deltaX = Math.Abs(mypointer.theIterator.X - p1);
                deltaY = Math.Abs(mypointer.theIterator.Y - p2);

                if(Answer > (deltaX * deltaX + deltaY * deltaY ))
                {
                    Answer = (deltaX * deltaX + deltaY * deltaY );
                    result = loopcount;
                }
            }
            return new CValue(result);
        }

        private CValue GetJourneynode(int p1){
            if(p1 < 0){return new CValue(0);}
            if(mypointer.myjourney.size() == 0){return new CValue(0);}
            if(p1 >= mypointer.myjourney.size() ){return new CValue(0);}
            mypointer.JourneyIterator = (AdvPathMovJourney)mypointer.myjourney.get(p1);
            return new CValue(mypointer.JourneyIterator.Node + 1);
        }
        private CValue NodeDistance(int p1, int p2){
            p1 --;
            p2 --;
            if ((p1 >= 0) && (p1 < mypointer.myvector.size()) &&
                (p2 >= 0) && (p2 < mypointer.myvector.size())){
                //Get second vector
                mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(p2);
                int v2x = mypointer.theIterator.X;
                int v2y = mypointer.theIterator.Y;

                //Get first vector
                mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(p1);
                int v1x = mypointer.theIterator.X;
                int v1y = mypointer.theIterator.Y;
                int deltax = v2x - v1x;
                int deltay = v2y - v1y;
                float distance = (float)Math.Sqrt(deltax * deltax + deltay * deltay );
                return new CValue(distance);
            }
            return new CValue(0);
        }
        private CValue NodeX(int p1){
            if(p1 < 1){return new CValue(0);}
            if(mypointer.myvector.size() == 0){return new CValue(0);}
            if(p1 > mypointer.myvector.size() ){return new CValue(0);}
            mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(p1 - 1);
            return new CValue(mypointer.theIterator.X);
        }
        private CValue NodeY(int p1){
            if(p1 < 1){return new CValue(0);}
            if(mypointer.myvector.size() == 0){return new CValue(0);}
            if(p1 > mypointer.myvector.size() ){return new CValue(0);}
            mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(p1 - 1);
            return new CValue(mypointer.theIterator.Y);
        }
        private CValue GetDirection(){
            int direction = (angle *32+180)/ 360;
            direction = 8-direction;
            if ( direction < 0){direction +=32;}
            return new CValue(direction);
        }
        private CValue Getconnection(int p1, int p2){
            p1--;
            if(p1 < 0){return new CValue(0);}
            if(p1 >= mypointer.myvector.size()){return new CValue(0);}

            mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(p1);
            if(p2 < 0){return new CValue(0);}
            if(mypointer.theIterator.Connections.size() <= p2){return new CValue(0);}
            mypointer.theIterator.ConnectIterator = (AdvPathMovConnect)mypointer.theIterator.Connections.get(p2);
            return new CValue(mypointer.theIterator.ConnectIterator.PointID + 1);
        }
        private CValue GetNumberconnections(int p1){
            p1--;
            if(p1 < 0){return new CValue(0);}
            if(p1 >= mypointer.myvector.size()){return new CValue(0);}
            mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(p1);
            return new CValue(mypointer.theIterator.Connections.size());
        }
        private CValue GetNodesSpeed(int p1, int p2){
            p1--;
            p2--;
            float speed = 0;
            bool cont = true;
            //param1 contains the number inputed by the user
            //param2 contains the number inputed by the user
            if ((p1 >= 0) && (p1 < mypointer.myvector.size()) &&
                (p2 >= 0) && (p2 < mypointer.myvector.size())){
                mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(p1);
                for(int i = 0;
                    i < mypointer.theIterator.Connections.size();
                    i++){
                    mypointer.theIterator.ConnectIterator = (AdvPathMovConnect)mypointer.theIterator.Connections.get(i);
                    if(mypointer.theIterator.ConnectIterator.PointID == p2)
                    {
                        speed = mypointer.theIterator.ConnectIterator.Distance;
                        cont = false;
                    }
                }

                if (cont){return new CValue(0.0f);}
                //Get second vector
                mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(p2);
                int v2x = mypointer.theIterator.X;
                int v2y = mypointer.theIterator.Y;

                //Get first vector
                mypointer.theIterator = (AdvPathMovPoints)mypointer.myvector.get(p1);
                int v1x = mypointer.theIterator.X;
                int v1y = mypointer.theIterator.Y;
                int deltax = v2x - v1x;
                int deltay = v2y - v1y;
                float distance = (float)Math.Sqrt(deltax * deltax + deltay * deltay );
                if(distance == 0){
                    return new CValue(1.0f);
                }
                return new CValue(distance/speed);
            }
            return new CValue(0.0f);
        }




    }

    public class AdvPathMovConnect
    {
        public int PointID;
        public float Distance;

        public AdvPathMovConnect(int PointID, float Distance)
        {
            this.PointID = PointID;
            this.Distance = Distance;
        }
    }
    public class AdvPathMovJourney
    {
        public int Node;

        public AdvPathMovJourney(int Node)
        {
            this.Node = Node;
        }
    }
    public class AdvPathMovPoints
    {
        public int X, Y;
        public CArrayList Connections = new CArrayList(); //CArrayList<AdvPathMovConnect>
        public AdvPathMovConnect ConnectIterator;

        public AdvPathMovPoints(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
        }
    }
    public class AdvPathMovmyclass
    {
        public CArrayList myvector = new CArrayList(); //CArrayList<AdvPathMovPoints>
        public AdvPathMovPoints theIterator;

        public CArrayList myjourney = new CArrayList(); //CArrayList<AdvPathMovJourney>
        public AdvPathMovJourney JourneyIterator;
    }




}
