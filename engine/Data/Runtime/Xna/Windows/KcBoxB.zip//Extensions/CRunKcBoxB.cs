﻿//----------------------------------------------------------------------------------
//
// CRUNKCBOXB
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunKcBoxB : CRunExtension
    {
        const int FLAG_HYPERLINK = 0x00004000;
        const int FLAG_CONTAINER = 0x00001000;
        const int FLAG_CONTAINED = 0x00002000;
        const int COLOR_NONE = 0xFFFF;
        const int FLAG_BUTTON_PRESSED = 0x10000000;
        const int FLAG_BUTTON_HIGHLIGHTED = 0x20000000;
        const int FLAG_HIDEIMAGE = 0x01000000;
        const int COLORFLAG_RGB = unchecked((int)0x80000000);
        const int COLOR_FLAGS = (COLORFLAG_RGB);
        const int FLAG_CHECKED = unchecked((int)0x80000000);
        const int COLOR_BTNFACE = 15;
        const int COLOR_3DLIGHT = 22;
        const int FLAG_BUTTON = 0x00100000;
        const int FLAG_CHECKBOX = 0x00200000;
        const int FLAG_IMAGECHECKBOX = 0x00800000;
        const int FLAG_DISABLED = 0x40000000;
        const int FLAG_FORCECLIPPING = 0x02000000;
        const int ALIGN_IMAGE_TOPLEFT = 0x00010000;
        const int ALIGN_IMAGE_CENTER = 0x00020000;
        const int ALIGN_IMAGE_PATTERN = 0x00040000;
        const int ALIGN_TOP = 0x00000001;
        const int ALIGN_VCENTER = 0x00000002;
        const int ALIGN_BOTTOM = 0x00000004;
        const int ALIGN_LEFT = 0x00000010;
        const int ALIGN_HCENTER = 0x00000020;
        const int ALIGN_RIGHT = 0x00000040;
        const int ALIGN_MULTILINE = 0x00000100;
        const int ALIGN_NOPREFIX = 0x00000200;
        const int ALIGN_ENDELLIPSIS = 0x00000400;
        const int ALIGN_PATHELLIPSIS = 0x00000800;
        const int FLAG_SHOWBUTTONBORDER = 0x00400000;

        const int PARAMFLAG_SYSTEMCOLOR = unchecked((int)0x80000000);

        const int ACT_ACTION_SETDIM = 0;
        const int ACT_ACTION_SETPOS = 1;

        const int ACT_ACTION_ENABLE = 2;
        const int ACT_ACTION_DISABLE = 3;
        const int ACT_ACTION_CHECK = 4;
        const int ACT_ACTION_UNCHECK = 5;

        const int ACT_ACTION_SETCOLOR_NONE = 6;
        const int ACT_ACTION_SETCOLOR_3DDKSHADOW = 7;
        const int ACT_ACTION_SETCOLOR_3DFACE = 8;
        const int ACT_ACTION_SETCOLOR_3DHILIGHT = 9;
        const int ACT_ACTION_SETCOLOR_3DLIGHT = 10;
        const int ACT_ACTION_SETCOLOR_3DSHADOW = 11;
        const int ACT_ACTION_SETCOLOR_ACTIVECAPTION = 12;
        const int ACT_ACTION_SETCOLOR_APPWORKSPACE = 13; //mdi
        const int ACT_ACTION_SETCOLOR_DESKTOP = 14;
        const int ACT_ACTION_SETCOLOR_HIGHLIGHT = 15;
        const int ACT_ACTION_SETCOLOR_INACTIVECAPTION = 16;
        const int ACT_ACTION_SETCOLOR_INFOBK = 17;
        const int ACT_ACTION_SETCOLOR_MENU = 18;
        const int ACT_ACTION_SETCOLOR_SCROLLBAR = 19;
        const int ACT_ACTION_SETCOLOR_WINDOW = 20;
        const int ACT_ACTION_SETCOLOR_WINDOWFRAME = 21;

        const int ACT_ACTION_SETB1COLOR_NONE = 22;
        const int ACT_ACTION_SETB1COLOR_3DDKSHADOW = 23;
        const int ACT_ACTION_SETB1COLOR_3DFACE = 24;
        const int ACT_ACTION_SETB1COLOR_3DHILIGHT = 25;
        const int ACT_ACTION_SETB1COLOR_3DLIGHT = 26;
        const int ACT_ACTION_SETB1COLOR_3DSHADOW = 27;
        const int ACT_ACTION_SETB1COLOR_ACTIVEBORDER = 28;
        const int ACT_ACTION_SETB1COLOR_INACTIVEBORDER = 29;
        const int ACT_ACTION_SETB1COLOR_WINDOWFRAME = 30;

        const int ACT_ACTION_SETB2COLOR_NONE = 31;
        const int ACT_ACTION_SETB2COLOR_3DDKSHADOW = 32;
        const int ACT_ACTION_SETB2COLOR_3DFACE = 33;
        const int ACT_ACTION_SETB2COLOR_3DHILIGHT = 34;
        const int ACT_ACTION_SETB2COLOR_3DLIGHT = 35;
        const int ACT_ACTION_SETB2COLOR_3DSHADOW = 36;
        const int ACT_ACTION_SETB2COLOR_ACTIVEBORDER = 37;
        const int ACT_ACTION_SETB2COLOR_INACTIVEBORDER = 38;
        const int ACT_ACTION_SETB2COLOR_WINDOWFRAME = 39;

        const int ACT_ACTION_TEXTCOLOR_NONE = 40;
        const int ACT_ACTION_TEXTCOLOR_3DHILIGHT = 41;
        const int ACT_ACTION_TEXTCOLOR_3DSHADOW = 42;
        const int ACT_ACTION_TEXTCOLOR_BTNTEXT = 43;
        const int ACT_ACTION_TEXTCOLOR_CAPTIONTEXT = 44;
        const int ACT_ACTION_TEXTCOLOR_GRAYTEXT = 45;
        const int ACT_ACTION_TEXTCOLOR_HIGHLIGHTTEXT = 46;
        const int ACT_ACTION_TEXTCOLOR_INACTIVECAPTIONTEXT = 47;
        const int ACT_ACTION_TEXTCOLOR_INFOTEXT = 48;
        const int ACT_ACTION_TEXTCOLOR_MENUTEXT = 49;
        const int ACT_ACTION_TEXTCOLOR_WINDOWTEXT = 50;

        const int ACT_ACTION_SETCOLOR_OTHER = 51;
        const int ACT_ACTION_SETB1COLOR_OTHER = 52;
        const int ACT_ACTION_SETB2COLOR_OTHER = 53;
        const int ACT_ACTION_TEXTCOLOR_OTHER = 54;

        const int ACT_ACTION_SETTEXT = 55;
        const int ACT_ACTION_SETTOOLTIPTEXT = 56;

        const int ACT_ACTION_UNDOCK = 57;
        const int ACT_ACTION_DOCK_LEFT = 58;
        const int ACT_ACTION_DOCK_RIGHT = 59;
        const int ACT_ACTION_DOCK_TOP = 60;
        const int ACT_ACTION_DOCK_BOTTOM = 61;

        const int ACT_ACTION_SHOWIMAGE = 62;
        const int ACT_ACTION_HIDEIMAGE = 63;

        const int ACT_ACTION_RESETCLICKSTATE = 64;

        const int ACT_ACTION_HYPERLINKCOLOR_NONE = 65;
        const int ACT_ACTION_HYPERLINKCOLOR_3DHILIGHT = 66;
        const int ACT_ACTION_HYPERLINKCOLOR_3DSHADOW = 67;
        const int ACT_ACTION_HYPERLINKCOLOR_BTNTEXT = 68;
        const int ACT_ACTION_HYPERLINKCOLOR_CAPTIONTEXT = 69;
        const int ACT_ACTION_HYPERLINKCOLOR_GRAYTEXT = 70;
        const int ACT_ACTION_HYPERLINKCOLOR_HIGHLIGHTTEXT = 71;
        const int ACT_ACTION_HYPERLINKCOLOR_INACTIVECAPTIONTEXT = 72;
        const int ACT_ACTION_HYPERLINKCOLOR_INFOTEXT = 73;
        const int ACT_ACTION_HYPERLINKCOLOR_MENUTEXT = 74;
        const int ACT_ACTION_HYPERLINKCOLOR_WINDOWTEXT = 75;
        const int ACT_ACTION_HYPERLINKCOLOR_OTHER = 76;
        const int EXP_COLOR_BACKGROUND = 0;
        const int EXP_COLOR_BORDER1 = 1;
        const int EXP_COLOR_BORDER2 = 2;
        const int EXP_COLOR_TEXT = 3;

        const int EXP_COLOR_3DDKSHADOW = 4;
        const int EXP_COLOR_3DFACE = 5;
        const int EXP_COLOR_3DHILIGHT = 6;
        const int EXP_COLOR_3DLIGHT = 7;
        const int EXP_COLOR_3DSHADOW = 8;
        const int EXP_COLOR_ACTIVEBORDER = 9;
        const int EXP_COLOR_ACTIVECAPTION = 10;
        const int EXP_COLOR_APPWORKSPACE = 11;
        const int EXP_COLOR_DESKTOP = 12;
        const int EXP_COLOR_BTNTEXT = 13;
        const int EXP_COLOR_CAPTIONTEXT = 14;
        const int EXP_COLOR_GRAYTEXT = 15;
        const int EXP_COLOR_HIGHLIGHT = 16;
        const int EXP_COLOR_HIGHLIGHTTEXT = 17;
        const int EXP_COLOR_INACTIVEBORDER = 18;
        const int EXP_COLOR_INACTIVECAPTION = 19;
        const int EXP_COLOR_INACTIVECAPTIONTEXT = 20;
        const int EXP_COLOR_INFOBK = 21;
        const int EXP_COLOR_INFOTEXT = 22;
        const int EXP_COLOR_MENU = 23;
        const int EXP_COLOR_MENUTEXT = 24;
        const int EXP_COLOR_SCROLLBAR = 25;
        const int EXP_COLOR_WINDOW = 26;
        const int EXP_COLOR_WINDOWFRAME = 27;
        const int EXP_COLOR_WINDOWTEXT = 28;
        const int EXP_GETTEXT = 29;
        const int EXP_GETTOOLTIPTEXT = 30;
        const int EXP_GETWIDTH = 31;
        const int EXP_GETHEIGHT = 32;
        const int EXP_COLOR_HYPERLINK = 33;
        const int EXP_GETX = 34;
        const int EXP_GETY = 35;
        const int EXP_SYSTORGB = 36;

        static short HOF_TRUEEVENT = 0x0002;

        const int CND_CLICKED = 0;
        const int CND_ENABLED = 1;
        const int CND_CHECKED = 2;
        const int CND_LEFTCLICK = 3;
        const int CND_RIGHTCLICK = 4;
        const int CND_MOUSEOVER = 5;
        const int CND_IMAGESHOWN = 6;
        const int CND_DOCKED = 7;

        public static bool bSysColorTab = false;
        const int COLOR_GRADIENTINACTIVECAPTION = 25;//28;
        public static int[] sysColorTab = null;
        const int DOCK_LEFT = 0x00000001;
        const int DOCK_RIGHT = 0x00000002;
        const int DOCK_TOP = 0x00000004;
        const int DOCK_BOTTOM = 0x00000008;
        const int DOCK_FLAGS = (DOCK_LEFT | DOCK_RIGHT | DOCK_TOP | DOCK_BOTTOM);
        CFontInfo wFont;
        int dwRtFlags;
        String pText;
        String pToolTip;
        //    int	httX;
        //    int	ttY;
        int rNumInObjList;		// Index of this object in objects list
        int rNumInContList;		// Index of this object in container list
        public int rContNum;			// Index of the container of this object in container list
        public short rContDx;			// Coordinates
        public short rContDy;
        int rClickCount;
        public int rData1_dwVersion;
        public int rData1_dwUnderlinedColor;
        public int rData_dwFlags;
        public int rData_fillColor;
        public int rData_borderColor1;
        public int rData_borderColor2;
        public CImage rData_wImage;
        public int rData_wFree;
        public int rData_textColor;
        public int rData_textMarginLeft;
        public int rData_textMarginTop;
        public int rData_textMarginRight;
        public int rData_textMarginBottom;
        CLayer pLayer;
        Rectangle tempRect = new Rectangle();
        public bool bToDisplay;

        public override int getNumberOfConditions()
        {
            return 8;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            CRun fprh = ho.hoAdRunHeader;

            // Get FrameData        
            KcBoxBFrameData pData = null;
            CExtStorage pExtData = fprh.getStorage(ho.hoIdentifier);
            if (pExtData == null)
            {
                pData = new KcBoxBFrameData();
                fprh.addStorage(pData, ho.hoIdentifier);
            }
            else
            {
                pData = (KcBoxBFrameData)pExtData;
            }

            // Set up parameters
            ho.setX(cob.cobX);
            ho.setY(cob.cobY);
            ho.setWidth(file.readAShort());
            ho.setHeight(file.readAShort());
            pLayer = rh.rhFrame.layers[ho.hoLayer];

            // Copy CDATA (memcpy(&rdPtr->rData, &edPtr->eData, sizeof(CDATA));)
            this.rData_dwFlags = file.readAInt();
            this.rData_fillColor = file.readAInt();
            this.rData_borderColor1 = file.readAInt();
            this.rData_borderColor2 = file.readAInt();

            //file.skipBytes(2);
            short[] imageList = new short[1];
            imageList[0] = file.readAShort();
            if (imageList[0] != -1)
            {
                ho.loadImageList(imageList);
                this.rData_wImage = ho.getImage(imageList[0]);
            }

            this.rData_wFree = file.readAShort();
            this.rData_textColor = file.readAInt();
            this.rData_textMarginLeft = file.readAShort();
            this.rData_textMarginTop = file.readAShort();
            this.rData_textMarginRight = file.readAShort();
            this.rData_textMarginBottom = file.readAShort();

            // Init font
            this.wFont = new CFontInfo();

            CFontInfo textLf;
            if (ho.hoAdRunHeader.rhApp.bUnicode == false)
            {
                textLf = file.readLogFont16();
            }
            else
            {
                textLf = file.readLogFont();
            }
            if (textLf.lfFaceName != null)
            {
                this.wFont = textLf;//this.wFont.font = textLf.createFont();
            }

            // Copy text
            this.dwRtFlags = 0;
            this.pText = "";
            this.pToolTip = "";
            file.readAString(40);
            file.adjustTo8();
            int textSize = file.readAInt();
            if (ho.hoAdRunHeader.rhApp.bUnicode)
            {
                textSize = textSize / 2;
            }
            if (textSize != 0)
            {
                // Extract tool tip
                String lText = file.readAString(textSize);//file.readString();
                textSize = lText.Length;
                for (int i = textSize; i > 1; i--)
                {
                    if ((lText[i - 1] == 'n') && (lText[i - 2] == '\\'))
                    {
                        int toolTipSize = textSize - i;
                        textSize = textSize - toolTipSize - 2;
                        if (toolTipSize != 0)
                        {
                            this.pToolTip = lText.Substring(i);
                        }
                        lText = lText.Substring(0, textSize);
                        break;
                    }
                }
                if (textSize != 0)
                {
                    this.pText = lText;
                }
            }

            // Add to global list of objects
            this.rNumInObjList = pData.AddObject(this); //up to here

            // Container?
            this.rNumInContList = -1;
            if ((this.rData_dwFlags & FLAG_CONTAINER) != 0)
            {
                this.rNumInContList = pData.AddContainer(this);
            }

            // Contained?
            this.rContNum = -1;
            if ((this.rData_dwFlags & FLAG_CONTAINED) != 0)
            {
                this.rContNum = pData.GetContainer(this);
                if (this.rContNum != -1)
                {
                    CRunKcBoxB rdPtrCont = (CRunKcBoxB)pData.pContainers.get(this.rContNum);
                    this.rContDx = (short)(ho.getX() - rdPtrCont.ho.getX());
                    this.rContDy = (short)(ho.getY() - rdPtrCont.ho.getY());
                }
            }
            this.rData1_dwVersion = file.readAInt();
            this.rData1_dwUnderlinedColor = file.readAInt();

            bToDisplay = true;

            // Tool tip
            //CreateToolTip(rdPtr);

            // Command ID
            //this.nCommandID = 0;

            fprh.delStorage(ho.hoIdentifier);
            fprh.addStorage(pData, ho.hoIdentifier);

            return false;
        }

        public override void destroyRunObject(bool bFast)
        {
            CRun rhPtr = this.ho.hoAdRunHeader;

            // Get FrameData
            KcBoxBFrameData pData = (KcBoxBFrameData)(rhPtr.getStorage(ho.hoIdentifier));

            // Container?
            if ((rNumInContList != -1) && (pData != null))
            {
                pData.RemoveContainer(this);
            }

            // Remove from global list of objects
            if ((rNumInObjList != -1) && (pData != null))
            {
                pData.RemoveObjectFromList(this);
            }
            rhPtr.delStorage(ho.hoIdentifier);
            if (pData.IsEmpty() == false)
            {
                rhPtr.addStorage(pData, ho.hoIdentifier);
            }
        }

        public override int handleRunObject()
        {
            CRun rhPtr = this.ho.hoAdRunHeader;

            KcBoxBFrameData pData = (KcBoxBFrameData)(rhPtr.getStorage(ho.hoIdentifier));
            int oldX = ho.getX();
            int oldY = ho.getY();
            int newX = oldX;
            int newY = oldY;
            int reCode = 0;

            // Docking
            if ((this.dwRtFlags & DOCK_FLAGS) != 0 && (this.rData_dwFlags & FLAG_CONTAINED) == 0)
            {
                int windowWidth = rhPtr.rhApp.gaCxWin;
                int windowHeight = rhPtr.rhApp.gaCyWin;
                int x = 0;
                int y = 0;
                int w = rhPtr.rhApp.gaCxWin;
                int h = rhPtr.rhApp.gaCyWin;
                // Dock
                if ((this.dwRtFlags & DOCK_LEFT) != 0)
                {
                    if (windowWidth > w)
                    {
                        newX = rh.rhFrame.leX + Math.Abs(x) - (windowWidth - w) / 2;
                    }
                    else
                    {
                        newX = rh.rhFrame.leX + Math.Abs(x);
                    }
                }
                if ((this.dwRtFlags & DOCK_RIGHT) != 0)
                {
                    if (windowWidth > w)
                    {
                        newX = rh.rhFrame.leX + Math.Abs(x) + w - ho.getWidth() - (windowWidth - w) / 2;
                    }
                    else
                    {
                        newX = rh.rhFrame.leX + Math.Abs(x) + w - ho.getWidth();
                    }
                }
                if ((this.dwRtFlags & DOCK_TOP) != 0)
                {
                    if (windowHeight > h)
                    {
                        newY = rh.rhFrame.leY + Math.Abs(y) - (windowHeight - h) / 2;
                    }
                    else
                    {
                        newY = rh.rhFrame.leY + Math.Abs(y);
                    }
                }
                if ((this.dwRtFlags & DOCK_BOTTOM) != 0)
                {
                    if (windowHeight > h)
                    {
                        newY = rh.rhFrame.leY + Math.Abs(y) + h - ho.getHeight() - (windowHeight - h) / 2;
                    }
                    else
                    {
                        newY = rh.rhFrame.leY - Math.Abs(y) + h - ho.getHeight(); //requires - here for some reason.
                    }
                }
            }

            CRunKcBoxB rdPtrCont;
            // Contained ? must update coordinates
            if ((this.rData_dwFlags & FLAG_CONTAINED) != 0)
            {
                // Not yet a container? search Medor, search!
                if (this.rContNum == -1)
                {
                    if (pData != null)
                    {
                        this.rContNum = pData.GetContainer(this);
                        if (this.rContNum != -1)
                        {
                            rdPtrCont = (CRunKcBoxB)(pData.pContainers.get(this.rContNum));
                            this.rContDx = (short)(ho.getX() - rdPtrCont.ho.getX());
                            this.rContDy = (short)(ho.getY() - rdPtrCont.ho.getY());
                        }
                    }
                }

                if ((this.rContNum != -1) && (pData != null) && (this.rContNum < pData.pContainers.size()))
                {
                    rdPtrCont = (CRunKcBoxB)(pData.pContainers.get(this.rContNum));
                    if (rdPtrCont != null)
                    {
                        newX = rdPtrCont.ho.getX() + this.rContDx;
                        newY = rdPtrCont.ho.getY() + this.rContDy;
                    }
                }
            }

            if ((newX != oldX) || (newY != oldY))
            {
                ho.setX(newX);
                ho.setY(newY);

                // Update tooltip position
                //UpdateToolTipRect(rdPtr);

                reCode = REFLAG_DISPLAY;
            }

            // Moved by Set X/Y Coordinate function? Update tooltip position
            //        if (((this.ttX != -1) && (this.ttY != -1)) && 
            //            ((this.ttX != ho.getX() - rhPtr.rhWindowX) || (this.ttY != ho.getY() - rhPtr.rhWindowY)))
            //        {
            //            UpdateToolTipRect(rdPtr);
            //        }
            if (bToDisplay)
            {
                bToDisplay = false;
                reCode = REFLAG_DISPLAY;
            }
            return reCode;	// REFLAG_ONESHOT+REFLAG_DISPLAY;	
        }

        public override void displayRunObject(SpriteBatchEffect batch)
        {
            // Get rhPtr
            CRun rhPtr = ho.hoAdRunHeader;

            CRect rc = new CRect();

            rc.left = ho.hoX - ho.hoAdRunHeader.rhWindowX + pLayer.x + ho.hoAdRunHeader.rhApp.xOffset;
            rc.top = ho.hoY - ho.hoAdRunHeader.rhWindowY + pLayer.y + ho.hoAdRunHeader.rhApp.yOffset;
            rc.right = rc.left + ho.hoImgWidth;
            rc.bottom = rc.top + ho.hoImgHeight;

            CFontInfo hFn = this.wFont;
            DisplayObject(batch, rc, this.pText, hFn);
        }

        public void BuildSysColorTable()
        {
            sysColorTab = new int[COLOR_GRADIENTINACTIVECAPTION];
            sysColorTab[0] = 0xc8c8c8;
            sysColorTab[1] = 0x000000;
            sysColorTab[2] = 0x99b4d1;
            sysColorTab[3] = 0xbfcddb;//SystemColor.activeCaptionBorder;
            sysColorTab[4] = 0xf0f0f0;
            sysColorTab[5] = 0xffffff;
            sysColorTab[6] = 0x646464;//SystemColor.inactiveCaptionBorder;
            sysColorTab[7] = 0x000000;
            sysColorTab[8] = 0x000000;
            sysColorTab[9] = 0x000000;
            sysColorTab[10] = 0xb4b4b4;//new
            sysColorTab[11] = 0xf4f7fc;//new
            sysColorTab[12] = 0xababab;//mdi one, doesn't quite match. There is no java mdi background colour./ AppWorksapce
            sysColorTab[13] = 0x3399ff;//SystemColor.textText;
            sysColorTab[14] = 0xffffff; //new //SystemColor.textHighlight;
            sysColorTab[15] = 0xf0f0f0;//SystemColor.textHighlightText;
            sysColorTab[16] = 0xa0a0a0;//SystemColor.textInactiveText;
            sysColorTab[17] = 0x808080;
            sysColorTab[18] = 0x000000;
            sysColorTab[19] = 0x434e54;
            sysColorTab[20] = 0xffffff;
            sysColorTab[21] = 0x696969;
            sysColorTab[22] = 0xe3e3e3;
            sysColorTab[23] = 0x000000;
            sysColorTab[24] = 0xffffe1;
        }

        public int myGetSysColor(int colorIndex)
        {
            // Build table
            if (!bSysColorTab)
            {
                BuildSysColorTable();
                bSysColorTab = true;
            }

            // Get color
            if (colorIndex < COLOR_GRADIENTINACTIVECAPTION)
            {
                return sysColorTab[colorIndex];
            }

            // Unknown color
            //return GetSysColor(colorIndex);
            return 0;
        }

        public int fromC(int c) //convert from c++ colour to java
        {
            int r = c & 0x0000FF;
            int g = (c & 0x00FF00) >> 8;
            int b = (c & 0xFF0000) >> 16;
            return (r << 16) | (g << 8) | b;
        }

        public void DisplayObject(SpriteBatchEffect batch, CRect rc, String pText, CFontInfo hFnt)
        {
            CRunApp app = ho.hoAdRunHeader.rhApp;

            int x = rc.left;
            int y = rc.top;
            int w = rc.right - rc.left;
            int h = rc.bottom - rc.top;

            // Background
            int color;
            int clr;
            if (rData_fillColor != COLOR_NONE)
            {
                clr = rData_fillColor;
                if ((clr & COLORFLAG_RGB) != 0)
                {
                    color = clr & ~COLOR_FLAGS;
                    color = fromC(color);
                }
                else
                {
                    color = myGetSysColor(clr);
                }
                app.services.fillRect(batch, rc, color, CSpriteGen.BOP_COPY, 0);
            }

            // Image
            if ((rData_wImage != null))
            {
                if (((rData_dwFlags & FLAG_HIDEIMAGE) == 0))
                {
                    int xc, yc, wc, hc;
                    xc = x;
                    wc = w;
                    yc = y;
                    hc = h;
                    if (wc > 0 && hc > 0)
                    {
                        if ((rData_dwFlags & ALIGN_IMAGE_TOPLEFT) != 0)
                        {
                            tempRect.X = x;
                            tempRect.Y = y;
                        }
                        else if ((rData_dwFlags & ALIGN_IMAGE_CENTER) != 0)
                        {
                            tempRect.X = x + (w - this.rData_wImage.width) / 2;
                            tempRect.Y = y + (h - this.rData_wImage.height) / 2;
                        }
                        if ((rData_dwFlags & ALIGN_IMAGE_PATTERN) != 0)
                        {
                            ho.hoAdRunHeader.rhApp.services.drawPatternRectangle(batch, rData_wImage, xc, yc, wc, hc, 0, 0, CSpriteGen.BOP_COPY, 0);
                        }
                        else
                        {
                            tempRect.Width = rData_wImage.width;
                            tempRect.Height = rData_wImage.height;
                            Texture2D texture = rData_wImage.image;
                            Nullable<Rectangle> sourceRect = null;
                            if (rData_wImage.mosaic != 0)
                            {
                                texture = app.imageBank.mosaics[rData_wImage.mosaic];
                                sourceRect = rData_wImage.mosaicRectangle;
                            }
                            batch.Draw(rData_wImage.image, tempRect, sourceRect, Color.White);
                        }
                    }
                    rData_dwFlags &= ~FLAG_FORCECLIPPING;
                }
            }

            // Text
            if ((pText.Length != 0) && (rData_textColor != COLOR_NONE))
            {
                CRect textLocation = new CRect();
                textLocation.left = rc.left + rData_textMarginLeft;
                textLocation.top = rc.top + rData_textMarginTop;
                textLocation.right = rc.right - rData_textMarginRight;
                textLocation.bottom = rc.bottom - rData_textMarginBottom;

                if ((rData_dwFlags & FLAG_DISABLED) != 0)
                {
                    clr = myGetSysColor(20);		// SystemColor.controlLtHighlight;
                    textLocation.left++;
                    textLocation.top++;
                    textLocation.right++;
                    textLocation.bottom++;
                    drawText(batch, pText, textLocation, hFnt, rData_dwFlags, false, clr);
                }
                else
                {
                    clr = rData_textColor;
                    bool hyperlink = false;
                    if ((clr & COLORFLAG_RGB) != 0)
                    {
                        clr &= ~COLOR_FLAGS;
                        clr = fromC(clr);
                    }
                    else
                    {
                        clr = myGetSysColor(clr);
                    }
                    drawText(batch, pText, textLocation, hFnt, rData_dwFlags, hyperlink, clr);
                }
            }

            // Border
            int color1 = rData_borderColor1;
            int color2 = rData_borderColor2;
            bool bDisplayBorder = true;
            if (bDisplayBorder == true)
            {
                if (color1 != COLOR_NONE)
                {
                    if ((color1 & COLORFLAG_RGB) != 0)
                    {
                        color1 &= ~COLOR_FLAGS;
                        color1 = fromC(color1);
                    }
                    else
                    {
                        color1 = myGetSysColor(color1);
                    }
                    app.services.drawLine(app.spriteBatch, x, y, x + w - 1, y, color1, 1, CSpriteGen.BOP_COPY, 0);
                    app.services.drawLine(app.spriteBatch, x, y, x, y + h - 1, color1, 1, CSpriteGen.BOP_COPY, 0);
                }
                if (color2 != COLOR_NONE)
                {
                    if ((color2 & COLORFLAG_RGB) != 0)
                    {
                        color2 &= ~COLOR_FLAGS;
                        color2 = fromC(color2);
                    }
                    else
                    {
                        color2 = myGetSysColor(color2);
                    }
                    app.services.drawLine(app.spriteBatch, x, y + h - 1, x + w - 1, y + h - 1, color2, 1, CSpriteGen.BOP_COPY, 0);
                    app.services.drawLine(app.spriteBatch, x + w - 1, y, x + w - 1, y + h - 1, color2, 1, CSpriteGen.BOP_COPY, 0);
                }
            }
        }

        public void drawText(SpriteBatchEffect batch, string text, CRect textLocation, CFontInfo font, int flags, bool hyperlink, int clr)
        {
            short dtFlags = 0;
            if ((rData_dwFlags & ALIGN_LEFT) != 0)
            {
                dtFlags |= CServices.DT_LEFT;
            }
            if ((rData_dwFlags & ALIGN_HCENTER) != 0)
            {
                dtFlags |= CServices.DT_CENTER;
            }
            if ((rData_dwFlags & ALIGN_RIGHT) != 0)
            {
                dtFlags |= CServices.DT_RIGHT;
            }
            if ((rData_dwFlags & ALIGN_VCENTER) != 0)
            {
                dtFlags |= CServices.DT_VCENTER;
            }
            if ((rData_dwFlags & ALIGN_BOTTOM) != 0)
            {
                dtFlags |= CServices.DT_BOTTOM;
            }

            if ((rData_dwFlags & ALIGN_MULTILINE) == 0)
            {
            }
            else
            {
                dtFlags |= CServices.DT_SINGLELINE;
            }

            if ((rData_dwFlags & ALIGN_NOPREFIX) == 0)
            {
                int n;
                string temp;
                for (n = 0; n < text.Length; n++)
                {
                    if (text[n] == '&')
                    {
                        temp = text.Substring(0, n) + text.Substring(n + 1);
                        if (temp.Length > n && temp[n] == '&')
                        {
                            n++;
                        }
                        text = temp;
                    }
                }
            }
            CFont cFont = CFont.createFromFontInfo(font, ho.hoAdRunHeader.rhApp);
            CServices.drawText(batch, text, dtFlags, textLocation, clr, cFont, 0, 0);
        }

	    public override CFontInfo getRunObjectFont()
	    {
	        return this.wFont;
	    }
	
	    public override void setRunObjectFont(CFontInfo fi, CRect rc)
	    {
	        this.wFont = fi;
	
	        if (rc != null)
	        {
	            ho.setWidth(rc.right);
	            ho.setHeight(rc.bottom);
	        }
	        bToDisplay=true;
	    }
	
	    public override int getRunObjectTextColor()
	    {
	        int clr= this.rData_textColor;
	        if ((clr & COLORFLAG_RGB) != 0)
	        {
	            clr&=~COLORFLAG_RGB;
	            return CServices.swapRGB(clr);
	        }
	        return myGetSysColor(clr);
	    }
	
	    public override void setRunObjectTextColor(int rgb)
	    {
	        this.rData_textColor = CServices.swapRGB(rgb)|COLORFLAG_RGB;
	        bToDisplay=true;
	    }

        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_ENABLED:
                    return IsEnabled();
                case CND_MOUSEOVER:
                    return MouseOver();
                case CND_IMAGESHOWN:
                    return IsImageShown();
            }
            return false;
        }

        private bool IsClicked()
        {
            CRun rhPtr = ho.hoAdRunHeader;
            if (rClickCount == -1)
            {
                return false;
            }
            if ((ho.hoFlags & HOF_TRUEEVENT) != 0)
            {
                return true;
            }
            if (rhPtr.rh4EventCount == rClickCount)
            {
                return true;
            }
            return false;
        }

        private bool IsEnabled()
        {
            return ((rData_dwFlags & CRunKcBoxB.FLAG_DISABLED) == 0);
        }

        private bool MouseOver()
        {
            CRun rhPtr = ho.hoAdRunHeader;
            KcBoxBFrameData pData = (KcBoxBFrameData)rhPtr.getStorage(ho.hoIdentifier);
            if (pData != null)
            {
                return (rNumInObjList == pData.GetObjectFromList(rh.rh2MouseX, rh.rh2MouseY));
            }
            return false;
        }

        private bool IsImageShown()
        {
            return ((rData_dwFlags & CRunKcBoxB.FLAG_HIDEIMAGE) == 0);
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_ACTION_SETDIM:
                    SetDimensions(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case ACT_ACTION_SETPOS:
                    SetPosition(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case ACT_ACTION_ENABLE:
                    Enable();
                    break;
                case ACT_ACTION_DISABLE:
                    Disable();
                    break;
                case ACT_ACTION_SETCOLOR_NONE:
                    SetFillColor_None();
                    break;
                case ACT_ACTION_SETCOLOR_3DDKSHADOW:
                    SetFillColor_3DDKSHADOW();
                    break;
                case ACT_ACTION_SETCOLOR_3DFACE:
                    SetFillColor_3DFACE();
                    break;
                case ACT_ACTION_SETCOLOR_3DHILIGHT:
                    SetFillColor_3DHIGHLIGHT();
                    break;
                case ACT_ACTION_SETCOLOR_3DLIGHT:
                    SetFillColor_3DLIGHT();
                    break;
                case ACT_ACTION_SETCOLOR_3DSHADOW:
                    SetFillColor_3DSHADOW();
                    break;
                case ACT_ACTION_SETCOLOR_ACTIVECAPTION:
                    SetFillColor_ACTIVECAPTION();
                    break;
                case ACT_ACTION_SETCOLOR_APPWORKSPACE:
                    SetFillColor_APPWORKSPACE();
                    break;
                case ACT_ACTION_SETCOLOR_DESKTOP:
                    SetFillColor_DESKTOP();
                    break;
                case ACT_ACTION_SETCOLOR_HIGHLIGHT:
                    SetFillColor_HIGHLIGHT();
                    break;
                case ACT_ACTION_SETCOLOR_INACTIVECAPTION:
                    SetFillColor_INACTIVECAPTION();
                    break;
                case ACT_ACTION_SETCOLOR_INFOBK:
                    SetFillColor_INFOBK();
                    break;
                case ACT_ACTION_SETCOLOR_MENU:
                    SetFillColor_MENU();
                    break;
                case ACT_ACTION_SETCOLOR_SCROLLBAR:
                    SetFillColor_SCROLLBAR();
                    break;
                case ACT_ACTION_SETCOLOR_WINDOW:
                    SetFillColor_WINDOW();
                    break;
                case ACT_ACTION_SETCOLOR_WINDOWFRAME:
                    SetFillColor_WINDOWFRAME();
                    break;
                case ACT_ACTION_SETCOLOR_OTHER:
                    SetFillColor_Other(act.getParamExpression(rh, 0));
                    break;
                case ACT_ACTION_SETB1COLOR_NONE:
                    SetB1Color_None();
                    break;
                case ACT_ACTION_SETB1COLOR_3DDKSHADOW:
                    SetB1Color_3DDKSHADOW();
                    break;
                case ACT_ACTION_SETB1COLOR_3DFACE:
                    SetB1Color_3DFACE();
                    break;
                case ACT_ACTION_SETB1COLOR_3DHILIGHT:
                    SetB1Color_3DHIGHLIGHT();
                    break;
                case ACT_ACTION_SETB1COLOR_3DSHADOW:
                    SetB1Color_3DSHADOW();
                    break;
                case ACT_ACTION_SETB1COLOR_ACTIVEBORDER:
                    SetB1Color_ACTIVEBORDER();
                    break;
                case ACT_ACTION_SETB1COLOR_INACTIVEBORDER:
                    SetB1Color_INACTIVEBORDER();
                    break;
                case ACT_ACTION_SETB1COLOR_WINDOWFRAME:
                    SetB1Color_WINDOWFRAME();
                    break;
                case ACT_ACTION_SETB1COLOR_OTHER:
                    SetB1Color_Other(act.getParamExpression(rh, 0));
                    break;
                case ACT_ACTION_SETB2COLOR_NONE:
                    SetB2Color_None();
                    break;
                case ACT_ACTION_SETB2COLOR_3DDKSHADOW:
                    SetB2Color_3DDKSHADOW();
                    break;
                case ACT_ACTION_SETB2COLOR_3DFACE:
                    SetB2Color_3DFACE();
                    break;
                case ACT_ACTION_SETB2COLOR_3DHILIGHT:
                    SetB2Color_3DHIGHLIGHT();
                    break;
                case ACT_ACTION_SETB2COLOR_3DLIGHT:
                    SetB2Color_3DLIGHT();
                    break;
                case ACT_ACTION_SETB2COLOR_3DSHADOW:
                    SetB2Color_3DSHADOW();
                    break;
                case ACT_ACTION_SETB2COLOR_ACTIVEBORDER:
                    SetB2Color_ACTIVEBORDER();
                    break;
                case ACT_ACTION_SETB2COLOR_INACTIVEBORDER:
                    SetB2Color_INACTIVEBORDER();
                    break;
                case ACT_ACTION_SETB2COLOR_WINDOWFRAME:
                    SetB2Color_WINDOWFRAME();
                    break;
                case ACT_ACTION_SETB2COLOR_OTHER:
                    SetB2Color_Other(act.getParamExpression(rh, 0));
                    break;
                case ACT_ACTION_TEXTCOLOR_NONE:
                    SetTxtColor_None();
                    break;
                case ACT_ACTION_TEXTCOLOR_3DHILIGHT:
                    SetTxtColor_3DHIGHLIGHT();
                    break;
                case ACT_ACTION_TEXTCOLOR_3DSHADOW:
                    SetTxtColor_3DSHADOW();
                    break;
                case ACT_ACTION_TEXTCOLOR_BTNTEXT:
                    SetTxtColor_BTNTEXT();
                    break;
                case ACT_ACTION_TEXTCOLOR_CAPTIONTEXT:
                    SetTxtColor_CAPTIONTEXT();
                    break;
                case ACT_ACTION_TEXTCOLOR_GRAYTEXT:
                    SetTxtColor_GRAYTEXT();
                    break;
                case ACT_ACTION_TEXTCOLOR_HIGHLIGHTTEXT:
                    SetTxtColor_HIGHLIGHTTEXT();
                    break;
                case ACT_ACTION_TEXTCOLOR_INACTIVECAPTIONTEXT:
                    SetTxtColor_INACTIVECAPTIONTEXT();
                    break;
                case ACT_ACTION_TEXTCOLOR_INFOTEXT:
                    SetTxtColor_INFOTEXT();
                    break;
                case ACT_ACTION_TEXTCOLOR_MENUTEXT:
                    SetTxtColor_MENUTEXT();
                    break;
                case ACT_ACTION_TEXTCOLOR_WINDOWTEXT:
                    SetTxtColor_WINDOWTEXT();
                    break;
                case ACT_ACTION_TEXTCOLOR_OTHER:
                    SetTxtColor_Other(act.getParamExpression(rh, 0));
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_NONE:
                    SetHyperlinkColor_None();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_3DHILIGHT:
                    SetHyperlinkColor_3DHIGHLIGHT();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_3DSHADOW:
                    SetHyperlinkColor_3DSHADOW();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_BTNTEXT:
                    SetHyperlinkColor_BTNTEXT();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_CAPTIONTEXT:
                    SetHyperlinkColor_CAPTIONTEXT();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_GRAYTEXT:
                    SetHyperlinkColor_GRAYTEXT();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_HIGHLIGHTTEXT:
                    SetHyperlinkColor_HIGHLIGHTTEXT();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_INACTIVECAPTIONTEXT:
                    SetHyperlinkColor_INACTIVECAPTIONTEXT();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_INFOTEXT:
                    SetHyperlinkColor_INFOTEXT();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_MENUTEXT:
                    SetHyperlinkColor_MENUTEXT();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_WINDOWTEXT:
                    SetHyperlinkColor_WINDOWTEXT();
                    break;
                case ACT_ACTION_HYPERLINKCOLOR_OTHER:
                    SetHyperlinkColor_Other(act.getParamExpression(rh, 0));
                    break;
                case ACT_ACTION_SETTEXT:
                    SetText(act.getParamExpString(rh, 0));
                    break;
                case ACT_ACTION_SETTOOLTIPTEXT:
                    SetToolTipText(act.getParamExpString(rh, 0));
                    break;
                case ACT_ACTION_UNDOCK:
                    Undock();
                    break;
                case ACT_ACTION_DOCK_LEFT:
                    DockLeft();
                    break;
                case ACT_ACTION_DOCK_RIGHT:
                    DockRight();
                    break;
                case ACT_ACTION_DOCK_TOP:
                    DockTop();
                    break;
                case ACT_ACTION_DOCK_BOTTOM:
                    DockBottom();
                    break;
                case ACT_ACTION_SHOWIMAGE:
                    ShowImage();
                    break;
                case ACT_ACTION_HIDEIMAGE:
                    HideImage();
                    break;
            }

        }

        private void SetDimensions(int w, int h)
        {
            // Set dimensions
            if ((ho.getWidth() != w) || (ho.getHeight() != h))
            {
                ho.setWidth(w);//rdPtr->rHo.hoImgWidth = (short)p1;
                ho.setHeight(h);//rdPtr->rHo.hoImgHeight = (short)p2;

                // Update tooltip rectangle
                //UpdateToolTipRect(rdPtr);
                bToDisplay = true;
            }
        }

        private void SetPosition(int x, int y)
        {
            if ((ho.getX() != x) || (ho.getY() != y))
            {
                ho.setX(x);//rdPtr->rHo.hoX = (short)p1;
                ho.setY(y);//rdPtr->rHo.hoY = (short)p2;

                // Update tooltip position
                //UpdateToolTipRect(rdPtr);

                // Container ? must update coordinates of contained objects
                if ((rData_dwFlags & CRunKcBoxB.FLAG_CONTAINER) != 0)
                {
                    CRun rhPtr = ho.hoAdRunHeader;
                    // Get FrameData
                    KcBoxBFrameData pData = (KcBoxBFrameData)rhPtr.getStorage(ho.hoIdentifier);
                    if (pData != null)
                    {
                        pData.UpdateContainedPos();// = new CFrameData();
                        rhPtr.delStorage(ho.hoIdentifier);
                        rhPtr.addStorage(pData, ho.hoIdentifier);
                    }
                }
                bToDisplay = true;
            }
        }

        private void Enable()
        {
            if ((rData_dwFlags & CRunKcBoxB.FLAG_DISABLED) != 0)
            {
                rData_dwFlags &= ~CRunKcBoxB.FLAG_DISABLED;
                bToDisplay = true;
            }
        }

        private void Disable()
        {
            if ((rData_dwFlags & CRunKcBoxB.FLAG_DISABLED) == 0)
            {
                rData_dwFlags |= CRunKcBoxB.FLAG_DISABLED;
                bToDisplay = true;
            }
        }

        private void SetFillColor_None()
        {
            if (rData_fillColor != CRunKcBoxB.COLOR_NONE)
            {
                rData_fillColor = CRunKcBoxB.COLOR_NONE;
                bToDisplay = true;
            }
        }

        private void SetFillColor_3DDKSHADOW()
        {
            if (rData_fillColor != 21)
            {
                rData_fillColor = 21;
                bToDisplay = true;
            }
        }

        private void SetFillColor_3DFACE()
        {
            if (rData_fillColor != 15)
            {
                rData_fillColor = 15;
                bToDisplay = true;
            }
        }

        private void SetFillColor_3DHIGHLIGHT()
        {
            if (rData_fillColor != 20)
            {
                rData_fillColor = 20;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_3DLIGHT()
        {
            if (rData_fillColor != 22)
            {
                rData_fillColor = 22;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_3DSHADOW()
        {
            if (rData_fillColor != 16)
            {
                rData_fillColor = 16;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_ACTIVECAPTION()
        {
            if (rData_fillColor != 2)
            {
                rData_fillColor = 2;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_APPWORKSPACE()
        {
            if (rData_fillColor != 12)
            {
                rData_fillColor = 12;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_DESKTOP()
        {
            if (rData_fillColor != 1)
            {
                rData_fillColor = 1;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_HIGHLIGHT()
        {
            if (rData_fillColor != 13)
            {
                rData_fillColor = 13;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_INACTIVECAPTION()
        {
            if (rData_fillColor != 3)
            {
                rData_fillColor = 3;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_INFOBK()
        {
            if (rData_fillColor != 24)
            {
                rData_fillColor = 24;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_MENU()
        {
            if (rData_fillColor != 4)
            {
                rData_fillColor = 4;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_SCROLLBAR()
        {
            if (rData_fillColor != 0)
            {
                rData_fillColor = 0;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_WINDOW()
        {
            if (rData_fillColor != 5)
            {
                rData_fillColor = 5;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_WINDOWFRAME()
        {
            if (rData_fillColor != 6)
            {
                rData_fillColor = 6;
                bToDisplay = true;;
            }
        }

        private void SetFillColor_Other(int c)
        {
            if ((c & PARAMFLAG_SYSTEMCOLOR) != 0)
            {
                c &= 0xFFFF;
            }
            else
            {
                c |= CRunKcBoxB.COLORFLAG_RGB;
            }
            if (rData_fillColor != c)
            {
                rData_fillColor = c;
                bToDisplay = true;;
            }
        }

        private void SetB1Color_None()
        {
            if (rData_borderColor1 != CRunKcBoxB.COLOR_NONE)
            {
                rData_borderColor1 = CRunKcBoxB.COLOR_NONE;
                bToDisplay = true;;
            }
        }

        private void SetB1Color_3DDKSHADOW()
        {
            if (rData_borderColor1 != 21)
            {
                rData_borderColor1 = 21;
                bToDisplay = true;;
            }
        }

        private void SetB1Color_3DFACE()
        {
            if (rData_borderColor1 != 15)
            {
                rData_borderColor1 = 15;
                bToDisplay = true;;
            }
        }

        private void SetB1Color_3DHIGHLIGHT()
        {
            if (rData_borderColor1 != 20)
            {
                rData_borderColor1 = 20;
                bToDisplay = true;;
            }
        }

        private void SetB1Color_3DLIGHT()
        {
            if (rData_borderColor1 != 22)
            {
                rData_borderColor1 = 22;
                bToDisplay = true;;
            }
        }

        private void SetB1Color_3DSHADOW()
        {
            if (rData_borderColor1 != 16)
            {
                rData_borderColor1 = 16;
                bToDisplay = true;;
            }
        }

        private void SetB1Color_ACTIVEBORDER()
        {
            if (rData_borderColor1 != 10)
            {
                rData_borderColor1 = 10;
                bToDisplay = true;;
            }
        }

        private void SetB1Color_INACTIVEBORDER()
        {
            if (rData_borderColor1 != 11)
            {
                rData_borderColor1 = 11;
                bToDisplay = true;;
            }
        }

        private void SetB1Color_WINDOWFRAME()
        {
            if (rData_borderColor1 != 6)
            {
                rData_borderColor1 = 6;
                bToDisplay = true;;
            }
        }

        private void SetB1Color_Other(int c)
        {
            if ((c & PARAMFLAG_SYSTEMCOLOR) != 0)
            {
                c &= 0xFFFF;
            }
            else
            {
                c |= CRunKcBoxB.COLORFLAG_RGB;
            }
            if (rData_borderColor1 != c)
            {
                rData_borderColor1 = c;
                bToDisplay = true;;
            }
        }

        private void SetB2Color_None()
        {
            if (rData_borderColor2 != CRunKcBoxB.COLOR_NONE)
            {
                rData_borderColor2 = CRunKcBoxB.COLOR_NONE;
                bToDisplay = true;;
            }
        }

        private void SetB2Color_3DDKSHADOW()
        {
            if (rData_borderColor2 != 21)
            {
                rData_borderColor2 = 21;
                bToDisplay = true;;
            }
        }

        private void SetB2Color_3DFACE()
        {
            if (rData_borderColor2 != 15)
            {
                rData_borderColor2 = 15;
                bToDisplay = true;;
            }
        }

        private void SetB2Color_3DHIGHLIGHT()
        {
            if (rData_borderColor2 != 20)
            {
                rData_borderColor2 = 20;
                bToDisplay = true;;
            }
        }

        private void SetB2Color_3DLIGHT()
        {
            if (rData_borderColor2 != 22)
            {
                rData_borderColor2 = 22;
                bToDisplay = true;;
            }
        }

        private void SetB2Color_3DSHADOW()
        {
            if (rData_borderColor2 != 16)
            {
                rData_borderColor2 = 16;
                bToDisplay = true;;
            }
        }

        private void SetB2Color_ACTIVEBORDER()
        {
            if (rData_borderColor2 != 10)
            {
                rData_borderColor2 = 10;
                bToDisplay = true;;
            }
        }

        private void SetB2Color_INACTIVEBORDER()
        {
            if (rData_borderColor2 != 11)
            {
                rData_borderColor2 = 11;
                bToDisplay = true;;
            }
        }

        private void SetB2Color_WINDOWFRAME()
        {
            if (rData_borderColor2 != 6)
            {
                rData_borderColor2 = 6;
                bToDisplay = true;;
            }
        }

        private void SetB2Color_Other(int c)
        {
            if ((c & PARAMFLAG_SYSTEMCOLOR) != 0)
            {
                c &= 0xFFFF;
            }
            else
            {
                c |= CRunKcBoxB.COLORFLAG_RGB;
            }
            if (rData_borderColor2 != c)
            {
                rData_borderColor2 = c;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_None()
        {
            if (rData_textColor != CRunKcBoxB.COLOR_NONE)
            {
                rData_textColor = CRunKcBoxB.COLOR_NONE;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_3DHIGHLIGHT()
        {
            if (rData_textColor != 20)
            {
                rData_textColor = 20;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_3DSHADOW()
        {
            if (rData_textColor != 16)
            {
                rData_textColor = 16;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_BTNTEXT()
        {
            if (rData_textColor != 18)
            {
                rData_textColor = 18;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_CAPTIONTEXT()
        {
            if (rData_textColor != 9)
            {
                rData_textColor = 9;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_GRAYTEXT()
        {
            if (rData_textColor != 17)
            {
                rData_textColor = 17;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_HIGHLIGHTTEXT()
        {
            if (rData_textColor != 14)
            {
                rData_textColor = 14;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_INACTIVECAPTIONTEXT()
        {
            if (rData_textColor != 19)
            {
                rData_textColor = 19;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_INFOTEXT()
        {
            if (rData_textColor != 23)
            {
                rData_textColor = 23;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_MENUTEXT()
        {
            if (rData_textColor != 7)
            {
                rData_textColor = 7;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_WINDOWTEXT()
        {
            if (rData_textColor != 8)
            {
                rData_textColor = 8;
                bToDisplay = true;;
            }
        }

        private void SetTxtColor_Other(int c)
        {
            if ((c & PARAMFLAG_SYSTEMCOLOR) != 0)
            {
                c &= 0xFFFF;
            }
            else
            {
                c |= CRunKcBoxB.COLORFLAG_RGB;
            }
            if (rData_textColor != c)
            {
                rData_textColor = c;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_None()
        {
            if (rData1_dwUnderlinedColor != CRunKcBoxB.COLOR_NONE)
            {
                rData1_dwUnderlinedColor = CRunKcBoxB.COLOR_NONE;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_3DHIGHLIGHT()
        {
            if (rData1_dwUnderlinedColor != 20)
            {
                rData1_dwUnderlinedColor = 20;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_3DSHADOW()
        {
            if (rData1_dwUnderlinedColor != 16)
            {
                rData1_dwUnderlinedColor = 16;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_BTNTEXT()
        {
            if (rData1_dwUnderlinedColor != 18)
            {
                rData1_dwUnderlinedColor = 18;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_CAPTIONTEXT()
        {
            if (rData1_dwUnderlinedColor != 9)
            {
                rData1_dwUnderlinedColor = 9;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_GRAYTEXT()
        {
            if (rData1_dwUnderlinedColor != 17)
            {
                rData1_dwUnderlinedColor = 17;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_HIGHLIGHTTEXT()
        {
            if (rData1_dwUnderlinedColor != 14)
            {
                rData1_dwUnderlinedColor = 14;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_INACTIVECAPTIONTEXT()
        {
            if (rData1_dwUnderlinedColor != 19)
            {
                rData1_dwUnderlinedColor = 19;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_INFOTEXT()
        {
            if (rData1_dwUnderlinedColor != 23)
            {
                rData1_dwUnderlinedColor = 23;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_MENUTEXT()
        {
            if (rData1_dwUnderlinedColor != 7)
            {
                rData1_dwUnderlinedColor = 7;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_WINDOWTEXT()
        {
            if (rData1_dwUnderlinedColor != 8)
            {
                rData1_dwUnderlinedColor = 8;
                bToDisplay = true;;
            }
        }

        private void SetHyperlinkColor_Other(int c)
        {
            if ((c & PARAMFLAG_SYSTEMCOLOR) != 0)
            {
                c &= 0xFFFF;
            }
            else
            {
                c |= CRunKcBoxB.COLORFLAG_RGB;
            }
            if (rData1_dwUnderlinedColor != c)
            {
                rData1_dwUnderlinedColor = c;
                bToDisplay = true;;
            }
        }

        private void SetText(String s)
        {
            pText = s;
            bToDisplay = true;;
        }

        private void SetToolTipText(String s)
        {
        }

        private void Undock()
        {
            if ((dwRtFlags & CRunKcBoxB.DOCK_FLAGS) != 0)
            {
                dwRtFlags &= ~CRunKcBoxB.DOCK_FLAGS;
            }
        }

        private void DockLeft()
        {
            if ((dwRtFlags & CRunKcBoxB.DOCK_LEFT) == 0)
            {
                dwRtFlags |= CRunKcBoxB.DOCK_LEFT;
                ho.reHandle();
            }
        }

        private void DockRight()
        {
            if ((dwRtFlags & CRunKcBoxB.DOCK_RIGHT) == 0)
            {
                dwRtFlags |= CRunKcBoxB.DOCK_RIGHT;
                ho.reHandle();
            }
        }

        private void DockTop()
        {
            if ((dwRtFlags & CRunKcBoxB.DOCK_TOP) == 0)
            {
                dwRtFlags |= CRunKcBoxB.DOCK_TOP;
                ho.reHandle();
            }
        }

        private void DockBottom()
        {
            if ((dwRtFlags & CRunKcBoxB.DOCK_BOTTOM) == 0)
            {
                dwRtFlags |= CRunKcBoxB.DOCK_BOTTOM;
                ho.reHandle();
            }
        }

        private void ShowImage()
        {
            if ((rData_dwFlags & CRunKcBoxB.FLAG_HIDEIMAGE) != 0)
            {
                rData_dwFlags &= ~CRunKcBoxB.FLAG_HIDEIMAGE;
                bToDisplay = true;;
            }
        }

        private void HideImage()
        {
            if ((rData_dwFlags & CRunKcBoxB.FLAG_HIDEIMAGE) == 0)
            {
                rData_dwFlags |= CRunKcBoxB.FLAG_HIDEIMAGE;
                bToDisplay = true;;
            }
        }

        private void ResetClickState()
        {
            rClickCount = -1;
        }

        private void AttachMenuCmd()
        {
            //        LPEVP pp = (LPEVP)param1;
            //	rdPtr->nCommandID = pp->evp.evpL.evpL0;
            //	rClickCount = -1;
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_COLOR_BACKGROUND:
                    return ExpColorBackground();
                case EXP_COLOR_BORDER1:
                    return ExpColorBorder1();
                case EXP_COLOR_BORDER2:
                    return ExpColorBorder2();
                case EXP_COLOR_TEXT:
                    return ExpColorText();
                case EXP_COLOR_HYPERLINK:
                    return ExpColorHyperlink();
                case EXP_COLOR_3DDKSHADOW:
                    return ExpColor_3DDKSHADOW();
                case EXP_COLOR_3DFACE:
                    return ExpColor_3DFACE();
                case EXP_COLOR_3DHILIGHT:
                    return ExpColor_3DHILIGHT();
                case EXP_COLOR_3DLIGHT:
                    return ExpColor_3DLIGHT();
                case EXP_COLOR_3DSHADOW:
                    return ExpColor_3DSHADOW();
                case EXP_COLOR_ACTIVEBORDER:
                    return ExpColor_ACTIVEBORDER();
                case EXP_COLOR_ACTIVECAPTION:
                    return ExpColor_ACTIVECAPTION();
                case EXP_COLOR_APPWORKSPACE:
                    return ExpColor_APPWORKSPACE();
                case EXP_COLOR_DESKTOP:
                    return ExpColor_DESKTOP();
                case EXP_COLOR_BTNTEXT:
                    return ExpColor_BTNTEXT();
                case EXP_COLOR_CAPTIONTEXT:
                    return ExpColor_CAPTIONTEXT();
                case EXP_COLOR_GRAYTEXT:
                    return ExpColor_GRAYTEXT();
                case EXP_COLOR_HIGHLIGHT:
                    return ExpColor_HIGHLIGHT();
                case EXP_COLOR_HIGHLIGHTTEXT:
                    return ExpColor_HIGHLIGHTTEXT();
                case EXP_COLOR_INACTIVEBORDER:
                    return ExpColor_INACTIVEBORDER();
                case EXP_COLOR_INACTIVECAPTION:
                    return ExpColor_INACTIVECAPTION();
                case EXP_COLOR_INACTIVECAPTIONTEXT:
                    return ExpColor_INACTIVECAPTIONTEXT();
                case EXP_COLOR_INFOBK:
                    return ExpColor_INFOBK();
                case EXP_COLOR_INFOTEXT:
                    return ExpColor_INFOTEXT();
                case EXP_COLOR_MENU:
                    return ExpColor_MENU();
                case EXP_COLOR_MENUTEXT:
                    return ExpColor_MENUTEXT();
                case EXP_COLOR_SCROLLBAR:
                    return ExpColor_SCROLLBAR();
                case EXP_COLOR_WINDOW:
                    return ExpColor_WINDOW();
                case EXP_COLOR_WINDOWFRAME:
                    return ExpColor_WINDOWFRAME();
                case EXP_COLOR_WINDOWTEXT:
                    return ExpColor_WINDOWTEXT();
                case EXP_GETTEXT:
                    return ExpGetText();
                case EXP_GETTOOLTIPTEXT:
                    return ExpGetToolTipText();
                case EXP_GETWIDTH:
                    return ExpGetWidth();
                case EXP_GETHEIGHT:
                    return ExpGetHeight();
                case EXP_GETX:
                    return ExpGetX();
                case EXP_GETY:
                    return ExpGetY();
                case EXP_SYSTORGB:
                    return ExpSysToRGB();
            }
            return new CValue();
        }

        private CValue ExpColorBackground()
        {
            long clr = rData_fillColor;
            if ((clr & COLORFLAG_RGB) != 0)
            {
                clr &= 0xFFFFFF;
            }
            else
            {
                clr |= PARAMFLAG_SYSTEMCOLOR;
            }
            return new CValue((int)clr);
        }

        private CValue ExpColorBorder1()
        {
            long clr = rData_borderColor1;
            if ((clr & COLORFLAG_RGB) != 0)
            {
                clr &= 0xFFFFFF;
            }
            else
            {
                clr |= PARAMFLAG_SYSTEMCOLOR;
            }
            return new CValue((int)clr);
        }

        private CValue ExpColorBorder2()
        {
            long clr = rData_borderColor2;
            if ((clr & COLORFLAG_RGB) != 0)
            {
                clr &= 0xFFFFFF;
            }
            else
            {
                clr |= PARAMFLAG_SYSTEMCOLOR;
            }
            return new CValue((int)clr);
        }

        private CValue ExpColorText()
        {
            long clr = rData_textColor;
            if ((clr & COLORFLAG_RGB) != 0)
            {
                clr &= 0xFFFFFF;
            }
            else
            {
                clr |= PARAMFLAG_SYSTEMCOLOR;
            }
            return new CValue((int)clr);
        }

        private CValue ExpColorHyperlink()
        {
            long clr = rData1_dwUnderlinedColor;
            if ((clr & COLORFLAG_RGB) != 0)
            {
                clr &= 0xFFFFFF;
            }
            else
            {
                clr |= PARAMFLAG_SYSTEMCOLOR;
            }
            return new CValue((int)clr);
        }

        private CValue ExpColor_3DDKSHADOW()
        {
            return new CValue((int)(21 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_3DFACE()
        {
            return new CValue((int)(15 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_3DHILIGHT()
        {
            return new CValue((int)(20 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_3DLIGHT()
        {
            return new CValue((int)(22 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_3DSHADOW()
        {
            return new CValue((int)(16 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_ACTIVEBORDER()
        {
            return new CValue((int)(10 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_ACTIVECAPTION()
        {
            return new CValue((int)(2 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_APPWORKSPACE()
        {
            return new CValue((int)(12 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_DESKTOP()
        {
            return new CValue((int)(1 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_BTNTEXT()
        {
            return new CValue((int)(18 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_CAPTIONTEXT()
        {
            return new CValue((int)(9 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_GRAYTEXT()
        {
            return new CValue((int)(17 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_HIGHLIGHT()
        {
            return new CValue((int)(13 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_HIGHLIGHTTEXT()
        {
            return new CValue((int)(14 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_INACTIVEBORDER()
        {
            return new CValue((int)(11 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_INACTIVECAPTION()
        {
            return new CValue((int)(3 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_INACTIVECAPTIONTEXT()
        {
            return new CValue((int)(19 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_INFOBK()
        {
            return new CValue((int)(24 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_INFOTEXT()
        {
            return new CValue((int)(23 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_MENU()
        {
            return new CValue((int)(4 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_MENUTEXT()
        {
            return new CValue((int)(7 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_SCROLLBAR()
        {
            return new CValue((int)(0 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_WINDOW()
        {
            return new CValue((int)(5 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_WINDOWFRAME()
        {
            return new CValue((int)(6 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpColor_WINDOWTEXT()
        {
            return new CValue((int)(8 | CRunKcBoxB.PARAMFLAG_SYSTEMCOLOR));
        }

        private CValue ExpGetText()
        {
            return new CValue(pText);
        }

        private CValue ExpGetToolTipText()
        {
            return new CValue(pToolTip);
        }

        private CValue ExpGetWidth()
        {
            return new CValue(ho.getWidth());
        }

        private CValue ExpGetHeight()
        {
            return new CValue(ho.getHeight());
        }

        private CValue ExpGetX()
        {
            return new CValue(ho.getX());
        }

        private CValue ExpGetY()
        {
            return new CValue(ho.getY());
        }

        private CValue ExpSysToRGB()
        {
            int rgb;
            long paramColor = ho.getExpParam().getInt();//DWORD)CNC_GetFirstExpressionParameter(rdPtr, param1, TYPE_INT);

            if ((paramColor & PARAMFLAG_SYSTEMCOLOR) != 0)
            {
                int sc = (int)(paramColor & 0xFFFF);
                rgb = myGetSysColor(sc);
            }
            else
            {
                rgb = (int)(paramColor & 0xFFFFFF);
                rgb = fromC(rgb);
            }
            //int ii = rgb.getRGB();
            int r = CServices.getRValueJava(rgb);
            int g = CServices.getGValueJava(rgb);
            int b = CServices.getBValueJava(rgb);
            return new CValue(b * 65536 + g * 256 + r);
        }







    }

    class KcBoxBFrameData : CExtStorage
    {
        public int TYPE_OBJECT = 0;
        public int TYPE_CONTAINER = 1;
        public int TYPE_BUTTON = 2;
        public int FLAG_CONTAINED = 0x00002000;

        public CArrayList pObjects;
        public CArrayList pContainers;
        public CArrayList pButtons;

        //	    public int gClickedButton;
        //	    public int gHighlightedButton;

        public bool IsEmpty()
        {
            int i;
            if (pObjects != null)
            {
                for (i = 0; i < pObjects.size(); i++)
                {
                    if (pObjects.get(i) != null)
                    {
                        return false;
                    }
                }
            }
            if (pContainers != null)
            {
                for (i = 0; i < pContainers.size(); i++)
                {
                    if (pContainers.get(i) != null)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        public int AddObjAddr(int t, CRunKcBoxB reObject)
        {
            int i;
            if (t == TYPE_OBJECT)
            {
                // 1st allocation
                if (pObjects == null)
                {
                    pObjects = new CArrayList();
                    pObjects.add(reObject);
                    return 0;
                }
                // Search for free place
                for (i = 0; i < pObjects.size(); i++)
                {
                    if (pObjects.get(i) == null)
                    {
                        pObjects.set(i, reObject);
                        return i;
                    }
                }
                // Reallocation
                pObjects.add(reObject);
                return pObjects.size() - 1;
            }
            if (t == TYPE_CONTAINER)
            {
                if (pContainers == null)
                {
                    pContainers = new CArrayList();
                    pContainers.add(reObject);
                    return 0;
                }
                // Search for free place
                for (i = 0; i < pContainers.size(); i++)
                {
                    if (pContainers.get(i) == null)
                    {
                        pContainers.set(i, reObject);
                        return i;
                    }
                }
                // Reallocation
                pContainers.add(reObject);
                return pContainers.size() - 1;
            }
            if (t == TYPE_BUTTON)
            {
                if (pButtons == null)
                {
                    pButtons = new CArrayList();
                    pButtons.add(reObject);
                    return 0;
                }
                // Search for free place
                for (i = 0; i < pButtons.size(); i++)
                {
                    if (pButtons.get(i) == null)
                    {
                        pButtons.set(i, reObject);
                        return i;
                    }
                }
                // Reallocation
                pButtons.add(reObject);
                return pButtons.size() - 1;
            }
            return 0; //won't happen
        }
        // Remove object from list
        public void RemoveObjAddr(int t, CRunKcBoxB reObject)
        {
            int i;
            if (t == TYPE_OBJECT)
            {
                if (pObjects != null)
                {
                    i = pObjects.indexOf(reObject);
                    if (i != -1)
                    {
                        pObjects.set(i, null);
                    }
                }
            }
            if (t == TYPE_CONTAINER)
            {
                if (pContainers != null)
                {
                    i = pContainers.indexOf(reObject);
                    if (i != -1)
                    {
                        pContainers.set(i, null);
                    }
                }
            }
            if (t == TYPE_BUTTON)
            {
                if (pButtons != null)
                {
                    i = pButtons.indexOf(reObject);
                    if (i != -1)
                    {
                        pButtons.set(i, null);
                    }
                }
            }

        }

        // Add objects
        public int AddContainer(CRunKcBoxB re)
        {
            return AddObjAddr(TYPE_CONTAINER, re);
        }
        public int AddObject(CRunKcBoxB re)
        {
            return AddObjAddr(TYPE_OBJECT, re);
        }
        public int AddButton(CRunKcBoxB re)
        {
            return AddObjAddr(TYPE_BUTTON, re);
        }
        public void RemoveContainer(CRunKcBoxB re)
        {
            RemoveObjAddr(TYPE_CONTAINER, re);
        }
        public void RemoveObjectFromList(CRunKcBoxB re)
        {
            RemoveObjAddr(TYPE_OBJECT, re);
        }
        public void RemoveButton(CRunKcBoxB re)
        {
            RemoveObjAddr(TYPE_BUTTON, re);
        }
        // Get objects
        public int GetContainer(CRunKcBoxB re)
        {
            int left = re.ho.getX();
            int top = re.ho.getY();
            int right = re.ho.getX() + re.ho.getWidth();
            int bottom = re.ho.getY() + re.ho.getHeight();

            int i;
            if (this.pContainers != null)
            {
                for (i = 0; i < this.pContainers.size(); i++)
                {
                    if ((this.pContainers.get(i) != null) && (this.pContainers.get(i) != re))
                    {
                        CRunKcBoxB reThisOne = (CRunKcBoxB)(this.pContainers.get(i));
                        if ((left >= reThisOne.ho.getX()) &&
                                (right <= reThisOne.ho.getX() + reThisOne.ho.getWidth()) &&
                                (top >= reThisOne.ho.getY()) &&
                                (bottom <= reThisOne.ho.getY() + reThisOne.ho.getHeight()))
                        {
                            return i;
                        }
                    }
                }
            }
            return -1;
        }
        public int GetObjectFromList(int x, int y)
        {
            int r = -1;
            int i;
            if (this.pObjects != null)
            {
                for (i = this.pObjects.size() - 1; i >= 0; i--)
                {
                    if (this.pObjects.get(i) != null)
                    {
                        CRunKcBoxB reThisOne = (CRunKcBoxB)(this.pObjects.get(i));
                        CRun rhPtr = reThisOne.ho.hoAdRunHeader;
                        if ((x >= reThisOne.ho.getX() - rhPtr.rhWindowX) &&
                                 (x <= (reThisOne.ho.getX() - rhPtr.rhWindowX + reThisOne.ho.getWidth())) &&
                                 (y >= (reThisOne.ho.getY() - rhPtr.rhWindowY)) &&
                                 (y <= (reThisOne.ho.getY() - rhPtr.rhWindowY + reThisOne.ho.getHeight())))
                        {
                            r = i;
                            break;
                        }
                    }
                }
            }
            return r;
        }
        // Update position of contained objects
        public void UpdateContainedPos()
        {
            int i;
            CRunKcBoxB rdPtrCont;
            if (this.pObjects != null)
            {
                for (i = 0; i < this.pObjects.size(); i++)
                {
                    if (this.pObjects.get(i) != null)
                    {
                        CRunKcBoxB reThisOne = (CRunKcBoxB)(this.pObjects.get(i));
                        // Contained ? must update coordinates
                        if ((reThisOne.rData_dwFlags & FLAG_CONTAINED) != 0)
                        {
                            // Not yet a container? search Medor, search!
                            if (reThisOne.rContNum == -1)
                            {
                                reThisOne.rContNum = GetContainer(reThisOne);
                                if (reThisOne.rContNum != -1)
                                {
                                    rdPtrCont = (CRunKcBoxB)(this.pContainers.get(reThisOne.rContNum));
                                    reThisOne.rContDx = (short)(reThisOne.ho.getX() - rdPtrCont.ho.getX());
                                    reThisOne.rContDy = (short)(reThisOne.ho.getY() - rdPtrCont.ho.getY());
                                }
                            }

                            if ((reThisOne.rContNum != -1) && (reThisOne.rContNum < this.pContainers.size()))
                            {
                                rdPtrCont = (CRunKcBoxB)(this.pContainers.get(reThisOne.rContNum));
                                if (rdPtrCont != null)
                                {
                                    int newX = rdPtrCont.ho.getX() + reThisOne.rContDx;
                                    int newY = rdPtrCont.ho.getY() + reThisOne.rContDy;
                                    if ((newX != reThisOne.ho.getX()) || (newY != reThisOne.ho.getY()))
                                    {
                                        reThisOne.ho.setX(newX);
                                        reThisOne.ho.setY(newY);
                                        // Update tooltip position
                                        //UpdateToolTipRect(reThisOne);
                                        reThisOne.bToDisplay = true;;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
